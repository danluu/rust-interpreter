#!/usr/bin/env python3
"""Run only the two already-built real Trap scope tests; never build tools."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time

PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
OWNER = Path('/Users/danluu/dev/rust-interp-trap-span-remap-20260913')
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
sys.path.insert(0, str(PRIMARY / 'scripts'))
from build_custom_tools import source_identity
from compare_saved_runtime import acquire_lock
from custom_compiler import digest, file_digest, load_compiler, require, validate_tool_compiler
from interpreter import installed_tools
from std_mir_source_paths import load as load_std
from workflow_io import capture, write_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--compiler-key', required=True)
    parser.add_argument('--tool-key', required=True)
    parser.add_argument('--std-key', required=True)
    parser.add_argument('--workspace-result', type=Path, required=True)
    parser.add_argument('--test-executable', type=Path, required=True)
    parser.add_argument('--run-id', required=True)
    args = parser.parse_args()
    require(re.fullmatch('[a-z0-9-]+', args.run_id), 'invalid run name')
    work = OWNER / '.work' / args.run_id
    work.mkdir(exist_ok=False)
    result = dict(status='waiting', owner=str(OWNER), primary=str(PRIMARY), pid=os.getpid(),
        parent_pid=os.getppid(), command=sys.argv, cwd=os.getcwd(), started_at=time.time(),
        lock=str(LOCK), lock_wait_seconds=600, benchmark=False)
    write_json(work / 'result.json', result)
    try:
        require(LOCK.resolve(strict=True) == LOCK and LOCK.is_file(), 'canonical lock changed')
        with LOCK.open('r+') as lock:
            acquire_lock(lock, 600)
            result.update(status='admitted', admitted_at=time.time())
            write_json(work / 'result.json', result)
            compiler = load_compiler(PRIMARY, args.compiler_key)
            tools, key = installed_tools(args.tool_key)
            validate_tool_compiler(tools, key, compiler)
            composition = json.loads((tools / 'compiler.json').read_text())
            sources = source_identity()
            require(composition['source_files'] == sources, 'tool source bytes differ')
            prerequisite = json.loads(args.workspace_result.read_text())
            require(prerequisite['status'] == 'passed' and prerequisite['compiler_key'] == compiler.key
                and prerequisite['tool_key'] == key and prerequisite['frozen_sources_unchanged'] is True,
                'exact full workspace qualification did not pass')
            executable = args.test_executable.resolve(strict=True)
            target = PRIMARY / '.work/custom-interpreter-build' / compiler.key / 'release'
            workspace_stderr=args.workspace_result.parent/'workspace-tests.stderr'
            require(file_digest(workspace_stderr)==prerequisite['evidence_files']['workspace-tests.stderr'],
                'workspace command evidence changed')
            recorded=re.findall(r'Running tests/trap_span_remap.rs \(([^\n]+)\)',workspace_stderr.read_text())
            require(len(recorded)==1 and (PRIMARY/recorded[0]).resolve(strict=True)==executable
                and executable.is_relative_to(target) and executable.name.startswith('trap_span_remap-')
                and os.access(executable, os.X_OK), 'not the qualified owned test target')
            std, host, std_key, ready = load_std(PRIMARY, args.std_key, compiler, 'stable-mono-cgu:off', rehash=True)
            expected = ['crates/bytecode/tests/trap_span_remap.rs',
                'crates/bytecode/tests/fixtures/trap_span_remap_fixture.rs']
            require(all(file_digest(OWNER / p) == sources[p] for p in expected), 'fixture differs from reviewed source')
            # Preserve all currently imported source bytes and the complete
            # matching package source set, without copying compiler binaries.
            frozen = {str(PRIMARY / p): h for p, h in sources.items()}
            frozen.update({str(p.resolve()): file_digest(p) for p in (PRIMARY / 'scripts').glob('*.py')})
            frozen.update({str(Path(__file__).resolve()): file_digest(Path(__file__)),
                str(args.workspace_result.resolve()): file_digest(args.workspace_result),
                str(workspace_stderr.resolve()): file_digest(workspace_stderr),
                str(executable): file_digest(executable)})
            frozen.update({str(tools / p): file_digest(tools / p) for p in
                ['compiler.json', 'ready.json', 'capabilities.json']})
            native_files = {str(compiler.sysroot / p): h for p, h in compiler.identity['files'].items()}
            require(all(file_digest(Path(p)) == h for p,h in native_files.items()), 'compiler bytes differ')
            (work / 'sources').mkdir()
            for index,(path,hash_) in enumerate(sorted(frozen.items())):
                if Path(path) == executable:
                    continue
                payload=Path(path).read_bytes()
                require(hashlib.sha256(payload).hexdigest() == hash_, 'source changed while copying')
                (work/'sources'/f'{index:04}-{Path(path).name}').write_bytes(payload)
            artifacts=work/'artifacts'; artifacts.mkdir()
            environment={k:v for k,v in os.environ.items() if not k.startswith(('RUST_INTERP_', 'CARGO_PROFILE_'))
                and k not in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC','RUSTDOC','RUSTC_WRAPPER',
                    'RUSTC_WORKSPACE_WRAPPER','CARGO_TARGET_DIR','CARGO_BUILD_TARGET','CARGO_INCREMENTAL']}
            environment=compiler.environment(environment)
            environment.update(RUST_INTERP_TEST_EXPORTER=str(tools/'rust-interp-mir-export'),
                RUST_INTERP_TEST_RUSTC=str(compiler.rustc), RUST_INTERP_TEST_VM=str(tools/'rust-interp-vm'),
                RUST_INTERP_TEST_STD_SYSROOT=str(std), RUST_INTERP_TEST_ARTIFACT_DIR=str(artifacts),
                RUST_TEST_THREADS='1')
            command=[str(executable),'--ignored','--test-threads=1','--nocapture']
            write_json(work/'plan.json',dict(command=command,compiler_key=compiler.key,tool_key=key,
                std_key=std_key,namespace='stable-mono-cgu:off',compiler_identity=compiler.identity,
                tool_composition=composition,std_readiness=ready,source_files=frozen,
                native_files=native_files,environment_sha256=digest(environment),
                selected_environment={k:v for k,v in environment.items() if k.startswith(('RUST_INTERP_','LD_','DYLD_'))
                    or k in ['RUSTC','PATH','RUST_TEST_THREADS']},workspace_result=prerequisite))
            def guard(rehash=False):
                require(load_compiler(PRIMARY,compiler.key)==compiler,'compiler installation changed')
                installed_tools(key)
                require(source_identity()==sources,'compiler/tool source set changed')
                require(all(file_digest(Path(p))==h for p,h in frozen.items()),'frozen test/source bytes changed')
                require(load_std(PRIMARY,std_key,compiler,'stable-mono-cgu:off',rehash=rehash)[3]==ready,
                    'prepared metadata/source sysroot changed')
                if rehash:
                    require(all(file_digest(Path(p))==h for p,h in native_files.items()),'native compiler bytes changed')
            guard()
            child,stdout,stderr=capture(command,cwd=PRIMARY,env=environment,receipt_path=work/'test-process.json',
                receipt=dict(qualification='two real Trap remap regressions',compiler_key=compiler.key,tool_key=key))
            (work/'stdout').write_text(stdout); (work/'stderr').write_text(stderr)
            guard(rehash=True)
            require(child.returncode==0 and re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)
                == [('2','0','0')], 'targeted controls failed; preserve original result')
            counts={p.name:len(list(p.glob('command-*/receipt.json'))) for p in artifacts.iterdir()}
            require(counts=={'trap-artifact-scopes':67,'trap-uncalled-diagnostics':63},'unexpected qualification command count')
            result.update(status='passed',finished_at=time.time(),returncode=child.returncode,passed=2,
                compiler_key=compiler.key,tool_key=key,std_key=std_key,command_counts=counts,
                frozen_sources_unchanged=True,plan_sha256=file_digest(work/'plan.json'))
            write_json(work/'result.json',result)
    except BaseException as error:
        result.update(status='failed',finished_at=time.time(),error=repr(error))
        write_json(work/'result.json',result)
        raise


if __name__ == '__main__':
    main()
