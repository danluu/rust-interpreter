#!/usr/bin/env python3
"""Archive completed Trap controls without running a compiler or changing inputs."""
import fcntl
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile
import time

OWNER = Path('/Users/danluu/dev/rust-interp-trap-span-remap-20260913')
PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
OUT = OWNER / 'results/trap-span-remapping-controls-01'
RUN = OWNER / '.work/trap-span-archive-01'
TOOL = 'ee858a5c30c2052959de7e9e132a4e4f39cec9b38fa3fac85777cf69ee6d9f21'
OLD_TOOL = '06520b4012bea1469ad402232b008b21d2aae927ae551d9238a8a49760394608'
COMPILER = 'f9fb3e5f59b8567fffd32c936a9864d0baee77038574236710fbcec75a57d33f'
STD = '4634cc1a80d3698d0c2194cbac1e714596d3492d30e8ca4c030dc3c76ed517c0'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    RUN.mkdir(exist_ok=False)
    result = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
        started_at=time.time(), argv=sys.argv, cwd=os.getcwd(), lock=str(LOCK),
        lock_wait_seconds=600, workload='saved evidence archive only', benchmark=False)
    save(RUN / 'result.json', result)
    try:
        require(LOCK.resolve(strict=True) == LOCK, 'canonical lock changed')
        with LOCK.open('r+') as lock:
            deadline = time.monotonic() + 600
            while True:
                try:
                    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        raise TimeoutError('600-second archive admission expired before input reads')
                    time.sleep(.2)
            result.update(status='admitted', admitted_at=time.time())
            save(RUN / 'result.json', result)
            OUT.mkdir(parents=True, exist_ok=False)
            members = {}
            inputs = {}
            excluded = {}

            def take(path):
                path = Path(path)
                before = path.lstat()
                require(stat.S_ISREG(before.st_mode), 'indirect/nonregular input: ' + str(path))
                data = path.read_bytes()
                after = path.lstat()
                require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                    == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
                    'input changed during read: ' + str(path))
                inputs[str(path)] = dict(sha256=sha(data), size=len(data))
                return data

            def read_json(path):
                return json.loads(take(path))

            def add(path, name):
                data = take(path)
                # Fixture executable outputs and debug bundles stay in their
                # original private histories. Bytecode and metadata are retained.
                native = data[:4] in [b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xca\xfe\xba\xbe', b'\x7fELF']
                if native or Path(path).suffix in ['.native', '.o', '.rlib', '.dylib']:
                    excluded[str(path)] = dict(sha256=sha(data), size=len(data), reason='native binary')
                    return
                require(name not in members, 'duplicate archive name: ' + name)
                members[name] = data

            def tree(root, prefix):
                require(root.is_dir() and not root.is_symlink(), 'missing/direct tree: ' + str(root))
                for base, directories, files in os.walk(root, followlinks=False):
                    directories[:] = sorted(d for d in directories if not d.endswith('.dSYM'))
                    require(all(not (Path(base) / d).is_symlink() for d in directories), 'indirect directory')
                    for name in sorted(files):
                        path = Path(base) / name
                        add(path, prefix + '/' + str(path.relative_to(root)))

            first = OWNER / '.work/trap-span-controls-01'
            second = OWNER / '.work/trap-span-controls-02'
            initial = read_json(first / 'result.json')
            final = read_json(second / 'result.json')
            p1 = read_json(first / 'plan.json')
            p2 = read_json(second / 'plan.json')
            require(initial['status'] == 'failed', 'original attempt must remain failed')
            require(final['status'] == 'passed' and final['passed'] == 1
                and final['reused_passing_scope_test'] is True and final['prior_attempt_remains_failed'] is True
                and final['frozen_sources_unchanged'] is True and final['command_counts'] == {'trap-uncalled-diagnostics': 63},
                'final corrected diagnostic qualification differs')
            require(final['tool_key'] == TOOL and final['compiler_key'] == COMPILER and final['std_key'] == STD,
                'wrong final association')
            require(sha(take(second / 'plan.json')) == final['plan_sha256'], 'final plan hash differs')
            require(p1['tool_composition']['binaries'] == p2['tool_composition']['binaries'], 'runtime binaries changed')
            require(p2['reuse_proof']['exact_diagnostic_helper_only'] is True
                and p2['reuse_proof']['binaries_identical'] is True, 'passing scope reuse proof differs')
            require(b'test trap_artifacts_follow_macro_scope_and_native_observables ... ok\n' in take(first / 'stdout')
                and b'test result: FAILED. 1 passed; 1 failed;' in take(first / 'stdout'), 'original outcome differs')
            require(b'test result: ok. 1 passed; 0 failed; 0 ignored;' in take(second / 'stdout'), 'final outcome differs')
            histories = [(first / 'artifacts/trap-artifact-scopes', 67),
                (first / 'artifacts/trap-uncalled-diagnostics', 15),
                (second / 'artifacts/trap-uncalled-diagnostics', 63)]
            for history, count in histories:
                receipts = sorted(history.glob('command-*/receipt.json'))
                require(len(receipts) == count, 'command count differs: ' + str(history))
                for index, path in enumerate(receipts):
                    require(path.parent.name == f'command-{index:03}', 'command sequence has a gap')
                    row = read_json(path)
                    require(isinstance(row.get('returncode'), int) and row['finished_at'] >= row['started_at'],
                        'unfinished command receipt')
                    take(path.parent / 'stdout'); take(path.parent / 'stderr')
                    if row['source_sha256']:
                        source = take(path.parent / 'input.rs')
                        require(all(sha(source) == h for h in row['source_sha256'].values()), 'command source differs')
            for number, work in [('01', first), ('02', second)]:
                tree(work, 'trap-' + number)
                add(OWNER / f'.work/run-trap-span-controls-{number}.py', 'helpers/run-trap-span-controls-' + number + '.py')

            for number in ['03', '04']:
                work = PRIMARY / ('.work/mono-production-workspace-' + number)
                receipt = read_json(work / 'result.json')
                require(receipt['status'] == 'passed' and receipt['passed'] == 505 and receipt['ignored'] == 4
                    and receipt['frozen_sources_unchanged'] is True, 'workspace qualification differs')
                for path, expected in receipt['evidence_files'].items():
                    require(sha(take(work / path)) == expected, 'workspace archived evidence differs')
                tree(work, 'workspace-' + number)
            for number in ['03', '06']:
                work = PRIMARY / ('.work/mono-production-tools-' + number)
                build = read_json(work / 'build.json')
                require(build['returncode'] == 0, 'successful tool build differs')
                tree(work, 'tools-' + number)
            for number in ['04', '05']:
                require(not (PRIMARY / ('.work/mono-production-tools-' + number)).exists(),
                    'admission failure unexpectedly created build inputs')
            outer_names = ['mono-production-tools-supervisor-' + n for n in ['03', '04', '05', '06']]
            outer_names += ['mono-production-workspace-supervisor-' + n for n in ['03', '04']]
            outer_names += ['trap-span-controls-supervisor-02']
            for name in outer_names:
                work = PRIMARY / '.work/experiments' / name
                status = read_json(work / 'status.json')
                failed = name in ['mono-production-tools-supervisor-04', 'mono-production-tools-supervisor-05']
                require(status['status'] == 'finished' and status['returncode'] == (1 if failed else 0),
                    'outer supervisor outcome differs')
                if failed:
                    require(b'timed out after 600s waiting for benchmark lock' in take(work / 'command.log'),
                        'tool attempt failed for a different reason')
                tree(work, 'supervisors/' + name)
            for key in [OLD_TOOL, TOOL]:
                for name in ['compiler.json', 'ready.json', 'capabilities.json']:
                    add(PRIMARY / '.work/interpreter-tools' / key / name, 'tool-identities/' + key + '/' + name)
            add(PRIMARY / '.work/compilers' / COMPILER / 'ready.json', 'compiler/ready.json')
            add(Path(__file__), 'helpers/archive-trap-span-controls-01.py')
            index = {name: dict(size=len(data), sha256=sha(data)) for name, data in sorted(members.items())}
            archive = OUT / 'evidence.tar.gz'
            with archive.open('xb') as output:
                with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for name, data in sorted(members.items()):
                            info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o444
                            tar.addfile(info, io.BytesIO(data))
            with tarfile.open(archive, 'r:gz') as tar:
                require(tar.getnames() == sorted(index), 'archive member set differs')
                for member in tar:
                    data = tar.extractfile(member).read()
                    require(dict(size=len(data), sha256=sha(data)) == index[member.name], 'archive member differs')
            for path, expected in inputs.items():
                data = Path(path).read_bytes()
                require(dict(size=len(data), sha256=sha(data)) == expected, 'retained input changed: ' + path)
            save(OUT / 'members.json', index)
            save(OUT / 'inputs.json', inputs)
            save(OUT / 'excluded-native-binaries.json', excluded)
            result.update(status='passed', finished_at=time.time(), archive=str(archive),
                archive_size=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()), members=len(index),
                source_unchanged=True, compiler_key=COMPILER, tool_key=TOOL, std_key=STD,
                original_attempt_status='failed', passing_scope_commands=67, corrected_diagnostic_commands=63,
                failed_diagnostic_prefix_commands=15, workspace_passed=505, workspace_ignored=4,
                tool_admission_only_failures=['04', '05'], performance_claim=False)
            save(RUN / 'result.json', result)
            save(OUT / 'summary.json', result)
            print(json.dumps(result))
    except BaseException as error:
        result.update(status='failed', finished_at=time.time(), error=repr(error))
        save(RUN / 'result.json', result)
        raise


if __name__ == '__main__':
    main()
