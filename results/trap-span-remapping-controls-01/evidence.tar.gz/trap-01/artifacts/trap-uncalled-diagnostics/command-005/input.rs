#![allow(dead_code)]
pub fn rust_interp_entry() -> u64 { 7 }
