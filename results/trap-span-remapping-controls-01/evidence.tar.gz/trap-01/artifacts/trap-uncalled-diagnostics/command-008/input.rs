#![allow(dead_code)]
pub fn rust_interp_entry() -> u64 { 7 }
fn uncalled() -> &'static u64 { let value=1; &value }
