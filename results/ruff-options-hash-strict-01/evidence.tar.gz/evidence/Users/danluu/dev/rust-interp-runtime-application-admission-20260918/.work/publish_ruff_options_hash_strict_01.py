#!/usr/bin/env python3
"""Archive the explicitly selected, closed strict01 evidence once."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile
import time

A = Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
Q = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
DEST = Q / 'results/ruff-options-hash-strict-01'
LIST = A / '.work/ruff-options-hash-strict-actual-publication-paths-01.json'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def stamp(path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, sort_keys=True, indent=2)
        f.write('\n')


def main():
    assert not DEST.exists()
    paths = [Path(p) for p in json.loads(LIST.read_bytes())] + [LIST, Path(__file__).absolute()]
    assert len(paths) == len(set(paths)) == 840
    members = []
    for p in paths:
        s = stamp(p)
        assert stat.S_ISREG(s[2]) and p.resolve(strict=True) == p
        assert p.is_relative_to(A) or p.is_relative_to(Q)
        with p.open('rb') as f:
            h = hashlib.file_digest(f, 'sha256').hexdigest()
        assert stamp(p) == s
        members.append(dict(path=str(p), member='evidence/' + str(p).removeprefix('/'), sha256=h, bytes=s[4], stamp=s))
    assert sum(r['bytes'] for r in members) <= 128*2**20
    DEST.mkdir()
    archive = DEST / 'evidence.tar.gz'
    with archive.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                for row in members:
                    p = Path(row['path']); data = p.read_bytes()
                    assert digest(data) == row['sha256'] and stamp(p) == row['stamp']
                    info = tarfile.TarInfo(row['member']); info.size = len(data); info.mode = 0o644
                    tar.addfile(info, io.BytesIO(data))
    assert archive.stat().st_size <= 32*2**20
    prior = Q / 'results/ruff-options-hash-strict-preparation-01/manifest.json'
    write(DEST/'preparation-reference.json', dict(path=str(prior), sha256=digest(prior.read_bytes()), scope='Prior committed preparation capsule contains exact four-file packet, binding, 123 source authentication rows and 159 input references. No provider/source/cache payload duplication here.'))
    (DEST/'STATUS.md').write_text('''The fresh strict Ruff off/on correctness history passed all 16 expected calls, including rejection of the deliberate wrong edit in both modes. Eight retained bytecode pairs match and the editable source was restored. The six selected tests and full ordinary frontend path were preserved.

The ordinary supervisor and parent both closed normally. Independent saved readback checked exact commands, environments, raw results, complete compiler-argv membership, all 64 retained artifacts and current source hashes. The on arm emitted 13,491 successful captures and 9,877 verified reuse hits; the off arm emitted no HIR events. This establishes mechanism eligibility for the prospective on/on screen.

This is instrumented correctness evidence, not a performance measurement. No timing ratios or speedup claims are made. No timed screen has run. The obsolete false/false screen01 remains unrun.

The archive contains only the finite closed evidence list, including a complete hash/stat inventory of the two newly generated caches. Cache payloads remain in their original task-owned paths and were not deleted or copied into this capsule. The original controller performed full provider and source guards; the independent saved readback does not relabel itself as a new provider qualification. Preparation and previously published source proofs are referenced separately.

The first local saved-reader attempt used an incorrect generic outer-plan shape and stopped before writing a report. Its exact source and narrow correction are preserved. The actual strict workload was run once; this metadata correction caused no rerun.
''')
    top = {}
    for p in sorted(DEST.iterdir()):
        if p.is_file():
            top[p.name] = dict(bytes=p.stat().st_size, sha256=digest(p.read_bytes()))
    write(DEST/'manifest.json', dict(status='published', created_at=time.time(), members=members, member_count=len(members), uncompressed_payload_bytes=sum(r['bytes'] for r in members), files=top, performance_qualified=False, source_publication_scope='No provider/cache binary payloads; selected output .rbc artifacts are retained reproducibility evidence.'))
    print(json.dumps(dict(path=str(DEST), members=len(members), bytes=sum(r['bytes'] for r in members), archive_bytes=archive.stat().st_size, manifest_sha256=digest((DEST/'manifest.json').read_bytes()))))


if __name__ == '__main__':
    main()
