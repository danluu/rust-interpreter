#!/usr/bin/env python3
"""Finite saved-output check; no provider import, process launch, or cache read."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import stat
import time

A = Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
Q = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
R = Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
X = Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
W = A / '.work/ruff-options-hash-strict-01'
H = A / 'experiments/runtime-application-admission/ruff-options-hash-strict-01'
OUT = A / '.work/ruff-options-hash-strict-independent-readback-01.json'
MECH = A / '.work/ruff-options-hash-strict-mechanism-eligibility-01.json'
refs = {}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def stamp(path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def payload(path, digest=None, size=None):
    path = Path(path)
    before = stamp(path)
    require(stat.S_ISREG(before[2]) and path.resolve(strict=True) == path, 'indirect file: ' + str(path))
    data = path.read_bytes()
    require(stamp(path) == before and len(data) == before[4], 'file changed: ' + str(path))
    actual = hashlib.sha256(data).hexdigest()
    require(digest is None or actual == digest, 'digest differs: ' + str(path))
    require(size is None or len(data) == size, 'size differs: ' + str(path))
    row = dict(path=str(path), sha256=actual, bytes=len(data), stamp=before)
    require(str(path) not in refs or refs[str(path)] == row, 'file changed between reads')
    refs[str(path)] = row
    return data


def read(path, digest=None):
    return json.loads(payload(path, digest))


def pure(path, names, namespace):
    tree = ast.parse(payload(path))
    selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    require({n.name for n in selected} == set(names), 'pure function selection differs')
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace


def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, sort_keys=True, indent=2)
        f.write('\n')


def main():
    require(not OUT.exists() and not MECH.exists(), 'readback already exists')
    payload(Path(__file__).absolute())
    plan = read(H / 'plan/plan.json', '7b6f840c7542cf1fa7a0dd02850d9519be225a5aa548a713303874c234c72c0e')
    launch = read(H / 'plan/launch.json', '6b4a063a36e881d8e29acce1d2e3bf48c838cd48feea0a4dced83a929dfa8334')
    payload(H / 'plan/inputs.json', '5140d056611a1552c7c4ef1ab6e1e3ee3e6600db7e728759e51c1750de580aca')
    result = read(W / 'result.json', 'fc2ae5d0870f777410dd32c95e12be6d3c3b0900e96f8a412225aa55508eb54c')
    sup = read(W / 'supervision.json', 'af22e76b7ed83ee2725146f58b68c282966b2452f2ac2ead0ac74ef819eab798')
    parent_path = Q / '.work/ruff-options-hash-strict-execution-01/record.json'
    parent = read(parent_path, '970bdb92d3d7f558bfef7efe491fa3aa24176ace22d5e19967db889e0d4d6630')
    outer_dir = A / '.work/experiments/ruff-options-hash-strict-supervisor-01'
    outer = read(outer_dir / 'status.json', parent['outer_status_sha256'])
    outer_plan = read(outer_dir / 'plan.json', parent['outer_plan_sha256'])
    payload(outer_dir / 'command.log', outer['log_sha256'])
    for name in ['stdout', 'stderr']:
        payload(parent_path.parent / name, parent[name + '_sha256'])
    require(parent['status'] == outer['status'] == 'finished' and sup['status'] == result['status'] == 'passed', 'terminal status')
    require(parent['returncode'] == parent['controller_returncode'] == outer['returncode'] == 0, 'closure return codes')
    require(parent['supervisor_may_be_live'] is parent['controller_may_be_live'] is False, 'unclosed owner')
    require(parent['pid'] == outer['supervisor_pid'] == sup['parent_pid'] == 96031
            and outer['child_pid'] == sup['pid'] == 96033
            and parent['parent_pid'] == outer['supervisor_parent_pid'] == 95312, 'PID associations')
    require(parent['started_at'] <= parent['child_started_at'] <= outer['started_at']
            <= outer['child_started_at'] <= sup['started_at'] <= sup['admitted_at']
            <= sup['finished_at'] <= outer['finished_at'] <= parent['finished_at'], 'owner chronology')
    require(outer_plan == dict(command=launch['command'], cwd=launch['cwd'], environment=launch['environment']), 'outer plan')
    require(outer['command'] == launch['command'] and parent['environment'] == launch['environment']
            and parent['cwd'] == launch['cwd'] == str(A), 'outer command/environment')
    require(sup['plan_sha256'] == refs[str(H / 'plan/plan.json')]['sha256']
            and sup['freeze_sha256'] == refs[str(H / 'plan/inputs.json')]['sha256'], 'packet pins')
    require(result['commands'] == len(result['records']) == len(plan['history'])
            == len(plan['commands']) == len(sup['children']) == 16, 'history length')
    require(result['strict_compatibility'] is result['cross_mode_bytecode_equal'] is True
            and result['performance_qualified'] is False and result['diagnostic_timing_only'] is True
            and result['trap_unsupported_calls'] is result['run_try_callbacks'] is False, 'qualification scope')
    sm = read(plan['source_manifest']['path'], plan['source_manifest']['sha256'])
    for name, value in sm['files'].items():
        payload(name, value if isinstance(value, str) else value['sha256'])
    require(len(sm['files']) == 123, 'source count')
    parser_path = A / 'experiments/runtime-application-admission/run_ruff_diagnostic.py'
    hir = pure(parser_path, ['require', 'observed_hir'], dict(re=re, Counter=Counter))
    guest = pure(R / 'scripts/suite_reports.py', ['guest_test_failure'], {})
    decoder = pure(R / 'scripts/mono_qualification.py', ['decode_record'], dict(require=require))
    tests = ['registry::tests::' + s for s in ['documentation', 'rule_naming_convention', 'check_code_serialization', 'linter_parse_code', 'rule_size', 'linter_sorting']]
    rows, checked, raw_refs, per_command = [], [], [], []
    previous = sup['admitted_at']
    minimum_free = sup['free_bytes_before']
    for index, (record, expected, spec, child) in enumerate(zip(result['records'], plan['commands'], plan['history'], sup['children'], strict=True)):
        require({k:record[k] for k in spec} == spec and record['label'] == child['label'] == expected['label'], 'history association')
        directory = W / 'raw' / f'{index:03}-{spec["label"]}'
        require(record['receipt'] == str(directory / 'receipt.json') and child['path'] == str(directory), 'child route')
        receipt = read(directory / 'receipt.json')
        require(receipt == child['receipt'] and receipt['status'] == 'finished', 'saved child closure')
        require(receipt['supervisor_pid'] == sup['pid'] and receipt['parent_pid'] == sup['parent_pid']
                and previous <= receipt['started_at'] <= receipt['finished_at'] <= sup['finished_at'], 'child chronology/owner')
        previous = receipt['finished_at']
        require(receipt['command'] == expected['command'] and receipt['cwd'] == expected['cwd']
                and receipt['environment'] == plan['child_environment'], 'actual child argv/env/cwd')
        expected_rc = 1 if spec['state'] == -1 else 0
        require(receipt['returncode'] == expected['expected_returncode'] == expected_rc, 'expected actual return code')
        stdout = payload(directory / 'stdout', receipt['stdout_sha256']).decode()
        stderr = payload(directory / 'stderr', receipt['stderr_sha256']).decode()
        require(guest['guest_test_failure'](stderr) if expected_rc else stdout.strip() == '0', 'batch outcome')
        identity = receipt['identity']
        require(identity['ps_returncode'] == identity['cwd_returncode'] == 0
                and identity['ps'].split()[:2] == [str(receipt['pid']), str(sup['pid'])]
                and 'n' + receipt['cwd'] + '\n' in identity['cwd'], 'recorded actual identity')
        samples = [receipt['free_bytes_before'], receipt['free_bytes_after']] + [s['free_bytes'] for s in receipt['disk_samples']]
        minimum_free = min(minimum_free, *samples)
        require(min(samples) >= 8 * 2**30, 'recorded running floor')
        proof = record['proof']; observed = [json.loads(s.removeprefix('rust-interp-launch: ')) for s in stderr.splitlines() if s.startswith('rust-interp-launch: ')]
        require(observed == [proof['launch']], 'lossless launcher association')
        launched = observed[0]
        on = 'true' if spec['mode'] == 'candidate' else 'false'
        flags = ['-Zmir-opt-level=3', '-Zhir-body-cache-capture=' + on, '-Zhir-body-cache-reuse=' + on, '-Zincremental-info=true']
        require(launched['application_rustflags'] == flags and launched['tool_key'] == plan['tool_key']
                and launched['custom_compiler']['key'] == plan['runtime_key'] and launched['std_mir']['key'] == plan['std_key'], 'actual runtime flags/keys')
        require(launched['trap_unsupported_calls'] is launched['run_try_callbacks'] is False
                and launched['function_cache'] == launched['borrowck_cache'] == 'off'
                and launched['engine'] == 'jit' and launched['inline_leaves'] is launched['jit_resumable_calls'] is launched['jit_persistent_registers'] is True, 'strict VM configuration')
        require(not re.search(r'(?mi)stripping debug info with .?rust-objcopy.? failed|failed to execute rust-objcopy|Library not loaded:|dyld\[|^rust-interp-unavailable:', stdout + '\n' + stderr), 'loader/strip/unsupported failure')
        for key in ['bytecode', 'catalog', 'dep_info', 'cargo_timing']:
            a = proof[key]; require(Path(a['path']).parent == W / 'artifacts', 'retained artifact scope')
            payload(a['path'], a['sha256'], a['bytes'])
        require(proof['bytecode']['sha256'] == launched['artifact_sha256'] and proof['bytecode']['bytes'] == launched['artifact_bytes'], 'bytecode identity')
        cat = json.loads(payload(proof['catalog']['path']))
        require(cat['schema_version'] == 1 and cat['bytecode_version'] == 5 and cat['artifact_sha256'] == proof['bytecode']['sha256']
                and [e['name'] for e in cat['entries']] == tests, 'six-test catalog')
        records = proof['compiler_records']
        require({str(p) for p in (W / 'compiler-argv' / spec['label']).iterdir()} == {r['path'] for r in records}, 'compiler record membership')
        selected = []
        for r in records:
            path = Path(r['path']); payload(path, r['sha256'])
            require(decoder['decode_record'](path) == {k:v for k,v in r.items() if k not in ['path','sha256']}, 'compiler argv payload')
            if r['role'] == 'exported':
                selected.append(r)
                require(all(r['argv'].count(f) == 1 for f in flags) and '-C' in r['argv']
                        and any(a.startswith('incremental=') for a in r['argv']), 'actual enabled/incremental compiler route')
        require(len(selected) == 1, 'selected compilation count')
        dep = payload(proof['dep_info']['path']).decode()
        environment = {}
        for line in dep.splitlines():
            if line.startswith('# env-dep:'):
                key, sep, value = line.removeprefix('# env-dep:').partition('=')
                require(key not in environment, 'duplicate env dependency')
                environment[key] = value if sep else None
        require(environment == proof['exporter_env_dependencies']
                and all(k in environment and environment[k] is None for k in ['RUST_INTERP_TRAP_UNSUPPORTED_CALLS','RUST_INTERP_RUN_TRY_CALLBACKS'])
                and json.loads(environment['RUST_INTERP_ENTRIES']) == tests, 'actual exporter dependency policy')
        row = dict(mode=spec['mode'], cycle=1 if spec['state'] == -2 else 0, state=spec['state'], phase=spec['phase'], calls=[dict(stderr=stderr)])
        rows.append(row)
        individual = hir['observed_hir']([row])
        per_command.append(dict(label=spec['label'], mode=spec['mode'], state=spec['state'], event_counts=individual['event_counts'], stderr=refs[str(directory / 'stderr')], receipt=refs[str(directory / 'receipt.json')]))
        checked.append(dict(label=spec['label'], pid=receipt['pid'], returncode=expected_rc, receipt=refs[str(directory / 'receipt.json')]))
    pairs = []
    for state in [0,-1,1,2,3,4,5,-2]:
        group = [r for r in result['records'] if r['state'] == state]
        require(len(group) == 2 and {r['mode'] for r in group} == {'baseline','candidate'}
                and group[0]['source_sha256'] == group[1]['source_sha256']
                and group[0]['proof']['bytecode']['sha256'] == group[1]['proof']['bytecode']['sha256'], 'cross-mode source/RBC pair')
        pairs.append(dict(state=state, source_sha256=group[0]['source_sha256'], bytecode_sha256=group[0]['proof']['bytecode']['sha256']))
    original = plan['editable_source']['original_sha256']
    payload(plan['editable_source']['path'], original)
    require(result['source_restoration'] == dict(bytes=89102713, exact_membership=True, files=11119)
            and pairs[0]['source_sha256'] == pairs[-1]['source_sha256'] == original, 'source restoration')
    parsed = hir['observed_hir'](rows)
    accepted = {'cold-tree-and-journal-after-stock-lowering', 'same-tree-and-journal-after-stock-lowering', 'changed-tree-or-journal-after-stock-lowering'}
    captures = sum(n for k,n in parsed['event_counts'].items() if k in accepted)
    require(captures > 0 and parsed['observed_hits'] > 0 and all(not c['event_counts'] for c in per_command if c['mode'] == 'baseline'), 'mechanism eligibility')
    compiler = X / '.work/hir-options-hash-compiler-01/source/compiler/rustc_ast_lowering/src/body_cache/mod.rs'
    payload(compiler, 'cb91d3a723616866b5eebe650f28c6c7c894735f26decf7eeef37727d15b1481')
    eligibility = dict(policy='ruff-options-hash-mechanism-eligibility-v1', status='passed', result=refs[str(W/'result.json')], supervision=refs[str(W/'supervision.json')], parent=refs[str(parent_path)], compiler_source=refs[str(compiler)], parser_source=refs[str(parser_path)], successful_captures=captures, verified_hits=parsed['observed_hits'], off_arm_events=0, event_counts=parsed['event_counts'], per_command=per_command, performance_qualified=False, scope=parsed['coverage_scope'], timing_scope=parsed['timing_scope'], checked_at=time.time())
    write(MECH, eligibility); payload(MECH)
    for name,row in refs.items():
        require(stamp(Path(name)) == row['stamp'], 'final readback stamp differs: ' + name)
    report = dict(status='passed', checked_at=time.time(), application_strict_compatibility=True, mechanism_eligible=True, performance_qualified=False, commands=16, bytecode_pairs=pairs, children=checked, minimum_recorded_free_bytes=minimum_free, retained_source_count=123, source_restoration=result['source_restoration'], eligibility=refs[str(MECH)], parent=refs[str(parent_path)], refs=list(refs.values()), scope='Saved raw/closed owner/artifact/source readback, plus current editable registry hash. No provider payload or cache tree walk, no target imports, probes, compiler calls, or timing interpretation. Original controller performed full source/provider guards; this readback does not repeat those live inventories.')
    write(OUT, report)
    print(json.dumps(dict(report=str(OUT), sha256=hashlib.sha256(OUT.read_bytes()).hexdigest(), eligibility=str(MECH), eligibility_sha256=hashlib.sha256(MECH.read_bytes()).hexdigest(), refs=len(refs), captures=captures, hits=parsed['observed_hits'])))


if __name__ == '__main__':
    main()
