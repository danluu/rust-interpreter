"""Paired full compiler/std validation only; no Cargo, VM or readiness claim."""
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
COMPILER = 'f9fb3e5f59b8567fffd32c936a9864d0baee77038574236710fbcec75a57d33f'
STD = 'e51184b28521ec446ce759d2f6e8334d554a1d1186334c2e872dec9c45763b48'
NAMESPACE = 'immutable-source-paths-v2:shared'
WORK = ROOT / '.work/owned-tree-validation-comparison-02'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import write_json
import custom_compiler as custom
import std_mir_source_paths as std

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

WORK.mkdir(exist_ok=False)
rows = []
result = dict(status='waiting', owner=str(ROOT), primary=str(PRIMARY), pid=os.getpid(),
    parent_pid=os.getppid(), started_at=time.time(), lock=str(LOCK), lock_wait_seconds=600,
    scope='complete compiler and shared std loading; no tool loading, Cargo, VM or application readiness',
    baseline_commit='151af48b', candidate_commit='7103301f', rows=rows)
write_json(WORK / 'result.json', result)
try:
    with LOCK.open('r+') as lock:
        acquire_lock(lock, 600)
        result.update(status='running', admitted_at=time.time())
        write_json(WORK / 'result.json', result)
        assert shutil.disk_usage(ROOT).free >= 8 * 1024**3
        tests = json.loads((ROOT / '.work/owned-tree-stamps-tests-02/result.json').read_bytes())
        assert tests['status'] == 'passed' and tests['sources_unchanged']
        test_plan = json.loads((ROOT / '.work/owned-tree-stamps-tests-02/plan.json').read_bytes())
        for name, digest in test_plan['sources'].items():
            assert sha(ROOT / name) == digest
        paths = sorted((ROOT / 'scripts').glob('*.py')) + [Path(__file__), ROOT / '.work/custom_compiler_baseline_02.py']
        before = {str(path.relative_to(ROOT)): sha(path) for path in paths}
        for path in paths:
            destination = WORK / 'source' / path.relative_to(ROOT)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(path.read_bytes())
            assert sha(destination) == before[str(path.relative_to(ROOT))]
        baseline_path = ROOT / '.work/custom_compiler_baseline_02.py'
        assert sha(baseline_path) == '9778298145d302fd5db2425ada1ba5a5ef86bb0b66cecc0a23c702280e03da6a'
        baseline_ast = ast.parse(baseline_path.read_bytes(), filename=str(baseline_path))
        nodes = [node for node in baseline_ast.body if isinstance(node, ast.FunctionDef) and node.name == 'tree_stamps']
        assert len(nodes) == 1
        namespace = dict(vars(custom))
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(baseline_path), 'exec'), namespace)
        baseline = namespace['tree_stamps']
        candidate = custom.tree_stamps
        compiler_ready = PRIMARY / '.work/compilers' / COMPILER / 'ready.json'
        std_ready = PRIMARY / '.work/std-mir' / STD / 'ready.json'
        ready_hashes = {str(path): sha(path) for path in (compiler_ready, std_ready)}
        (WORK / 'readiness').mkdir()
        for label, path in [('compiler', compiler_ready), ('std', std_ready)]:
            copy = WORK / 'readiness' / (label + '.json')
            copy.write_bytes(path.read_bytes())
            assert sha(copy) == ready_hashes[str(path)]
        write_json(WORK / 'plan.json', dict(sources=before, readiness=ready_hashes,
            compiler_key=COMPILER, std_key=STD, namespace=NAMESPACE,
            order=[['baseline', 'candidate'] if i % 2 == 0 else ['candidate', 'baseline'] for i in range(5)],
            environment_sha256=hashlib.sha256(json.dumps(dict(os.environ), sort_keys=True).encode()).hexdigest()))

        def load():
            compiler = custom.load_compiler(PRIMARY, COMPILER)
            prepared = std.load(PRIMARY, STD, compiler, NAMESPACE)
            return compiler, prepared

        # Both complete loaders already validate every returned tree against
        # its immutable readiness. This untimed load establishes exact outputs.
        expected = load()
        try:
            for pair in range(5):
                order = ['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']
                for mode in order:
                    custom.tree_stamps = std.tree_stamps = baseline if mode == 'baseline' else candidate
                    wall_start = time.perf_counter_ns()
                    cpu_start = time.process_time_ns()
                    actual = load()
                    cpu_ns = time.process_time_ns() - cpu_start
                    wall_ns = time.perf_counter_ns() - wall_start
                    assert actual == expected, 'loader outputs differ'
                    assert all(sha(Path(name)) == value for name, value in ready_hashes.items())
                    rows.append(dict(pair=pair, mode=mode, wall_ns=wall_ns, cpu_ns=cpu_ns,
                        exact_loader_outputs_equal=True))
                    write_json(WORK / 'records.json', rows)
        finally:
            custom.tree_stamps = std.tree_stamps = candidate
        assert load() == expected
        assert all(sha(ROOT / name) == value for name, value in before.items())
        result.update(status='passed', finished_at=time.time(), sources_unchanged=True,
            readiness_unchanged=True, tests_result_sha256=sha(ROOT / '.work/owned-tree-stamps-tests-02/result.json'),
            medians={mode: {metric: statistics.median(row[metric] for row in rows if row['mode'] == mode)
                for metric in ('wall_ns', 'cpu_ns')} for mode in ('baseline', 'candidate')},
            plan_sha256=sha(WORK / 'plan.json'), application_readiness_qualified=False)
        write_json(WORK / 'result.json', result)
        print(json.dumps(result))
except BaseException as error:
    result.update(status='failed', error=repr(error), finished_at=time.time())
    write_json(WORK / 'result.json', result)
    raise
