"""Retain completed source controls and native probes; never read runtime inputs."""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-runtime-source-qualification-20260913')
FREEZE = ROOT / '.work/runtime-source-evidence-freeze-01.json'
WORK = ROOT / '.work/runtime-source-evidence-archive-01'
OUT = ROOT / 'results/runtime-source-qualification-01'
OWNED = ROOT / 'experiments/stable-cgu/owned_stage.py'
CONTROL = ROOT / '.work/runtime-source-expectations-controls-01'
NATIVE = ROOT / '.work/runtime-source-preflight-01'
MIB = 2 ** 20


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def stamp(path):
    s = path.lstat()
    return (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_nlink)


def capture(path, expected):
    require(path.resolve(strict=True) == path, 'indirect proof path')
    before = stamp(path)
    require(stat.S_ISREG(before[2]) and before[3] <= 32 * MIB, 'unbounded or nonordinary proof')
    data = path.read_bytes()
    require(stamp(path) == before and digest(data) == expected, 'proof bytes or identity changed')
    return data


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--freeze-sha', required=True)
    args = parser.parse_args()
    require(Path.cwd() == ROOT and sys.dont_write_bytecode and not sys.flags.optimize, 'fixed owner/Python -B required')
    freeze_bytes = capture(FREEZE, args.freeze_sha)
    freeze = json.loads(freeze_bytes)
    require(freeze['owner'] == str(ROOT) and freeze['source_commit'] == 'b7c2ba4f1f47dff32331ec5b2815b6d823740a65', 'foreign source freeze')
    require(digest(Path(sys.executable).resolve().read_bytes()) == freeze['python_sha256'], 'Python changed')
    require(freeze['files'][str(OWNED)]['sha256'] == '7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e', 'owned helper differs')
    capture(OWNED, freeze['files'][str(OWNED)]['sha256'])
    capture(Path(__file__), freeze['files'][str(Path(__file__))]['sha256'])
    spec = importlib.util.spec_from_file_location('runtime_source_archive_owned', OWNED)
    owned = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = owned
    spec.loader.exec_module(owned)
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(), freeze_sha256=args.freeze_sha)
    owned.write(WORK / 'summary.json', record)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK, 600):
            free = owned.disk(ROOT, 8)
            require(free >= 8 * 2**30 + 96 * MIB, 'archive reservation unavailable')
            record.update(status='running', admitted_at=time.time(), free_bytes_before=free)
            owned.write(WORK / 'summary.json', record)
            payloads = {}
            for name, item in freeze['files'].items():
                owned.disk(ROOT, 8)
                data = capture(Path(name), item['sha256'])
                require(len(data) == item['bytes'], 'frozen proof size differs')
                payloads[name] = data
            require(len(payloads) <= 2048 and sum(map(len, payloads.values())) == freeze['input_bytes'] <= 64 * MIB, 'proof retention bound differs')
            for directory, members in freeze['directories'].items():
                actual = sorted(str(p) for p in Path(directory).rglob('*') if p.is_symlink() or not p.is_dir())
                require(actual == members, 'completed evidence directory membership changed')
            c = json.loads(payloads[str(CONTROL / 'summary.json')])
            n = json.loads(payloads[str(NATIVE / 'receipt.json')])
            require(digest(payloads[str(CONTROL / 'summary.json')]) == '8e65c82918c8439ad2d1debf3bfa9f868a73ab9afd44b96accf32a994be70577' and c['status'] == 'passed', 'four-control result differs')
            raw = payloads[str(CONTROL / 'command/stderr')].decode()
            names = re.findall(r'^test_[^\n]* \((test_runtime_source_qualification\.[^)]+)\) \.\.\. ok$', raw, re.M)
            require(names == c['actual_tests'] == c['required_tests'] and len(names) == 4 and raw.rstrip().endswith('OK') and 'skipped' not in raw, 'four raw test outcomes differ')
            require(digest(payloads[str(NATIVE / 'receipt.json')]) == '8bd341a23550e0d77c0bf7f6472811bb1586cad1af9a214a7be1d5684a7af4dc' and n['status'] == 'passed' and n['full_current_guard_passed'] is True and len(n['children']) == 12 and n['compiler_commands'] == 2, 'native qualification differs')
            for ref in n['children']:
                require(digest(payloads[ref['path']]) == ref['sha256'], 'native child association differs')
            payloads[str(FREEZE)] = freeze_bytes
            OUT.mkdir(parents=True, exist_ok=False)
            archive = OUT / 'evidence.tar.gz'
            manifest, first = {}, {}
            with archive.open('xb') as stream:
                with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for path, data in sorted(payloads.items()):
                            owned.disk(ROOT, 8)
                            name = path.lstrip('/')
                            member = tarfile.TarInfo(name)
                            member.mode = 0o644
                            key = (digest(data), len(data))
                            if key in first:
                                member.type, member.linkname = tarfile.LNKTYPE, first[key]
                                tar.addfile(member)
                            else:
                                member.size = len(data)
                                tar.addfile(member, io.BytesIO(data))
                                first[key] = name
                            manifest[name] = dict(source=path, sha256=key[0], bytes=key[1])
            require(archive.stat().st_size <= 64 * MIB, 'compressed proof bound exceeded')
            seen = set()
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    owned.disk(ROOT, 8)
                    require(member.name in manifest and member.name not in seen and (member.isfile() or member.islnk()), 'unexpected archive member')
                    if member.islnk():
                        require(member.linkname in seen, 'forward or missing proof link')
                    data = tar.extractfile(member).read()
                    item = manifest[member.name]
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback differs')
                    seen.add(member.name)
            require(seen == set(manifest), 'incomplete archive readback')
            for path, data in payloads.items():
                owned.disk(ROOT, 8)
                require(capture(Path(path), digest(data)) == data, 'proof changed during archival')
            owned.write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed', source_commit=freeze['source_commit'], controls=4, skipped=0,
                native_children=12, compiler_probes=2, compiler_returncodes=[1, 1],
                control_summary_sha256=digest(payloads[str(CONTROL / 'summary.json')]),
                native_receipt_sha256=digest(payloads[str(NATIVE / 'receipt.json')]),
                source_commit_qualified=n['source_commit'], full_current_guard_passed=True,
                default_source_snippets_verified=True, virtual_source_identity_verified=True,
                actual_commands_rerun=False, live_runtime_read_by_archive=False, installation=False,
                source_capability_published=False, application_qualified=False, performance_claim=False,
                archive=dict(path='evidence.tar.gz', sha256=digest(archive.read_bytes()), bytes=archive.stat().st_size,
                    members=len(manifest), physical_members=len(first), all_member_hashes_verified=True),
                manifest_sha256=digest((OUT / 'manifest.json').read_bytes()),
                archive_pid=os.getpid(), archive_parent_pid=os.getppid(), archive_admitted_at=record['admitted_at'])
            owned.write(OUT / 'summary.json', summary)
            record.update(status='passed', finished_at=time.time(), free_bytes_after=owned.disk(ROOT, 8),
                summary_sha256=digest((OUT / 'summary.json').read_bytes()), archive=summary['archive'])
            owned.write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        owned.write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
