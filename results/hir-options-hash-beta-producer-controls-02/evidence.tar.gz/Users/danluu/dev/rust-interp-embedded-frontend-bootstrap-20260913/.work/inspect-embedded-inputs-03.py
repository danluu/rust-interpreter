#!/usr/bin/env python3
"""One recorded metadata-only inspection. Never assembles, compiles or deletes."""
import collections
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import stat
import sys
import tarfile
import time

OWNER = Path('/Users/danluu/dev/rust-interp-embedded-frontend-bootstrap-20260913')
SOURCE = Path('/Users/danluu/dev/rustc-hir-capture-check-20260913')
STAGE2 = Path('/Users/danluu/dev/rust-interp-hir-arena-stage2-20260913')
HERE = OWNER / 'experiments/embedded-frontend-bootstrap'
WORK = OWNER / '.work/embedded-frontend-input-inspection-03'
FROZEN = OWNER / '.work/embedded-frontend-input-inspection-freeze-03.json'
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
HOST = 'aarch64-apple-darwin'
BUILD = SOURCE / 'build' / HOST
CONTROLS = OWNER / '.work/embedded-compositor-controls-01'
CONTROL_SHA = '0272d235fa1152e96b877d00942d2baefffee44c1a0253dee6810f15d996be22'
FAILED01 = OWNER / '.work/embedded-frontend-input-inspection-failure01-bindings-02.json'
FAILED02 = OWNER / '.work/embedded-frontend-input-inspection-failure02-bindings-03.json'
OLD_PLAN_ARCHIVE = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913/results/hir-upgrade-check-failed-01/evidence.tar.gz')
OLD_PLAN_ARCHIVE_SHA = '53a8fa2fab9504a8dbef7a44fbe26bf094a254bf8443f0cda43c9fe35eacaf54'
OLD_PLAN_SHA = 'd97d608124128bf203375125786683ada8c6d9a758971be8e861301b9835cf42'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(data)
    return result.hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def option(argv, flag):
    values = []
    for index, value in enumerate(argv):
        if value == flag:
            require(index + 1 < len(argv), 'missing compiler option operand')
            values.append(argv[index + 1])
        elif value.startswith(flag + '='):
            values.append(value[len(flag) + 1:])
    require(len(values) <= 1, 'duplicate compiler option: ' + flag)
    return values[0] if values else None


def option_values(argv, flag):
    """Keep repeated extern/search/codegen values ordered, never last-value wins."""
    result, index = [], 0
    while index < len(argv):
        value = argv[index]
        index += 1
        if value == flag:
            require(index < len(argv), 'missing ' + flag + ' operand')
            result.append(argv[index])
            index += 1
        elif value.startswith(flag + '='):
            result.append(value[len(flag) + 1:])
        elif flag in ('-C', '-L', '-Z') and value.startswith(flag):
            result.append(value[len(flag):])
    return result


def cargo_rows(text):
    commands, fresh, native_search = [], [], []
    for index, line in enumerate(text.splitlines()):
        stripped = line.strip()
        if stripped.startswith('Fresh '):
            fresh.append(dict(line=index + 1, text=line, sha256=digest(line.encode())))
        if 'cargo:rustc-link-' in line or 'cargo::rustc-link-' in line:
            search = re.search(r'\bcargo::?rustc-link-search=(?:native=)?(/.*)$', line)
            native_search.append(dict(line=index + 1, text=line, sha256=digest(line.encode()),
                                      search_path=search.group(1) if search else None))
        if not stripped.startswith('Running `'):
            continue
        require(stripped.endswith('`'), 'unterminated saved Cargo command')
        argv = shlex.split(stripped[len('Running `'):-1])
        row = dict(index=len(commands), line=index + 1, line_sha256=digest(line.encode()),
                   raw=line, argv=argv, externs=[], native_search=[], output_paths=[])
        for value in option_values(argv, '--extern'):
            name, separator, path = value.partition('=')
            row['externs'].append(dict(name=name, path=path if separator else None, raw=value))
        for value in option_values(argv, '-L'):
            kind, separator, path = value.partition('=')
            if separator and kind == 'native':
                row['native_search'].append(path)
        # Only a literal assignment in the original exec argv supplies OUT_DIR.
        dirs = [value[len('OUT_DIR='):] for value in argv if value.startswith('OUT_DIR=')]
        require(len(dirs) <= 1, 'ambiguous saved build-script OUT_DIR')
        row['build_script_out_dir'] = dirs[0] if dirs else None
        if '--crate-name' in argv or any(v.startswith('--crate-name=') for v in argv):
            type_values = option_values(argv, '--crate-type')
            emit_values = option_values(argv, '--emit')
            row.update(crate=option(argv, '--crate-name'), crate_type=','.join(type_values),
                       crate_type_values=type_values, out_dir=option(argv, '--out-dir'),
                       emit=','.join(emit_values), emit_values=emit_values,
                       test='--test' in argv)
            suffix = [x[len('extra-filename='):] for x in option_values(argv, '-C')
                      if x.startswith('extra-filename=')]
            require(len(suffix) <= 1, 'ambiguous compiler filename suffix')
            row['extra_filename'] = suffix[0] if suffix else None
            if row['out_dir'] and suffix and re.fullmatch('-[0-9a-f]+', suffix[0]):
                crate, directory = row['crate'], Path(row['out_dir'])
                emit = set((row['emit'] or '').split(','))
                types = set((row['crate_type'] or '').split(','))
                if 'metadata' in emit:
                    row['output_paths'].append(str(directory / ('lib' + crate + suffix[0] + '.rmeta')))
                if 'link' in emit:
                    for kind, extension in [('lib', '.rlib'), ('rlib', '.rlib'), ('dylib', '.dylib'),
                                             ('cdylib', '.dylib'), ('proc-macro', '.dylib'), ('staticlib', '.a')]:
                        if kind in types:
                            path = str(directory / ('lib' + crate + suffix[0] + extension))
                            if path not in row['output_paths']:
                                row['output_paths'].append(path)
        commands.append(row)
    return dict(commands=commands, fresh=fresh, native_link_output=native_search)


def evidence_for(path, rows):
    direct, consumed, scripts, searches = [], [], [], []
    for row in rows['commands']:
        reference = dict(index=row['index'], line=row['line'], line_sha256=row['line_sha256'])
        if str(path) in row['output_paths']:
            direct.append(reference)
        matches = [dict(ordinal=i, **value) for i, value in enumerate(row['externs'])
                   if value['path'] == str(path)]
        if matches:
            consumed.append(dict(**reference, bindings=matches))
        directory = row['build_script_out_dir']
        if directory and Path(directory).is_absolute() and path.is_relative_to(directory):
            scripts.append(dict(**reference, out_dir=directory))
        for directory in row['native_search']:
            if Path(directory).is_absolute() and path.is_relative_to(directory):
                searches.append(dict(**reference, directory=directory))
    # Raw link output is retained separately. Full-path association only; names
    # never turn an unobserved output into a fabricated producer command.
    raw_links = [row for row in rows['native_link_output']
                 if row['search_path'] and path.is_relative_to(Path(row['search_path']))]
    classes = []
    if direct:
        classes.append('direct-rustc-producer')
    if consumed:
        classes.append('exact-consumed-dependency')
    if scripts and (searches or raw_links):
        classes.append('native-build-script-output')
    if not classes:
        classes.append('stamp-mediated-reused-input')
    return dict(classes=classes, direct=direct, consumed=consumed,
                build_scripts=scripts, native_search=searches, raw_link_output=raw_links)


def raw_stamp(data):
    """Retain all raw rows, including malformed ones, before constrained parsing."""
    raw_rows = data.split(b'\0')
    if raw_rows[-1:] == [b'']:
        raw_rows.pop()
    result = []
    for index, raw in enumerate(raw_rows):
        row = dict(index=index, hex=raw.hex(), tag=None, source=None, errors=[])
        if raw[:1] not in (b'h', b't', b's'):
            row['errors'].append('unknown dependency tag')
        else:
            row['tag'] = raw[:1].decode()
        try:
            row['source'] = raw[1:].decode('utf-8')
        except UnicodeDecodeError:
            row['errors'].append('non-UTF8 source path')
        result.append(row)
    return result


def main():
    require(sys.dont_write_bytecode and not sys.flags.optimize, 'use Python -B without optimization')
    require(len(sys.argv) == 3 and sys.argv[1] == '--frozen-sha'
            and re.fullmatch('[0-9a-f]{64}', sys.argv[2]), 'supply reviewed --frozen-sha')
    frozen_sha = sys.argv[2]
    data = FROZEN.read_bytes()
    require(digest(data) == frozen_sha, 'inspection freeze changed before loading')
    frozen = json.loads(data)

    def check_sources():
        require(sha(FROZEN) == frozen_sha, 'inspection freeze changed')
        for path, expected in frozen['files'].items():
            p = Path(path)
            require(p.is_file() and not p.is_symlink() and p.resolve() == p and sha(p) == expected,
                    'frozen inspector/helper source changed: ' + path)
        require(str(Path(sys.executable).resolve()) == frozen['python']['resolved']
                and sha(sys.executable) == frozen['python']['sha256'], 'actual Python changed')

    check_sources()
    sys.path.insert(0, str(OWNER / 'scripts'))
    from workflow_io import capture, write_json
    owned = load('embedded_inspector_owned', OWNER / 'experiments/stable-cgu/owned_stage.py')
    comp = load('embedded_inspector_compositor', HERE / 'compose_sysroot.py')
    WORK.mkdir(exist_ok=False)
    record = dict(schema_version=1, status='waiting', owner=str(OWNER), pid=os.getpid(),
        parent_pid=os.getppid(), started_at=time.time(), command=sys.argv, cwd=os.getcwd(),
        canonical_lock=str(LOCK), wait_seconds=600, frozen_sha256=frozen_sha,
        python={**frozen['python'], 'path': sys.executable}, commands=[],
        assemblies=0, compiler_commands=0, deletions=0, process_controls=0, assembly_approved=False)
    proofs, files = {}, {}

    def save():
        write_json(WORK / 'summary.json', record)

    def capacity():
        free = shutil.disk_usage(OWNER).free
        require(free >= 8 * 1024**3, 'metadata retention reached 8 GiB running floor')
        return free

    def retain_bytes(origin, payload, expected=None, archive=None):
        actual = digest(payload)
        require(expected is None or actual == expected, 'retained payload hash mismatch: ' + origin)
        destination = WORK / 'proof-bytes' / actual
        destination.parent.mkdir(exist_ok=True)
        if not destination.exists():
            require(capacity() - len(payload) >= 8 * 1024**3, 'metadata copy would cross running floor')
            with destination.open('xb') as output:
                comp.stream_hash(io.BytesIO(payload), output, capacity)
                output.flush()
                os.fsync(output.fileno())
        require(sha(destination) == actual, 'retained proof copy changed')
        # Current helper bytes and archived historical bytes may share an
        # original path. Retain both identities instead of replacing either.
        proofs.setdefault(origin, {})[actual] = dict(sha256=actual, bytes=len(payload),
                                                     copy=str(destination), archive=archive)
        return payload

    def checked(path, expected=None):
        path = Path(path)
        initial = comp.ordinary(path)
        if expected is None:
            with path.open('rb') as stream:
                actual, size = comp.stream_hash(stream)
            require(comp.ordinary(path) == initial, 'input changed during initial hash')
            expected = actual
        value = comp.check_file(dict(path=str(path), sha256=expected, identity=initial))
        if str(path) in files:
            require(files[str(path)] == value, 'previously read input changed')
        files[str(path)] = value
        return value

    def retain(path, expected=None):
        value = checked(path, expected)
        payload = Path(path).read_bytes()
        require(comp.ordinary(path) == value['identity'], 'proof changed during retention')
        return retain_bytes(str(path), payload, value['sha256'])

    def read(path, expected=None):
        return json.loads(retain(path, expected))

    def command(argv, cwd=SOURCE):
        require(argv[:1] == ['git'] and argv[1:3] in
            [['rev-parse', 'HEAD'], ['diff', 'HEAD'], ['ls-files', '--stage']], 'only recorded Git source guards allowed')
        out = WORK / 'commands' / f'{len(record["commands"]):03}'
        out.mkdir(parents=True)
        process, stdout, stderr = capture(argv, cwd=cwd, env=environment,
            receipt_path=out / 'receipt.json', receipt=dict(environment=environment))
        for name, text in [('stdout', stdout), ('stderr', stderr)]:
            (out / name).write_text(text)
        record['commands'].append(dict(path=str(out / 'receipt.json'), sha256=sha(out / 'receipt.json'),
            command=argv, cwd=str(cwd), pid=process.pid, returncode=process.returncode,
            stdout_sha256=sha(out / 'stdout'), stderr_sha256=sha(out / 'stderr')))
        save()
        require(process.returncode == 0 and not stderr, 'read-only Git source guard failed')
        return dict(stdout=stdout, stderr=stderr)

    save()
    try:
        with owned.workload_lock(LOCK, 600):
            check_sources()
            record.update(status='inspecting', admitted_at=time.time(), free_bytes_before=capacity())
            save()
            retain(FROZEN, frozen_sha)
            for path, expected in frozen['files'].items():
                retain(path, expected)
            failed01 = read(FAILED01)
            for path, expected in failed01['files'].items():
                retain(path, expected)
            failed_summary = read(failed01['summary'])
            failed_outer = read(failed01['supervisor'])
            require(failed_summary['status'] == 'failed' and failed_summary['commands'] == []
                    and failed_summary['error'] == failed01['error']
                    and failed_outer['status'] == 'finished' and failed_outer['returncode'] == 1
                    and failed_outer['child_pid'] == failed_summary['pid'] == 83091
                    and failed_outer['supervisor_pid'] == failed_summary['parent_pid'] == 83088,
                    'original failed inspection01 association changed')
            record['failed01'] = dict(binding=str(FAILED01), sha256=sha(FAILED01),
                summary=failed01['summary'], error=failed_summary['error'], files=len(failed01['files']))
            failed02 = read(FAILED02)
            for path, expected in failed02['files'].items():
                retain(path, expected)
            failed_summary02 = read(failed02['summary'])
            failed_outer02 = read(failed02['supervisor'])
            require(failed_summary02['status'] == 'failed' and len(failed_summary02['commands']) == 5
                    and failed_summary02['error'] == failed02['error'] == 'RuntimeError(\'duplicate compiler option: --crate-type\')'
                    and failed_outer02['status'] == 'finished' and failed_outer02['returncode'] == 1
                    and failed_outer02['child_pid'] == failed_summary02['pid'] == 44065
                    and failed_outer02['supervisor_pid'] == failed_summary02['parent_pid'] == 44062,
                    'original failed inspection02 association changed')
            record['failed02'] = dict(binding=str(FAILED02), sha256=sha(FAILED02),
                summary=failed02['summary'], error=failed_summary02['error'], files=len(failed02['files']))
            proposal = read(HERE / 'INSPECTION.json')
            inputs = read(proposal['inputs']['path'], proposal['inputs']['sha256'])
            controls = read(CONTROLS / 'summary.json', CONTROL_SHA)
            control_freeze = read(CONTROLS / 'frozen-inputs.json', controls['frozen_inputs_sha256'])
            require(controls['status'] == 'passed' and controls['tests'] == 8
                    and control_freeze['files'].items() <= frozen['files'].items(), 'eight frozen compositor controls required')
            snapshots = read(CONTROLS / 'source-snapshots.json', controls['source_snapshots_sha256'])
            for origin, item in snapshots.items():
                require(item['sha256'] == control_freeze['files'][origin], 'control snapshot identity differs')
                retain(item['path'], item['sha256'])
            require(set(snapshots) == set(control_freeze['files']), 'control snapshot omitted')
            child = read(CONTROLS / 'command/receipt.json', controls['command_receipt_sha256'])
            require(child['status'] == 'finished' and child['returncode'] == 0
                    and child['command'] == control_freeze['command'], 'control child differs')
            control_text = ''.join(retain(CONTROLS / 'command' / name, child[name + '_sha256']).decode()
                                   for name in ['stdout', 'stderr'])
            require(sorted(re.findall(r'^test_[^\n]* \(([^)]+)\) \.\.\. ok$', control_text, re.M))
                    == control_freeze['required_tests'], 'named control results differ')
            outer_dir = OWNER / '.work/experiments/embedded-compositor-controls-supervisor-01'
            outer = read(outer_dir / 'status.json')
            require(outer['status'] == 'finished' and outer['returncode'] == 0
                    and outer['child_pid'] == controls['pid'] == 85382
                    and outer['supervisor_pid'] == controls['parent_pid'] == 85379, 'control supervisor differs')
            retain(outer_dir / 'plan.json', outer['plan_sha256'])
            retain(outer_dir / 'command.log', outer['log_sha256'])
            retain(outer_dir / 'supervisor.log')
            stage2 = load('embedded_inspector_stage2', STAGE2 / 'experiments/hir-stage2-package/check.py')
            for module in list(sys.modules.values()):
                path = getattr(module, '__file__', None)
                if path and str(path).startswith('/Users/danluu/dev/rust-interp'):
                    require(str(Path(path).resolve()) in frozen['files'], 'unfrozen imported local helper: ' + path)
            require(stage2.inputs() == proposal['guard_reuse']['helper_inputs'], 'complete135 helper closure changed')
            stage_plan = read(proposal['guard_reuse']['materialized_stage2_plan']['path'],
                              proposal['guard_reuse']['materialized_stage2_plan']['sha256'])
            q = stage2.qualified
            archive = q.Archive(stage2.native, q.ARCHIVE_PATHS)
            prior = stage2.previous(q.REPLAY_PLAN, q.REPLAY_PLAN_SHA, q.TERMINAL, q.SUPERVISOR, archive)
            require(prior == stage_plan['previous'] and prior['actual_complete_direct_replay']
                    and prior['source']['revision'] == proposal['source_revision'] == q.SOURCE_REVISION,
                    'qualified native/source history differs')
            stage2.verify_references(prior)
            for path, expected in archive.hashes.items():
                checked(path, expected)
            for kind in ['manifest', 'summary']:
                retain(archive.paths[kind], archive.hashes[archive.paths[kind]])
            for history in prior['historical_archives']:
                for path, expected in history['hashes'].items():
                    checked(path, expected)
                for kind in ['manifest', 'summary']:
                    retain(history['paths'][kind], history['hashes'][history['paths'][kind]])
            # Exact archived bytes, never live substitution for historical logs.
            for path, expected in prior['files'].items():
                retain_bytes(path, archive.read(path, expected), expected, archive.hashes[archive.paths['archive']])
            source_record = read(inputs['source_record']['path'], inputs['source_record']['sha256'])
            require(source_record == prior['source'], 'source record differs from native qualification')
            environment = prior['old_plan']['environment']
            record['source_guard_environment'] = environment
            # This older plan belongs to the explicitly qualified failed-upgrade
            # archive, not the newest native archive. Never read a live plan as
            # a substitute for missing historical evidence.
            references = [item for item in prior['historical_archives']
                          if item['paths']['archive'] == str(OLD_PLAN_ARCHIVE)]
            require(len(references) == 1, 'exact older plan archive reference required')
            reference = references[0]
            require(reference['hashes'][str(OLD_PLAN_ARCHIVE)] == OLD_PLAN_ARCHIVE_SHA
                    and reference['required'].get(prior['old_plan_path']) == OLD_PLAN_SHA,
                    'older plan reference hash changed')
            old_manifest = read(reference['paths']['manifest'], reference['hashes'][reference['paths']['manifest']])
            old_member = prior['old_plan_path'].lstrip('/')
            require(old_manifest[old_member] == dict(source=prior['old_plan_path'],
                bytes=9632, sha256=OLD_PLAN_SHA), 'older plan member association changed')
            # verify_references above validates every member of this exact tar.
            # Select this one explicitly and still require unique membership.
            with tarfile.open(OLD_PLAN_ARCHIVE, 'r:gz') as tar:
                matches = [member for member in tar if member.name == old_member]
                require(len(matches) == 1 and matches[0].isfile(), 'older plan member missing or ambiguous')
                old_plan_bytes = tar.extractfile(matches[0]).read()
            require(len(old_plan_bytes) == 9632 and digest(old_plan_bytes) == OLD_PLAN_SHA
                    and json.loads(old_plan_bytes) == prior['old_plan'], 'older plan bytes/content changed')
            retain_bytes(prior['old_plan_path'], old_plan_bytes, OLD_PLAN_SHA, OLD_PLAN_ARCHIVE_SHA)
            old_plan_sha = OLD_PLAN_SHA
            stage2.engine.source_guard(source_record, command, old_plan_sha)
            retain(SOURCE / 'bootstrap.toml', source_record['config_sha256'])
            retain(SOURCE / '.rust-interp-owned.json')
            require(stage2.native.artifacts() == prior['stage1'], 'qualified E runtime changed')
            for path, item in prior['stage1']['files'].items():
                checked(BUILD / 'stage1' / path, item['sha256'])
            write_json(WORK / 'qualified-runtime.json', prior['stage1'])
            producer = proposal['native005']
            produced = read(producer['path'], producer['sha256'])
            require(produced['status'] == 'finished' and produced['returncode'] == 0
                    and produced['command'] == producer['command'] and produced['cwd'] == str(SOURCE)
                    and produced['environment'] == environment, 'native005 producer changed')
            raw = {}
            for name in ['stdout', 'stderr']:
                path = Path(producer['path']).parent / name
                raw[name] = retain(path, produced[name + '_sha256'])
                require(raw[name] == archive.read(path, produced[name + '_sha256']), 'native005 differs from archive')
            rows = cargo_rows(raw['stderr'].decode())
            write_json(WORK / 'native005-producers.json', rows)
            record['native005'] = dict(receipt=producer, running=len(rows['commands']), fresh=len(rows['fresh']))
            stamp_path = Path(proposal['stamp_path'])
            stamp = retain(stamp_path)
            require(len(stamp) <= 16 * 1024**2, 'unexpected stamp size')
            write_json(WORK / 'raw-stamp.json', dict(file=files[str(stamp_path)], hex=stamp.hex(),
                       terminated=stamp.endswith(b'\0'), rows=raw_stamp(stamp)))
            (WORK / 'stamp.bin').write_bytes(stamp)
            require(sha(WORK / 'stamp.bin') == files[str(stamp_path)]['sha256'], 'raw stamp retention failed')
            stamp_rows = raw_stamp(stamp)
            candidate, destinations, warnings = {}, {}, []
            modified = files[str(stamp_path)]['identity']['mtime_ns'] / 1_000_000_000
            record['stamp_time_association'] = dict(mtime=modified,
                native005_started=produced['started_at'], native005_finished=produced['finished_at'],
                within_native005=produced['started_at'] <= modified <= produced['finished_at'],
                interpretation='supporting timestamp only; complete archived later history retained')
            if not record['stamp_time_association']['within_native005']:
                warnings.append('stamp mtime outside native005; inspect retained subsequent bootstrap history')
            if not stamp or not stamp.endswith(b'\0'):
                warnings.append('empty or unterminated stamp')
            for row in stamp_rows:
                text = row['source']
                path = Path(text) if text else None
                if not path or not path.is_absolute() or str(path) != text or '..' in path.parts or '\0' in text:
                    row['errors'].append('noncanonical absolute source')
                elif not path.is_relative_to(BUILD):
                    row['errors'].append('source outside exact owned compiler build root; not read')
                if row['errors']:
                    continue
                try:
                    file = checked(path)
                except (RuntimeError, ValueError, OSError) as error:
                    row['errors'].append('ordinary artifact read rejected: ' + repr(error))
                    continue
                destination = f'lib/rustlib/{HOST}/lib/' + ('self-contained/' if row['tag'] == 's' else '') + path.name
                row.update(file=file, destination=destination, evidence=evidence_for(path, rows))
                if str(path) in candidate or destination in destinations:
                    row['errors'].append('duplicate source or destination')
                if not any(path.is_relative_to(root) for root in
                           [comp.TREE / 'release', comp.TREE / HOST / 'release']):
                    row['errors'].append('outside current compositor roots; explicit recipe review required')
                candidate[str(path)] = dict(sha256=file['sha256'], size=file['size'])
                destinations[destination] = str(path)
                # Save every classified row as inspection progresses; no missing
                # member is replaced by a convenient same-name artifact.
                write_json(WORK / 'stamp-artifacts.json', stamp_rows)
            write_json(WORK / 'stamp-artifacts.json', stamp_rows)
            write_json(WORK / 'candidate-private-files.json', candidate)
            archive_records, beta_rows = [], {}
            for name, item in proposal['archives'].items():
                path = Path(item['owned_copy'])
                archive_record = checked(path, item['sha256'])
                members = []
                try:
                    with tarfile.open(path, 'r:xz') as tar:
                        for member in tar:
                            members.append(dict(name=member.name, type=member.type.decode('ascii'),
                                size=member.size, mode=member.mode, linkname=member.linkname,
                                pax_headers=member.pax_headers))
                finally:
                    write_json(WORK / (name + '.members.json'), dict(file=archive_record, members=members))
                checked(path, item['sha256'])
                archive_records.append(comp.archive_rows(dict(path=str(path), sha256=item['sha256']), beta_rows))
            write_json(WORK / 'beta-archive-selection.json', archive_records)
            write_json(WORK / 'beta-library-files.json', beta_rows)
            compiler = checked(Path(proposal['build_compiler_path']))
            beta_name = 'rustc-beta-' + HOST + '.tar.xz'
            beta_path = Path(proposal['archives'][beta_name]['owned_copy'])
            member_name = beta_name[:-len('.tar.xz')] + '/rustc/bin/rustc'
            with tarfile.open(beta_path, 'r:xz') as tar:
                matches = [member for member in tar if member.name == member_name]
                require(len(matches) == 1 and matches[0].isfile() and not matches[0].issparse(),
                        'ordinary original beta compiler archive member required')
                with tar.extractfile(matches[0]) as stream:
                    actual, size = comp.stream_hash(stream)
            require(actual == compiler['sha256'] and size == compiler['size'], 'D differs from pinned beta archive compiler')
            write_json(WORK / 'build-compiler.json', dict(file=compiler, archive=str(beta_path),
                member=member_name, version_probe_run=False, default_sysroot_probe_run=False))
            overlaps = sorted(set(destinations) & set(beta_rows))
            if overlaps:
                warnings.append('beta/private destination collisions: ' + repr(overlaps))
            driver_path = BUILD / 'stage1' / inputs['embedded_runtime']['driver']
            driver = checked(driver_path, inputs['embedded_runtime']['files'][inputs['embedded_runtime']['driver']]['sha256'])
            matching = [row for row in stamp_rows if row.get('destination') == f'lib/rustlib/{HOST}/lib/' + driver_path.name]
            require(len(matching) == 1 and matching[0]['file']['sha256'] == driver['sha256'],
                    'full stamp link driver differs from qualified E driver')
            check_sources()
            stage2.engine.source_guard(source_record, command, old_plan_sha)
            require(stage2.native.artifacts() == prior['stage1'], 'E runtime changed during inspection')
            for path, item in list(files.items()):
                require(comp.check_file(item) == item, 'inspected input changed before completion: ' + path)
            counts = collections.Counter(kind for row in stamp_rows for kind in row.get('evidence', {}).get('classes', []))
            issues = [dict(index=row['index'], source=row['source'], errors=row['errors'])
                      for row in stamp_rows if row['errors']]
            write_json(WORK / 'retained-proofs.json', proofs)
            write_json(WORK / 'read-inputs.json', files)
            record.update(status='inspected-pending-review', finished_at=time.time(),
                free_bytes_after=capacity(), stamp_rows=len(stamp_rows), hashed_artifacts=len(candidate),
                classifications=dict(counts), row_issues=issues, warnings=warnings,
                source_unchanged=True, runtime_unchanged=True, imported_sources=len(frozen['files']),
                stamp_sha256=files[str(stamp_path)]['sha256'], beta_library_files=len(beta_rows),
                complete_map=len(candidate) == len(stamp_rows) and not issues,
                candidate_map_sha256=sha(WORK / 'candidate-private-files.json'),
                retained_proofs_sha256=sha(WORK / 'retained-proofs.json'),
                read_inputs_sha256=sha(WORK / 'read-inputs.json'),
                metadata_compatibility_checked=False, assembly_approved=False)
            save()
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        save()
        raise
    finally:
        write_json(WORK / 'retained-proofs.json', proofs)
        write_json(WORK / 'read-inputs.json', files)


if __name__ == '__main__':
    main()
