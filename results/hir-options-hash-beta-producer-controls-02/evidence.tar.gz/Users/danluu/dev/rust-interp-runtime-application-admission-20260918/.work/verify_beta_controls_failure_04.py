import hashlib,json,re,time
from pathlib import Path
A=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
D=A/'experiments/hir-options-hash-beta-controls-04'
W=A/'.work/hir-options-hash-beta-controls-04'
S=A/'.work/experiments/hir-options-hash-beta-controls-supervisor-04'
L=A/'.work/beta-controls-launch-execution-04'
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def stamp(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink]
assert sha(D/'launch.json')=='e559c1a82cba7a58415a37594e9917c2160af3e82fde60c02c3910395d7321ad'
assert sha(D/'inputs.json')=='d23086d3976197409833607dbe875c514f8da942208a407a127cd5cca08ab6cf'
f=read(D/'inputs.json');launch=read(D/'launch.json');r=read(W/'receipt.json');c=read(W/'command/receipt.json');o=read(S/'status.json');l=read(L/'record.json');t=read(W/'result.json')
for n,v in f['files'].items():
 p=Path(n);assert p.resolve(strict=True)==p and stamp(p)==v['stamp'] and sha(p)==v['sha256'] and stamp(p)==v['stamp'],n
for n,v in f['routes'].items():assert str(Path(n).resolve(strict=True))==v,n
assert l['status']=='finished' and l['returncode']==0 and l['command']==launch['command'] and l['environment']==launch['environment'] and l['cwd']==str(A)
for stream in ['stdout','stderr']:assert l[stream+'_sha256']==sha(L/stream)
hand=read(L/'stdout');assert hand['supervisor_pid']==o['supervisor_pid'] and hand['directory']==str(S)
assert o['status']=='finished' and o['returncode']==1 and o['command']==launch['command'][6:] and o['cwd']==str(A)
assert o['plan_sha256']==sha(S/'plan.json') and o['log_sha256']==sha(S/'command.log')
assert r['status']=='failed' and 'owned command failed' in r['error'] and r['pid']==o['child_pid'] and r['parent_pid']==o['supervisor_pid']
assert r['inputs_sha256']==sha(D/'inputs.json')
assert len(r['commands'])==1 and r['commands'][0]==dict(path=str(W/'command/receipt.json'),pid=c['pid'],sha256=sha(W/'command/receipt.json'))
assert c['status']=='finished' and c['returncode']==1 and c['command']==f['command'] and c['cwd']==str(A/'experiments/hir-options-hash-beta-composition-05') and c['environment']==f['environment']
assert c['supervisor_pid']==r['pid'] and c['parent_pid']==o['supervisor_pid']
assert c['identity']['ps_returncode']==c['identity']['cwd_returncode']==0
ps=c['identity']['ps'].split();assert list(map(int,ps[:3]))==[c['pid'],r['pid'],c['pid']]
assert c['identity']['ps'].endswith(' '.join(c['command'])) and 'n'+c['cwd']+'\n' in c['identity']['cwd']
assert o['child_started_at']<=r['started_at']<=r['admitted_at']<=c['started_at']<=c['finished_at']<=r['finished_at']<=o['finished_at']
for stream in ['stdout','stderr']:assert c[stream+'_sha256']==sha(W/'command'/stream)
raw=(W/'command/stderr').read_text();names=re.findall(r'^test_[A-Za-z0-9_]+ \(([^)]+)\) \.\.\. ok$',raw,re.M)
assert sorted(names)==sorted(n for n in f['expected_names'] if not n.endswith('test_complete_saved_actual_catalog_has_all_256_final_private_producers')) and len(names)==92
assert f['expected_names']==t['expected_names']
assert re.search(r'^Ran 93 tests in [0-9.]+s\n\nFAILED \(errors=1\)\n',raw,re.M) and not (W/'command/stdout').read_bytes()
assert t['status']=='failed' and t['tests_run']==93 and t['errors']==1 and all(t[k]==0 for k in ['failures','skipped','expected_failures','unexpected_successes','child_processes','compiler_calls'])
assert 'ValueError: require one compiler option: --crate-type' in raw
assert all(r[k]==0 for k in ['compiler_calls','provider_probes','B3_compositions']) and not list((W/'tmp').iterdir())
assert r['free_bytes_before']>=16*2**30
proof=dict(status='verified-retained-failure',passed=92,errors=1,finished_at=time.time(),controls=93,input_files=len(f['files']),input_bytes=sum(v['stamp'][3] for v in f['files'].values()),receipt_sha256=sha(W/'receipt.json'),result_sha256=sha(W/'result.json'),raw_sha256={s:sha(W/'command'/s) for s in ['stdout','stderr']},supervisor_pid=o['supervisor_pid'],helper_pid=r['pid'],test_pid=c['pid'],exact_names=names,compiler_calls=0,provider_probes=0,process_signals=0,observed_context='Synthetic and exact retained-source/raw-format controls; no new compiler or provider calls',verifier_sha256=sha(Path(__file__)))
out=A/'.work/beta-controls-failure-independent-verification-04.json'
with out.open('x') as f:json.dump(proof,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(dict(path=str(out),sha256=sha(out),receipt_sha256=proof['receipt_sha256'])))
