from pathlib import Path
import gzip,hashlib,io,json,os,stat,tarfile,time
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913');X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918');O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
H=ROOT/'experiments/proc-macro-arena-ruff-screen-02';E=ROOT/'results/proc-macro-arena-ruff-screen-02';W=ROOT/'.work/proc-macro-arena-ruff-screen-02'
P=ROOT/'results/proc-macro-arena-ruff-screen-02-publication';FIELDS=('dev','ino','mode','nlink','size','mtime_ns','ctime_ns')
def stamp(p):s=p.lstat();return {k:getattr(s,'st_'+k) for k in FIELDS}
def read(p):return json.loads(p.read_bytes())
def row(p):
 assert p.is_absolute() and p.resolve(strict=True)==p;s=stamp(p);assert stat.S_ISREG(s['mode']) and s['size']<=8*2**20
 b=p.read_bytes();assert stamp(p)==s and len(b)==s['size'];return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),identity=s)
def save(p,d):
 b=(json.dumps(d,sort_keys=True,indent=2)+'\n').encode();assert len(b)<=2**20
 with p.open('xb') as f:f.write(b)
def ref(p):return dict(path=str(p),**row(p))
assert not P.exists()
plan=read(H/'plan.json');proof=X/'.work/proc-macro-arena-ruff-screen02-failure-independent-readback-01.json';audit=read(proof)
assert row(proof)['sha256']=='a7aa1809703a78846e8ae6cc4533e8cc349837316e94df421421416635ca55a7'
assert audit['status']=='verified-failed-screen-before-timing' and audit['timed_calls']==0
selected=set()
for base in [H,E]:
 for root,dirs,files in os.walk(base,followlinks=False):
  for name in dirs:assert (Path(root)/name).resolve(strict=True)==Path(root)/name
  for name in files:selected.add(Path(root)/name)
assert len([p for p in selected if p.is_relative_to(E)])==55
selected.update([proof,X/'.work/verify_ruff_screen02_failure_01.py',X/'.work/proc-macro-arena-ruff-screen02-source-handoff-01.json',X/'.work/proc-macro-arena-ruff-screen02-source-handoff-02.json',X/'.work/verify_ruff_screen02_saved_01.py',X/'.work/proc-macro-arena-ruff-screen02-saved-reader-source-handoff-01.json',
 ROOT/'.work/proc-macro-arena-ruff-screen02-root-review-01.json',ROOT/'.work/proc-macro-arena-ruff-screen-invocation-02.json',
 O/'.work/ruff-screen01-cargo-layout-source-review-01.json',W/'contexts/stock.json',Path(__file__).absolute(),Path(plan['source_inventory']['path'])])
for r in [*plan['reference_sources'],*plan['probe_source_references'],*plan['proc_macro2_probe_sources'].values()]:
 p=Path(r['path']);assert row(p)['sha256']==r['sha256'];selected.add(p)
assert row(ROOT/'.work/proc-macro-arena-ruff-screen02-root-review-01.json')['sha256']=='ab3c3a1e6464e7179db329e6acdf4887d89566d44815dde82cd5d7616d34c9d9'
assert all(not p.is_relative_to(W/'source') and not p.is_relative_to(W/'target') for p in selected)
rows={str(p):row(p) for p in sorted(selected)};logical=sum(r['bytes'] for r in rows.values());assert len(rows)<=128 and logical<=24*2**20
P.mkdir();archive=P/'evidence.tar.gz'
with archive.open('xb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w|') as tar:
   for name,r in rows.items():
    p=Path(name);assert row(p)==r;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256']
    item=tarfile.TarInfo(name.lstrip('/'));item.size=len(b);item.mode=stat.S_IMODE(r['identity']['mode']);item.mtime=r['identity']['mtime_ns']//10**9
    item.uid=0;item.gid=0;item.uname='';item.gname='';tar.addfile(item,io.BytesIO(b))
assert archive.stat().st_size<=4*2**20
# Complete compressed EOF first, then exact member-by-member payload verification.
uncompressed=0
with gzip.open(archive,'rb') as f:
 while block:=f.read(2**20):uncompressed+=len(block);assert uncompressed<=26*2**20
seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for item in tar:
  name='/'+item.name;assert item.isfile() and name in rows and name not in seen;seen.add(name)
  with tar.extractfile(item) as stream:b=stream.read(8*2**20+1)
  assert len(b)==rows[name]['bytes'] and hashlib.sha256(b).hexdigest()==rows[name]['sha256']
assert seen==set(rows)
for name,r in rows.items():assert row(Path(name))==r
manifest=dict(policy='portable-closed-Ruff-screen02-setup-refusal-v1',archive=ref(archive),member_count=len(rows),logical_bytes=logical,
 members={name.lstrip('/'):dict(original_path=name,**r) for name,r in rows.items()},
 external=dict(copied_Ruff_source=str(W/'source'),fresh_failed_Cargo_target=str(W/'target'),canonical_Ruff_source=plan['source_root'],
 source_payloads='excluded; complete acquired source inventory and producer current source tables retained as metadata',
 compiler_and_Cargo_binaries='excluded; exact original invocation and prior passed N overlay provenance remain authoritative',
 original_WORK_and_providers='preserved unchanged; no retirement or reuse authority'))
save(P/'manifest.json',manifest)
summary=dict(status='published-closed-screen-setup-refusal',observed_at=time.time(),source=str(H),actual_results=str(E),independent_failure_readback=ref(proof),
 actual_execution_sha256=audit['execution']['sha256'],parent_pid=22262,parent_exit_observed_by_root=1,cargo_pid=76979,cargo_returncode=101,
 native_query_children=[77600,77694,77696],native_query_returncodes=[0,0,0],native_crate_children=[77764],native_crate_returncodes=[0],wrapper_refusal_pid=77846,
 reason='wrapper rejected normal no-suffix Cargo build-script binary before its compiler spawn',crate_compilations=1,timed_calls=0,source_edits=0,
 performance_claim=False,qualification_passed=False,archive=ref(archive),manifest=ref(P/'manifest.json'),preserved_originals=True)
save(P/'summary.json',summary)
save(P/'READBACK.json',dict(status='verified',full_gzip_EOF=True,all_members_read_to_EOF=True,all_member_hashes_match=True,
 current_selected_sources_raw_stamps_and_bytes_unchanged=True,members=len(rows),logical_bytes=logical,gzip_bytes=archive.stat().st_size,uncompressed_tar_bytes=uncompressed,
 archive=ref(archive),manifest=ref(P/'manifest.json'),summary=ref(P/'summary.json')))
(P/'README.md').write_text('This capsule preserves the second Ruff screen setup refusal. Cargo closed101 after three successful compiler queries and one successful unicode_ident crate compile. The next wrapper attempt rejected normal build_script_build arguments without an extra-filename suffix before spawning its compiler. No source edit, warmup, timing call or performance result occurred.\n\nAll55 closed evidence files, exact source/history, source inventories, invocation, root review and independent failure readback are retained. The unrun success reader is retained as source, never successful evidence. Ruff source-copy and binary payloads remain external, unchanged, and unused by any successor. Archive identities are historical original observations, not extracted-file identities. Full gzipEOF, every member hash and current selected stamps are verified. No Git, retry, cleanup or process control is performed.\n')
print(str(P));print('members',len(rows),'logical',logical,'gzip',archive.stat().st_size)
print('readback',row(P/'READBACK.json')['sha256']);print('summary',row(P/'summary.json')['sha256'])
