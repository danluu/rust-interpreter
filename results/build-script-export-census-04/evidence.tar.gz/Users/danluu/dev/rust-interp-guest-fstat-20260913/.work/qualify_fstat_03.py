#!/usr/bin/env python3
"""Owned fstat qualification with an independent SDK oracle. Frozen plan first; no benchmark or publication."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import shlex
import sys
import time

ROOT = Path('/Users/danluu/dev/rust-interp-guest-fstat-20260913')
WORK = ROOT / '.work/fstat-qualification-03'
TARGET = WORK / 'target'
PLAN = WORK / 'plan.json'
PUBLIC = Path('/Users/danluu/.rustup/toolchains/nightly-2026-09-08-aarch64-apple-darwin')
STD = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913/.work/std-mir/bd27cc0f910e0c93a9a6cf088789ef526d36a8697a7717e08d7585f5d19467ef')
PYTHON = Path('/opt/homebrew/bin/python3')
HOST = 'aarch64-apple-darwin'
CHECKPOINT = 'a8b93b65baed2a487efe6a6c8e6f7eba520149c6'
DOC_CHECKPOINT = CHECKPOINT
COMPILER = 'cea272fa356e94bd2ee2cadf376630aa0683867a'
POLICY = 'guest-fstat-sdk-native-qualification-v1'
CC = Path('/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang')
SDK = Path('/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk')
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'experiments/stable-cgu')]
import owned_stage as owned
import custom_cargo_libraries as loaders
import std_mir
from public_tool_publication import file_identity
from toolchain_lookup import _stamp
spec = importlib.util.spec_from_file_location('exporter_role_build_inputs', ROOT / 'benchmarks/experiments/host-proc-macro/build.py')
inputs = importlib.util.module_from_spec(spec); sys.modules[spec.name] = inputs; spec.loader.exec_module(inputs)
require, sha, write = owned.require, owned.sha, owned.write
ROLE_TESTS = [
    'separate_roles_accept_real_distinct_commits_and_reject_crossed_bindings',
    'actual_probe_must_match_named_role_without_version_substitution',
    'build_environment_rejects_wrong_compiler_flags_and_even_empty_overrides',
    'private_build_sysroot_cannot_be_overridden',
    'exhaustive_private_files_reject_missing_corrupt_extra_and_symlink_inputs',
    'binding_file_hash_and_schema_are_enforced',
    'runtime_default_and_loaded_image_checks_preserve_distinct_roles',
    'exporter_route_requires_runtime_compiler_and_rejects_build_compiler',
]
GETCWD_TESTS = [
    'getcwd::tests::disabled_partial_target_and_register_admission_precede_both_engines',
    'getcwd::tests::darwin::native_buffer_null_sizes_full_bytes_errno_and_owned_free_agree',
    'getcwd::tests::darwin::invalid_pointer_size_and_errno_fail_before_memory_or_host_errno_changes',
    'getcwd::tests::darwin::null_allocation_charges_live_count_register_and_byte_budgets_without_leaks',
]
STAT_TESTS = [
    'descriptor_io::stat_tests::stat_encoding_all_registers_and_capability_preflight_cover_both_engines',
    'descriptor_io::stat_tests::darwin::stat_full_native_bytes_named_metadata_size_changes_and_errno_agree',
    'descriptor_io::stat_tests::darwin::stat_invalid_memory_and_unmapped_or_closed_descriptors_preserve_output',
]
RUST_TESTS = ROLE_TESTS + GETCWD_TESTS + STAT_TESTS
PYTHON_TESTS = [
    'test_sdk_layout_full_bytes_named_fields_growth_errno_and_negative_expectations',
    'test_incompatible_fstat_signature_and_equal_size_layout_reject_before_export',
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ordinary(path):
    path = Path(path)
    require(path.is_absolute() and path.is_file() and not path.is_symlink()
            and path.resolve(strict=True) == path, 'expected ordinary file: ' + str(path))
    return path


def files(root):
    root = Path(root)
    require(root.is_dir() and root.resolve(strict=True) == root, 'expected ordinary directory: ' + str(root))
    found = []
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink(), 'unexpected source/artifact symlink: ' + str(p))
        if p.is_dir(): continue
        found.append(ordinary(p))
    return found


def environment():
    return dict(HOME='/Users/danluu', CARGO_HOME='/Users/danluu/.cargo', RUSTUP_HOME='/Users/danluu/.rustup',
        PATH=str(PUBLIC / 'bin') + ':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
        RUSTC=str(PUBLIC / 'bin/rustc'), RUSTDOC=str(PUBLIC / 'bin/rustdoc'),
        RUSTUP_TOOLCHAIN='nightly-2026-09-08-aarch64-apple-darwin', TMPDIR=str(WORK / 'tmp') + '/',
        LANG='C', LC_ALL='C', TZ='UTC', CARGO_TERM_COLOR='never', CARGO_NET_OFFLINE='true',
        PYTHONDONTWRITEBYTECODE='1')


def native_environment():
    return environment() | dict(RUST_INTERP_TEST_RUSTC=str(PUBLIC / 'bin/rustc'),
        RUST_INTERP_TEST_EXPORTER=str(TARGET / 'release/rust-interp-mir-export'),
        RUST_INTERP_TEST_VM=str(TARGET / 'release/rust-interp-vm'),
        RUST_INTERP_TEST_STD_SYSROOT=str(STD / 'sysroot'), RUST_INTERP_TEST_ARTIFACT_DIR=str(WORK / 'native'),
        RUST_INTERP_TEST_CC=str(CC.resolve(strict=True)), RUST_INTERP_TEST_SDK=str(SDK.resolve(strict=True)))


def commands():
    cargo = str(PUBLIC / 'bin/cargo')
    return [
        [cargo, 'test', '--workspace', '--release', '--locked', '--offline', '--jobs', '2', '--target-dir', str(TARGET), '--', '--test-threads=2'],
        [cargo, 'build', '--release', '--locked', '--offline', '--jobs', '2', '--target-dir', str(TARGET),
         '-p', 'rust-interp-bytecode', '-p', 'rust-interp-mir-export', '--bin', 'rust-interp-vm',
         '--bin', 'rust-interp-mir-export', '--bin', 'rust-interp-rustc-wrapper'],
        [str(TARGET / 'release/rust-interp-mir-export'), '--rust-interp-capabilities'],
        [str(TARGET / 'release/rust-interp-rustc-wrapper'), '--rust-interp-compiler-roles'],
        [str(PYTHON), '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_fstat_native.py', '-v'],
    ]


def source_paths():
    fixed = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'EXPORTER_COMPILER_ROLES.md',
             'tests/getcwd_fixture.rs', 'tests/test_getcwd_native.py', 'tests/test_descriptor_io_native.py',
             'tests/fstat_fixture.rs', 'tests/fstat_layout_oracle.c', 'tests/test_fstat_native.py',
             'docs/FSTAT.md', 'docs/GETCWD.md', 'scripts/supervise_experiment.py']
    paths = {ordinary(ROOT / name) for name in fixed} | set(files(ROOT / 'crates')) | {ordinary(Path(__file__))}
    # Freeze the actual imported local implementation closure, without invoking a publisher.
    for module in list(sys.modules.values()):
        name = getattr(module, '__file__', None)
        if name and Path(name).suffix == '.py' and Path(name).is_relative_to(ROOT):
            paths.add(ordinary(Path(name)))
    return sorted(paths)


def configs():
    config = inputs.configuration(environment())
    require(not config['files'] and not any(config['searches'].values()), 'Cargo configuration requires a separately reviewed recipe')
    for name in config['searches']:
        path = Path(name)
        for parent in path.parents:
            require(not parent.is_symlink(), 'Cargo search path contains a symlink: ' + str(parent))
    return config


def snapshot(paths, directory, index_name='source-inputs.json'):
    directory.mkdir(parents=True, exist_ok=False)
    rows = []
    index_path = directory.parent / index_name
    write(index_path, dict(complete=False, files=rows))
    for index, path in enumerate(paths):
        owned.disk(ROOT)
        row = file_identity(ordinary(path)); data = path.read_bytes()
        require(digest(data) == row['sha256'] and _stamp(path) == row['stamp'], 'input changed during snapshot')
        dest = directory / f'{index:04d}'
        dest.write_bytes(data)
        rows.append(dict(**row, snapshot=str(dest)))
        write(index_path, dict(complete=False, files=rows))
    write(index_path, dict(complete=True, files=rows))
    return rows


def guard_records(records, *, full=False):
    for record in records:
        path = Path(record['path'])
        require(_stamp(path) == record['stamp'], 'input stamp changed: ' + str(path))
        if full: require(file_identity(path) == {k:v for k,v in record.items() if k != 'snapshot'}, 'input bytes changed: ' + str(path))
        if 'snapshot' in record:
            require(sha(ordinary(record['snapshot'])) == record['sha256'], 'retained source snapshot changed')


def std_proof(version):
    ready_path = ordinary(STD / 'ready.json')
    ready = json.loads(ready_path.read_bytes()); identity = ready['identity']
    require(ready['owner'] == '/Users/danluu/dev/rust-interp-semantic-reuse-20260913'
            and set(identity) == {'policy', 'compiler', 'target', 'flags', 'lock_sha256'}
            and identity['policy'] == std_mir.POLICY and identity['flags'] == std_mir.FLAGS
            and identity['target'] == HOST and identity['compiler'] == version
            and re.fullmatch('[0-9a-f]{64}', identity['lock_sha256'])
            and digest(json.dumps(identity, sort_keys=True).encode()) == STD.name,
            'prepared public std identity differs')
    require(re.fullmatch('[0-9a-f]{64}', ready['source_sha256'])
            and len(ready['artifacts']) == 26, 'prepared std source/artifact receipt incomplete')
    expected = {str(STD / name) for name in ready['artifacts']}
    require(expected == {str(p) for p in files(STD / 'sysroot')}, 'prepared std has a different exact inventory')
    library = Path('sysroot/lib/rustlib') / HOST / 'lib'
    for crate in ['core', 'alloc', 'std', 'test', 'proc_macro']:
        require(sum(Path(name).parent == library and re.fullmatch('lib' + crate + r'-[0-9a-f]+\.rmeta', Path(name).name) is not None
                    for name in ready['artifacts']) == 1, 'required prepared std metadata missing: ' + crate)
    records = [file_identity(ready_path)]
    for name, row in sorted(ready['artifacts'].items()):
        path = ordinary(STD / name)
        require(path.is_relative_to(STD / library) and path.suffix == '.rmeta'
                and std_mir.stamp(path) == row['stamp'] and sha(path) == row['sha256'], 'prepared std artifact changed')
        records.append(file_identity(path))
    require(sha(PUBLIC / 'lib/rustlib/src/rust/library/Cargo.lock') == identity['lock_sha256'],
            'prepared std library lock differs from selected compiler component')
    return dict(path=str(STD), ready_sha256=sha(ready_path), ready=ready, files=records)


def rust_results(text):
    for name in RUST_TESTS:
        require(len(re.findall(r'^test ' + re.escape(name) + r' \.\.\. ok$', text, re.M)) == 1,
                'required merged Rust test did not pass once: ' + name)
    rows = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
    require(rows and all(int(failed) == int(measured) == int(filtered) == 0 for _,failed,_,measured,filtered in rows),
            'workspace summaries incomplete or filtered')
    return dict(suites=len(rows), passed=sum(int(row[0]) for row in rows), ignored=sum(int(row[2]) for row in rows),
                failed=0, filtered=0, compiler_role_tests=ROLE_TESTS, getcwd_tests=GETCWD_TESTS, stat_tests=STAT_TESTS)


def c_dependencies(data, target, source, sdk, resource):
    text = data.decode('utf-8')
    require('\0' not in text and text.endswith('\n'), 'malformed C dependency file')
    head, separator, body = text.replace('\\\n', ' ').partition(':')
    require(separator and head == str(target), 'C dependency target differs')
    names = shlex.split(body, comments=False, posix=True)
    require(names and len(names) == len(set(names)) and str(source) in names,
            'C dependency source/uniqueness differs')
    result = []
    for name in names:
        path = Path(name)
        require(path.is_absolute(), 'relative C dependency')
        resolved = ordinary(path.resolve(strict=True))
        if path == source:
            require(resolved == ordinary(source), 'C source dependency route changed')
            continue
        require(resolved.is_relative_to(sdk) or resolved.is_relative_to(resource),
                'C dependency outside selected SDK/compiler resources: ' + name)
        result.append(dict(path=str(path), resolved=str(resolved)))
    require(result, 'empty C header closure')
    return sorted(result, key=lambda r:r['path'])


def native_results(command_record, text, c_oracle):
    require(re.search(r'(?m)^Ran 2 tests in [0-9.]+s$', text) and re.search(r'(?m)^OK$', text)
            and 'skipped' not in text, 'native Python suite did not pass exactly two tests without skips')
    for name in PYTHON_TESTS:
        require(len(re.findall(r'^' + name + r' \(test_fstat_native\.FstatNativeTests\.' + name + r'\) \.\.\. ok$', text, re.M)) == 1,
                'required fstat Python test did not pass once: ' + name)
    nested_env = {k: environment()[k] for k in ['PATH', 'HOME', 'TMPDIR', 'LC_ALL', 'LANG', 'TZ']}
    rustc, exporter, vm = [str(Path(p).resolve(strict=True)) for p in [PUBLIC / 'bin/rustc', TARGET / 'release/rust-interp-mir-export', TARGET / 'release/rust-interp-vm']]
    cc, sdk = Path(c_oracle['compiler']['resolved']), Path(c_oracle['sdk'])
    fixture = (ROOT / 'tests/fstat_fixture.rs').read_bytes()
    offsets = [0,4,6,8,16,20,24,32,40,48,56,64,72,80,88,96,104,112,116,120,124,128,136]
    widths = [4,2,2,8,4,4,4,8,8,8,8,8,8,8,8,8,8,4,4,4,4,8,8]
    rows, observations = [], []
    for index, name in enumerate(PYTHON_TESTS):
        root = WORK / 'native' / name
        count = 42 if index == 0 else 7
        require(sorted(p.name for p in root.glob('command-*.json')) == [f'command-{i:03}.json' for i in range(1,count+1)], 'nested command inventory differs')
        def read(i, argv, cwd=None, extra=None, success=True, diagnostic=None):
            path = root / f'command-{i:03}.json'; row = json.loads(ordinary(path).read_bytes())
            require(row['command'] == list(map(str, argv)) and row['cwd'] == str(cwd or root)
                    and row['environment'] == nested_env | dict(extra or {}) and row['status'] == 'finished'
                    and row['parent_pid'] == command_record['pid'] and isinstance(row['pid'], int) and row['pid'] > 0
                    and command_record['started_at'] <= row['started_at'] <= row['finished_at'] <= command_record['finished_at']
                    and (row['returncode'] == 0 if success else row['returncode'] != 0), 'nested command route/outcome changed')
            if rows and Path(rows[-1]['path']).parent == root:
                require(rows[-1]['finished_at'] <= row['started_at'], 'native child histories overlap or are reordered')
            payload = {}
            for stream in ['stdout','stderr']:
                p = root / f'command-{i:03}.{stream}'
                require(row[stream]['path'] == str(p) and sha(ordinary(p)) == row[stream]['sha256'], 'nested raw output differs')
                payload[stream] = p.read_bytes()
            require(b'internal compiler error' not in payload['stderr'], 'nested compiler panicked')
            if diagnostic: require(diagnostic in payload['stderr'], 'expected negative diagnostic missing')
            rows.append(dict(path=str(path), sha256=sha(path), **row))
            return (row['returncode'], payload['stdout'], payload['stderr'])
        def export(i, source, artifact, **kwargs):
            return read(i, [exporter, source, '--crate-name', 'descriptor_io_fixture', '--edition=2024', '--emit=metadata',
                '--sysroot', STD / 'sysroot', '-Copt-level=0', '-o', artifact.with_suffix('.rmeta')],
                extra=dict(RUST_INTERP_ENTRY='rust_interp_entry', RUST_INTERP_OUTPUT=str(artifact), RUST_INTERP_DEMAND_BODIES='0', RUST_INTERP_DEMAND_CACHE='0'), **kwargs)
        def pair(i, folder, expected):
            source, native, artifact = folder / 'fixture.rs', folder / 'native', folder / 'fixture.rbc'
            expected_source = (f'const EXPECTED_BYTES: [u8; 144] = {expected["bytes"]!r};\n'
                f'const EXPECTED_FIELDS: [u128; 23] = {expected["fields"]!r};\n'
                f'const EXPECTED_RETURN: i32 = {expected["returncode"]};\n'
                f'const EXPECTED_ERRNO: i32 = {expected["errno"]};\n')
            require(ordinary(source).read_bytes() == fixture
                    and ordinary(folder / 'expected.rs').read_bytes() == expected_source.encode()
                    and ordinary(folder / 'oracle-expectation.json').read_bytes() == (json.dumps(expected,sort_keys=True,indent=2)+'\n').encode(),
                    'actual fixture/expectation source differs from independent native oracle')
            read(i, [rustc, source, '--edition=2024', '-Copt-level=0', '-o', native]); export(i+1, source, artifact)
            ordinary(native); ordinary(artifact)
            return native, artifact
        if index == 0:
            oracle, c_source, depfile = root / 'oracle', root / 'oracle.c', root / 'oracle.d'
            require(ordinary(c_source).read_bytes() == (ROOT / 'tests/fstat_layout_oracle.c').read_bytes(), 'SDK oracle source changed')
            read(1, [cc, '-isysroot', sdk, '-std=c11', '-Wall', '-Wextra', '-Werror', '-MD', '-MF', depfile, c_source, '-o', oracle])
            require(c_dependencies(ordinary(depfile).read_bytes(), oracle, c_source, sdk, Path(c_oracle['resource_directory'])) == c_oracle['header_routes'],
                    'actual compiled oracle header closure differs from frozen metadata')
            layout = read(2, [oracle, '--layout'])
            require(layout[2] == b'' and json.loads(layout[1]) == dict(size=144,align=8,offsets=offsets,widths=widths), 'SDK C stat layout differs')
            cwd = root / 'data'
            for phase, (start, contents) in enumerate([(3,b'abc'),(21,b'longer\0contents\xff')]):
                raw = read(start, [oracle, '--stat', cwd / 'data.bin'])
                require(raw[2] == b'', 'unexpected C oracle stderr')
                expected = json.loads(raw[1])
                require(set(expected) == {'returncode','errno','bytes','fields'} and expected['returncode'] == 0
                        and type(expected['errno']) is int and -(1<<31) <= expected['errno'] < 1<<31
                        and len(expected['bytes']) == 144 and all(type(n) is int and 0 <= n <= 255 for n in expected['bytes'])
                        and len(expected['fields']) == 23 and all(type(n) is int and 0 <= n < 1<<64 for n in expected['fields']), 'invalid actual oracle output')
                expected['fields'] = [n & ((1 << (8*width))-1) for n,width in zip(expected['fields'],widths)]
                require(expected['fields'] == [int.from_bytes(bytes(expected['bytes'][offset:offset+width]),'little') for offset,width in zip(offsets,widths)]
                        and expected['fields'][15] == len(contents), 'C named fields/raw bytes/phase size disagree')
                native, artifact = pair(start+1, root / f'phase-{phase}', expected)
                for mode in [0,1,2]:
                    i = start+3+mode*3
                    result = read(i, [native,mode], cwd=cwd)
                    require(result == (0,b'15\n',b''), 'native stat return/errno/bytes/fields mismatch')
                    for offset,engine in enumerate(['interpreter','jit'],start=1):
                        require(read(i+offset,[vm,'--guest-descriptor-io','--engine',engine,artifact,mode],cwd=cwd) == result,
                                'guest stat differs from native/oracle')
                if phase == 0:
                    for i,engine in [(15,'interpreter'),(18,'jit')]:
                        read(i,[vm,'--engine',engine,artifact,0],cwd=cwd,success=False,diagnostic=b'guest descriptor I/O is disabled')
                        for offset,mode in enumerate([10,11],start=1):
                            negative=read(i+offset,[vm,'--guest-descriptor-io','--engine',engine,artifact,mode],cwd=cwd,success=False)
                            require(any(s in negative[2] for s in [b'guest memory',b'address overflow',b'read-only guest']), 'invalid stat pointer lacked checked error')
                observations.append(dict(phase=phase,oracle_receipt=rows[start-1]['path'],oracle_stdout_sha256=digest(raw[1]),
                    expected=expected,source=file_identity(root/f'phase-{phase}'/'expected.rs'),artifact=file_identity(artifact)))
            for start,name,field,index,answer in [(33,'wrong-byte','bytes',96,11),(38,'wrong-field','fields',15,7)]:
                wrong=json.loads(json.dumps(expected));wrong[field][index]^=1
                native,artifact=pair(start,root/name,wrong)
                result=read(start+2,[native,0],cwd=cwd)
                require(result==(0,f'{answer}\n'.encode(),b''),'native expectation negative did not clear exactly one comparison bit')
                for offset,engine in enumerate(['interpreter','jit'],start=3):
                    require(read(start+offset,[vm,'--guest-descriptor-io','--engine',engine,artifact,0],cwd=cwd)==result,
                            'guest expectation negative differs from native')
            require(ordinary(cwd/'data.bin').read_bytes()==b'longer\0contents\xff','final task-owned data differs')
        else:
            declaration=fixture.decode().split('unsafe extern "C"')[0]
            cases=[
                ('fd-width','fn fstat(fd:i64,p:*mut Stat)->i32;','fstat(3, std::ptr::null_mut())',declaration,'C'),
                ('return-width','fn fstat(fd:i32,p:*mut Stat)->i64;','fstat(3, std::ptr::null_mut())',declaration,'C'),
                ('const-pointer','fn fstat(fd:i32,p:*const Stat)->i32;','fstat(3, std::ptr::null())',declaration,'C'),
                ('variadic','fn fstat(fd:i32,p:*mut Stat,...)->i32;','fstat(3, std::ptr::null_mut())',declaration,'C'),
                ('short-layout','fn fstat(fd:i32,p:*mut Stat)->i32;','fstat(3, std::ptr::null_mut())','#[repr(C)] struct Stat { value:u64 }\n','C'),
                ('equal-size-wrong-type','fn fstat(fd:i32,p:*mut Stat)->i32;','fstat(3, std::ptr::null_mut())',declaration.replace('dev: i32','dev: u32',1),'C'),
                ('unwind-abi','fn fstat(fd:i32,p:*mut Stat)->i32;','fstat(3, std::ptr::null_mut())',declaration,'C-unwind'),
            ]
            for i,(case,signature,call,structure,abi) in enumerate(cases,start=1):
                source,artifact=root/(case+'.rs'),root/(case+'.rbc')
                expected_source=structure+f'unsafe extern "{abi}" {{ {signature} }}\n'+f'pub fn rust_interp_entry()->u64 {{ unsafe {{ {call} as u64 }} }}\nfn main() {{}}\n'
                require(ordinary(source).read_bytes()==expected_source.encode(),'actual negative ABI source differs')
                export(i,source,artifact,success=False,diagnostic=b'invalid fstat signature')
                require(not artifact.exists(),'negative ABI export produced bytecode')
    chronological = sorted(rows,key=lambda row:row['started_at'])
    require(len(rows)==49 and all(a['finished_at']<=b['started_at'] for a,b in zip(chronological,chronological[1:])),
            'native history count/order/overlap differs')
    return dict(tests=2,children=rows,artifacts=[file_identity(p) for p in files(WORK/'native')],
        c_header_routes=c_oracle['header_routes'],oracle_observations=observations,
        comparisons='Independent SDK layout + actual raw bytes/named fields; native and both engines; two independently forged expectations rejected',
        file_history_limit='Final data bytes retained; earlier size phase is bound by raw oracle output and actual fixture assertions')


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('stage', choices=['plan', 'run'])
    parser.add_argument('--plan-sha256')
    args = parser.parse_args()
    require(Path(__file__).resolve() == ROOT / '.work/qualify_fstat_03.py' and Path.cwd() == ROOT,
            'fixed helper location/cwd required')
    require(sys.version_info >= (3,11) and Path(sys.executable).resolve() == PYTHON.resolve(strict=True), 'selected Python 3.11+ required')
    if args.stage == 'plan':
        WORK.mkdir(parents=True, exist_ok=False); (WORK / 'tmp').mkdir()
    else:
        require(re.fullmatch('[0-9a-f]{64}', args.plan_sha256 or '') and sha(ordinary(PLAN)) == args.plan_sha256,
                'reviewed plan SHA required')
    out = WORK / args.stage
    out.mkdir(exist_ok=False)
    receipt = dict(schema_version=1, policy=POLICY, owner=str(ROOT), stage=args.stage, status='waiting',
        pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(), commands=[])
    write(out / 'receipt.json', receipt)
    current = None
    initial_sources, initial_config, initial_index_sha = None, None, None
    def guard(full=False):
        owned.disk(ROOT, 9)
        if current is None:
            if initial_sources is not None:
                require(configs() == initial_config and [str(p) for p in source_paths()] == [r['path'] for r in initial_sources],
                        'source/config changed during metadata preparation')
                guard_records(initial_sources, full=full)
                require(sha(out / 'source-inputs.json') == initial_index_sha, 'source snapshot index changed')
            return
        require(WORK.resolve(strict=True) == WORK and (WORK / 'tmp').resolve(strict=True) == WORK / 'tmp'
                and (WORK / 'tmp').is_dir(), 'owned work/temporary directory changed')
        require(configs() == current['configuration'] and [str(p) for p in source_paths()] == [r['path'] for r in current['sources']], 'source/configuration set changed')
        require(sha(ordinary(current['source_index']['path'])) == current['source_index']['sha256'], 'source snapshot index changed')
        records = current['sources'] + current['public']['files'] + current['std']['files']
        records += [row for pkg in current['dependencies']['packages'] for row in pkg['files']]
        records += current['closure_files'] + current['c_oracle']['headers']
        require(sha(ordinary(current['c_oracle']['header_index']['path'])) == current['c_oracle']['header_index']['sha256'], 'C header snapshot index changed')
        require(sha(ordinary(current['c_oracle']['dependency_file']['path'])) == current['c_oracle']['dependency_file']['sha256'], 'C metadata depfile changed')
        require(str(CC.resolve(strict=True)) == current['c_oracle']['compiler']['resolved']
                and str(SDK.resolve(strict=True)) == current['c_oracle']['sdk'], 'C compiler/SDK route changed')
        public_names = {str(p) for p in (PUBLIC / 'lib').rglob('*') if p.is_file()
                        and p.suffix in ('.rlib', '.rmeta', '.dylib', '.so', '.dll')}
        require(public_names == set(current['public_library_paths']), 'public compiler/std library inventory changed')
        for package in current['dependencies']['packages']:
            base = Path(package['manifest_path']).parent
            expected = {row['path'] for row in package['files'] if Path(row['path']).is_relative_to(base)}
            require(expected == {str(p) for p in files(base)}, 'dependency source inventory changed: ' + str(base))
        require(sha(ordinary(current['cargo_metadata']['path'])) == current['cargo_metadata']['sha256'], 'retained Cargo resolution changed')
        require(sha(ordinary(WORK / 'plan/std-ready.json')) == current['std']['ready_sha256'], 'retained std receipt changed')
        for value in current['sdk']['directories'].values():
            path = Path(value['path'])
            require(str(path.resolve(strict=True)) == value['resolved'] and path.is_dir(), 'selected SDK/developer directory changed')
        for route in current['c_oracle']['header_routes']:
            require(str(Path(route['path']).resolve(strict=True)) == route['resolved'], 'C header route changed')
        guard_records(records, full=full)
        for closure in current['closures'].values():
            require(loaders.library_state(closure['identity']) == closure['state'], 'public loader state changed')
        require({str(p) for p in files(STD / 'sysroot')} == {r['path'] for r in current['std']['files'][1:]}, 'std inventory changed')
        if args.stage == 'run': require(sha(PLAN) == args.plan_sha256, 'reviewed plan changed')
    def command(argv, *, env=None, label='metadata'):
        guard(); directory = out / 'commands' / f'{len(receipt["commands"]):03d}'
        ref = dict(path=str(directory / 'receipt.json'), command=list(map(str, argv)), label=label)
        receipt['commands'].append(ref); write(out / 'receipt.json', receipt)
        try:
            row = owned.run(argv, cwd=ROOT, env=env or environment(), out=directory, capacity_root=ROOT)
        finally:
            if (directory / 'receipt.json').exists():
                ref['sha256'] = sha(directory / 'receipt.json'); write(out / 'receipt.json', receipt)
        guard()
        return row, (directory / 'stdout').read_bytes(), (directory / 'stderr').read_bytes()
    def closure(path):
        def inspect(argv, *, text):
            require(text is True, 'unexpected closure inspection mode')
            return command(argv, label='loader')[1].decode()
        identity, state = loaders.library_closure(path, HOST, inspect=inspect)
        return dict(identity=identity, state=state)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK, 600):
            receipt.update(status='running', admitted_at=time.time(), free_bytes_before=owned.disk(ROOT, 16 if args.stage == 'run' else 8))
            write(out / 'receipt.json', receipt)
            if args.stage == 'plan':
                source = snapshot(source_paths(), out / 'sources')
                config = configs()
                initial_sources, initial_config, initial_index_sha = source, config, sha(out / 'source-inputs.json')
                # Verify the complete production/crate tree and documentation, not only HEAD.
                prefixes = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'crates', 'EXPORTER_COMPILER_ROLES.md',
                    'tests/getcwd_fixture.rs', 'tests/test_getcwd_native.py', 'tests/test_descriptor_io_native.py',
                    'tests/fstat_fixture.rs', 'tests/fstat_layout_oracle.c', 'tests/test_fstat_native.py', 'docs/FSTAT.md', 'docs/GETCWD.md']
                _, raw, _ = command(['/usr/bin/git', 'ls-tree', '-rz', CHECKPOINT, '--', *prefixes])
                tree = {}
                for item in raw.split(b'\0'):
                    if not item: continue
                    meta, name = item.split(b'\t'); mode, kind, object_id = meta.split()
                    require(kind == b'blob' and mode in [b'100644', b'100755'], 'nonordinary production Git input')
                    tree[name.decode()] = (object_id.decode(), int(mode, 8))
                actual = {str(p.relative_to(ROOT)) for p in source_paths() if str(p.relative_to(ROOT)).startswith('crates/')} | set(prefixes) - {'crates'}
                require(set(tree) == actual, 'production source inventory differs from frozen checkpoint')
                for name, (object_id, mode) in tree.items():
                    data = ordinary(ROOT / name).read_bytes()
                    require(hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == object_id
                            and bool((ROOT / name).stat().st_mode & 0o100) == (mode == 0o100755),
                            'production source bytes or Git executable class differs: ' + name)
                _, doc, _ = command(['/usr/bin/git', 'show', DOC_CHECKPOINT + ':EXPORTER_COMPILER_ROLES.md'])
                require(doc == (ROOT / 'EXPORTER_COMPILER_ROLES.md').read_bytes(), 'qualification document changed')
                _, head, _ = command(['/usr/bin/git', 'rev-parse', 'HEAD'])
                public = inputs.compiler_inventory(PUBLIC)
                public_library_paths = [row['path'] for row in public['files'] if Path(row['path']).is_relative_to(PUBLIC / 'lib')
                                        and Path(row['path']).suffix in ('.rlib', '.rmeta', '.dylib', '.so', '.dll')]
                public['files'] += [file_identity(p) for p in [PYTHON, Path('/usr/bin/git'), Path('/usr/bin/otool'),
                                    Path('/usr/bin/xcrun'), Path('/usr/bin/xcode-select'), Path('/usr/bin/cc'), Path('/usr/bin/ld'), Path('/usr/bin/ar')]]
                sdk = dict(directories={}, tools={}, assumption='Exact C preprocessor header closure is frozen; remaining SDK contents are not a hermetic distribution')
                for name, argv in [('developer', ['/usr/bin/xcode-select', '-p']), ('sdk', ['/usr/bin/xcrun', '--show-sdk-path']),
                                   ('clang', ['/usr/bin/xcrun', '--find', 'clang']), ('ld', ['/usr/bin/xcrun', '--find', 'ld'])]:
                    _, raw_path, _ = command(argv)
                    path = Path(raw_path.decode().strip())
                    require(path.is_absolute(), 'SDK/tool selection returned a relative path')
                    if name in ('developer', 'sdk'):
                        require(path.is_dir(), 'selected SDK/developer directory missing')
                        sdk['directories'][name] = dict(path=str(path), resolved=str(path.resolve(strict=True)))
                    else:
                        row = file_identity(path); public['files'].append(row); sdk['tools'][name] = row
                require(str(CC.resolve(strict=True)) == sdk['tools']['clang']['resolved']
                        and str(SDK.resolve(strict=True)) == sdk['directories']['sdk']['resolved'], 'selected C compiler/SDK differs')
                _, cc_version, _ = command([CC.resolve(strict=True), '--version'], label='c-compiler-version')
                _, cc_host, _ = command([CC.resolve(strict=True), '-dumpmachine'], label='c-compiler-host')
                _, cc_resource, _ = command([CC.resolve(strict=True), '-print-resource-dir'], label='c-compiler-resource-dir')
                require(cc_version.startswith(b'Apple clang version ') and re.fullmatch(rb'(arm64|aarch64)-apple-darwin[0-9.]*\n', cc_host),
                        'actual C compiler is not the selected native Apple arm64 compiler')
                resource = Path(cc_resource.decode().strip())
                require(resource.is_absolute() and resource.is_dir(), 'compiler resource directory missing')
                resource = resource.resolve(strict=True)
                require(resource.is_relative_to(Path(sdk['directories']['developer']['resolved'])), 'compiler resources outside selected developer directory')
                sdk['directories']['clang-resource'] = dict(path=cc_resource.decode().strip(), resolved=str(resource))
                c_source, depfile, oracle_target = ROOT / 'tests/fstat_layout_oracle.c', out / 'oracle.d', out / 'oracle'
                c_argv = [CC.resolve(strict=True), '-isysroot', SDK.resolve(strict=True), '-std=c11', '-Wall', '-Wextra', '-Werror',
                    '-M', '-MF', depfile, '-MT', oracle_target, c_source]
                command(c_argv, label='c-header-dependencies')
                header_routes = c_dependencies(ordinary(depfile).read_bytes(), oracle_target, c_source, SDK.resolve(strict=True), resource)
                headers = snapshot(sorted({Path(row['resolved']) for row in header_routes}), out / 'headers', 'c-header-inputs.json')
                c_oracle = dict(compiler=file_identity(CC.resolve(strict=True)), sdk=str(SDK.resolve(strict=True)),
                    resource_directory=str(resource), versions=dict(clang=cc_version.decode(), host=cc_host.decode()),
                    dependency_command=list(map(str,c_argv)), dependency_file=dict(path=str(depfile),sha256=sha(depfile)),
                    header_index=dict(path=str(out/'c-header-inputs.json'),sha256=sha(out/'c-header-inputs.json')),
                    header_routes=header_routes, headers=headers, source_sha256=sha(c_source),
                    policy='actual-clang-M-discovery-and-MD-compile-equality-v1')
                _, version, _ = command([PUBLIC / 'bin/rustc', '-vV']); version = version.decode()
                _, sysroot, _ = command([PUBLIC / 'bin/rustc', '--print', 'sysroot'])
                _, cargo_version, _ = command([PUBLIC / 'bin/cargo', '-Vv'])
                _, python_version, _ = command([PYTHON, '--version'])
                require('commit-hash: ' + COMPILER + '\n' in version and 'host: ' + HOST + '\n' in version
                        and sysroot.decode().strip() == str(PUBLIC), 'actual public compiler identity differs')
                std = std_proof(version)
                (out / 'std-ready.json').write_bytes((STD / 'ready.json').read_bytes())
                _, metadata, _ = command([PUBLIC / 'bin/cargo', 'metadata', '--locked', '--offline', '--format-version=1', '--manifest-path', ROOT / 'Cargo.toml'])
                (out / 'cargo-metadata.json').write_bytes(metadata)
                dependencies = inputs.dependency_inventory(json.loads(metadata), environment(), dict(config))
                require(len(dependencies['packages']) == 30 and sum(bool(p['source']) for p in dependencies['packages']) == 26,
                        'reviewed workspace/registry package count differs')
                closures = {name: closure(path) for name,path in [('rustc', PUBLIC / 'bin/rustc'), ('rustdoc', PUBLIC / 'bin/rustdoc'), ('cargo', PUBLIC / 'bin/cargo'), ('python', PYTHON), ('clang', CC.resolve(strict=True))]}
                closure_files = {item['logical']: file_identity(Path(item['logical'])) for value in closures.values() for item in value['identity']['libraries']}
                current = dict(schema_version=1, policy=POLICY, owner=str(ROOT), work=str(WORK), source_checkpoint=CHECKPOINT,
                    documentation_checkpoint=DOC_CHECKPOINT, actual_head=head.decode().strip(), sources=source,
                    source_index=dict(path=str(out / 'source-inputs.json'), sha256=initial_index_sha),
                    environment=environment(), native_environment=native_environment(), configuration=config, public=public,
                    versions=dict(rustc=version, cargo=cargo_version.decode(), python=python_version.decode()),
                    std=std, dependencies=dependencies, closures=closures, closure_files=list(closure_files.values()), c_oracle=c_oracle,
                    public_library_paths=sorted(public_library_paths), sdk=sdk,
                    commands=commands(), required_rust_tests=RUST_TESTS, required_python_tests=PYTHON_TESTS, separate_roles=False, publication=False,
                    lock=str(owned.CANONICAL_LOCK), wait_seconds=600, capacity=dict(initial_free_gib=16, stop_gib=9, floor_gib=8),
                    cargo_metadata=dict(path=str(out / 'cargo-metadata.json'), sha256=digest(metadata)))
                guard(full=True)
                write(PLAN, current)
                receipt.update(plan=str(PLAN), plan_sha256=sha(PLAN), status='planned')
            else:
                current = json.loads(PLAN.read_bytes())
                require(current['policy'] == POLICY and current['owner'] == str(ROOT) and current['work'] == str(WORK)
                        and current['source_checkpoint'] == CHECKPOINT and current['documentation_checkpoint'] == DOC_CHECKPOINT
                        and current['commands'] == commands() and current['environment'] == environment()
                        and current['native_environment'] == native_environment() and current['required_python_tests'] == PYTHON_TESTS
                        and current['required_rust_tests'] == RUST_TESTS and current['separate_roles'] is False
                        and current['publication'] is False and current['lock'] == str(owned.CANONICAL_LOCK)
                        and current['wait_seconds'] == 600 and current['capacity'] == dict(initial_free_gib=16, stop_gib=9, floor_gib=8), 'fixed qualification plan differs')
                require(not TARGET.exists() and not (WORK / 'native').exists(), 'fresh fstat target and native history required')
                guard(full=True)
                first, stdout, stderr = command(commands()[0], label='workspace-tests')
                receipt['workspace'] = rust_results((stdout + stderr).decode())
                write(out / 'receipt.json', receipt)
                command(commands()[1], label='standalone-build')
                binaries = [file_identity(ordinary(TARGET / 'release' / name)) for name in ['rust-interp-mir-export', 'rust-interp-rustc-wrapper', 'rust-interp-vm']]
                binary_closures = {Path(row['path']).name: closure(Path(row['path'])) for row in binaries}
                binary_records = {r['path']:r for r in binaries}
                for value in binary_closures.values():
                    for item in value['identity']['libraries']:
                        binary_records[item['logical']] = file_identity(Path(item['logical']))
                write(out / 'actual-tools.json', dict(binaries=binaries, closures=binary_closures, files=list(binary_records.values())))
                guard_records(binary_records.values(), full=True)
                _, exporter_out, exporter_err = command(commands()[2], label='default-exporter-capabilities')
                capability = json.loads(exporter_out)
                require(not exporter_err and capability.get('schema_version') == 1
                        and capability.get('bytecode_version') == 5 and capability.get('compiler_sysroot') == str(PUBLIC)
                        and 'compiler_roles' not in capability, 'default exporter capability changed roles')
                _, wrapper_out, wrapper_err = command(commands()[3], label='default-wrapper-roles')
                require(not wrapper_err and wrapper_out == b'null\n', 'default wrapper roles must be exactly null')
                guard_records(binary_records.values(), full=True)
                (WORK / 'native').mkdir()
                child, stdout, stderr = command(commands()[4], env=native_environment(), label='native-controls')
                result = native_results(child, (stdout + stderr).decode(), current['c_oracle'])
                write(out / 'native-results.json', result)
                guard_records(binary_records.values(), full=True)
                for value in binary_closures.values(): require(loaders.library_state(value['identity']) == value['state'], 'actual tool closure changed')
                guard(full=True)
                receipt.update(status='passed', plan_sha256=args.plan_sha256,
                    actual_tools_sha256=sha(out / 'actual-tools.json'), qualification_commands_passed=5,
                    native_results_sha256=sha(out / 'native-results.json'), native_children_passed=49,
                    default_exporter_capabilities=capability, default_wrapper_roles=None,
                    separate_roles=False, publication=False)
            receipt.update(finished_at=time.time(), free_bytes_after=owned.disk(ROOT))
            write(out / 'receipt.json', receipt)
    except BaseException as error:
        receipt.update(status='failed', error=repr(error), finished_at=time.time(), free_bytes_after=shutil.disk_usage(ROOT).free)
        write(out / 'receipt.json', receipt)
        raise


if __name__ == '__main__': main()
