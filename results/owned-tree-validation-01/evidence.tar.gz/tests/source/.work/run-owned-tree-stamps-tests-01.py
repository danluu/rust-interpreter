import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture, write_json

WORK = ROOT / '.work/owned-tree-stamps-tests-01'
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
TESTS = ['test_owned_tree_stamps', 'test_custom_compiler', 'test_std_mir_source_paths']
WORK.mkdir(exist_ok=False)
result = dict(status='waiting', owner=str(ROOT), pid=os.getpid(), parent_pid=os.getppid(),
              started_at=time.time(), lock=str(LOCK), lock_wait_seconds=600, benchmarks=0)
write_json(WORK / 'result.json', result)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

try:
    with LOCK.open('r+') as lock:
        acquire_lock(lock, 600)
        result.update(status='running', admitted_at=time.time())
        write_json(WORK / 'result.json', result)
        assert shutil.disk_usage(ROOT).free >= 8 * 1024**3
        paths = sorted((ROOT / 'scripts').glob('*.py')) + [ROOT / 'tests' / (name + '.py') for name in TESTS] + [Path(__file__)]
        before = {str(path.relative_to(ROOT)): digest(path) for path in paths}
        for path in paths:
            destination = WORK / 'source' / path.relative_to(ROOT)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(path.read_bytes())
            assert digest(destination) == before[str(path.relative_to(ROOT))]
        command = [sys.executable, '-B', '-m', 'unittest', '-v', *TESTS]
        environment = dict(os.environ)
        environment.pop('PYTHONPATH', None)
        environment.pop('PYTHONHOME', None)
        write_json(WORK / 'plan.json', dict(command=command, cwd=str(ROOT / 'tests'), sources=before,
            environment_sha256=hashlib.sha256(json.dumps(environment, sort_keys=True).encode()).hexdigest()))
        child, out, err = capture(command, cwd=ROOT / 'tests', env=environment,
            receipt_path=WORK / 'test-process.json', receipt={})
        (WORK / 'stdout').write_text(out)
        (WORK / 'stderr').write_text(err)
        result.update(returncode=child.returncode, sources_unchanged=all(
            digest(ROOT / name) == value for name, value in before.items()))
        assert result['sources_unchanged'], 'test source changed'
        match = re.search(r'(?m)^Ran (\d+) tests? in ([0-9.]+)s$', err)
        assert child.returncode == 0 and match and re.search(r'(?m)^OK$', err), 'tests failed or incomplete'
        result.update(status='passed', tests=int(match[1]), test_seconds=float(match[2]),
                      finished_at=time.time(), plan_sha256=digest(WORK / 'plan.json'))
        write_json(WORK / 'result.json', result)
        print(json.dumps(result))
except BaseException as error:
    result.update(status='failed', error=repr(error), finished_at=time.time())
    write_json(WORK / 'result.json', result)
    raise
