import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import write_json
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
OUT = ROOT / 'results/owned-tree-validation-01'
def sha(data): return hashlib.sha256(data).hexdigest()
with LOCK.open('r+') as lock:
    acquire_lock(lock, 600)
    assert shutil.disk_usage(ROOT).free >= 8 * 1024**3
    tests = ROOT / '.work/owned-tree-stamps-tests-01'
    comparison = ROOT / '.work/owned-tree-validation-comparison-01'
    t = json.loads((tests / 'result.json').read_bytes())
    c = json.loads((comparison / 'result.json').read_bytes())
    assert t['status'] == c['status'] == 'passed' and t['tests'] == 33 and len(c['rows']) == 10
    assert t['sources_unchanged'] and c['sources_unchanged'] and c['readiness_unchanged']
    roots = dict(tests=tests, comparison=comparison,
        tests_supervisor=ROOT / '.work/experiments/owned-tree-stamps-tests-supervisor-01',
        comparison_supervisor=ROOT / '.work/experiments/owned-tree-validation-comparison-supervisor-01')
    for label in ('tests_supervisor', 'comparison_supervisor'):
        status = json.loads((roots[label] / 'status.json').read_bytes())
        assert status['status'] == 'finished' and status['returncode'] == 0
    payloads = {}
    paths = {}
    for label, root in roots.items():
        for path in sorted(root.rglob('*')):
            assert not path.is_symlink()
            if path.is_file():
                name = label + '/' + str(path.relative_to(root))
                payloads[name] = path.read_bytes()
                paths[name] = path
    for label in ('tests', 'comparison'):
        plan = json.loads(payloads[label + '/plan.json'])
        for name, digest in plan['sources'].items():
            assert sha(payloads[label + '/source/' + name]) == digest
    for label, original in [('compiler', str(Path(c['primary']) / '.work/compilers/f9fb3e5f59b8567fffd32c936a9864d0baee77038574236710fbcec75a57d33f/ready.json')),
                            ('std', str(Path(c['primary']) / '.work/std-mir/e51184b28521ec446ce759d2f6e8334d554a1d1186334c2e872dec9c45763b48/ready.json'))]:
        assert sha(payloads['comparison/readiness/' + label + '.json']) == plan['readiness'][original]
    payloads['archive-runner.py'] = Path(__file__).read_bytes()
    paths['archive-runner.py'] = Path(__file__)
    manifest = {name: dict(sha256=sha(data), bytes=len(data), original=str(paths[name])) for name, data in payloads.items()}
    OUT.mkdir(parents=True, exist_ok=False)
    with (OUT / 'evidence.tar.gz').open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, filename='', mode='wb', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, data in sorted(payloads.items()):
                    info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644
                    archive.addfile(info, io.BytesIO(data))
    with tarfile.open(OUT / 'evidence.tar.gz', mode='r:gz') as archive:
        assert set(archive.getnames()) == set(payloads)
        for item in archive:
            assert item.isfile()
            assert archive.extractfile(item).read() == payloads[item.name]
    assert all(path.read_bytes() == payloads[name] for name, path in paths.items())
    write_json(OUT / 'members.json', manifest)
    write_json(OUT / 'summary.json', dict(status='passed', tests=t, comparison=c,
        archive=dict(path='evidence.tar.gz', sha256=sha((OUT / 'evidence.tar.gz').read_bytes()),
            bytes=(OUT / 'evidence.tar.gz').stat().st_size, members=len(payloads), all_members_verified=True),
        archive_pid=os.getpid(), parent_pid=os.getppid(), canonical_lock=str(LOCK), finished_at=time.time()))
    (OUT / 'README.md').write_text('''The compiler/std installation validator now uses one no-follow stat per file and rechecks every directory after traversal. It still enumerates and validates every entry on every call; all six identity fields, immutable-file checks, key validation and source/configuration guards remain. No persistent cache or root-only shortcut was added.

All 33 controls passed, including unchanged compiler/std loader tests and six new inventory/refusal controls: nested changes, same-size/mtime-restored content changes, links, special files and a directory replaced by a symlink during traversal.

Five alternating paired samples of complete compiler plus shared-std loading reduced median wall time from 454.980 ms to 167.079 ms (CPU 451.494 ms to 166.977 ms). Every returned value and existing readiness manifest matched exactly. This measures only those loaders; it excludes tool loading, Cargo and VM execution and makes no end-to-end or sub-0.500-second claim. Baseline source is 85b56435 and candidate source 151af48b.

The archive retains all tests, ten samples, raw process/supervisor receipts, exact baseline/candidate helper source and readiness bytes. Every member was read back and verified. The existing compiler, standard-library installation and Nushell source were unchanged; no holdout ran.
''')
    print(json.dumps(dict(status='passed', members=len(payloads), archive_sha256=sha((OUT / 'evidence.tar.gz').read_bytes()))))
