"""Independently audit saved std setup and all immutable output bytes; no compiler calls."""
import hashlib,importlib.util,json,os,stat,sys,time
from pathlib import Path
R=Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
H=R/'experiments/runtime-compiler-installation/std-01'
W=R/'.work/runtime-std-preparation-supervision-01'
RUN=R/'.work/runtime-std-source-paths-01'
OUT=R/'.work/runtime-std-preparation-independent-verification-01.json'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def digest(j):return hashlib.sha256(json.dumps(j,sort_keys=True).encode()).hexdigest()
def require(ok,m):
    if not ok:raise RuntimeError(m)
def tree(root,files,stamps):
    actual={};count=total=0
    for p in [root,*sorted(root.rglob('*'))]:
        s=p.lstat();name='.' if p==root else str(p.relative_to(root))
        require(stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode),'nonordinary std tree')
        require(not s.st_mode&0o222,'writable std tree')
        actual[name]=[s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
        if stat.S_ISREG(s.st_mode):
            require(s.st_nlink==1 and files.get(name)==sha(p),'std copy/content differs')
            count+=1;total+=s.st_size
        after=p.lstat()
        require([after.st_dev,after.st_ino,after.st_mode,after.st_size,after.st_mtime_ns,after.st_ctime_ns]==actual[name] and after.st_nlink==s.st_nlink,'std changed during hash')
    require(actual==stamps and count==len(files),'std membership/stamps differ')
    return dict(files=count,bytes=total)
def main():
    plan=read(H/'plan.json');frozen=read(H/'inputs.json');launch=read(H/'launch.json')
    require(sha(H/'launch.json')=='430384f9b21996a856eb0371ba05c36d6213e887f895227159e76a55e51c20b4','launch differs')
    for p,h in frozen['files'].items():
        require(sha(p)==h and sha(W/'inputs'/p.lstrip('/'))==h,'source/copy changed: '+p)
    own=R/'experiments/stable-cgu/owned_stage.py'
    spec=importlib.util.spec_from_file_location('std_audit_owned',own);owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
    with owned.workload_lock(owned.CANONICAL_LOCK,600):
        owned.disk(R,8)
        record=read(W/'receipt.json');child=read(W/'command/receipt.json')
        outer_path=R/'.work/experiments/runtime-std-preparation-supervisor-01/status.json';outer=read(outer_path)
        execution=R/'.work/runtime-std-preparation-launch-execution-01';entry=read(execution/'record.json')
        require(record['status']=='passed' and outer['status']==child['status']==entry['status']=='finished','unfinished setup')
        require(outer['returncode']==child['returncode']==entry['returncode']==0,'failed setup')
        require(entry['command']==launch['command'] and entry['environment']==launch['environment']==record['environment']==child['environment'],'outer environment/command differs')
        require(child['command']==plan['command']==record['command'] and child['cwd']==entry['cwd']==str(R),'CLI route differs')
        require(outer['child_pid']==record['pid']==child['supervisor_pid'] and record['parent_pid']==outer['supervisor_pid']==child['parent_pid'],'parent associations differ')
        require(sha(W/'command/receipt.json')==record['child']['sha256'],'child receipt hash differs')
        for name in ['stdout','stderr']:
            require(sha(W/'command'/name)==child[name+'_sha256'] and sha(execution/name)==entry[name+'_sha256'],'outer raw stream hash differs')
        require(outer['started_at']<=record['started_at']<=child['started_at']<=child['finished_at']<=record['finished_at']<=outer['finished_at'],'outer times differ')
        require(sha(record['ready']['path'])==record['ready']['sha256'] and sha(record['result']['path'])==record['result']['sha256'],'result association differs')
        ready=read(record['ready']['path']);work=Path(record['sysroot']).parent
        require(digest(ready['identity'])==record['std_key']==work.name and ready['owner']==str(R),'std identity differs')
        require(ready['identity']['compiler_key']==plan['runtime_key'] and ready['identity']['namespace']==plan['namespace'],'std/compiler association differs')
        runenv=dict(plan['environment']);runenv.update(RUSTC_WRAPPER='',RUSTC_WORKSPACE_WRAPPER='',CARGO_TERM_COLOR='never')
        runtime=R/'.work/runtime-compilers'/plan['runtime_key']/'sysroot'
        buildenv=dict(runenv);buildenv.update(PATH=str(runtime/'bin')+os.pathsep+runenv['PATH'],RUSTC=str(runtime/'bin/rustc'))
        if (runtime/'bin/rustdoc').exists():buildenv['RUSTDOC']=str(runtime/'bin/rustdoc')
        buildenv.update(ready['environment']);probeenv={k:v for k,v in buildenv.items() if k not in ['RUSTFLAGS','__CARGO_RUSTC_BOOTSTRAP_WS_REMAP']}
        require(digest(buildenv)==ready['identity']['build_environment_sha256'],'expanded build environment differs')
        cargo=plan['cargo_executable'];expected=[['rustup','which','--toolchain','nightly-2026-09-08','cargo'],[cargo,'-Vv'],['/usr/bin/otool','-arch','arm64','-L',cargo],['/usr/bin/otool','-arch','arm64','-l',cargo]]
        for label,sysroot in [('native',runtime),('prepared',work/'sysroot')]:
            directory=RUN/('probe-'+label)
            command=[str(runtime/'bin/rustc'),str(directory/'source.rs'),'--crate-type=lib','--edition=2024','--emit=metadata','--error-format=json','--sysroot',str(sysroot),'-o',str(directory/'probe.rmeta')]
            if label=='prepared':expected.append(ready['command'])
            expected.append(command)
        rows=read(RUN/'commands.json');require(len(rows)==7,'unexpected direct children')
        previous=child['started_at'];pids=set();streams={}
        for i,(row,declared,command) in enumerate(zip(rows,plan['expected_outer_cli_children'],expected)):
            label=declared['label'];proc=read(RUN/(label+'-process.json'))
            require(row==read(RUN/(label+'.json')) and row['label']==label and row['command']==command==proc['command'],'saved child command differs')
            require(row['returncode']==declared['returncode']==proc['returncode'] and proc['status']=='finished','saved child status differs')
            require(proc['parent_pid']==child['pid'] and proc['pid'] not in pids,'inner parent/PID differs');pids.add(proc['pid'])
            require(previous<=proc['started_at']<=proc['finished_at']<=child['finished_at'],'inner times differ');previous=proc['finished_at']
            cwd=work if label=='metadata' else RUN/label if label.startswith('probe-') else RUN
            require(proc['cwd']==str(cwd),'inner cwd differs')
            env=runenv if i<4 else buildenv if label=='metadata' else probeenv
            require(row['environment_sha256']==proc['environment_sha256']==digest(env),'inner environment differs')
            streams[label]={name:hashlib.sha256(row[name].encode()).hexdigest() for name in ['stdout','stderr']}
        trees={'library':tree(work/'library',ready['identity']['source_files'],ready['snapshot_stamps']),'sysroot':tree(work/'sysroot',ready['sysroot_files'],ready['sysroot_stamps']),'evidence':tree(work/'evidence',ready['evidence_files'],ready['evidence_stamps'])}
        require(ready['full_presentation_qualified'] is False,'unearned presentation claim')
        result=dict(status='passed',verifier_sha256=sha(Path(__file__)),pid=os.getpid(),finished_at=time.time(),std_key=work.name,runtime_key=plan['runtime_key'],receipt_sha256=sha(W/'receipt.json'),ready_sha256=sha(work/'ready.json'),source_and_retained_files=len(frozen['files']),direct_children=7,child_pids=sorted(pids),raw_stream_hashes=streams,trees=trees,build_seconds=ready['build_seconds'],setup_seconds=ready['setup_seconds'],metadata_bytes=ready['metadata_bytes'],application_qualified=False,benchmark=False,actual_commands_rerun=False)
        owned.write(OUT,result);print(json.dumps(result,sort_keys=True,indent=2))
if __name__=='__main__':
    try:main()
    except BaseException as error:
        failure=OUT.with_name(OUT.stem+'-failure.json')
        with failure.open('x') as f:json.dump(dict(status='failed',error=repr(error),verifier_sha256=sha(Path(__file__)),time=time.time()),f,indent=2)
        raise
