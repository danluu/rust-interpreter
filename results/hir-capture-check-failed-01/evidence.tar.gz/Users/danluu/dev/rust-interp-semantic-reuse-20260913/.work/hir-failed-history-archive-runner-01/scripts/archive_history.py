"""Preserve the failed capture-only compiler check after an independent source guard."""
import gzip,hashlib,importlib.util,io,json,os,re,shutil,sys,tarfile,time
from pathlib import Path
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
HIRC=Path('/Users/danluu/dev/rust-interp-hir-capture-check-20260913')
SOURCE=Path('/Users/danluu/dev/rustc-hir-capture-check-20260913')
RUNNER=Path(__file__).resolve().parents[1]
RAW=HIRC/'.work/hir-capture-check-01'
WORK=ROOT/'.work/hir-capture-failed-history-archive-01'
OUTPUT=ROOT/'results/hir-capture-check-failed-01'
PLAN=HIRC/'experiments/hir-capture-check/planned-check-01.json'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
PLAN_SHA='d97d608124128bf203375125786683ada8c6d9a758971be8e861301b9835cf42'
SOURCE_SHA='75b383414aa1c9005419c658ad9c5da97e19378eddfd24b63ab80b9767721c0b'
REVISION='7c1a064b649c0e7610c557a2c98f5f3e2fc8ed27'
DRIVER_REVISION='af9c37f427fb1447c1219c0e828dc71ceedbd8dd'
WORK.mkdir(exist_ok=False)
record=dict(schema_version=1,status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,source_changes=0,compiler_commands=0,benchmarks=0)
def sha(data):return hashlib.sha256(data).hexdigest()
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  while b:=stream.read(4*1024*1024):h.update(b)
 return h.hexdigest()
def ordinary(path):assert path.resolve(strict=True)==path and not path.is_symlink(),str(path)
def save():write_json(WORK/'summary.json',record)
def read(path):return json.loads(path.read_bytes())
files={}
def retain(path):
 path=Path(path);ordinary(path);data=path.read_bytes();name=str(path).removeprefix('/')
 if name in files:assert files[name]==data,'retained source changed: '+str(path)
 else:files[name]=data
 return data
save()
try:
 with LOCK.open('r+') as lock:
  acquire_lock(lock,600);assert shutil.disk_usage(ROOT).free>=8*1024**3
  record.update(status='verifying old source',admitted_at=time.time());save()
  assert digest(PLAN)==PLAN_SHA and digest(RAW/'source.json')==SOURCE_SHA
  plan=json.loads(retain(PLAN));state=json.loads(retain(RAW/'source.json'));completed=json.loads(retain(RAW/'completed.json'))
  assert state['revision']==REVISION and len(state['files'])==62700 and len(state['backtrace_files'])==102
  assert state['plan_sha256']==PLAN_SHA and plan['checkpoint']=='3f3e9c28704a7866f72ad0974336d79671714ae9'
  assert set(completed)=={'prepare'} and set(p.name for p in (RAW/'stages').iterdir())=={'prepare-01','check-01'}
  for name,h in plan['inputs'].items():assert sha(retain(Path(name)))==h
  copied=read(RUNNER/'copied-inputs.json');assert len(copied)==9
  for name,item in copied.items():assert sha(retain(Path(name)))==item['sha256']==plan['inputs'][item['source']]
  for name in ['archive_history.py','workflow_io.py','compare_saved_runtime.py']:retain(RUNNER/'scripts'/name)
  retain(RUNNER/'copied-inputs.json')
  # Execute only the frozen driver's read-only metadata/guard functions.
  module_path=RUNNER/'experiments/hir-capture-check/check.py'
  spec=importlib.util.spec_from_file_location('frozen_capture_driver',module_path);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
  driver.ROOT=HIRC;driver.HERE=HIRC/'experiments/hir-capture-check';driver.__file__=str(driver.HERE/'check.py')
  assert driver.SOURCE==SOURCE and driver.frozen_plan()==plan
  assert read(SOURCE/'.rust-interp-owned.json')==dict(owner=str(HIRC),plan_sha256=PLAN_SHA)
  retain(SOURCE/'.rust-interp-owned.json');retain(SOURCE/'bootstrap.toml')
  command_rows=[]
  def command(argv,cwd=SOURCE):
   assert driver.frozen_plan()==plan
   out=WORK/'verification-commands'/f'{len(command_rows):03d}';out.mkdir(parents=True)
   child,stdout,stderr=capture(argv,cwd=cwd,env=plan['environment'],receipt_path=out/'receipt.json',receipt={})
   (out/'stdout').write_bytes(stdout.encode());(out/'stderr').write_bytes(stderr.encode())
   row=dict(command=argv,cwd=str(cwd),pid=child.pid,returncode=child.returncode,receipt=str(out/'receipt.json'),stdout_sha256=sha(stdout.encode()),stderr_sha256=sha(stderr.encode()))
   command_rows.append(row);write_json(WORK/'verification-commands.json',command_rows)
   assert child.returncode==0,(argv,stderr)
   return dict(row,stdout=stdout,stderr=stderr)
  def source_guard():
   assert (SOURCE/'.git').is_dir() and not (SOURCE/'.git').is_symlink()
   assert not (SOURCE/'.git/objects/info/alternates').exists() and not (SOURCE/'library/backtrace/.git/objects/info/alternates').exists()
   assert command(['git','rev-parse','HEAD'])['stdout'].strip()==REVISION
   assert command(['git','diff','HEAD','--'])['stdout']==''
   assert command(['git','rev-parse','HEAD'],cwd=SOURCE/'library/backtrace')['stdout'].strip()==plan['backtrace']
   assert driver.inventory(command,SOURCE)==state['files']
   assert driver.inventory(command,SOURCE/'library/backtrace')==state['backtrace_files']
   assert digest(SOURCE/'bootstrap.toml')==state['config_sha256']
   assert driver.configurations()==plan['configurations']
   driver.verify_archives(plan['archives']);driver.verify_copied_archives()
   assert driver.frozen_plan()==plan
  source_guard()
  assert command(['git','rev-parse','HEAD^'])['stdout'].strip()==plan['base']
  command(['git','cat-file','-p',REVISION])
  command(['git','cat-file','-p',plan['base']])
  command(['git','diff','--binary',plan['base'],REVISION,'--'])
  assert command(['git','diff',DRIVER_REVISION,'--',*[str(Path(p).relative_to(HIRC)) for p in plan['inputs']]],cwd=HIRC)['stdout']==''
  command(['git','rev-parse','HEAD'],cwd=HIRC)
  patch=json.loads(retain(driver.HERE/'inputs/patch.json'));assert len(patch['files'])==17
  patched={}
  for name,item in patch['files'].items():
   data=retain(SOURCE/name);assert sha(data)==item['after_sha256'];patched[name]=dict(path=str(SOURCE/name),sha256=sha(data),bytes=len(data))
  prior=[]
  for stage,count in [('prepare',12),('check',6)]:
   path=RAW/'stages'/(stage+'-01')/'receipt.json';receipt=json.loads(retain(path));assert receipt['plan_sha256']==PLAN_SHA and len(receipt['commands'])==count
   assert receipt['status']==('passed' if stage=='prepare' else 'failed')
   if stage=='prepare':assert completed['prepare']==dict(path=str(path),sha256=sha(retain(path)))
   for index,item in enumerate(receipt['commands']):
    cp=Path(item['path']);row=json.loads(retain(cp));assert sha(retain(cp))==item['sha256'] and row['command']==item['command'] and row['status']=='finished'
    expected=1 if stage=='check' and index==5 else 0;assert row['returncode']==expected
    assert sha(retain(cp.parent/'stdout'))==row['stdout_sha256'] and sha(retain(cp.parent/'stderr'))==row['stderr_sha256']
   prior.append(dict(stage=stage,path=str(path),sha256=sha(retain(path)),commands=count,status=receipt['status']))
  error_path=RAW/'stages/check-01/commands/005/stderr';error_count=len(re.findall(rb'error\[E0308\]',retain(error_path)));assert error_count==3
  for label,expected in [('hir-capture-prepare-supervisor-01',0),('hir-capture-check-supervisor-01',1)]:
   directory=HIRC/'.work/experiments'/label;receipt=read(directory/'status.json')
   assert receipt['status']=='finished' and receipt['returncode']==expected
   assert sha(retain(directory/'plan.json'))==receipt['plan_sha256'] and sha(retain(directory/'command.log'))==receipt['log_sha256']
   for p in directory.iterdir():
    if p.is_file():retain(p)
  for p in RAW.rglob('*'):
   assert not p.is_symlink()
   if p.is_file():retain(p)
  # Re-run the entire source guard after evidence collection, independently of
  # the old driver, whose exception path did not perform its post-failure guard.
  source_guard()
  archives={}
  for path,h in plan['archives'].items():archives[path]=dict(sha256=h,bytes=Path(path).stat().st_size,role='original seed')
  for path,item in plan['copied_archives'].items():archives[path]=dict(sha256=item['sha256'],bytes=Path(path).stat().st_size,role='copied seed',source=item['source'])
  guard=dict(status='passed',source= str(SOURCE),source_revision=REVISION,source_files=62700,backtrace_files=102,source_inventory_sha256=SOURCE_SHA,plan_sha256=PLAN_SHA,owner_and_head_and_parent_checked=True,all_tracked_content_verified=True,backtrace_head_verified=True,config_and_configuration_absences_verified=True,original_and_copied_archives=archives,post_failure_guard='independent archive-time guard; original failed command did not run its driver postguard',finished_at=time.time())
  write_json(WORK/'source-postguard.json',guard)
  for p in WORK.rglob('*'):
   if p.is_file() and p!=WORK/'summary.json':retain(p)
  for name,data in list(files.items()):assert Path('/'+name).read_bytes()==data,'input changed before packing: '+name
  assert shutil.disk_usage(ROOT).free-sum(map(len,files.values()))>=8*1024**3
  OUTPUT.mkdir(exist_ok=False)
  manifest={name:dict(sha256=sha(data),bytes=len(data),source='/'+name) for name,data in files.items()}
  with (OUTPUT/'evidence.tar.gz').open('xb') as raw:
   with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode='w') as tar:
     for name,data in sorted(files.items()):
      member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o444;member.mtime=0;tar.addfile(member,io.BytesIO(data))
  verified=set()
  with tarfile.open(OUTPUT/'evidence.tar.gz','r:gz') as tar:
   for member in tar:
    assert member.isfile() and member.name in manifest and member.name not in verified
    data=tar.extractfile(member).read();assert sha(data)==manifest[member.name]['sha256'] and len(data)==manifest[member.name]['bytes'];verified.add(member.name)
  assert verified==set(manifest)
  archive=dict(path='evidence.tar.gz',bytes=(OUTPUT/'evidence.tar.gz').stat().st_size,sha256=digest(OUTPUT/'evidence.tar.gz'),members=len(manifest),all_member_hashes_verified=True,gzip_mtime=0)
  summary=dict(schema_version=1,status='failed history archived and source verified',owner=str(HIRC),source=str(SOURCE),source_revision=REVISION,base_revision=plan['base'],driver_revision=DRIVER_REVISION,checkpoint=plan['checkpoint'],plan=dict(path=str(PLAN),sha256=PLAN_SHA),source_receipt=dict(path=str(RAW/'source.json'),sha256=SOURCE_SHA),prior_stages=prior,prepare_commands=12,check_commands=6,total_original_commands=18,errors=dict(code='E0308',count=3,stderr=str(error_path),sha256=sha(files[str(error_path).removeprefix('/')])),unit_commands=0,cache_hit_implemented=False,performance_claim=False,source_postguard=guard,patched_source_files=patched,archive=archive,manifest_sha256=sha((json.dumps(manifest,indent=2)+'\n').encode()),finished_at=time.time())
  write_json(OUTPUT/'manifest.json',manifest);assert digest(OUTPUT/'manifest.json')==summary['manifest_sha256'];write_json(OUTPUT/'summary.json',summary)
  (OUTPUT/'README.md').write_text('# Failed capture-only compiler check\n\nThe3f3e9c capture journal checkpoint prepared successfully in12commands, then the sixth check-stage command failed with three E0308 type mismatches. No unit test or cache-performance experiment ran. The actual owned compiler revision was '+REVISION+'.\n\nThe original driver stopped on command failure before its post-source guard. This archive independently rechecked all62,700 tracked compiler entries and102backtrace entries, HEAD/parent/ownership/configuration, all nine frozen harness inputs and all original/copied seed archives. The source stayed unchanged. Original receipts were preserved verbatim.\n\nThe archive contains all18 original command receipts and raw outputs, both supervisors, source/complete inventories, the exact17 patched source files, base/new Git identity and diff, and the new independent verification receipts. All members were read back and hash checked. Compiler binaries, caches and full unchanged source-tree payloads are excluded; unchanged files are identified by the complete inventory and Git lineage. This is a compile failure record, not a cache correctness or speed result.\n')
  record.update(status='passed',finished_at=time.time(),output=str(OUTPUT),archive=archive,source_postguard_sha256=digest(WORK/'source-postguard.json'),summary_sha256=digest(OUTPUT/'summary.json'));save();print(json.dumps(record))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());save();raise
