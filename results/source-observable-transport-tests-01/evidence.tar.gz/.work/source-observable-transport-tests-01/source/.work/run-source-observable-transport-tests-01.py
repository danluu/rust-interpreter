#!/usr/bin/env python3
"""One canonically serialized source-only contract execution; no Rust children."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('/Users/danluu/dev/rust-interp-source-observable-transport-20260913')
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
sys.path.insert(0, str(ROOT / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture, write_json

def sha(data):
    return hashlib.sha256(data).hexdigest()

modules = ['test_std_source_observables', 'test_strict_warm_mono_screen', 'test_owned_mono_screen_assessment']
work = ROOT / '.work/source-observable-transport-tests-01'
work.mkdir(exist_ok=False)
result = dict(owner=str(ROOT), status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
    started_at=time.time(), lock=str(LOCK), lock_wait_seconds=600, expected_tests=27, benchmark=False)
write_json(work / 'result.json', result)
try:
    with LOCK.open('r+') as lock:
        acquire_lock(lock, 600)
        result.update(status='admitted', admitted_at=time.time())
        write_json(work / 'result.json', result)
        revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
        paths = list((ROOT / 'scripts').glob('*.py'))
        paths += list((ROOT / 'benchmarks/experiments/strict-warm-build').glob('*.py'))
        paths += [ROOT / 'tests' / (name + '.py') for name in modules]
        paths += [ROOT / 'experiments/stable-cgu/owned_stage.py', Path(__file__).resolve()]
        frozen = {}
        for path in sorted(set(paths)):
            if path.is_symlink() or not path.is_file():
                raise RuntimeError('source input is not an ordinary file: ' + str(path))
            data = path.read_bytes(); name = str(path.relative_to(ROOT))
            destination = work / 'source' / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            frozen[name] = dict(bytes=len(data), sha256=sha(data))
        write_json(work / 'source-manifest.json', dict(revision=revision, files=frozen))
        code = ('import sys, unittest; sys.path.insert(0, "tests"); '
            'suite=unittest.defaultTestLoader.loadTestsFromNames(' + repr(modules) + '); '
            'result=unittest.TextTestRunner(verbosity=2).run(suite); '
            'sys.exit(not result.wasSuccessful())')
        command = [sys.executable, '-B', '-c', code]
        write_json(work / 'plan.json', dict(owner=str(ROOT), source_revision=revision,
            modules=modules, command=command, expected_tests=27,
            source_manifest_sha256=sha((work / 'source-manifest.json').read_bytes()), benchmark=False))
        (work / 'tmp').mkdir()
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(work / 'tmp'))
        child, stdout, stderr = capture(command, cwd=ROOT, env=env,
            receipt_path=work / 'process.json', receipt=dict(phase='27-source-observable-contracts'))
        (work / 'stdout').write_text(stdout); (work / 'stderr').write_text(stderr)
        unchanged = all(not (ROOT / name).is_symlink() and sha((ROOT / name).read_bytes()) == row['sha256']
            and sha((work / 'source' / name).read_bytes()) == row['sha256'] for name, row in frozen.items())
        counts = re.findall(r'^Ran (\d+) tests? in ', stderr, re.MULTILINE)
        result.update(returncode=child.returncode, child_pid=child.pid, source_revision=revision,
            source_files=len(frozen), sources_unchanged=unchanged,
            actual_tests=int(counts[0]) if len(counts)==1 else None,
            stdout_sha256=sha((work / 'stdout').read_bytes()), stderr_sha256=sha((work / 'stderr').read_bytes()))
        if not (child.returncode == 0 and counts == ['27'] and re.search(r'^OK$', stderr, re.MULTILINE) and unchanged):
            raise RuntimeError('27 passing controls, zero skips, or source equality failed')
        result.update(status='passed', finished_at=time.time())
        write_json(work / 'result.json', result)
        print(json.dumps(result))
except BaseException as error:
    result.update(status='failed', error=repr(error), finished_at=time.time())
    write_json(work / 'result.json', result)
    raise
