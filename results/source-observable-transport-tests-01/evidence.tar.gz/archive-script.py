#!/usr/bin/env python3
"""Retain the completed27 source controls; serialize compression and verification."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-source-observable-transport-20260913')
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
sys.path.insert(0, str(ROOT / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import write_json

def sha(data):
    return hashlib.sha256(data).hexdigest()

work = ROOT / '.work/source-observable-transport-tests-01'
supervisor = ROOT / '.work/experiments/source-observable-transport-tests-supervisor-01'
with LOCK.open('r+') as lock:
    acquire_lock(lock, 600)
    admitted = time.time()
    result = json.loads((work / 'result.json').read_bytes())
    plan = json.loads((work / 'plan.json').read_bytes())
    child = json.loads((work / 'process.json').read_bytes())
    outer = json.loads((supervisor / 'status.json').read_bytes())
    outer_plan = json.loads((supervisor / 'plan.json').read_bytes())
    sources = json.loads((work / 'source-manifest.json').read_bytes())
    stderr = (work / 'stderr').read_text()
    counts = re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$', stderr, re.MULTILINE)
    assert result['status'] == 'passed' and result['actual_tests'] == result['expected_tests'] == 27
    assert result['sources_unchanged'] and len(sources['files']) == result['source_files'] == 123
    assert result['returncode'] == child['returncode'] == outer['returncode'] == 0
    assert child['status'] == outer['status'] == 'finished'
    assert counts == [('27', '0.061')] and re.search(r'^OK$', stderr, re.MULTILINE)
    assert child['pid'] == result['child_pid'] and child['parent_pid'] == result['pid']
    assert outer['child_pid'] == result['pid'] and outer['supervisor_pid'] == result['parent_pid']
    assert child['command'] == plan['command'] and child['cwd'] == str(ROOT)
    assert sources['revision'] == result['source_revision'] == plan['source_revision']
    assert result['admitted_at'] <= child['started_at'] <= child['finished_at'] <= result['finished_at']
    assert outer['plan_sha256'] == sha((supervisor / 'plan.json').read_bytes())
    assert outer['log_sha256'] == sha((supervisor / 'command.log').read_bytes())
    assert plan['source_manifest_sha256'] == sha((work / 'source-manifest.json').read_bytes())
    assert outer_plan['supervisor_sha256'] == sources['files']['scripts/supervise_experiment.py']['sha256']
    for name in ['stdout', 'stderr']:
        assert result[name + '_sha256'] == sha((work / name).read_bytes())
    for name, record in sources['files'].items():
        snapshot = work / 'source' / name
        assert not snapshot.is_symlink() and snapshot.is_file()
        data = snapshot.read_bytes()
        assert record == dict(bytes=len(data), sha256=sha(data))
    payloads = {'archive-script.py': Path(__file__).read_bytes()}
    for base in [work, supervisor]:
        for path in sorted(base.rglob('*')):
            assert not path.is_symlink()
            if path.is_file():
                payloads[str(path.relative_to(ROOT))] = path.read_bytes()
    manifest = {name: dict(bytes=len(data), sha256=sha(data)) for name, data in payloads.items()}
    output = ROOT / 'results/source-observable-transport-tests-01'
    output.mkdir(exist_ok=False)
    archive = output / 'evidence.tar.gz'
    with archive.open('xb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as writer:
            for name, data in sorted(payloads.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode = len(data), 0o644
                writer.addfile(item, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as reader:
        assert len(reader.getnames()) == len(manifest) and set(reader.getnames()) == set(manifest)
        for member in reader.getmembers():
            assert member.isfile()
            data = reader.extractfile(member).read()
            assert manifest[member.name] == dict(bytes=len(data), sha256=sha(data))
    write_json(output / 'manifest.json', manifest)
    summary = dict(status='passed', source_revision=result['source_revision'], tests=27, ignored=0,
        test_seconds=float(counts[0][1]), source_snapshots=len(sources['files']), modules=plan['modules'],
        supervisor_pid=outer['supervisor_pid'], helper_pid=result['pid'], test_pid=child['pid'],
        compiler_commands=0, benchmarks=0,
        archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()), members=len(manifest)),
        verification=dict(pid=os.getpid(), parent_pid=os.getppid(), lock=str(LOCK), admitted_at=admitted,
                          finished_at=time.time(), all_member_hashes_verified=True))
    write_json(output / 'summary.json', summary)
    (output / 'README.md').write_text(
        'All27 source-observable transport and mono screen/assessor Python controls passed in0.061s, with zero skips, '
        'at source e408abb4aeae40cbba09cca48c33878b4c7d5de2. The controls cover exact expected bytes/coordinates, '
        'negative comparison masks, altered generated source, native-row association, fabricated constant-success '
        'fixtures and obsolete qualification policies. Existing strict36/std/screen contracts also passed.\n\n'
        'The archive retains123 exact source snapshots, raw output and child/supervisor receipts. Every snapshot '
        'and archive member was verified under the canonical workload lock. No compiler or benchmark ran in '
        'this test execution. The real61-command qualification and any performance screen remain separate gates.\n')
    print(json.dumps(summary))
