import fcntl, hashlib, json, os, pathlib, subprocess, sys, time
root=pathlib.Path.cwd(); out=root/'.work/demand-retention-correctness-03'
vm=pathlib.Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913/.work/interpreter-tools/923ad6d94c365365f15322ee65d32dca6ba9ccc4fd07a8147111329ea1955c86/rust-interp-vm')
lockpath=pathlib.Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
target=root/'.work/demand-retention-target'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','crates','scripts','tests','Cargo.toml','Cargo.lock','rust-toolchain.toml'],text=True).splitlines()
 return {name:digest(root/name) for name in sorted(set(names)) if (root/name).is_file()}
receipt={'supervisor_pid':os.getpid(),'cwd':str(root),'shared_lock':str(lockpath),'started_at':time.time(),'source_before':snapshot(),'vm':str(vm),'vm_sha256':digest(vm),'commands':[]}
assert receipt['vm_sha256']=='83ca5b7882debeae37af8099c99c5cfb1a3829ed969444ee350eee12aa72b4df'
def save(): (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save(); print('task-owned supervisor PID',os.getpid(),flush=True)
env=dict(os.environ,CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',RUST_INTERP_TEST_EXPORTER=str(target/'debug/rust-interp-mir-export'),RUST_INTERP_TEST_ARTIFACT_DIR=str(out/'fixtures'),RUST_INTERP_TEST_VM=str(vm))
commands=[['cargo','+nightly-2026-09-08','test','--locked','--offline','--jobs','2','--package','rust-interp-mir-export','--target-dir',str(target)]]
commands += [['python3','-m','unittest','discover','-s','tests','-p',pattern,'-v'] for pattern in ['test_demand_retention_launcher.py','test_demand_retention.py','test_demand_retention_cargo.py','test_borrowck_cache_launcher.py','test_borrowck_cache.py']]
status=0
with lockpath.open('a+') as lock:
 deadline=time.monotonic()+300
 while True:
  try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB); break
  except BlockingIOError:
   if time.monotonic()>deadline: raise SystemExit('shared lock unavailable after bounded wait')
   print('waiting for shared lock',flush=True);time.sleep(15)
 for stage,command in enumerate(commands):
  row={'command':command,'started_at':time.time(),'log':str(out/f'{stage}.log')};receipt['commands'].append(row)
  with pathlib.Path(row['log']).open('w') as log:
   child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
   row['pid']=child.pid;save();print('task-owned correctness PID',child.pid,'stage',stage,flush=True)
   while child.poll() is None:
    try: child.wait(timeout=30)
    except subprocess.TimeoutExpired: print('correctness stage still running',stage,'PID',child.pid,flush=True)
  row['returncode']=child.returncode;row['finished_at']=time.time();save()
  print(pathlib.Path(row['log']).read_text()[-5000:],flush=True)
  if child.returncode:status=child.returncode;break
receipt['source_after']=snapshot();receipt['source_unchanged']=receipt['source_before']==receipt['source_after']
receipt['binaries']={str(p.relative_to(root)):digest(p) for p in [target/'debug/rust-interp-mir-export',target/'debug/rust-interp-rustc-wrapper']}
receipt['finished_at']=time.time();save()
if not receipt['source_unchanged']:raise SystemExit('source inputs changed during correctness run')
sys.exit(status)
