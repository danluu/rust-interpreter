#!/usr/bin/env python3
"""Retain the post-getcwd census and its four actual compiler-only observations."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import time

ROOT=Path('/Users/danluu/dev/rust-interp-hir-upgrade-controls-evidence-20260913')
WORK=ROOT/'.work/build-script-census-archive-03'
OUTPUT=ROOT/'results/build-script-export-census-03'
SOURCE=ROOT/'.work/census-build-script-export-03.py'
SOURCE_SHA='118d24e0c7bd5060f21adaca3bb12499bccdf56232a3899ee58282474468d01f'
PLAN_SHA='b1041da1913f0179cd8ad550264ed1cd50d989718da837b0466c4427094bf9d5'
RUN_SHA='5f1dda60b0955ce8f7a017de228d5e46c229ee197c08611bcc0faa67ee3fbf68'
OLD=ROOT/'.work/build-script-export-census-01'
CURRENT=ROOT/'.work/build-script-export-census-03'
TERMINALS=[(CURRENT/'plan/receipt.json','557371ffa3bd37aa40e5368c84610e60b3607d059db4584c6c994dcfb3207708','plan',3),
    (CURRENT/'run/receipt.json',RUN_SHA,'run',3)]

def digest(data):return hashlib.sha256(data).hexdigest()
if digest(SOURCE.read_bytes())!=SOURCE_SHA:raise RuntimeError('frozen census helper changed')
spec=importlib.util.spec_from_file_location('census_for_archival',SOURCE)
c=importlib.util.module_from_spec(spec);sys.modules[spec.name]=c;spec.loader.exec_module(c)
q=c.q
require,sha,write=c.require,c.sha,c.write

def main():
    WORK.mkdir(exist_ok=False)
    receipt=dict(status='waiting',owner=str(ROOT),pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),
        canonical_lock=str(q.owned.CANONICAL_LOCK),wait_seconds=600,compiler_or_test_commands=0,helper_sha256=sha(Path(__file__)))
    write(WORK/'receipt.json',receipt)
    try:
        with q.owned.workload_lock(q.owned.CANONICAL_LOCK,600):
            receipt.update(admitted_at=time.time(),status='archiving',free_bytes_before=q.owned.disk(ROOT));write(WORK/'receipt.json',receipt)
            selected={}
            def add(path,expected=None):
                path=c.ordinary(path);data=path.read_bytes();row=dict(source=str(path),sha256=digest(data),bytes=len(data))
                require(expected is None or row['sha256']==expected,'archive input changed: '+str(path))
                require(str(path) not in selected or selected[str(path)]==row,'archive input changed between reads')
                selected[str(path)]=row;return data
            def tree(path):
                for path in q.files(path):add(path)
            plan=json.loads(add(CURRENT/'plan.json',PLAN_SHA));run=json.loads(add(CURRENT/'run/receipt.json',RUN_SHA))
            require(run['status']=='passed' and run['compiler_commands']==4 and run['main_audits']==3
                and run['plan_sha256']==PLAN_SHA and run['guest_executions']==run['native_build_script_executions']==0
                and not run['performance_claim'] and len(run['commands'])==4,'actual census scope differs')
            require(plan['commands']==c.command_plan() and plan['configuration']==c.configuration()
                and plan['built_source_policy']=='complete-archived-qualified-sources-v1','frozen census recipe differs')
            require(not (OLD/'run').exists() and not (OLD/'fixture').exists(),'old metadata-only history was executed')
            for path,expected,stage,attempt in TERMINALS:
                row=json.loads(add(path,expected))
                require(row['status']==('planned' if stage=='plan' else 'passed')
                    and row['stage']==stage and row['owner']==str(ROOT),'terminal history changed')
                if stage=='plan':
                    require(row['commands']==[],'metadata history contains a child')
                    base=path.parent.parent;add(base/'plan.json',row['plan_sha256'])
                    index=json.loads(add(base/'plan/source-snapshots.json',row['snapshot_index_sha256']))
                    require(len(index)==231,'snapshot inventory cardinality differs')
                    for snapshot in index.values():
                        data=add(snapshot['snapshot'],snapshot['sha256']);require(len(data)==snapshot['bytes'],'snapshot size differs')
                outer=ROOT/'.work/experiments'/f'build-script-export-census-{stage}-supervisor-{attempt:02d}'
                status=json.loads(add(outer/'status.json'))
                require(status['status']=='finished' and status['returncode']==0 and status['child_pid']==row['pid']
                    and status['supervisor_pid']==row['parent_pid'] and status['started_at']<=row['started_at']
                    and row['finished_at']<=status['finished_at'],'actual supervisor association differs')
                add(outer/'plan.json',status['plan_sha256']);add(outer/'command.log',status['log_sha256']);add(outer/'supervisor.log')
            for i,ref in enumerate(run['commands']):
                path=Path(ref['path']);child=json.loads(add(path,ref['sha256']));expected=plan['commands'][i]
                require(path==CURRENT/'run/commands'/f'{i:03d}'/'receipt.json' and child['command']==expected['command']
                    and child['cwd']==expected['cwd'] and child['environment']==expected['environment']
                    and child['returncode']==0 and child['status']=='finished' and child['supervisor_pid']==run['pid']
                    and run['admitted_at']<=child['started_at']<=child['finished_at']<=run['finished_at'],'compiler child differs')
                for stream in ['stdout','stderr']:add(path.parent/stream,child[stream+'_sha256'])
            observations=json.loads(add(CURRENT/'run/observations.json',run['observations_sha256']))
            require([r['configuration'] for r in observations]==[name for name,_ in c.MODES],'audit configuration set differs')
            for i,row in enumerate(observations,start=1):
                report=Path(row['report']);data=add(report,row['sha256']);result=json.loads(data)
                child=json.loads(Path(run['commands'][i]['path']).read_bytes())
                require(row['result']==result and row['actual_compiler_child']==child['pid']
                    and row['child_receipt_sha256']==run['commands'][i]['sha256']
                    and result['kind']=='lowering-audit' and result['strict_frontend'] is True and result['executed'] is False
                    and result['requested']==result['blocked']==1 and result['lowered']==0
                    and result['entries'][0]['entry']=='main' and result['entries'][0]['status']=='blocked'
                    and result['entries'][0]['error']==('libc::unix::_exit: MIR unavailable for libc::unix::_exit' if row['configuration']=='unsupported-build-operation' else 'libc::unix::fstat: MIR unavailable for libc::unix::fstat'),
                    'retained first blocker differs')
                require(add(report.parent/'metadata.rmeta.audit.json')==data,'audit sidecar differs')
            artifacts=json.loads(add(CURRENT/'run/artifacts.json',run['artifacts_sha256']))
            add(CURRENT/'helper/libibs_fixture_helper.rmeta',run['helper_metadata_sha256'])
            prior=c.load_prerequisites()
            require(prior['live_helpers']==plan['live_helpers'],'executing Python helper identity differs')
            def guard():
                require(c.configuration()==plan['configuration'],'census configuration changed')
                q.guard_records(prior['records']+artifacts,full=True)
                require(c.imported_paths()==prior['imported_paths'],'executing Python closure changed')
                require(q.std_proof(prior['qualified_plan']['versions']['rustc'])==prior['qualified_plan']['std'],'std changed')
                for root in [c.FIXTURE,c.COPIED]:
                    require({str(p.relative_to(root)):sha(p) for p in q.files(root)}==plan['fixture'],'fixture changed')
                for value in list(prior['qualified_plan']['closures'].values())+list(prior['tools']['closures'].values()):
                    require(q.loaders.library_state(value['identity'])==value['state'],'loader closure changed')
                for ref in c.ARCHIVES.values():
                    for key,name in [('archive','evidence.tar.gz'),('manifest','manifest.json'),('summary','summary.json')]:
                        require(sha(Path(ref['root'])/name)==ref[key],'qualified archive reference changed')
                for row in selected.values():require(sha(row['source'])==row['sha256'],'selected archive input changed')
                q.owned.disk(ROOT)
            tree(CURRENT)
            add(SOURCE,SOURCE_SHA)
            add(ROOT/'.work/build-script-export-census-03-review.json','3539b914d098bebc15910e5fd5cbe0780db418a42f37d8a3a1d8e8c803361fd8')
            for name in ['build-script-export-census-plan-launch-03','build-script-export-census-run-admission-03']:
                for suffix in ['.json','.stdout','.stderr']:add(ROOT/'.work'/(name+suffix))
            add(ROOT/'.work/build-script-export-census-03-from-02.diff','d5f9d808bac5befc35825dd387ae8de579cff86f7fa86ddab72a10801e72c083')
            add(ROOT/'.work/build-script-census-archive-launch-03.json')
            add(ROOT/'.work/build-script-census-archive-03.README.md')
            for p in [Path(__file__),ROOT/'scripts/supervise_experiment.py',*prior['own_sources']]:add(p)
            for row in prior['live_helpers']:add(row['path'],row['sha256'])
            for ref in c.ARCHIVES.values():
                for name in ['manifest.json','summary.json']:add(Path(ref['root'])/name)
            guard();OUTPUT.mkdir(parents=True,exist_ok=False)
            archive=OUTPUT/'evidence.tar.gz';manifest={};first={}
            with tarfile.open(archive,'w:gz',compresslevel=6) as bundle:
                for name,row in sorted(selected.items()):
                    data=Path(name).read_bytes();require(digest(data)==row['sha256'],'input changed during compression');q.owned.disk(ROOT)
                    member=name.lstrip('/');info=tarfile.TarInfo(member);info.mode=0o600;info.mtime=0;key=(row['sha256'],row['bytes'])
                    if key in first:info.type=tarfile.LNKTYPE;info.linkname=first[key];bundle.addfile(info)
                    else:info.size=len(data);bundle.addfile(info,io.BytesIO(data));first[key]=member
                    manifest[member]=row
            seen=set()
            with tarfile.open(archive,'r:gz') as bundle:
                for member in bundle:
                    require(member.name in manifest and member.name not in seen and (member.isfile() or member.islnk()),'archive membership differs')
                    stream=bundle.extractfile(member);require(stream is not None,'missing archive bytes')
                    with stream:data=stream.read()
                    expected=manifest[member.name];require(digest(data)==expected['sha256'] and len(data)==expected['bytes'],'archive readback differs');seen.add(member.name)
            require(seen==set(manifest),'archive incomplete');guard();write(OUTPUT/'manifest.json',manifest)
            summary=dict(status='passed',plan_sha256=PLAN_SHA,run_receipt_sha256=RUN_SHA,metadata_children=[0],compiler_children=4,
                audits=observations,guest_executions=0,native_build_script_executions=0,performance_claim=False,
                scope='First strict lowering blocker per configuration; later support unknown',qualified_archive_references=c.ARCHIVES,
                actual_binaries=plan['actual_binaries'],source_checkpoint=c.SOURCE,snapshots=[231],
                archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,archive_members=len(manifest),physical_members=len(first),
                all_member_hashes_verified=True,all_current_runtime_helper_std_fixture_guards_passed=True)
            (OUTPUT/'README.md').write_bytes((ROOT/'.work/build-script-census-archive-03.README.md').read_bytes())
            write(OUTPUT/'summary.json',summary)
            receipt.update(status='passed',finished_at=time.time(),archive_sha256=summary['archive_sha256'],archive_members=len(manifest),free_bytes_after=q.owned.disk(ROOT))
            write(WORK/'receipt.json',receipt);write(OUTPUT/'archive-receipt.json',receipt);print(json.dumps(summary,sort_keys=True))
    except BaseException as error:
        receipt.update(status='failed',error=repr(error),finished_at=time.time());write(WORK/'receipt.json',receipt);raise

if __name__=='__main__':main()
