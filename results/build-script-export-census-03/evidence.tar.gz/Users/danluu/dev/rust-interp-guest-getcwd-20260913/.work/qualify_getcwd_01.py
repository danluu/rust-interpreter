#!/usr/bin/env python3
"""Fixed getcwd correctness sequence; plan first, reviewed SHA before build."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time

ROOT = Path('/Users/danluu/dev/rust-interp-guest-getcwd-20260913')
WORK = ROOT / '.work/getcwd-qualification-01'
TARGET = WORK / 'target'
PLAN = WORK / 'plan.json'
PUBLIC = Path('/Users/danluu/.rustup/toolchains/nightly-2026-09-08-aarch64-apple-darwin')
STD = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913/.work/std-mir/bd27cc0f910e0c93a9a6cf088789ef526d36a8697a7717e08d7585f5d19467ef')
PYTHON = Path('/opt/homebrew/bin/python3')
HOST = 'aarch64-apple-darwin'
CHECKPOINT = 'c176cc5cd8228bdb2911a3438b51455b9acd5695'
DOC_CHECKPOINT = CHECKPOINT
COMPILER = 'cea272fa356e94bd2ee2cadf376630aa0683867a'
POLICY = 'getcwd-native-correctness-v1'
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'experiments/stable-cgu')]
import owned_stage as owned
import custom_cargo_libraries as loaders
import std_mir
from public_tool_publication import file_identity
from toolchain_lookup import _stamp
spec = importlib.util.spec_from_file_location('descriptor_build_inputs', ROOT / 'benchmarks/experiments/host-proc-macro/build.py')
inputs = importlib.util.module_from_spec(spec); sys.modules[spec.name] = inputs; spec.loader.exec_module(inputs)
require, sha, write = owned.require, owned.sha, owned.write
RUST_TESTS = [
    'getcwd::tests::disabled_partial_target_and_register_admission_precede_both_engines',
    'getcwd::tests::darwin::native_buffer_null_sizes_full_bytes_errno_and_owned_free_agree',
    'getcwd::tests::darwin::invalid_pointer_size_and_errno_fail_before_memory_or_host_errno_changes',
    'getcwd::tests::darwin::null_allocation_charges_live_count_register_and_byte_budgets_without_leaks',
]
PYTHON_TESTS = [
    'test_native_null_and_buffer_contracts_both_engines_and_default_refusal',
    'test_incompatible_getcwd_abis_reject_during_export',
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def ordinary(path):
    path = Path(path)
    require(path.is_absolute() and path.is_file() and not path.is_symlink()
            and path.resolve(strict=True) == path, 'expected ordinary file: ' + str(path))
    return path


def files(root):
    root = Path(root)
    require(root.is_dir() and root.resolve(strict=True) == root, 'expected ordinary directory: ' + str(root))
    found = []
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink(), 'unexpected source/artifact symlink: ' + str(p))
        if p.is_dir(): continue
        found.append(ordinary(p))
    return found


def environment():
    return dict(HOME='/Users/danluu', CARGO_HOME='/Users/danluu/.cargo', RUSTUP_HOME='/Users/danluu/.rustup',
        PATH=str(PUBLIC / 'bin') + ':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
        RUSTC=str(PUBLIC / 'bin/rustc'), RUSTDOC=str(PUBLIC / 'bin/rustdoc'),
        RUSTUP_TOOLCHAIN='nightly-2026-09-08-aarch64-apple-darwin', TMPDIR=str(WORK / 'tmp') + '/',
        LANG='C', LC_ALL='C', TZ='UTC', CARGO_TERM_COLOR='never', CARGO_NET_OFFLINE='true',
        PYTHONDONTWRITEBYTECODE='1')


def native_environment():
    return environment() | dict(RUST_INTERP_TEST_RUSTC=str(PUBLIC / 'bin/rustc'),
        RUST_INTERP_TEST_EXPORTER=str(TARGET / 'release/rust-interp-mir-export'),
        RUST_INTERP_TEST_VM=str(TARGET / 'release/rust-interp-vm'),
        RUST_INTERP_TEST_STD_SYSROOT=str(STD / 'sysroot'), RUST_INTERP_TEST_ARTIFACT_DIR=str(WORK / 'native'))


def commands():
    cargo = str(PUBLIC / 'bin/cargo')
    return [
        [cargo, 'test', '--workspace', '--release', '--locked', '--offline', '--jobs', '2', '--target-dir', str(TARGET), '--', '--test-threads=2'],
        [cargo, 'build', '--release', '--locked', '--offline', '--jobs', '2', '--target-dir', str(TARGET),
         '-p', 'rust-interp-bytecode', '-p', 'rust-interp-mir-export', '--bin', 'rust-interp-vm', '--bin', 'rust-interp-mir-export'],
        [str(PYTHON), '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_getcwd_native.py', '-v'],
    ]


def source_paths():
    fixed = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'tests/getcwd_fixture.rs',
             'tests/test_getcwd_native.py', 'tests/test_descriptor_io_native.py', 'docs/GETCWD.md',
             'scripts/supervise_experiment.py']
    paths = {ordinary(ROOT / name) for name in fixed} | set(files(ROOT / 'crates')) | {ordinary(Path(__file__))}
    # Freeze the actual imported local implementation closure, without invoking a publisher.
    for module in list(sys.modules.values()):
        name = getattr(module, '__file__', None)
        if name and Path(name).suffix == '.py' and Path(name).is_relative_to(ROOT):
            paths.add(ordinary(Path(name)))
    return sorted(paths)


def configs():
    config = inputs.configuration(environment())
    require(not config['files'] and not any(config['searches'].values()), 'Cargo configuration requires a separately reviewed recipe')
    for name in config['searches']:
        path = Path(name)
        for parent in path.parents:
            require(not parent.is_symlink(), 'Cargo search path contains a symlink: ' + str(parent))
    return config


def snapshot(paths, directory):
    directory.mkdir(parents=True, exist_ok=False)
    rows = []
    index_path = directory.parent / 'source-inputs.json'
    write(index_path, dict(complete=False, files=rows))
    for index, path in enumerate(paths):
        owned.disk(ROOT)
        row = file_identity(ordinary(path)); data = path.read_bytes()
        require(digest(data) == row['sha256'] and _stamp(path) == row['stamp'], 'input changed during snapshot')
        dest = directory / f'{index:04d}'
        dest.write_bytes(data)
        rows.append(dict(**row, snapshot=str(dest)))
        write(index_path, dict(complete=False, files=rows))
    write(index_path, dict(complete=True, files=rows))
    return rows


def guard_records(records, *, full=False):
    for record in records:
        path = Path(record['path'])
        require(_stamp(path) == record['stamp'], 'input stamp changed: ' + str(path))
        if full: require(file_identity(path) == {k:v for k,v in record.items() if k != 'snapshot'}, 'input bytes changed: ' + str(path))
        if 'snapshot' in record:
            require(sha(ordinary(record['snapshot'])) == record['sha256'], 'retained source snapshot changed')


def std_proof(version):
    ready_path = ordinary(STD / 'ready.json')
    ready = json.loads(ready_path.read_bytes()); identity = ready['identity']
    require(ready['owner'] == '/Users/danluu/dev/rust-interp-semantic-reuse-20260913'
            and set(identity) == {'policy', 'compiler', 'target', 'flags', 'lock_sha256'}
            and identity['policy'] == std_mir.POLICY and identity['flags'] == std_mir.FLAGS
            and identity['target'] == HOST and identity['compiler'] == version
            and re.fullmatch('[0-9a-f]{64}', identity['lock_sha256'])
            and digest(json.dumps(identity, sort_keys=True).encode()) == STD.name,
            'prepared public std identity differs')
    require(re.fullmatch('[0-9a-f]{64}', ready['source_sha256'])
            and len(ready['artifacts']) == 26, 'prepared std source/artifact receipt incomplete')
    expected = {str(STD / name) for name in ready['artifacts']}
    require(expected == {str(p) for p in files(STD / 'sysroot')}, 'prepared std has a different exact inventory')
    library = Path('sysroot/lib/rustlib') / HOST / 'lib'
    for crate in ['core', 'alloc', 'std', 'test', 'proc_macro']:
        require(sum(Path(name).parent == library and re.fullmatch('lib' + crate + r'-[0-9a-f]+\.rmeta', Path(name).name) is not None
                    for name in ready['artifacts']) == 1, 'required prepared std metadata missing: ' + crate)
    records = [file_identity(ready_path)]
    for name, row in sorted(ready['artifacts'].items()):
        path = ordinary(STD / name)
        require(path.is_relative_to(STD / library) and path.suffix == '.rmeta'
                and std_mir.stamp(path) == row['stamp'] and sha(path) == row['sha256'], 'prepared std artifact changed')
        records.append(file_identity(path))
    require(sha(PUBLIC / 'lib/rustlib/src/rust/library/Cargo.lock') == identity['lock_sha256'],
            'prepared std library lock differs from selected compiler component')
    return dict(path=str(STD), ready_sha256=sha(ready_path), ready=ready, files=records)


def rust_results(text):
    for name in RUST_TESTS:
        require(len(re.findall(r'^test ' + re.escape(name) + r' \.\.\. ok$', text, re.M)) == 1,
                'required getcwd Rust test did not pass once: ' + name)
    rows = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
    require(rows and all(int(failed) == int(measured) == int(filtered) == 0 for _,failed,_,measured,filtered in rows),
            'workspace summaries incomplete or filtered')
    return dict(suites=len(rows), passed=sum(int(row[0]) for row in rows), ignored=sum(int(row[2]) for row in rows),
                failed=0, filtered=0, getcwd_tests=RUST_TESTS)


def native_results(command_record, text):
    require(re.search(r'(?m)^Ran 2 tests in [0-9.]+s$', text) and re.search(r'(?m)^OK$', text)
            and 'skipped' not in text, 'native Python suite did not pass exactly two tests without skips')
    for name in PYTHON_TESTS:
        require(len(re.findall(r'^' + name + r' \(test_getcwd_native\.GetcwdNativeTests\.' + name + r'\) \.\.\. ok$', text, re.M)) == 1,
                'required Python test did not pass once: ' + name)
    nested_env = {k: environment()[k] for k in ['PATH', 'HOME', 'TMPDIR', 'LC_ALL', 'LANG', 'TZ']}
    rustc, exporter, vm = [str(Path(p).resolve(strict=True)) for p in [PUBLIC / 'bin/rustc', TARGET / 'release/rust-interp-mir-export', TARGET / 'release/rust-interp-vm']]
    rows = []
    for index, name in enumerate(PYTHON_TESTS):
        root = WORK / 'native' / name
        count = 29 if index == 0 else 4
        require(sorted(p.name for p in root.glob('command-*.json')) == [f'command-{i:03}.json' for i in range(1,count+1)], 'nested command inventory differs')
        def read(i, argv, cwd=None, extra=None, success=True, diagnostic=None):
            path = root / f'command-{i:03}.json'; row = json.loads(ordinary(path).read_bytes())
            require(row['command'] == list(map(str, argv)) and row['cwd'] == str(cwd or root)
                    and row['environment'] == nested_env | dict(extra or {}) and row['status'] == 'finished'
                    and row['parent_pid'] == command_record['pid'] and isinstance(row['pid'], int) and row['pid'] > 0
                    and command_record['started_at'] <= row['started_at'] <= row['finished_at'] <= command_record['finished_at']
                    and (row['returncode'] == 0 if success else row['returncode'] != 0), 'nested command route/outcome changed')
            payload = {}
            for stream in ['stdout', 'stderr']:
                p = root / f'command-{i:03}.{stream}'
                require(row[stream]['path'] == str(p) and sha(ordinary(p)) == row[stream]['sha256'], 'nested raw output differs')
                payload[stream] = p.read_bytes()
            require(b'internal compiler error' not in payload['stderr'], 'nested compiler panicked')
            if diagnostic: require(diagnostic in payload['stderr'], 'expected negative diagnostic missing')
            rows.append(dict(path=str(path), sha256=sha(path), **row))
            return (row['returncode'], payload['stdout'], payload['stderr'])
        def export(i, source, artifact, **kwargs):
            return read(i, [exporter, source, '--crate-name', 'descriptor_io_fixture', '--edition=2024', '--emit=metadata',
                '--sysroot', STD / 'sysroot', '-Copt-level=0', '-o', artifact.with_suffix('.rmeta')],
                extra=dict(RUST_INTERP_ENTRY='rust_interp_entry', RUST_INTERP_OUTPUT=str(artifact), RUST_INTERP_DEMAND_BODIES='0', RUST_INTERP_DEMAND_CACHE='0'), **kwargs)
        if index == 0:
            source, native, artifact = root / 'fixture.rs', root / 'native', root / 'fixture.rbc'
            require(source.read_bytes() == (ROOT / 'tests/getcwd_fixture.rs').read_bytes()
                and artifact.is_file() and native.is_file(), 'actual getcwd fixture/native/RBC missing or changed')
            read(1, [rustc, source, '--edition=2024', '-Copt-level=0', '-o', native]); export(2, source, artifact)
            cwd = root / 'cwd with spaces and é'; extra = dict(RUST_INTERP_GETCWD_EXPECTED=str(cwd))
            for i, engine in enumerate(['interpreter', 'jit'], start=3):
                read(i, [vm, '--engine', engine, artifact, '0'], cwd=cwd, extra=extra,
                    success=False, diagnostic=b'guest getcwd is disabled')
            for mode in range(6):
                expected = read(5+mode*3, [native, str(mode)], cwd=cwd, extra=extra)
                require((int(expected[1]) & 0xffff_ffff) == (8 if mode in [1,2] else 29 if mode >= 3 else 15),
                    'native pointer/path/full-byte comparison bits differ')
                for offset, engine in enumerate(['interpreter', 'jit'], start=1):
                    actual = read(5+mode*3+offset, [vm, '--guest-getcwd', '--engine', engine, artifact, str(mode)], cwd=cwd, extra=extra)
                    require(actual == expected, 'native/getcwd path/result/errno differs')
            wrong = dict(RUST_INTERP_GETCWD_EXPECTED=str(cwd)+'-wrong')
            expected = read(23, [native, '0'], cwd=cwd, extra=wrong)
            require(int(expected[1]) & 0xffff_ffff == 11, 'wrong-path native negative did not clear exact byte-match bit')
            for engine_index, engine in enumerate(['interpreter', 'jit']):
                actual = read(24+engine_index*3, [vm, '--guest-getcwd', '--engine', engine, artifact, '0'], cwd=cwd, extra=wrong)
                require(actual == expected, 'wrong-path guest negative differs from native')
                for offset, mode in enumerate([10,11], start=1):
                    actual = read(24+engine_index*3+offset, [vm, '--guest-getcwd', '--engine', engine, artifact, str(mode)],
                        cwd=cwd, extra=extra, success=False)
                    require(any(message in actual[2] for message in [b'guest memory', b'address overflow', b'read-only guest']),
                        'invalid getcwd guest buffer did not report checked memory error')
            require(not list(cwd.iterdir()), 'getcwd-only history created cwd files')
        else:
            suite = ast.parse((ROOT / 'tests/test_getcwd_native.py').read_bytes())
            method = next(n for n in ast.walk(suite) if isinstance(n, ast.FunctionDef) and n.name == name)
            loop = next(n for n in method.body if isinstance(n, ast.For) and isinstance(n.iter, ast.List))
            cases = ast.literal_eval(loop.iter); require(len(cases) == 4, 'frozen getcwd negative ABI table changed')
            for i, (case, signature, call) in enumerate(cases, start=1):
                source, artifact = root / (case + '.rs'), root / (case + '.rbc')
                expected_source = (f'unsafe extern "C" {{ {signature} }}\n'
                    f'pub fn rust_interp_entry()->u64 {{ unsafe {{ {call} as u64 }} }}\nfn main() {{}}\n')
                require(source.read_bytes() == expected_source.encode(), 'actual getcwd negative source differs from frozen fixture')
                export(i, source, artifact, success=False, diagnostic=b'invalid getcwd signature')
                require(not artifact.exists(), 'negative export produced bytecode')
    return dict(tests=2, children=rows, artifacts=[file_identity(p) for p in files(WORK / 'native')],
        path_comparisons='Full C-string equality to independent cwd; explicit pointer/sentinel bits and complete errno; wrong-cwd negative')


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('stage', choices=['plan', 'run'])
    parser.add_argument('--plan-sha256')
    args = parser.parse_args()
    require(Path(__file__).resolve() == ROOT / '.work/qualify_getcwd_01.py' and Path.cwd() == ROOT,
            'fixed helper location/cwd required')
    require(sys.version_info >= (3,11) and Path(sys.executable).resolve() == PYTHON.resolve(strict=True), 'selected Python 3.11+ required')
    if args.stage == 'plan':
        WORK.mkdir(parents=True, exist_ok=False); (WORK / 'tmp').mkdir()
    else:
        require(re.fullmatch('[0-9a-f]{64}', args.plan_sha256 or '') and sha(ordinary(PLAN)) == args.plan_sha256,
                'reviewed plan SHA required')
    out = WORK / args.stage
    out.mkdir(exist_ok=False)
    receipt = dict(schema_version=1, policy=POLICY, owner=str(ROOT), stage=args.stage, status='waiting',
        pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(), commands=[])
    write(out / 'receipt.json', receipt)
    current = None
    initial_sources, initial_config, initial_index_sha = None, None, None
    def guard(full=False):
        owned.disk(ROOT, 9)
        if current is None:
            if initial_sources is not None:
                require(configs() == initial_config and [str(p) for p in source_paths()] == [r['path'] for r in initial_sources],
                        'source/config changed during metadata preparation')
                guard_records(initial_sources, full=full)
                require(sha(out / 'source-inputs.json') == initial_index_sha, 'source snapshot index changed')
            return
        require(WORK.resolve(strict=True) == WORK and (WORK / 'tmp').resolve(strict=True) == WORK / 'tmp'
                and (WORK / 'tmp').is_dir(), 'owned work/temporary directory changed')
        require(configs() == current['configuration'] and [str(p) for p in source_paths()] == [r['path'] for r in current['sources']], 'source/configuration set changed')
        require(sha(ordinary(current['source_index']['path'])) == current['source_index']['sha256'], 'source snapshot index changed')
        records = current['sources'] + current['public']['files'] + current['std']['files']
        records += [row for pkg in current['dependencies']['packages'] for row in pkg['files']]
        records += current['closure_files']
        public_names = {str(p) for p in (PUBLIC / 'lib').rglob('*') if p.is_file()
                        and p.suffix in ('.rlib', '.rmeta', '.dylib', '.so', '.dll')}
        require(public_names == set(current['public_library_paths']), 'public compiler/std library inventory changed')
        for package in current['dependencies']['packages']:
            base = Path(package['manifest_path']).parent
            expected = {row['path'] for row in package['files'] if Path(row['path']).is_relative_to(base)}
            require(expected == {str(p) for p in files(base)}, 'dependency source inventory changed: ' + str(base))
        require(sha(ordinary(current['cargo_metadata']['path'])) == current['cargo_metadata']['sha256'], 'retained Cargo resolution changed')
        require(sha(ordinary(WORK / 'plan/std-ready.json')) == current['std']['ready_sha256'], 'retained std receipt changed')
        for value in current['sdk']['directories'].values():
            path = Path(value['path'])
            require(str(path.resolve(strict=True)) == value['resolved'] and path.is_dir(), 'selected SDK/developer directory changed')
        guard_records(records, full=full)
        for closure in current['closures'].values():
            require(loaders.library_state(closure['identity']) == closure['state'], 'public loader state changed')
        require({str(p) for p in files(STD / 'sysroot')} == {r['path'] for r in current['std']['files'][1:]}, 'std inventory changed')
        if args.stage == 'run': require(sha(PLAN) == args.plan_sha256, 'reviewed plan changed')
    def command(argv, *, env=None, label='metadata'):
        guard(); directory = out / 'commands' / f'{len(receipt["commands"]):03d}'
        ref = dict(path=str(directory / 'receipt.json'), command=list(map(str, argv)), label=label)
        receipt['commands'].append(ref); write(out / 'receipt.json', receipt)
        try:
            row = owned.run(argv, cwd=ROOT, env=env or environment(), out=directory, capacity_root=ROOT)
        finally:
            if (directory / 'receipt.json').exists():
                ref['sha256'] = sha(directory / 'receipt.json'); write(out / 'receipt.json', receipt)
        guard()
        return row, (directory / 'stdout').read_bytes(), (directory / 'stderr').read_bytes()
    def closure(path):
        def inspect(argv, *, text):
            require(text is True, 'unexpected closure inspection mode')
            return command(argv, label='loader')[1].decode()
        identity, state = loaders.library_closure(path, HOST, inspect=inspect)
        return dict(identity=identity, state=state)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK, 600):
            receipt.update(status='running', admitted_at=time.time(), free_bytes_before=owned.disk(ROOT, 16 if args.stage == 'run' else 8))
            write(out / 'receipt.json', receipt)
            if args.stage == 'plan':
                source = snapshot(source_paths(), out / 'sources')
                config = configs()
                initial_sources, initial_config, initial_index_sha = source, config, sha(out / 'source-inputs.json')
                # This verifies the complete production/crate tree and two fixtures, not only a clean HEAD.
                prefixes = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'crates', 'tests/getcwd_fixture.rs',
                    'tests/test_getcwd_native.py', 'tests/test_descriptor_io_native.py', 'docs/GETCWD.md']
                _, raw, _ = command(['/usr/bin/git', 'ls-tree', '-rz', CHECKPOINT, '--', *prefixes])
                tree = {}
                for item in raw.split(b'\0'):
                    if not item: continue
                    meta, name = item.split(b'\t'); mode, kind, object_id = meta.split()
                    require(kind == b'blob' and mode in [b'100644', b'100755'], 'nonordinary production Git input')
                    tree[name.decode()] = (object_id.decode(), int(mode, 8))
                actual = {str(p.relative_to(ROOT)) for p in source_paths() if str(p.relative_to(ROOT)).startswith('crates/')} | set(prefixes) - {'crates'}
                require(set(tree) == actual, 'production source inventory differs from frozen checkpoint')
                for name, (object_id, mode) in tree.items():
                    data = ordinary(ROOT / name).read_bytes()
                    require(hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == object_id
                            and bool((ROOT / name).stat().st_mode & 0o100) == (mode == 0o100755),
                            'production source bytes or Git executable class differs: ' + name)
                _, doc, _ = command(['/usr/bin/git', 'show', DOC_CHECKPOINT + ':docs/GETCWD.md'])
                require(doc == (ROOT / 'docs/GETCWD.md').read_bytes(), 'qualification document changed')
                _, head, _ = command(['/usr/bin/git', 'rev-parse', 'HEAD'])
                public = inputs.compiler_inventory(PUBLIC)
                public_library_paths = [row['path'] for row in public['files'] if Path(row['path']).is_relative_to(PUBLIC / 'lib')
                                        and Path(row['path']).suffix in ('.rlib', '.rmeta', '.dylib', '.so', '.dll')]
                public['files'] += [file_identity(p) for p in [PYTHON, Path('/usr/bin/git'), Path('/usr/bin/otool'),
                                    Path('/usr/bin/xcrun'), Path('/usr/bin/xcode-select'), Path('/usr/bin/cc'), Path('/usr/bin/ld'), Path('/usr/bin/ar')]]
                sdk = dict(directories={}, tools={}, assumption='Host SDK selection recorded; SDK contents are not a hermetic distribution')
                for name, argv in [('developer', ['/usr/bin/xcode-select', '-p']), ('sdk', ['/usr/bin/xcrun', '--show-sdk-path']),
                                   ('clang', ['/usr/bin/xcrun', '--find', 'clang']), ('ld', ['/usr/bin/xcrun', '--find', 'ld'])]:
                    _, raw_path, _ = command(argv)
                    path = Path(raw_path.decode().strip())
                    require(path.is_absolute(), 'SDK/tool selection returned a relative path')
                    if name in ('developer', 'sdk'):
                        require(path.is_dir(), 'selected SDK/developer directory missing')
                        sdk['directories'][name] = dict(path=str(path), resolved=str(path.resolve(strict=True)))
                    else:
                        row = file_identity(path); public['files'].append(row); sdk['tools'][name] = row
                _, version, _ = command([PUBLIC / 'bin/rustc', '-vV']); version = version.decode()
                _, sysroot, _ = command([PUBLIC / 'bin/rustc', '--print', 'sysroot'])
                _, cargo_version, _ = command([PUBLIC / 'bin/cargo', '-Vv'])
                _, python_version, _ = command([PYTHON, '--version'])
                require('commit-hash: ' + COMPILER + '\n' in version and 'host: ' + HOST + '\n' in version
                        and sysroot.decode().strip() == str(PUBLIC), 'actual public compiler identity differs')
                std = std_proof(version)
                (out / 'std-ready.json').write_bytes((STD / 'ready.json').read_bytes())
                _, metadata, _ = command([PUBLIC / 'bin/cargo', 'metadata', '--locked', '--offline', '--format-version=1', '--manifest-path', ROOT / 'Cargo.toml'])
                (out / 'cargo-metadata.json').write_bytes(metadata)
                dependencies = inputs.dependency_inventory(json.loads(metadata), environment(), dict(config))
                closures = {name: closure(path) for name,path in [('rustc', PUBLIC / 'bin/rustc'), ('rustdoc', PUBLIC / 'bin/rustdoc'), ('cargo', PUBLIC / 'bin/cargo'), ('python', PYTHON)]}
                closure_files = {item['logical']: file_identity(Path(item['logical'])) for value in closures.values() for item in value['identity']['libraries']}
                current = dict(schema_version=1, policy=POLICY, owner=str(ROOT), work=str(WORK), source_checkpoint=CHECKPOINT,
                    documentation_checkpoint=DOC_CHECKPOINT, actual_head=head.decode().strip(), sources=source,
                    source_index=dict(path=str(out / 'source-inputs.json'), sha256=initial_index_sha),
                    environment=environment(), native_environment=native_environment(), configuration=config, public=public,
                    versions=dict(rustc=version, cargo=cargo_version.decode(), python=python_version.decode()),
                    std=std, dependencies=dependencies, closures=closures, closure_files=list(closure_files.values()),
                    public_library_paths=sorted(public_library_paths), sdk=sdk,
                    commands=commands(), required_rust_tests=RUST_TESTS, required_python_tests=PYTHON_TESTS,
                    lock=str(owned.CANONICAL_LOCK), wait_seconds=600, capacity=dict(initial_free_gib=16, stop_gib=9, floor_gib=8),
                    cargo_metadata=dict(path=str(out / 'cargo-metadata.json'), sha256=digest(metadata)))
                guard(full=True)
                write(PLAN, current)
                receipt.update(plan=str(PLAN), plan_sha256=sha(PLAN), status='planned')
            else:
                current = json.loads(PLAN.read_bytes())
                require(current['policy'] == POLICY and current['owner'] == str(ROOT) and current['work'] == str(WORK)
                        and current['source_checkpoint'] == CHECKPOINT and current['documentation_checkpoint'] == DOC_CHECKPOINT
                        and current['commands'] == commands() and current['environment'] == environment()
                        and current['native_environment'] == native_environment() and current['required_rust_tests'] == RUST_TESTS
                        and current['required_python_tests'] == PYTHON_TESTS and current['lock'] == str(owned.CANONICAL_LOCK)
                        and current['wait_seconds'] == 600 and current['capacity'] == dict(initial_free_gib=16, stop_gib=9, floor_gib=8), 'fixed qualification plan differs')
                require(not TARGET.exists() and not (WORK / 'native').exists(), 'fresh target and native history required')
                guard(full=True)
                first, stdout, stderr = command(commands()[0], label='workspace-tests')
                receipt['workspace'] = rust_results((stdout + stderr).decode())
                write(out / 'receipt.json', receipt)
                command(commands()[1], label='standalone-build')
                binaries = [file_identity(ordinary(TARGET / 'release' / name)) for name in ['rust-interp-mir-export', 'rust-interp-vm']]
                binary_closures = {Path(row['path']).name: closure(Path(row['path'])) for row in binaries}
                binary_records = {r['path']:r for r in binaries}
                for value in binary_closures.values():
                    for item in value['identity']['libraries']:
                        binary_records[item['logical']] = file_identity(Path(item['logical']))
                write(out / 'actual-tools.json', dict(binaries=binaries, closures=binary_closures, files=list(binary_records.values())))
                guard_records(binary_records.values(), full=True)
                (WORK / 'native').mkdir()
                child, stdout, stderr = command(commands()[2], env=native_environment(), label='native-controls')
                result = native_results(child, (stdout + stderr).decode())
                guard_records(binary_records.values(), full=True)
                for value in binary_closures.values(): require(loaders.library_state(value['identity']) == value['state'], 'actual tool closure changed')
                write(out / 'native-results.json', result)
                guard(full=True)
                receipt.update(status='passed', plan_sha256=args.plan_sha256, native_results_sha256=sha(out / 'native-results.json'),
                    actual_tools_sha256=sha(out / 'actual-tools.json'), qualification_commands_passed=3, native_children_passed=33)
            receipt.update(finished_at=time.time(), free_bytes_after=owned.disk(ROOT))
            write(out / 'receipt.json', receipt)
    except BaseException as error:
        receipt.update(status='failed', error=repr(error), finished_at=time.time(), free_bytes_after=shutil.disk_usage(ROOT).free)
        write(out / 'receipt.json', receipt)
        raise


if __name__ == '__main__': main()
