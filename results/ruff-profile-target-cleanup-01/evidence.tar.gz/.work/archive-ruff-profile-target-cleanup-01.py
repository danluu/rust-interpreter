import gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
OWNER=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
DEST=OWNER/'results/ruff-profile-target-cleanup-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=set()
work=OWNER/'.work/ruff-profile-target-cleanup-01'
assert json.loads((work/'receipt.json').read_bytes())['status']=='passed'
for root in [work,OWNER/'.work/experiments/ruff-profile-target-cleanup-supervisor-01',
             OWNER/'experiments/ruff-profile-target-cleanup/plan-01']:
    paths.update(p for p in root.rglob('*') if p.is_file())
paths.update(OWNER/'.work'/name for name in ['ruff-profile-target-cleanup-assessment-01.json',
    'ruff-profile-target-cleanup-outer-launch-01.json','ruff-profile-target-cleanup-verification-01.json',
    'verify-ruff-profile-target-cleanup-01.py'])
paths.update(OWNER/'experiments/ruff-profile-target-cleanup'/name for name in ['prepare.py','remove_completed_targets.py'])
paths.add(Path(__file__).resolve())
paths.update(OWNER/'experiments/oxc-runtime-compatibility'/name for name in
             ['acquire_runtime_source.py'])
paths.update(OWNER/name for name in ['scripts/supervise_experiment.py','experiments/stable-cgu/owned_stage.py'])
assert all(p.resolve(strict=True)==p and not p.is_symlink() and p.stat().st_nlink==1 for p in paths)
assert sum(p.stat().st_size for p in paths)<48*2**20
members={str(p.relative_to(OWNER)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(paths)}
manifest=dict(schema_version=1,members=members,input_bytes=sum(v['bytes'] for v in members.values()),
    scope='Exact approved Ruff profile target cleanup plan/freeze, source, assessments, admitted inventories, readonly probes, raw supervisors, terminal receipts, deletion ledgers and independent checks. Previously committed complete Ruff profile archive and system executor bytes are referenced by frozen SHA-256 rather than duplicated here.')
DEST.mkdir(parents=True,exist_ok=False)
with (DEST/'manifest.json').open('x') as f:json.dump(manifest,f,sort_keys=True,indent=2);f.write('\n')
archive=DEST/'evidence.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
    for name,row in members.items():
        assert shutil.disk_usage(OWNER).free>=9*2**30
        data=(OWNER/name).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
        item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0;tar.addfile(item,io.BytesIO(data))
assert archive.stat().st_size<16*2**20
with tarfile.open(archive,'r:gz') as tar:
    rows=tar.getmembers();assert len(rows)==len(members) and {row.name for row in rows}==set(members)
    for row in rows:
        assert row.isfile() and row.size==members[row.name]['bytes']
        assert hashlib.sha256(tar.extractfile(row).read()).hexdigest()==members[row.name]['sha256']
    while tar.fileobj.read(1024**2):pass
print(json.dumps(dict(members=len(members),input_bytes=manifest['input_bytes'],archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),manifest_sha256=sha(DEST/'manifest.json')),indent=2))
