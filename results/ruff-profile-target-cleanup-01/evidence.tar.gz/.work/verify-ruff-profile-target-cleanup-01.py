import hashlib,json,time
from pathlib import Path
O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
W=O/'.work/ruff-profile-target-cleanup-01'
P=O/'experiments/ruff-profile-target-cleanup/plan-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
r=read(W/'receipt.json')
s=read(O/'.work/experiments/ruff-profile-target-cleanup-supervisor-01/status.json')
p=read(P/'plan.json');f=read(P/'inputs.json')
a=read(O/'.work/ruff-profile-target-cleanup-assessment-01.json');root=Path(r['root'])
assert r['status']=='passed' and s['status']=='finished' and s['returncode']==0
assert s['child_pid']==r['pid'] and r['parent_pid']==s['supervisor_pid']
assert s['started_at']<=r['started_at']<=r['admitted_at']<=r['finished_at']<=s['finished_at']
for n,h in f['files'].items():assert sha(Path(n))==h,n
assert not root.exists() and not root.is_symlink()
expected=set(a['entries'])|{'.'}
assert set(r['deleted'])==expected and len(r['deleted'])==len(expected)==14139
ledger=[json.loads(x) for x in (W/'deleted.jsonl').read_text().splitlines()]
assert len(ledger)==14139
assert [str(root if n=='.' else root/n) for n in r['deleted']]==[x['path'] for x in ledger]
assert all(r['admitted_at']<=x['time']<=r['finished_at'] for x in ledger)
assert len(r['children'])==2
for child,spec in zip(r['children'],p['commands']):
    c=child['receipt'];d=Path(child['path'])
    assert read(d/'receipt.json')==c and c['command']==spec['argv']
    assert c['environment']==p['environment'] and c['cwd']==str(O)
    assert c['supervisor_pid']==r['pid'] and c['parent_pid']==r['parent_pid']
    assert c['status']=='finished' and c['returncode'] in spec['expected']
    assert r['admitted_at']<=c['started_at']<=c['finished_at']<=r['finished_at']
    assert c['identity']['ps'].split()[:3]==[str(c['pid']),str(r['pid']),str(c['pid'])]
    for n in ['stdout','stderr']:assert sha(d/n)==c[n+'_sha256']
    assert (d/'stderr').read_bytes()==b''
    if child['label']=='open-handles':assert c['returncode']==1 and (d/'stdout').read_bytes()==b''
    else:
        for line in (d/'stdout').read_text().splitlines():
            fields=line.split();assert len(fields)>=9
            assert fields[3:8]!=p['owned_start_times'].get(fields[0])
for n,h in read(W/'preserved-evidence.json').items():assert sha(Path(n))==h,n
paths=[W/'receipt.json',W/'deleted.jsonl',W/'preserved-evidence.json',P/'inputs.json',
       O/'.work/experiments/ruff-profile-target-cleanup-supervisor-01/status.json']
v=dict(status='passed',checked_at=time.time(),exact_deleted_entries=14139,frozen_inputs=len(f['files']),
       readonly_children=2,root_absent=True,preserved_evidence=True,
       hashes={str(x.relative_to(O)):sha(x) for x in paths})
out=O/'.work/ruff-profile-target-cleanup-verification-01.json'
with out.open('x') as stream:json.dump(v,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps(v,indent=2));print('verification_sha256',sha(out))
