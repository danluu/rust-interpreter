import collections,gzip,hashlib,json,os,shutil,stat,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json
from custom_compiler import load_compiler,validate_tool_compiler
from interpreter import installed_tools
from std_mir_source_paths import load as load_std
WORK=ROOT/'.work/mono-failed-screen-target-inspection-01'
RAW=ROOT/'.work/strict-warm-mono-production-screen-01'
RESULT=ROOT/'results/strict-warm-mono-production-screen-01'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
WORK.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
def digest(path):return sha(Path(path).read_bytes())
def write(name,value):write_json(WORK/name,value)
def space():
 free=shutil.disk_usage(ROOT).free
 assert free>=8*1024**3,'inspection requires 8 GiB free space'
 return free
def ordinary(path):
 assert path.resolve(strict=True)==path and not path.is_symlink(),str(path)
def walk(base,exclude=()):
 for directory,dirs,names in os.walk(base,followlinks=False):
  dirs[:]=sorted(n for n in dirs if Path(directory)/n not in exclude)
  for name in dirs:assert not (Path(directory)/name).is_symlink(),str(Path(directory)/name)
  for name in sorted(names):yield Path(directory)/name
retained={}
def retain(path):
 path=Path(path);ordinary(path);assert path.is_file(),str(path)
 data=path.read_bytes();proof=dict(sha256=sha(data),bytes=len(data))
 if str(path) in retained:assert retained[str(path)]==proof,'retained file changed: '+str(path)
 retained[str(path)]=proof;return data
def dependency_state(path):
 path=Path(path)
 if not path.exists() and not path.is_symlink():return None
 s=path.stat();link=path.lstat()
 return dict(resolved=str(path.resolve(strict=True)),device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,logical=[link.st_dev,link.st_ino,link.st_mode,link.st_size,link.st_mtime_ns,link.st_ctime_ns],symlink=os.readlink(path) if path.is_symlink() else None)
record=dict(schema_version=1,status='waiting',owner=str(ROOT),pid=os.getpid(),parent_pid=os.getppid(),
 started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,deleted=[],workloads_executed=0,
 scope='inspection only: three failed-but-completed Mono cold-screen inner Cargo targets',screen_status='failed',screen_commands=3)
write('summary.json',record)
try:
 with LOCK.open('r+') as lock:
  acquire_lock(lock,600)
  record.update(status='inspecting',lock_acquired_at=time.time(),free_bytes_before=space())
  record['revision']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
  write('summary.json',record)
  source_paths={Path(__file__),ROOT/'scripts/supervise_experiment.py'}|{Path(m.__file__) for m in tuple(sys.modules.values()) if getattr(m,'__file__',None) and str(m.__file__).startswith(str(ROOT/'scripts')+'/')}
  for path in source_paths:
   data=retain(path);dest=WORK/'sources'/path.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  completed=json.loads(retain(RAW/'summary.json'));plan=json.loads(retain(RAW/'plan.json'));rows=json.loads(retain(RAW/'records.json'))
  assessed=json.loads(retain(RESULT/'summary.json'))
  assert completed['status']==assessed['status']=='failed' and completed['source_restored'] and assessed['source_restored']
  assert len(rows)==completed['commands']==assessed['commands']==3
  assert completed['error']==assessed['reason']=='executed bytecode or entry catalogs differ between arms'
  assert assessed['edited_commands']==0 and assessed['latency_qualified'] is False
  archive=RESULT/assessed['archive']['path'];assert sha(retain(archive))==assessed['archive']['sha256']=='a771de9d254f77dd60afa4d47e1919fd4d5146853a8dca60a34cebdb1de9839b'
  assert assessed['archive']['all_member_hashes_verified'] is True
  archive_manifest=json.loads(retain(RESULT/'manifest.json'))
  for name in ['summary.json','plan.json','records.json','transitions.json']:
   assert sha(retain(RAW/name))==archive_manifest['screen/'+name]['sha256']
  assert assessed['structured_changes']==dict(functions=80,traps=153,constant_data_paths=18,other_fields=0,changed_bytes=10431)
  completion={}
  supervisors=[(ROOT/'.work/experiments/mono-production-screen-supervisor-01',1),
    (Path('/Users/danluu/dev/rust-interp-source-observable-transport-20260913/.work/experiments/mono-screen-failure-archive-supervisor-02'),0)]
  for directory,expected in supervisors:
   value=json.loads(retain(directory/'status.json'));assert value['status']=='finished' and value['returncode']==expected
   assert sha(retain(directory/'plan.json'))==value['plan_sha256']
   assert sha(retain(directory/'command.log'))==value['log_sha256']
   completion[str(directory)]=value
   for path in walk(directory):retain(path)
  for number in ['01','02','03']:
   directory=ROOT/('.work/mono-screen-bytecode-inspection-'+number)
   for path in walk(directory,exclude=(directory/'target',)):retain(path)
  for row in rows:
   receipt=json.loads(retain(RAW/'receipts'/f"{row['index']}-{row['mode']}.json"))
   assert receipt['status']=='finished' and receipt['pid']==row['pid'] and receipt['returncode']==row['returncode']
  source=Path(plan['source'])/plan['case']['file'];assert sha(retain(source))==plan['original_source_sha256']
  retain(Path(plan['source'])/'.rust-interp-owned.json')
  cache=RAW/'caches';ordinary(cache)
  assert {p.name for p in cache.iterdir()}=={'baseline','candidate','duplicate'}
  namespace='rust-interp-'+sha(str(ROOT).encode())[:24]
  candidates={}
  workspaces={row['mode']:row['launch']['workspace_path'] for row in rows}
  assert set(workspaces)=={'baseline','candidate','duplicate'}
  for arm,workspace in workspaces.items():
   assert arm in ('baseline','candidate','duplicate')
   parent=cache/arm;ordinary(parent);assert {p.name for p in parent.iterdir()}=={namespace}
   marker=parent/namespace/'.rust-interp-cache.json'
   assert json.loads(retain(marker))==dict(schema_version=1,kind='rust-interp-cache',owner=str(ROOT))
   workspace=Path(workspace);ordinary(workspace)
   expected_leaf={'baseline':'da4a0bf16d0bd7149e212ce6','candidate':'b9c3f42a0c622de7ec29d79c','duplicate':'6024acd20f4af941c3810f24'}
   assert workspace==parent/namespace/'workspaces'/'45aadeafe86e1268c37d3c2d4344c99d3e2a8f142b1d218d484292fd0990a463'/expected_leaf[arm]
   target=workspace/'target';ordinary(target);assert target.is_dir()
   candidates[arm]=target
  selected=list(candidates.values())
  assert len(selected)==3 and len(set(selected))==3
  for path in walk(RAW,exclude=(cache,)):retain(path)
  for path in walk(RESULT):retain(path)
  for path in walk(cache,exclude=tuple(selected)):retain(path)
  artifact_paths=set()
  for row in rows:
   assert row['phase']=='cold' and row['label']=='cold-original' and row['returncode']==0 and row['validated']
   assert row['stdout']=='0\n' and len(row['outcomes'])==14 and all(v=='passed' for _,v in row['outcomes'])
   for item in row['artifacts']:
    path=ROOT/item['path'];assert path.is_relative_to(RAW/'artifacts')
    data=retain(path);assert sha(data)==item['sha256'] and len(data)==item['bytes'];artifact_paths.add(path)
   assert digest(Path(row['launch']['suite_report_path']))==row['suite_sha256']==row['launch']['suite_report_sha256']
  artifact_count=len(artifact_paths)
  key='45aadeafe86e1268c37d3c2d4344c99d3e2a8f142b1d218d484292fd0990a463'
  compiler_key='f9fb3e5f59b8567fffd32c936a9864d0baee77038574236710fbcec75a57d33f'
  assert set(plan['tools'].values())=={key} and plan['custom_compiler']['key']==compiler_key
  compiler=load_compiler(ROOT,compiler_key)
  assert compiler.identity==plan['custom_compiler']['identity']
  tool,actual_key=installed_tools(key);assert actual_key==key
  validate_tool_compiler(tool,key,compiler)
  composition=json.loads(retain(tool/'compiler.json'))
  for name in ['ready.json','capabilities.json']:retain(tool/name)
  compiler_ready=json.loads(retain(ROOT/'.work/compilers'/compiler_key/'ready.json'))
  dependencies={str(tool/name) for name in composition['binaries']}|{str(compiler.sysroot)}
  dependencies.update(str(compiler.sysroot/name) for name in compiler_ready['stamps'])
  standards={}
  for arm in ['baseline','candidate']:
   expected=plan['std_mir_by_mode'][arm];std_key=expected['key'];mode='on' if arm=='candidate' else 'off'
   ready_path=Path(expected['path']);assert digest(ready_path)==expected['sha256']
   sysroot,target,actual,ready=load_std(ROOT,std_key,compiler,'stable-mono-cgu:'+mode,rehash=True)
   assert actual==std_key and str(sysroot)==str(ready_path.parent/'sysroot')
   retain(ready_path);retain(ready_path.parent/'owner.json')
   for folder,field in [('sysroot','sysroot_stamps'),('library','snapshot_stamps'),('evidence','evidence_stamps')]:
    base=ready_path.parent/folder;dependencies.add(str(base));dependencies.update(str(base/name) for name in ready[field])
   for path in walk(ready_path.parent/'evidence'):retain(path)
   cargo=ready['identity']['cargo'];dependencies.add(cargo['executable'])
   dependencies.update(x['path'] for x in ready['cargo_state']['route'].values() if isinstance(x,dict) and 'path' in x)
   for item in cargo['libraries']['libraries']:
    dependencies.update(str(v) for k,v in item.items() if k in ['path','resolved_path','logical_path'])
   dependencies.update(cargo['libraries']['searches'])
   standards[arm]=dict(key=std_key,ready=str(ready_path),ready_sha256=expected['sha256'],namespace='stable-mono-cgu:'+mode)
  for label in ['compiler_qualification','source_observables']:
   proof=plan[label];path=Path(proof['path']);assert sha(retain(path))==proof['sha256']
   result=json.loads(retain(path));assert result['status']=='passed' and result['tool_key']==key and result['compiler_key']==compiler_key
   for relative,expected in result['evidence_files'].items():assert sha(retain(path.parent/relative))==expected
  dependencies.update(plan['frozen'])
  # Include helpers imported lazily during immutable input validation.
  source_paths|={Path(m.__file__) for m in tuple(sys.modules.values()) if getattr(m,'__file__',None) and str(m.__file__).startswith(str(ROOT/'scripts')+'/')}
  for path in source_paths:
   data=retain(path);dest=WORK/'sources'/path.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True)
   if dest.exists():assert dest.read_bytes()==data
   else:dest.write_bytes(data)
  input_guard=dict(compiler_key=compiler_key,tool_key=key,compiler_manifest=str(ROOT/'.work/compilers'/compiler_key/'ready.json'),
    compiler_manifest_sha256=digest(ROOT/'.work/compilers'/compiler_key/'ready.json'),tool_composition_sha256=digest(tool/'compiler.json'),
    tool_binaries=composition['binaries'],std=standards)
  write('custom-input-guard.json',input_guard)
  for dependency in dependencies|set(retained):
   path=Path(dependency)
   assert not any(path==target or path.is_relative_to(target) for target in selected),('retained dependency enters target',dependency)
   if path.exists():assert not any(path.resolve().is_relative_to(target) for target in selected),('retained dependency alias enters target',dependency)
  inventory=[];inodes=set();inode_rows=collections.defaultdict(list);copies={};allocations={}
  for arm,target in candidates.items():
   entries=[target]
   for directory,dirs,names in os.walk(target,followlinks=False):
    for name in sorted(dirs+names):entries.append(Path(directory)/name)
   for path in entries:
    s=path.lstat();kind='directory' if stat.S_ISDIR(s.st_mode) else 'file' if stat.S_ISREG(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'special'
    assert kind!='special',str(path)
    row=dict(root=str(target),path=str(path.relative_to(target)),arm=arm,kind=kind,device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,blocks=s.st_blocks,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink,link=os.readlink(path) if kind=='symlink' else None)
    inventory.append(row);inodes.add((s.st_dev,s.st_ino));inode_rows[(s.st_dev,s.st_ino)].append(row)
    if kind=='file' and (path.suffix in ('.rbc','.json','.jsonl','.rs','.toml','.lock','.txt','.d','.h','.c','.cc','.cpp','.S','.inc') or '.fingerprint' in path.relative_to(target).parts or 'history' in path.name or path.name in ('CACHEDIR.TAG','.cargo-lock','output','stderr','root-output','invoked.timestamp')):
     space();data=path.read_bytes();h=sha(data);destination=WORK/'retained-target-inputs'/h
     destination.parent.mkdir(exist_ok=True)
     if not destination.exists():
      assert space()-len(data)>=8*1024**3,'retained copy would cross the 8 GiB floor'
      destination.write_bytes(data)
     space()
     assert digest(destination)==h
     copies[str(path)]=dict(path=str(destination),sha256=h,bytes=len(data),role='bytecode' if '.rbc' in path.name else 'generated source, history or target metadata')
   armrows=[r for r in inventory if r['arm']==arm]
   unique={(r['device'],r['inode']):r for r in armrows}
   allocations[arm]=dict(path=str(target),entries=len(armrows),regular_files=sum(r['kind']=='file' for r in armrows),symlinks=sum(r['kind']=='symlink' for r in armrows),logical_bytes=sum(r['bytes'] for r in armrows if r['kind']=='file'),allocated_bytes_unique_inodes=sum(r['blocks']*512 for r in unique.values()),root_identity=armrows[0])
  dependency_inode_matches=[]
  for dependency in dependencies|set(retained):
   path=Path(dependency)
   if path.exists():
    s=path.stat()
    if (s.st_dev,s.st_ino) in inodes:dependency_inode_matches.append(dependency)
  assert not dependency_inode_matches,'retained input shares a target inode'
  for original,item in copies.items():
   assert digest(Path(original))==digest(Path(item['path']))==item['sha256']
  inventory_bytes=''.join(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n' for row in inventory).encode()
  packed=gzip.compress(inventory_bytes,mtime=0);(WORK/'inventory.jsonl.gz').write_bytes(packed)
  write('retained-target-inputs.json',copies)
  dependency_records={}
  for name in sorted(dependencies):
   dependency_records[name]=dependency_state(name)
  write('publication-dependencies.json',dict(tool_key=key,compiler_key=compiler_key,files=dependency_records,live_guard=str(WORK/'custom-input-guard.json')))
  quiescence={}
  for label,argv in [('processes',['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,tty=,command=']),('handles',['/usr/sbin/lsof','-nP','-FpcftDin'])]:
   child,out,err=capture(argv,cwd=ROOT,env=dict(os.environ),receipt_path=WORK/(label+'-process.json'),receipt={})
   found=[]
   if label=='processes':
    found=[line for line in out.splitlines() if any(str(path) in line for path in selected)]
   else:
    process={};entry={}
    def finish():
     name=entry.get('n','')
     try:inode=(int(entry.get('D',''),16),int(entry.get('i','')))
     except ValueError:inode=None
     path_match=any(name==str(path) or name.startswith(str(path)+'/') for path in selected)
     if inode in inodes or path_match:found.append(dict(process=process.copy(),file=entry.copy(),inode_match=inode in inodes,path_match=path_match))
    for line in out.splitlines():
     if not line:continue
     k,v=line[0],line[1:]
     if k=='p':finish();process={'pid':v};entry={}
     elif k=='c':process['command']=v
     elif k=='f':finish();entry={'fd':v}
     else:entry[k]=v
    finish()
   quiescence[label]=dict(pid=child.pid,returncode=child.returncode,stdout_sha256=sha(out.encode()),stderr_sha256=sha(err.encode()),stdout_lines=len(out.splitlines()),stderr_lines=len(err.splitlines()),matches=found,raw_output_retained=False)
   write('quiescence.json',quiescence)
   assert child.returncode==0 and not err.strip(),label+' inspection incomplete'
   assert not found,label+' has candidate users'
  # Re-stat every inventoried entry after handle inspection; no candidate was modified.
  for row in inventory:
   path=Path(row['root'])/row['path'];s=path.lstat()
   assert (s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_blocks,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink)==tuple(row[k] for k in ['device','inode','mode','bytes','blocks','mtime_ns','ctime_ns','nlink']),str(path)
  for path,proof in retained.items():assert digest(Path(path))==proof['sha256'],path
  assert load_compiler(ROOT,compiler_key)==compiler
  assert installed_tools(key)==(tool,key)
  validate_tool_compiler(tool,key,compiler)
  for item in standards.values():
   assert digest(item['ready'])==item['ready_sha256']
   load_std(ROOT,item['key'],compiler,item['namespace'],rehash=False)
  for name,expected in dependency_records.items():assert dependency_state(name)==expected,'dependency changed: '+name
  for original,item in copies.items():assert digest(original)==digest(item['path'])==item['sha256']
  write('retained-proof-manifest.json',retained)
  unique={key:values[0] for key,values in inode_rows.items()}
  external_links=[dict(device=dev,inode=ino,observed_paths=len(values),nlink=values[0]['nlink']) for (dev,ino),values in inode_rows.items() if values[0]['kind']=='file' and values[0]['nlink']>len(values)]
  write('external-hardlinks.json',external_links)
  record.update(status='passed',finished_at=time.time(),candidates=allocations,inventory_entries=len(inventory),
   inventory_sha256=sha(packed),inventory_bytes=len(packed),retained_proof_manifest_sha256=digest(WORK/'retained-proof-manifest.json'),
   retained_files=len(retained),retained_target_inputs=len(copies),retained_target_input_bytes=sum(x['bytes'] for x in copies.values()),
   publication_dependencies=len(dependencies),dependency_inode_matches=dependency_inode_matches,quiescence=quiescence,
   no_users_proved=True,all_target_entries_unchanged=True,retained_inputs_unchanged=True,completion=completion,
   artifacts_preserved=artifact_count,allocated_bytes_unique_all_targets=sum(row['blocks']*512 for row in unique.values()),
   external_hardlink_inodes=len(external_links),allocation_limit='st_blocks by unique inode; APFS shared extents can make actual reclaimed space smaller',
   archive_sha256=assessed['archive']['sha256'],free_bytes_after=shutil.disk_usage(ROOT).free,
   retirement_requires='fresh canonical admission, exact inventory/retained-proof revalidation and fresh path/inode/handle/cwd checks; no deletion authorized by this inspection')
  record['proof_files']={name:digest(WORK/name) for name in ['inventory.jsonl.gz','retained-proof-manifest.json','retained-target-inputs.json','publication-dependencies.json','custom-input-guard.json','quiescence.json','external-hardlinks.json']}
  write('summary.json',record)
  print(json.dumps({k:record[k] for k in ['status','pid','inventory_entries','retained_files','retained_target_inputs','allocated_bytes_unique_all_targets','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());write('summary.json',record);raise
