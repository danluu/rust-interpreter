"""Pure development checks of actual parser functions; never starts rustc or Cargo."""
from pathlib import Path
import copy,hashlib,importlib.util,json,os,sys,time
R=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913');X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918');A=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
H=R/'experiments/proc-macro-arena-ruff-screen-03';DEST=X/'.work/ruff-screen03-parser-development-01.json'
CENSUS=X/'.work/ruff-screen03-retained-cargo-shape-census-01.json'
assert not DEST.exists()
def audit(event,args):
 if event.startswith(('subprocess.','socket.')) or event in ['os.system','os.posix_spawn','os.posix_spawnp','os.fork','os.exec']:raise RuntimeError('no processes/network in parser development')
 if event=='open':
  path,mode,flags=args
  writing=(type(mode)is str and any(x in mode for x in 'wax+')) or type(flags)is int and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
  if writing and (not isinstance(path,(str,bytes,os.PathLike)) or Path(path)!=DEST):raise RuntimeError('only owned result may be written')
sys.addaudithook(audit)
def digest(value):return hashlib.sha256(value).hexdigest()
def wire(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode()
def ref(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
source_before={n:ref(H/n) for n in ['common.py','screen.py','rustc_capture.py','plan.json','source-manifest.json']}
assert source_before['common.py']['sha256']=='b911630c2e8fa59e867abd3368b3e93c81d20aae78b243bf900ad77ba7e38bde'
spec=importlib.util.spec_from_file_location('actual_screen03_common_parser',H/'common.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=json.loads((H/'plan.json').read_bytes());census=json.loads(CENSUS.read_bytes());assert len(census['rows'])==632
results=[];examples={};counts={};negative=[]
for path,saved in sorted(census['rows'].items()):
 p=Path(path);assert ref(p)['sha256']==saved['sha256'];value=json.loads(p.read_bytes());original=list(value['original_args'][1:]);env=copy.deepcopy(value['environment'])
 arm='candidate' if '/prime/candidate/' in path else 'baseline';oldtarget=str(A/'.work/ruff-hir-self-profile-02/targets'/arm);target=X/'.work/ruff-screen03-parser-fixtures-not-created-01'/arm/'target'
 encoded=env.get('CARGO_ENCODED_RUSTFLAGS','');oldflags=encoded.split('\x1f') if encoded else [];assert all(x.startswith(('-Zmir-opt-level=','-Zhir-body-cache-capture=','-Zhir-body-cache-reuse=','-Zincremental-info=')) for x in oldflags)
 args=[];removed=[];i=0
 while i<len(original):
  arg=original[i]
  if arg in oldflags:removed.append({'index':i,'arguments':[arg],'reason':'prior profiling Rustflag; fresh screen has no Rustflags'});i+=1;continue
  if arg=='-C' and i+1<len(original) and original[i+1].startswith('incremental='):
   removed.append({'index':i,'arguments':original[i:i+2],'reason':'prior incremental target; fresh screen explicitly nonincremental'});i+=2;continue
  args.append(arg.replace(oldtarget,str(target)));i+=1
 env={k:v.replace(oldtarget,str(target)) for k,v in env.items()};env['CARGO_ENCODED_RUSTFLAGS']='';env['CARGO_INCREMENTAL']='0'
 fixture_args=list(args);fixture_env=copy.deepcopy(env)
 result=m.classify_rustc(args,env,value['cwd'],target,plan['probe_sources']);kind=result['kind'];role=saved['role'];expected='query' if role.endswith('query') else ('cargo-crate' if role.startswith('cargo-') else role);assert kind==expected,(path,result,role)
 basename=None
 if kind=='cargo-crate':
  dep=m.cargo_depinfo_path(args,value['cwd']);extra=saved['extra_filename_options'];expected_suffix=extra[0].split('=',1)[1] if extra else '';basename=saved['crate'][0]+expected_suffix+'.d';assert dep==Path(m.option(args,'--out-dir'))/basename
  assert m.crate_types(args)==saved['crate_types'];assert args==fixture_args and env==fixture_env # parser does not mutate actual fixture maps
 key=role if len(saved['crate_types'])<2 else 'cargo-repeated-crate-types';examples.setdefault(key,(args,env,value['cwd'],target))
 counts[role]=counts.get(role,0)+1
 results.append({'source':{'path':path,'bytes':saved['bytes'],'sha256':saved['sha256']},'original_args_sha256':digest(wire(value['original_args'])),'original_environment_sha256':digest(wire(value['environment'])),'role':role,'classified_kind':kind,'dependency_basename':basename,'actual_saved_returncode':value.get('returncode'),'fixture_target_rebinding':{'from':oldtarget,'to':str(target)},'removed_arguments':removed,'fixture_environment_updates':{'CARGO_ENCODED_RUSTFLAGS':{'from':encoded,'to':''},'CARGO_INCREMENTAL':{'from':value['environment'].get('CARGO_INCREMENTAL'),'to':'0'}},'fixture_args_sha256':digest(wire(args)),'fixture_environment_sha256':digest(wire(env))})
def reject(label,role,mutate):
 args,env,cwd,target=copy.deepcopy(examples[role]);mutate(args,env)
 try:m.classify_rustc(args,env,cwd,target,plan['probe_sources'])
 except (RuntimeError,KeyError,FileNotFoundError,TypeError) as error:negative.append({'case':label,'rejected':True,'error':repr(error)})
 else:raise AssertionError('unsupported shape accepted: '+label)
def remove_codegen(args,key):
 for i in range(len(args)-1,-1,-1):
  if args[i].startswith('-C'+key+'='):del args[i]
  elif args[i].startswith(key+'='):
   assert i and args[i-1]=='-C';del args[i-1:i+1]
def replace_option(args,key,value):
 for i,a in enumerate(args):
  if a==key:args[i+1]=value;return
  if a.startswith(key+'='):args[i]=key+'='+value;return
 raise AssertionError(key)
reject('ordinary library cannot omit suffix','cargo-ordinary-library',lambda a,e:remove_codegen(a,'extra-filename'))
reject('build script needs metadata','cargo-build-script-no-suffix',lambda a,e:remove_codegen(a,'metadata'))
reject('build script needs matching Cargo crate','cargo-build-script-no-suffix',lambda a,e:e.update(CARGO_CRATE_NAME='other'))
reject('build script source outside package','cargo-build-script-no-suffix',lambda a,e:e.update(CARGO_MANIFEST_DIR='/unrelated-package'))
reject('build script emit policy','cargo-build-script-no-suffix',lambda a,e:replace_option(a,'--emit','dep-info,metadata'))
reject('duplicate crate type is ambiguous','cargo-ordinary-library',lambda a,e:a.extend(['--crate-type',m.crate_types(a)[0]]))
reject('unknown crate type','cargo-ordinary-library',lambda a,e:replace_option(a,'--crate-type','mystery'))
reject('duplicate suffix is ambiguous','cargo-ordinary-library',lambda a,e:a.extend(['-C','extra-filename=-extra']))
for role in ['proc-macro2-probe','thiserror-probe','anyhow-probe','autocfg-probe','rustix-probe']:
 reject(role+' rejects extra flag',role,lambda a,e:a.append('-Zunknown-option'))
 reject(role+' rejects output escape',role,lambda a,e:e.update(OUT_DIR='/outside-owned-target'))
 if role!='autocfg-probe':reject(role+' rejects foreign target',role,lambda a,e:replace_option(a,'--target','x86_64-unknown-linux-gnu'))
assert len(negative)==22
assert source_before=={n:ref(H/n) for n in source_before}
report={'status':'passed-pure-parser-development','observed_at':time.time(),'parent_pid':os.getpid(),'source_before':source_before,'source_after':{n:ref(H/n) for n in source_before},'census':ref(CENSUS),'recorded_invocations_checked':len(results),'role_counts':counts,'positive_cases':results,'negative_cases':negative,'negative_count':len(negative),'fixture_paths_created':False,'processes_spawned':0,'compiler_Cargo_or_benchmark_calls':0,'application_sources_modified':False,'actual_old_vectors_unchanged':True,'scope':'Actual common.py parser and dep-info-name functions invoked against saved vectors with every prior-profile and fixture-route substitution recorded. This is pure development checking, not semantic compiler qualification, source observer qualification or timing.'}
b=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();assert len(b)<=4*2**20
with DEST.open('xb') as f:f.write(b)
print(DEST);print(digest(b));print('positive',len(results),'negative',len(negative))
