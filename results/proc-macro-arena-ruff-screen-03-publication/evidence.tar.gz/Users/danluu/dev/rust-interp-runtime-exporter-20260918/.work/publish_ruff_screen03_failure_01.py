"""Publish the closed third screen failure; no source restoration or execution."""
from pathlib import Path
import gzip,hashlib,io,json,os,stat,tarfile,time
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913');X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918');O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
H=ROOT/'experiments/proc-macro-arena-ruff-screen-03';H4=ROOT/'experiments/proc-macro-arena-ruff-screen-04';E=ROOT/'results/proc-macro-arena-ruff-screen-03';W=ROOT/'.work/proc-macro-arena-ruff-screen-03'
P=ROOT/'results/proc-macro-arena-ruff-screen-03-publication';FIELDS=('dev','ino','mode','nlink','size','mtime_ns','ctime_ns')
def stamp(p):s=p.lstat();return {k:getattr(s,'st_'+k) for k in FIELDS}
def read(p):return json.loads(p.read_bytes())
def row(p):
 assert p.is_absolute() and p.resolve(strict=True)==p;s=stamp(p);assert stat.S_ISREG(s['mode']) and s['size']<=(16 if p==P/'evidence.tar.gz' else 8)*2**20
 b=p.read_bytes();assert stamp(p)==s and len(b)==s['size'];return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),identity=s)
def save(p,d):
 b=(json.dumps(d,sort_keys=True,indent=2)+'\n').encode();assert len(b)<=4*2**20
 with p.open('xb') as f:f.write(b)
def ref(p):return dict(path=str(p),**row(p))
def tree(base):
 found=set()
 for root,dirs,files in os.walk(base,followlinks=False):
  for name in dirs:assert (Path(root)/name).resolve(strict=True)==Path(root)/name
  for name in files:found.add(Path(root)/name)
 return found
assert not P.exists()
plan=read(H/'plan.json');proof=X/'.work/proc-macro-arena-ruff-screen03-failure-independent-readback-01.json';audit=read(proof)
assert row(proof)['sha256']=='b45d20994cee699d500e57e1c2085673d03d7af05b6c9d89cf5b2564ac7301da'
assert audit['status']=='verified-failed-screen-before-timing' and audit['timed_calls']==0 and audit['source_edits']==1 and audit['restorations']==0
assert audit['setup_native_calls']==650 and audit['warmup_compiler_calls']==1 and audit['recorded_successful_warmups']==0
assert row(E/'execution.json')=={k:v for k,v in audit['execution'].items() if k!='path'}
edited=audit['preserved_edited_source'];assert edited['state']=='edited' and row(Path(edited['path']))==edited['row']
trees={base:tree(base) for base in [H,H4,E]};assert len(trees[E])==3902
assert {str(p.relative_to(E)) for p in trees[E]}==set(audit['closed_output_files'])
for name,r in audit['closed_output_files'].items():assert row(E/name)==r
selected=set().union(*trees.values())
selected.update([proof,X/'.work/verify_ruff_screen03_failure_01.py',X/'.work/proc-macro-arena-ruff-screen03-source-handoff-01.json',X/'.work/proc-macro-arena-ruff-screen03-source-handoff-02.json',
 X/'.work/verify_ruff_screen03_saved_01.py',X/'.work/proc-macro-arena-ruff-screen03-saved-reader-source-handoff-01.json',X/'.work/proc-macro-arena-ruff-screen04-source-handoff-01.json',
 X/'.work/proc-macro-arena-ruff-screen04-source-handoff-02.json',X/'.work/proc-macro-arena-ruff-screen04-source-handoff-02.from-handoff01.diff',
 X/'.work/check_ruff_screen04_json_messages_01.py',X/'.work/ruff-screen04-json-development-01.json',
 X/'.work/check_ruff_screen03_saved_shapes_01.py',X/'.work/ruff-screen03-parser-development-01.json',X/'.work/ruff-screen03-parser-development-failure-01.json',X/'.work/ruff-screen03-retained-cargo-shape-census-01.json',
 ROOT/'.work/proc-macro-arena-ruff-screen03-root-review-01.json',ROOT/'.work/proc-macro-arena-ruff-screen-invocation-03.json',
 O/'.work/ruff-screen03-json-contract-independent-review-01.json',O/'.work/ruff-screen01-cargo-layout-source-review-01.json',
 W/'contexts/stock.json',W/'contexts/candidate.json',Path(__file__).absolute(),Path(plan['source_inventory']['path'])])
for r in [*plan['reference_sources'],*plan['probe_source_references'],*plan['probe_sources'].values(),*read(H4/'plan.json')['json_contract_sources']]:
 p=Path(r['path']);assert row(p)['sha256']==r['sha256'];selected.add(p)
assert row(ROOT/'.work/proc-macro-arena-ruff-screen03-root-review-01.json')['sha256']=='e391eedd9c115745307f8bb1d76d2c106ebfdeee36e4e11133fea7a02365fa5b'
assert row(ROOT/'.work/proc-macro-arena-ruff-screen-invocation-03.json')['sha256']=='a2a03d90bd27e91a4600444b10958f07d989d41c9795b2f5a85d9c735f23f21b'
assert row(O/'.work/ruff-screen03-json-contract-independent-review-01.json')['sha256']=='1b6fd7955a414639b34457c6cf736bbb7e2ab36358557c7413141c3867dd624e'
assert row(X/'.work/proc-macro-arena-ruff-screen04-source-handoff-01.json')['sha256']=='7ac614ebcf5db175a9f25a32b51faadb285a4307d9c88e203600d382b7c26e95'
assert row(X/'.work/proc-macro-arena-ruff-screen04-source-handoff-02.json')['sha256']=='330f6cfb8875c585bd7cf9c42db7d6115a8766964ee7ce8a60ecf7b686ffa2c9'
assert all(not p.is_relative_to(W/'source') and not p.is_relative_to(W/'target') and not p.is_relative_to(W/'replays') for p in selected)
rows={str(p):row(p) for p in sorted(selected)};logical=sum(r['bytes'] for r in rows.values());assert len(rows)<=4200 and logical<=64*2**20
P.mkdir();archive=P/'evidence.tar.gz'
with archive.open('xb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w|') as tar:
   for name,r in rows.items():
    p=Path(name);assert row(p)==r;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256']
    item=tarfile.TarInfo(name.lstrip('/'));item.size=len(b);item.mode=stat.S_IMODE(r['identity']['mode']);item.mtime=r['identity']['mtime_ns']//10**9
    item.uid=0;item.gid=0;item.uname='';item.gname='';tar.addfile(item,io.BytesIO(b))
assert archive.stat().st_size<=16*2**20
uncompressed=0
with gzip.open(archive,'rb') as f:
 while block:=f.read(2**20):uncompressed+=len(block);assert uncompressed<=72*2**20
seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for item in tar:
  name='/'+item.name;assert item.isfile() and name in rows and name not in seen;seen.add(name)
  with tar.extractfile(item) as stream:b=stream.read(8*2**20+1)
  assert len(b)==rows[name]['bytes'] and hashlib.sha256(b).hexdigest()==rows[name]['sha256']
assert seen==set(rows)
for name,r in rows.items():assert row(Path(name))==r
for base,found in trees.items():assert tree(base)==found
assert row(Path(edited['path']))==edited['row']
manifest=dict(policy='portable-closed-Ruff-screen03-json-validator-failure-v1',archive=ref(archive),member_count=len(rows),logical_bytes=logical,
 members={name.lstrip('/'):dict(original_path=name,**r) for name,r in rows.items()},
 external=dict(copied_Ruff_source=str(W/'source'),fresh_Cargo_targets=str(W/'target'),warmup_artifact_outputs=str(W/'replays'),canonical_Ruff_source=plan['source_root'],
 source_and_binary_payloads='excluded; complete source and captured input inventories retained as metadata, exact reviewed experiment source retained',
 compiler_and_Cargo_binaries='excluded; exact invocation and prior passed N overlay provenance remain authoritative',
 original_WORK_and_providers='preserved unchanged; no restoration, retirement, reuse or subsequent execution authority'))
save(P/'manifest.json',manifest)
summary=dict(status='published-closed-screen-json-validator-failure',observed_at=time.time(),source=str(H),actual_results=str(E),independent_failure_readback=ref(proof),
 actual_execution_sha256=audit['execution']['sha256'],parent_pid=56126,parent_exit_observed_by_root=audit['parent_exit_observed_by_root'],
 cargo_children=[dict(pid=read(E/('cargo-'+arm)/'record.json')['pid'],returncode=read(E/('cargo-'+arm)/'record.json')['returncode'],arm=arm) for arm in ['stock','candidate']],
 setup_native_calls=650,setup_kind_counts=audit['setup_kind_counts'],first_unrecorded_warmup=audit['first_unrecorded_warmup'],
 reason='requested normal unused_extern JSON rejected after successful first edited warmup compiler; no timed sample recorded',
 crate_compilations=audit['crate_compilations'],timed_calls=0,recorded_successful_warmups=0,source_edits=1,restorations=0,preserved_failed_edited_source=edited,
 json_contract_review=ref(O/'.work/ruff-screen03-json-contract-independent-review-01.json'),source04_successor=ref(H4/'source-manifest.json'),
 source04_scope='source and pure parser development evidence only; no screen04 invocation or result included',
 performance_claim=False,qualification_passed=False,archive=ref(archive),manifest=ref(P/'manifest.json'),preserved_originals=True)
save(P/'summary.json',summary)
save(P/'READBACK.json',dict(status='verified',full_gzip_EOF=True,all_members_read_to_EOF=True,all_member_hashes_match=True,
 current_selected_sources_raw_stamps_and_bytes_unchanged=True,closed_evidence_members=3902,source_and_evidence_tree_membership_unchanged=True,failed_edited_source_unchanged=True,
 members=len(rows),logical_bytes=logical,gzip_bytes=archive.stat().st_size,uncompressed_tar_bytes=uncompressed,
 archive=ref(archive),manifest=ref(P/'manifest.json'),summary=ref(P/'summary.json')))
(P/'README.md').write_text('This capsule preserves the third Ruff native frontend screen failure. Both Cargo setups closed0 with 325 captured native invocations each. The first edited stock warmup compiler also closed0, then the validator rejected the normal unused_extern JSON record requested by the captured command. Zero timed samples, zero successful recorded warmups and zero restorations occurred. The owned Ruff source remains in its actual edited failure state. This is neither a performance result nor a successful screen qualification.\n\nAll3902 closed raw/attempt/record/input-metadata files, exact source03/history and successor04 bindings, invocation, root review, independent failure readback and JSON-contract source review are retained. Successor04 is source and pure parser development evidence only. The unrun success reader03 is retained as source, never successful evidence. Ruff copies, target/replay binary artifacts, compiler and provider payloads remain external; no old output is reused or restored. Archive identities describe original observations, not extracted-file identities. Full gzipEOF, every member EOF/hash, current selected byte/stamp readback and exact tree membership were verified. No Git, compiler, Cargo, retry, cleanup or process control is performed.\n')
print(json.dumps(dict(path=str(P),members=len(rows),logical_bytes=logical,gzip_bytes=archive.stat().st_size,readback_sha256=row(P/'READBACK.json')['sha256'],summary_sha256=row(P/'summary.json')['sha256'])))
