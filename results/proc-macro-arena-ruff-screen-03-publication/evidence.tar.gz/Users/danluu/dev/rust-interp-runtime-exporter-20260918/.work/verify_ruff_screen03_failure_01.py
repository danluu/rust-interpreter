"""Closed screen03 failure/raw readback only; no compiler/Cargo/provider inventory walk."""
from pathlib import Path
import collections,hashlib,json,os,stat,time,re
R=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913');X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
H=R/'experiments/proc-macro-arena-ruff-screen-03';E=R/'results/proc-macro-arena-ruff-screen-03';W=R/'.work/proc-macro-arena-ruff-screen-03';DEST=X/'.work/proc-macro-arena-ruff-screen03-failure-independent-readback-01.json'
FIELDS=('dev','ino','mode','nlink','size','mtime_ns','ctime_ns');CHECKED={};TOTAL_READ=0
assert not DEST.exists()
def stamp(p):s=Path(p).lstat();return {k:getattr(s,'st_'+k) for k in FIELDS}
def file(p):
 global TOTAL_READ
 p=Path(p);assert p.resolve(strict=True)==p;s=stamp(p);assert stat.S_ISREG(s['mode']) and s['size']<=64*2**20
 if str(p) in CHECKED:assert CHECKED[str(p)]['identity']==s;return CHECKED[str(p)]
 b=p.read_bytes();assert len(b)==s['size'] and stamp(p)==s;TOTAL_READ+=len(b);assert TOTAL_READ<=256*2**20
 r=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),identity=s);CHECKED[str(p)]=r;return r
def read(p,sha=None):
 r=file(p);assert sha is None or r['sha256']==sha;d=json.loads(Path(p).read_bytes());assert stamp(p)==r['identity'];return d
def pin(ref):
 r=file(ref['path']);assert r['sha256']==ref['sha256'];return read(ref['path'])
def raw(directory,record):
 for name in ['stdout','stderr','stdin']:
  if name in record:assert file(directory/name)==record[name]
def process(p,allowed):
 d=read(p/'record.json');assert d['status']=='closed' and d['may_be_live'] is False and d['returncode'] in allowed and d['observation_errors']==[]
 assert os.waitstatus_to_exitcode(d['wait_status'])==d['returncode'] and d['rusage_source']=='actual os.wait4 return for this child'
 assert d['started_at']<=d['spawned_at']<=d['finished_at']<=d['observation_finished_at'];raw(p,d);return d
execution=read(E/'execution.json','0f6cc0d187592167e07e0de747cdb0504fb659eba7bd12e24a2a7db5eaa21190')
assert execution['status']=='failed' and execution['parent_pid']==56126 and execution['error']=="RuntimeError('unexpected rustc message kind')"
assert len(execution['edits'])==1 and all(execution[k]==[] for k in ['samples','warmups','restorations','signals']) and execution['retries']==0
assert execution['started_at']<=execution['admitted_at']<=execution['observation_finished_at']<=execution['parent_lock_closed_at'] and not (E/'result.json').exists()
inv=read(R/'.work/proc-macro-arena-ruff-screen-invocation-03.json','a2a03d90bd27e91a4600444b10958f07d989d41c9795b2f5a85d9c735f23f21b')
manifest=read(H/'source-manifest.json',inv['source_manifest_sha256']);assert inv['source_manifest_sha256']=='538484bc340be6c7909c55bb2de3a2224a8eb0f6d853bed11b2d2609ea958626'
for name,row in manifest['files'].items():assert (file(H/name)['bytes'],file(H/name)['sha256'])==(row['bytes'],row['sha256'])
plan=read(H/'plan.json',execution['plan_sha256']);setups={};native=[];attempt_paths=set();kinds=collections.Counter();exit_counts=collections.Counter()
for arm,expected_pid in [('stock',58997),('candidate',3148)]:
 cargo=process(E/('cargo-'+arm),{0});assert cargo['pid']==expected_pid and cargo['parent_pid']==56126
 assert cargo['command']==[plan['cargo']]+[str(W/'target'/arm) if v=='<fresh-arm-target>' else v for v in plan['cargo_arguments']]
 saved=read(E/('setup-'+arm+'.json'));assert saved['record']==cargo and saved['compiler_calls']==325
 closure=read(E/('native-closure-'+arm+'.json'));assert len(closure)==325
 for ref in saved['route_records']:
  route=pin(ref);directory=Path(route['call_directory']);assert directory.parent==E/'capture'/arm
  attempt_path=Path(route['attempt']);attempt=read(attempt_path);attempt_paths.add(str(attempt_path));assert attempt['status']=='returned-native-exit' and attempt['id']==directory.name
  kind=route['classification']['kind'];allowed={0,1} if kind.endswith('-probe') else {0};child=process(directory,allowed)
  assert child['parent_pid']==attempt['wrapper_pid']==route['wrapper_pid'] and attempt['returned_code']==child['returncode']
  assert child['command']==route['forwarded_arguments'] and child['environment']==route['forwarded_environment']
  expected=[plan['compiler']]+attempt['argv'][1:]+['--sysroot',str(Path(plan['overlay_work'])/arm/'sysroot')]+(['-Zbinary-dep-depinfo'] if kind=='cargo-crate' else [])
  assert child['command']==expected and route['original_arguments']==attempt['argv'][1:]
  assert route['received_environment']==attempt['received_environment'] and route['cwd']==attempt['cwd']==child['cwd']
  assert cargo['spawned_at']<=attempt['started_at']<=child['started_at']<=child['finished_at']<=attempt['finished_at']<=cargo['finished_at']
  assert file(directory/'record.json')['sha256']==route['record']['sha256'];cl=next(x for x in closure if x['path']==str(directory/'record.json'));assert cl['sha256']==route['record']['sha256'] and cl['native_closure_known'] is True and cl['may_be_live'] is False and cl['pid']==child['pid']
  kinds[arm+':'+kind]+=1;exit_counts[str(child['returncode'])]+=1;native.append(dict(arm=arm,pid=child['pid'],wrapper_pid=route['wrapper_pid'],kind=kind,returncode=child['returncode'],record=route['record'],attempt=dict(path=str(attempt_path),**file(attempt_path))))
 assert {Path(r['path']).parent for r in saved['route_records']}==set((E/'capture'/arm).iterdir())
 assert {r['path'] for r in saved['attempts']}=={n['attempt']['path'] for n in native if n['arm']==arm}
 for ref in saved['attempts']:pin(ref)
 events=[json.loads(x) for x in (E/('cargo-'+arm)/'stdout').read_text().splitlines()];assert events[-1]=={'reason':'build-finished','success':True}
 top=saved['top'];topraw=Path(top['call_directory'])/'stderr';messages=[json.loads(x) for x in topraw.read_text().splitlines()]
 setups[arm]=dict(cargo_record=dict(path=str(E/('cargo-'+arm)/'record.json'),**file(E/('cargo-'+arm)/'record.json')),cargo_pid=cargo['pid'],cargo_returncode=0,top=top,top_messages=messages,top_stderr=dict(path=str(topraw),**file(topraw)))
assert len(native)==650 and len(attempt_paths)==650 and {str(p) for p in (E/'wrapper-attempts').iterdir()}==attempt_paths
assert setups['stock']['cargo_pid']==58997 and setups['candidate']['cargo_pid']==3148
replaydir=E/'replays/b0-warm-stock';warm=process(replaydir,{0});assert warm['pid']==51003 and warm['parent_pid']==56126 and not (replaydir/'verification.json').exists()
assert {p.name for p in (E/'replays').iterdir()}=={'b0-warm-stock'} and {p.name for p in (W/'replays').iterdir()}=={'b0-warm-stock'}
expected=list(setups['stock']['top']['forwarded_arguments']);index=expected.index('--out-dir');expected[index+1]=str(W/'replays/b0-warm-stock');assert warm['command']==expected and warm['cwd']==setups['stock']['top']['cwd']
messages=[json.loads(x) for x in (replaydir/'stderr').read_text().splitlines()];assert len(messages)==3 and [x['$message_type'] for x in messages]==['artifact','unused_extern','artifact']
unused={'$message_type':'unused_extern','lint_level':'force-warn','unused_extern_names':[]};assert messages[1]==unused and all(s['top_messages'][1]==unused for s in setups.values())
assert warm['stdout']['bytes']==0 and warm['finished_at']<=execution['observation_finished_at']
edit=execution['edits'][0];assert edit['state']=='edited' and edit['path']==str(W/'source'/plan['source_edit']['relative']) and file(edit['path'])==edit['row']
assert edit['row']['sha256']==plan['source_edit']['edited']['sha256'] and edit['at']<=warm['started_at']
assert file(Path(plan['source_root'])/plan['source_edit']['relative'])['sha256']==plan['source_edit']['original']['sha256']
# Retain exact complete closed raw/evidence membership, without walking target/source/provider payloads.
closed={};total=0
for directory,dirs,files in os.walk(E,followlinks=False):
 for name in dirs:assert (Path(directory)/name).resolve(strict=True)==Path(directory)/name
 for name in files:
  p=Path(directory)/name;row=file(p);closed[str(p.relative_to(E))]=row;total+=row['bytes'];assert len(closed)<=5000 and total<=128*2**20
for p,row in CHECKED.items():assert stamp(p)==row['identity']
summary=dict(status='verified-failed-screen-before-timing',observed_at=time.time(),execution=dict(path=str(E/'execution.json'),**file(E/'execution.json')),parent_pid=56126,parent_exit_observed_by_root=dict(session=94677,exit_code=1),
 source_manifest_sha256=inv['source_manifest_sha256'],invocation_sha256=execution['invocation_sha256'],setup_commands=2,setup_native_calls=650,setup_kind_counts=dict(kinds),setup_native_exit_counts=dict(exit_counts),native_closures=native,
 setup_top_streams={a:{k:v for k,v in s.items() if k!='top'} for a,s in setups.items()},first_unrecorded_warmup=dict(record=dict(path=str(replaydir/'record.json'),**file(replaydir/'record.json')),pid=51003,returncode=0,stderr=dict(path=str(replaydir/'stderr'),**file(replaydir/'stderr')),message_kinds=[x['$message_type'] for x in messages],rejected_record=unused),
 warmup_compiler_calls=1,recorded_successful_warmups=0,crate_compilations=sum(n['kind']=='cargo-crate' for n in native)+1,timed_calls=0,source_edits=1,restorations=0,performance_decision=None,qualification_passed=False,preserved_edited_source=edit,
 closed_output_files=closed,closed_output_bytes=total,checked_file_count=len(CHECKED),checked_file_rows_sha256=hashlib.sha256(json.dumps(CHECKED,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
 scope='Complete saved closure/raw/source proof only. No success reader, provider/source/cache payload walk, restoration, compiler/Cargo call or timing was performed by this reader.')
payload=(json.dumps(summary,sort_keys=True,indent=2)+'\n').encode();assert len(payload)<=8*2**20
with DEST.open('xb') as f:f.write(payload)
print(DEST);print(hashlib.sha256(payload).hexdigest());print('native',len(native),'closed files',len(closed),'closed bytes',total,'reportbytes',len(payload))
