extern crate proc_macro;
#[proc_macro]
pub fn host_value(_: proc_macro::TokenStream) -> proc_macro::TokenStream {
let value = custom_shared::value() + custom_shared::generic(2u32) + custom_shared::inlined(3) + custom_shared::constant();
value.to_string().parse().unwrap()
}
