fn main() { println!("{}", custom_compiler_fixture::entry()); }
