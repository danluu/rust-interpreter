#![allow(dead_code)]
include!(concat!(env!("OUT_DIR"), "/generated.rs"));
pub const MACRO: u32 = custom_macros::host_value!();
pub fn entry() -> u32 { custom_shared::value() + custom_shared::generic(2u32) + custom_shared::inlined(3) + custom_shared::constant() + BUILT + MACRO }
