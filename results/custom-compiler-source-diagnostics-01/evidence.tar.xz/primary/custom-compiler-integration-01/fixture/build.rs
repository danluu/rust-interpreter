fn main() {
let value = custom_shared::value() + custom_shared::generic(2u32) + custom_shared::inlined(3) + custom_shared::constant();
let out = std::path::PathBuf::from(std::env::var_os("OUT_DIR").unwrap());
std::fs::write(out.join("generated.rs"), format!("pub const BUILT: u32 = {value};")).unwrap();
std::fs::write(out.join("host-value.txt"), value.to_string()).unwrap();
println!("cargo:rerun-if-changed=build.rs");
}
