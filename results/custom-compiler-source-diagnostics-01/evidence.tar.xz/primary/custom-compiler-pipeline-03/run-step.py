"""Receipt-only supervisor: children own the campaign lock; never nest it here."""
import json, os, shutil, sys, time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'scripts'))
from custom_compiler import file_digest
from workflow_io import capture, write_json
work=Path(__file__).resolve().parent
plan_path=Path(sys.argv[1]).resolve(strict=True)
plan=json.loads(plan_path.read_text())
frozen=json.loads((work/'frozen-inputs.json').read_text())
name=plan['name']
result_path=work/(name+'-result.json')
if result_path.exists():raise RuntimeError('step result already exists; use a new step name')
def verify():
    for path,expected in frozen['files'].items():
        if file_digest(root/path)!=expected:raise RuntimeError('frozen input changed: '+path)
record={'name':name,'plan':str(plan_path),'plan_sha256':file_digest(plan_path),
        'supervisor_pid':os.getpid(),'parent_pid':os.getppid(),'supervisor_sha256':file_digest(Path(__file__)),'started_at':time.time(),
        'root':str(root),'lock_owner':'child helper only','children_started':0}
try:
    verify()
    free=shutil.disk_usage(root).free
    record['free_bytes_before']=free
    if free < plan['minimum_free_bytes']:raise RuntimeError('insufficient disk for admitted step')
    write_json(result_path,record|{'status':'launching'})
    record['children_started']=None
    child,out,err=capture(plan['command'],cwd=root,env=os.environ.copy(),
        receipt_path=work/(name+'-child.json'),receipt={'step':name,'frozen_head':frozen['head']})
    record.update(children_started=1,pid=child.pid,returncode=child.returncode)
    (work/(name+'.stdout')).write_text(out)
    (work/(name+'.stderr')).write_text(err)
    verify()
    record.update(status='passed' if child.returncode==0 else 'failed',finished_at=time.time(),
                  free_bytes_after=shutil.disk_usage(root).free)
    write_json(result_path,record)
    if record['free_bytes_after'] < 8*2**30:raise RuntimeError('disk floor violated after step; no next step admitted')
    print(out,end='');print(err,end='',file=sys.stderr)
    if child.returncode:raise SystemExit(child.returncode)
except BaseException as error:
    record.update(status='failed',error=str(error),finished_at=time.time())
    write_json(result_path,record)
    raise
