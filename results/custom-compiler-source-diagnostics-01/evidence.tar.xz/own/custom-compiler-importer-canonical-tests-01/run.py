import json, os, sys, time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'scripts'))
from custom_compiler import file_digest
from compare_saved_runtime import acquire_lock
from workflow_io import capture, write_json, require_space
work=Path(__file__).resolve().parent
record={'supervisor_pid':os.getpid(),'started_at':time.time(),'status':'waiting','children_started':0,'lock_path':'/Users/danluu/dev/rust-interp/.work/benchmark.lock','lock_wait_seconds':600,'inputs':{name:file_digest(root/name) for name in ['scripts/custom_compiler.py', 'tests/test_custom_compiler.py']}}
write_json(work/'result.json',record)
try:
 with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('a') as lock:
  acquire_lock(lock,600);require_space(root,8)
  child,out,err=capture([sys.executable,'-m','unittest','discover','-s','tests','-p','test_custom_compiler.py','-v'],cwd=root,env=os.environ.copy(),receipt_path=work/'child.json',receipt={'kind':'synthetic-importer-canonical-tests'})
  record.update(children_started=1,pid=child.pid,returncode=child.returncode,status='passed' if child.returncode==0 else 'failed',finished_at=time.time())
  (work/'stdout').write_text(out);(work/'stderr').write_text(err)
  write_json(work/'result.json',record)
  print(out,end='');print(err,end='',file=sys.stderr)
  if child.returncode:raise SystemExit(child.returncode)
except BaseException as error:
 record.update(status='failed',error=str(error),finished_at=time.time());write_json(work/'result.json',record);raise
