"""Inventory only the404 reviewed compiler files; never remove or signal anything."""
import ast,collections,fcntl,gzip,hashlib,json,os,shutil,stat,sys,time
from pathlib import Path
from workflow_io import capture,write_json
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
RUNNER=Path(__file__).resolve().parents[1]
SOURCE=Path('/Users/danluu/dev/rustc-stable-mono-production-20260913')
DRIVER=Path('/Users/danluu/dev/rust-interp-stable-mono-compiler-build-20260913')
RAW=DRIVER/'.work/mono-production-build-02'
WORK=ROOT/'.work/mono-compiler-intermediate-inventory-01'
PROPOSAL=ROOT/'.work/mono-compiler-intermediate-proposal-01.json'
PROPOSAL_SHA='99c6189c99656c9f97b68d88f07d7ab91886104209ebf454d51649ac89f16be1'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
HOST='aarch64-apple-darwin'
TREES=[SOURCE/'build'/HOST/name for name in ['stage1-rustc','stage2-rustc']]
WORK.mkdir(exist_ok=False)
record=dict(schema_version=1,status='waiting',owner=str(ROOT),runner=str(RUNNER),pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,deleted=[],process_controls=0,builds=0,benchmarks=0)
def sha(data):return hashlib.sha256(data).hexdigest()
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  while b:=stream.read(4*1024*1024):h.update(b)
 return h.hexdigest()
def save():write_json(WORK/'summary.json',record)
def space():
 free=shutil.disk_usage(ROOT).free
 assert free>=8*1024**3,'inventory requires8GiB free'
 return free
def state(path):
 path=Path(path)
 if not path.exists() and not path.is_symlink():return None
 s=path.lstat()
 return dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,blocks=s.st_blocks,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink,symlink=os.readlink(path) if path.is_symlink() else None,resolved=str(path.resolve(strict=True)))
def ordinary(path):assert path.resolve(strict=True)==path and not path.is_symlink(),str(path)
proofs={};protected={}
def retain(path):
 path=Path(path);ordinary(path);before=state(path);data=path.read_bytes();assert state(path)==before
 info=dict(sha256=sha(data),bytes=len(data),state=before)
 if str(path) in proofs:assert proofs[str(path)]==info
 else:
  proofs[str(path)]=info;dest=WORK/'proof-bytes'/info['sha256'];dest.parent.mkdir(exist_ok=True)
  if not dest.exists():assert space()-len(data)>=8*1024**3;dest.write_bytes(data)
 return data
def protect(path):
 path=Path(path);value=state(path)
 if str(path) in protected:assert protected[str(path)]==value
 protected[str(path)]=value
 if value and value['symlink'] is not None:
  resolved=path.resolve(strict=True)
  if str(resolved) not in protected:protected[str(resolved)]=state(resolved)
def protect_tree(base):
 # Preservation metadata only. Never enter linked source directories or Cargo targets.
 protect(base)
 for directory,dirs,names in os.walk(base,followlinks=False):
  for name in sorted(dirs+names):protect(Path(directory)/name)
  dirs[:]=[name for name in dirs if not (Path(directory)/name).is_symlink()]
def read(path):return json.loads(retain(path))
save()
try:
 with LOCK.open('r+') as lock:
  deadline=time.monotonic()+600
  while True:
   try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
   except BlockingIOError:
    if time.monotonic()>=deadline:raise RuntimeError('canonical admission timed out')
    time.sleep(.1)
  record.update(status='inspecting',admitted_at=time.time(),free_bytes_before=space());save()
  for name in ['inventory.py','workflow_io.py','supervise_experiment.py']:retain(RUNNER/'scripts'/name)
  assert digest(PROPOSAL)==PROPOSAL_SHA
  proposal=read(PROPOSAL);assert proposal['source']==str(SOURCE) and proposal['source_revision']=='58e1e1f5311f4424ea81def4763081f6da62d9b3'
  completed=read(Path(proposal['completed']['path']));assert digest(Path(proposal['completed']['path']))==proposal['completed']['sha256'] and len(completed)==12
  producer_rows={}
  for stage,item in completed.items():
   path=Path(item['path']);row=read(path);assert digest(path)==item['sha256']==proposal['receipts'][stage]['sha256']
   assert row['status']=='passed' and row['returncode']==0 and row['source']==str(SOURCE) and row['owner']==str(DRIVER)
   producer_rows[stage]=row
  assert read(SOURCE/'.rust-interp-owned.json')==producer_rows['prepare']['marker']
  source_proof=read(RAW/'source.json');assert source_proof['source_commit']==proposal['source_revision']
  child,out,err=capture(['git','rev-parse','HEAD'],cwd=SOURCE,env=dict(os.environ),receipt_path=WORK/'source-head-process.json',receipt={})
  assert child.returncode==0 and not err and out.strip()==proposal['source_revision']
  write_json(WORK/'source-head.json',dict(stdout=out,stderr=err,returncode=child.returncode))
  for item in proposal['actual_commands']:
   cp=Path(item['receipt']);assert digest(cp)==item['sha256'];row=read(cp)
   assert row['status']=='finished' and row['returncode']==0 and row['cwd']==str(SOURCE)
   assert digest(Path(item['stderr']))==item['stderr_sha256']==row['stderr_sha256'];retain(Path(item['stderr']))
  files=sorted(Path(name) for unit in proposal['candidates'] for name in unit['proposed_files']);assert len(files)==len(set(files))==404
  for path in files:
   assert path.suffix in ['.rlib','.rmeta'] and any(path.is_relative_to(t) for t in TREES)
   assert path.parent.name=='out' and path.name.startswith('librustc_') and not path.name.startswith('librustc_driver')
  candidate_set=set(files)
  # Package and stage2 manifests bind known immutable runtime artifacts. Stage1
  # has no historical full inventory, so inspect its small sysroot metadata only.
  for stage,row in producer_rows.items():
   for base,items in row.get('artifact_inventories',{}).items():
    assert Path(base)==SOURCE/'build'/HOST/'stage2'
    for name in items:protect(Path(base)/name)
  for name in ['stage1','stage2']:protect_tree(SOURCE/'build'/HOST/name)
  package_receipt=Path(producer_rows['package']['package_receipt']['path'])
  assert digest(package_receipt)==producer_rows['package']['package_receipt']['sha256'];package=read(package_receipt)
  prefix=Path(producer_rows['complete']['package']);assert str(prefix)==package['prefix']
  for name in package['files']:protect(prefix/name)
  retain(Path(producer_rows['complete']['provenance']))
  for group in ['compilers','interpreter-tools','std-mir']:
   base=ROOT/'.work'/group
   if not base.exists():continue
   for directory in sorted(base.iterdir()):
    if not directory.is_dir() or directory.is_symlink() or not (directory/'ready.json').is_file():continue
    ready=read(directory/'ready.json');protect(directory/'ready.json')
    if group=='compilers':
     assert ready['owner']==str(ROOT)
     for name in ready['stamps']:protect(directory/'sysroot'/name)
    elif group=='interpreter-tools':
     for name in ready:
      assert Path(name).name==name;protect(directory/name)
     for name in ['compiler.json','capabilities.json','source.json']:
      if (directory/name).is_file():retain(directory/name)
    else:
     for field,folder in [('sysroot_stamps','sysroot'),('snapshot_stamps','library'),('evidence_stamps','evidence')]:
      for name in ready.get(field,{}):protect(directory/folder/name)
     for name in ready.get('artifacts',{}):protect(Path(name) if Path(name).is_absolute() else directory/'sysroot'/name)
     for name in ['owner.json']:
      if (directory/name).is_file():retain(directory/name)
  # HIR uses these six exact archives, not donor compiler Cargo intermediates.
  archives=producer_rows['prepare']['archive_sources']
  record['archive_source_schema']=type(archives).__name__
  for name in ['rustc-beta-aarch64-apple-darwin.tar.xz','rust-std-beta-aarch64-apple-darwin.tar.xz','cargo-beta-aarch64-apple-darwin.tar.xz','rustfmt-nightly-aarch64-apple-darwin.tar.xz','rustc-nightly-aarch64-apple-darwin.tar.xz']:
   protect(SOURCE/'build/cache/2026-08-30'/name)
  protect(Path('/Users/danluu/dev/rust-interp-stable-cgu-20260913/.work/stable-cgu-compiler-setup-01/rust-dev-nightly-aarch64-apple-darwin.tar.xz'))
  for name in ['.git/HEAD','.git/refs/heads/stable-mono-production','library/backtrace/.git/HEAD','bootstrap.toml','.rust-interp-owned.json']:protect(SOURCE/name)
  for name in ['.git','library/backtrace/.git','build/cache','build/'+HOST+'/stage0','build/'+HOST+'/ci-llvm']:protect(SOURCE/name)
  preserved_inodes=collections.defaultdict(list)
  for path,value in protected.items():
   assert Path(path) not in candidate_set,'protected manifest names a proposed file'
   if value:preserved_inodes[(value['device'],value['inode'])].append(path)
  rows=[];aliases=collections.defaultdict(list)
  for path in files:
   before=state(path);row=dict(path=str(path),state=before)
   if before is None:row.update(status='excluded',reason='missing')
   elif before['symlink'] is not None or before['resolved']!=str(path) or not stat.S_ISREG(before['mode']):row.update(status='excluded',reason='not an ordinary canonical file')
   elif before['mode']&0o111:row.update(status='excluded',reason='executable mode')
   else:
    row.update(status='pending',sha256=digest(path));assert state(path)==before,str(path)
    aliases[(before['device'],before['inode'])].append(row)
   rows.append(row)
  for inode,group in aliases.items():
   for row in group:
    overlap=preserved_inodes.get(inode,[])
    if overlap:row.update(status='excluded',reason='preserved dependency inode',preserved_paths=overlap)
    elif row['state']['nlink']!=len(group):row.update(status='excluded',reason='hardlink count exceeds proposed names',proposed_inode_paths=len(group))
    else:row.update(status='eligible')
  quiescence={};candidate_inodes=set(aliases)
  for label,argv in [('processes',['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,tty=,command=']),('handles',['/usr/sbin/lsof','-nP','-FpcftDin'])]:
   child,out,err=capture(argv,cwd=RUNNER,env=dict(os.environ),receipt_path=WORK/(label+'-process.json'),receipt={});found=[]
   if label=='processes':found=[line for line in out.splitlines() if any(str(t) in line for t in TREES)]
   else:
    process={};entry={}
    def finish():
     name=entry.get('n','')
     try:inode=(int(entry.get('D',''),16),int(entry.get('i','')))
     except ValueError:inode=None
     path_match=any(name==str(t) or name.startswith(str(t)+'/') for t in TREES)
     cwd_match=entry.get('fd')=='cwd' and name==str(SOURCE)
     if inode in candidate_inodes or path_match or cwd_match:found.append(dict(process=process.copy(),file=entry.copy(),inode_match=inode in candidate_inodes,path_match=path_match,cwd_match=cwd_match))
    for line in out.splitlines():
     if not line:continue
     key,value=line[0],line[1:]
     if key=='p':finish();process={'pid':value};entry={}
     elif key=='c':process['command']=value
     elif key=='f':finish();entry={'fd':value}
     else:entry[key]=value
    finish()
   quiescence[label]=dict(pid=child.pid,returncode=child.returncode,stdout_sha256=sha(out.encode()),stderr_sha256=sha(err.encode()),stdout_lines=len(out.splitlines()),stderr_lines=len(err.splitlines()),matches=found,raw_output_retained=False)
   write_json(WORK/'quiescence.json',quiescence);assert child.returncode==0 and not err.strip(),label+' incomplete';assert not found,label+' has users'
  for row in rows:assert state(row['path'])==row['state'],'candidate changed: '+row['path']
  for path,value in protected.items():assert state(path)==value,'preserved dependency changed: '+path
  for path,value in proofs.items():assert digest(path)==value['sha256'] and state(path)==value['state'],'proof changed: '+path
  encoded=json.dumps(rows,sort_keys=True,separators=(',',':')).encode();(WORK/'inventory.json.gz').write_bytes(gzip.compress(encoded,mtime=0))
  write_json(WORK/'proof-manifest.json',proofs);write_json(WORK/'preserved-dependencies.json',protected)
  eligible=[r for r in rows if r['status']=='eligible'];unique={(r['state']['device'],r['state']['inode']):r for r in eligible}
  record.update(status='passed',finished_at=time.time(),proposal_sha256=PROPOSAL_SHA,proposed_files=404,eligible_files=len(eligible),excluded_files=len(rows)-len(eligible),exclusions=dict(collections.Counter(r.get('reason') for r in rows if r['status']=='excluded')),eligible_logical_bytes=sum(r['state']['bytes'] for r in unique.values()),eligible_allocated_bytes=sum(r['state']['blocks']*512 for r in unique.values()),preserved_dependencies=len(protected),retained_proofs=len(proofs),quiescence=quiescence,free_bytes_after=space(),allocation_limit='Unique-inode allocated blocks; APFS shared extents and unrelated allocation prevent guaranteed reclamation.',all_candidate_and_preserved_identities_unchanged=True,retirement_authorized=False)
  record['proof_files']={name:digest(WORK/name) for name in ['inventory.json.gz','proof-manifest.json','preserved-dependencies.json','quiescence.json','source-head.json','source-head-process.json']};save()
  print(json.dumps({k:record[k] for k in ['status','pid','eligible_files','excluded_files','eligible_allocated_bytes','free_bytes_after','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());save();raise
