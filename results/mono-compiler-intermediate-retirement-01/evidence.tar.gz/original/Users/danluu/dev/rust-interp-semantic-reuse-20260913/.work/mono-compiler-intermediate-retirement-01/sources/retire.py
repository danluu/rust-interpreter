"""Retire only258 reviewed ordinary compiler-library files after fresh checks.

Prepared for explicit root review. No other deletion or process control exists.
"""
import collections,fcntl,gzip,hashlib,json,os,shutil,stat,sys,time
from pathlib import Path
from workflow_io import capture,write_json
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
RUNNER=Path(__file__).resolve().parents[1]
SOURCE=Path('/Users/danluu/dev/rustc-stable-mono-production-20260913')
PROOF=ROOT/'.work/mono-compiler-intermediate-inventory-02'
WORK=ROOT/'.work/mono-compiler-intermediate-retirement-01'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
INSPECTION_SHA='a52e05c65c2d0063d158a7fcb042607a45e925c7dd8c52160f4cf0ab09105002'
PROPOSAL_SHA='99c6189c99656c9f97b68d88f07d7ab91886104209ebf454d51649ac89f16be1'
TREES=[SOURCE/'build/aarch64-apple-darwin'/name for name in ['stage1-rustc','stage2-rustc']]
WORK.mkdir(exist_ok=False)
record=dict(schema_version=1,status='waiting',owner=str(ROOT),runner=str(RUNNER),pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,deleted=[],process_controls=0,builds=0,benchmarks=0)
def sha(data):return hashlib.sha256(data).hexdigest()
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  while b:=stream.read(4*1024*1024):h.update(b)
 return h.hexdigest()
def save():write_json(WORK/'summary.json',record)
def ordinary(path):assert path.resolve(strict=True)==path and not path.is_symlink(),str(path)
def space():
 free=shutil.disk_usage(ROOT).free;assert free>=8*1024**3,'retirement requires8GiB free';return free
def state(path):
 path=Path(path)
 if not path.exists() and not path.is_symlink():return None
 s=path.lstat()
 return dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,blocks=s.st_blocks,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink,symlink=os.readlink(path) if path.is_symlink() else None,resolved=str(path.resolve(strict=True)))
save()
try:
 with LOCK.open('r+') as lock:
  deadline=time.monotonic()+600
  while True:
   try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
   except BlockingIOError:
    if time.monotonic()>=deadline:raise RuntimeError('canonical admission timed out')
    time.sleep(.1)
  record.update(status='revalidating',admitted_at=time.time(),free_bytes_before=space());save()
  assert digest(PROOF/'summary.json')==INSPECTION_SHA
  inspection=json.loads((PROOF/'summary.json').read_bytes())
  assert inspection['status']=='passed' and inspection['deleted']==[] and inspection['proposed_files']==404 and inspection['eligible_files']==258
  assert inspection['proposal_sha256']==PROPOSAL_SHA and inspection['all_candidate_and_preserved_identities_unchanged']
  assert inspection['eligible_allocated_bytes']==3484483584
  for name,h in inspection['proof_files'].items():assert digest(PROOF/name)==h
  rows=json.loads(gzip.decompress((PROOF/'inventory.json.gz').read_bytes()))
  assert len(rows)==404 and len({r['path'] for r in rows})==404
  eligible=[r for r in rows if r['status']=='eligible'];excluded=[r for r in rows if r['status']=='excluded'];assert len(eligible)==258 and len(excluded)==146
  proofs=json.loads((PROOF/'proof-manifest.json').read_bytes());protected=json.loads((PROOF/'preserved-dependencies.json').read_bytes())
  assert len(proofs)==85 and len(protected)==63448
  proposal_path=ROOT/'.work/mono-compiler-intermediate-proposal-01.json';assert digest(proposal_path)==PROPOSAL_SHA
  proposal=json.loads(proposal_path.read_bytes());assert {r['path'] for r in rows}=={p for u in proposal['candidates'] for p in u['proposed_files']}
  for row in eligible:
   path=Path(row['path']);s=row['state'];ordinary(path)
   assert any(path.is_relative_to(t) for t in TREES) and path.parent.name=='out'
   assert path.suffix in ['.rlib','.rmeta'] and path.name.startswith('librustc_') and not path.name.startswith('librustc_driver')
   assert stat.S_ISREG(s['mode']) and not s['mode']&0o111 and s['nlink']==1 and s['symlink'] is None
  def preserved_check():
   for path,value in protected.items():assert state(path)==value,'preserved dependency changed: '+path
   for path,value in proofs.items():assert state(path)==value['state'] and digest(path)==value['sha256'],'proof changed: '+path
   for name,h in inspection['proof_files'].items():assert digest(PROOF/name)==h
   assert digest(PROOF/'summary.json')==INSPECTION_SHA
  preserved_check()
  for row in rows:
   assert state(row['path'])==row['state'],'candidate/exclusion identity changed: '+row['path']
   assert digest(row['path'])==row['sha256'],'candidate/exclusion content changed: '+row['path']
  supervisor=ROOT/'.work/mono-compiler-intermediate-inventory-runner-02/.work/experiments/inventory-supervisor-02'
  completed=json.loads((supervisor/'status.json').read_bytes());assert completed['status']=='finished' and completed['returncode']==0 and completed['child_pid']==inspection['pid']
  assert digest(supervisor/'plan.json')==completed['plan_sha256'] and digest(supervisor/'command.log')==completed['log_sha256']
  sources={}
  for name in ['retire.py','workflow_io.py','supervise_experiment.py']:
   path=RUNNER/'scripts'/name;ordinary(path);data=path.read_bytes();sources[str(path)]=sha(data)
   destination=WORK/'sources'/name;destination.parent.mkdir(exist_ok=True);assert space()-len(data)>=8*1024**3;destination.write_bytes(data)
  write_json(WORK/'source-inputs.json',sources)
  inodes={(r['state']['device'],r['state']['inode']) for r in rows}
  eligible_inodes={(r['state']['device'],r['state']['inode']) for r in eligible};assert len(eligible_inodes)==258
  for path,value in protected.items():
   assert path not in {r['path'] for r in eligible}
   if value:assert (value['device'],value['inode']) not in eligible_inodes,'preserved inode overlap: '+path
  checks={}
  for label,argv in [('processes',['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,tty=,command=']),('handles',['/usr/sbin/lsof','-nP','-FpcftDin'])]:
   child,out,err=capture(argv,cwd=RUNNER,env=dict(os.environ),receipt_path=WORK/(label+'-process.json'),receipt={});found=[]
   if label=='processes':found=[line for line in out.splitlines() if any(str(t) in line for t in TREES)]
   else:
    process={};entry={}
    def finish():
     name=entry.get('n','')
     try:inode=(int(entry.get('D',''),16),int(entry.get('i','')))
     except ValueError:inode=None
     path_match=any(name==str(t) or name.startswith(str(t)+'/') for t in TREES)
     cwd_match=entry.get('fd')=='cwd' and name==str(SOURCE)
     if inode in inodes or path_match or cwd_match:found.append(dict(process=process.copy(),file=entry.copy(),inode_match=inode in inodes,path_match=path_match,cwd_match=cwd_match))
    for line in out.splitlines():
     if not line:continue
     k,v=line[0],line[1:]
     if k=='p':finish();process={'pid':v};entry={}
     elif k=='c':process['command']=v
     elif k=='f':finish();entry={'fd':v}
     else:entry[k]=v
    finish()
   checks[label]=dict(pid=child.pid,returncode=child.returncode,stdout_sha256=sha(out.encode()),stderr_sha256=sha(err.encode()),stdout_lines=len(out.splitlines()),stderr_lines=len(err.splitlines()),matches=found,raw_output_retained=False)
   write_json(WORK/'quiescence.json',checks);assert child.returncode==0 and not err.strip(),label+' incomplete';assert not found,label+' has users'
  preserved_check()
  for path,h in sources.items():assert digest(path)==h
  write_json(WORK/'selected-files.json',eligible)
  record.update(status='retiring',inspection_sha256=INSPECTION_SHA,proposal_sha256=PROPOSAL_SHA,inventory_sha256=inspection['proof_files']['inventory.json.gz'],selected_sha256=digest(WORK/'selected-files.json'),quiescence=checks,quiescent_at=time.time(),eligible_allocated_bytes=inspection['eligible_allocated_bytes'],selected_count=258,excluded_count=146);save()
  for row in eligible:
   path=Path(row['path']);ordinary(path);assert state(path)==row['state'] and digest(path)==row['sha256'];space()
   path.unlink()
   assert not path.exists() and not path.is_symlink()
   record['deleted'].append(dict(path=str(path),sha256=row['sha256'],state=row['state'],finished_at=time.time()));save()
  for row in excluded:assert state(row['path'])==row['state'] and digest(row['path'])==row['sha256'],'excluded file changed: '+row['path']
  preserved_check()
  for path,h in sources.items():assert digest(path)==h
  record.update(status='passed',finished_at=time.time(),free_bytes_after=space(),preserved_dependency_count=len(protected),retained_proof_count=len(proofs),excluded_files_unchanged=True,all_preserved_dependencies_and_proofs_unchanged=True,directories_removed=0,only_selected_ordinary_files_removed=True);save()
  print(json.dumps({k:record[k] for k in ['status','pid','selected_count','free_bytes_before','free_bytes_after','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());save();raise
