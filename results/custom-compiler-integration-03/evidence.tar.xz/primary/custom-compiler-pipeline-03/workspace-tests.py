"""Owned actual-workspace qualification; this child alone owns the shared lock."""
import json,os,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'scripts'))
from build_custom_tools import cargo_identity,source_identity
from compare_saved_runtime import acquire_lock
from custom_compiler import load_compiler,file_digest,digest,require,validate_tool_compiler
from interpreter import installed_tools
from workflow_io import capture,require_space,write_json
compiler_key,tool_key,run_id=sys.argv[1:]
work=root/'.work'/run_id;work.mkdir(exist_ok=False)
record={'status':'waiting','supervisor_pid':os.getpid(),'started_at':time.time(),'children_started':0,'benchmark':False,'compiler_key':compiler_key,'tool_key':tool_key,'runner_sha256':file_digest(Path(__file__))}
write_json(work/'result.json',record)
try:
 with (root/'.work/benchmark.lock').open('a') as lock:
  acquire_lock(lock,600);require_space(work,8)
  compiler=load_compiler(root,compiler_key);tools,key=installed_tools(tool_key);validate_tool_compiler(tools,key,compiler)
  composition=json.loads((tools/'compiler.json').read_text());require(cargo_identity()==composition['cargo'],'matching Cargo changed');require(source_identity()==composition['source_files'],'matching tool source changed')
  sources={str(p.relative_to(root)):file_digest(p) for p in (root/'crates').rglob('*') if p.is_file()}
  env={k:v for k,v in os.environ.items() if not k.startswith(('RUST_INTERP_','CARGO_PROFILE_')) and k not in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC','RUSTDOC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_TARGET_DIR','CARGO_BUILD_TARGET','CARGO_INCREMENTAL']}
  env.update(CARGO_TERM_COLOR='never',RUSTC_WRAPPER='',RUSTC_WORKSPACE_WRAPPER='');env=compiler.environment(env)
  rustdoc=compiler.sysroot/'bin/rustdoc';require(rustdoc.is_file() and os.access(rustdoc,os.X_OK),'matching rustdoc is missing');env['RUSTDOC']=str(rustdoc)
  command=[composition['cargo']['executable'],'test','--release','--locked','--offline','--jobs','2','--workspace','--target-dir',str(root/'.work/custom-interpreter-build'/compiler_key),'--','--test-threads=2']
  plan={'kind':'actual-custom-compiler-workspace-tests','benchmark':False,'compiler_key':compiler_key,'tool_key':key,'cargo':composition['cargo'],'source_files':sources,'command':command,'environment_sha256':digest(env),'rustdoc':{'path':str(rustdoc),'sha256':file_digest(rustdoc)},'settings':{'profile':'release','jobs':2,'test_threads':2,'profile_overrides':{},'compiler_environment':{k:env[k] for k in ['RUSTC','RUSTDOC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','PATH']}}}
  write_json(work/'plan.json',plan)
  child,out,err=capture(command,cwd=root,env=env,receipt_path=work/'child.json',receipt={'phase':'workspace-correctness','compiler_key':compiler_key,'tool_key':key})
  (work/'stdout').write_text(out);(work/'stderr').write_text(err);record.update(children_started=1,pid=child.pid,returncode=child.returncode)
  require(child.returncode==0,'actual workspace correctness failed')
  require(all(file_digest(root/name)==h for name,h in sources.items()),'workspace test sources changed');require(source_identity()==composition['source_files'],'matching tool source changed');require(cargo_identity()==composition['cargo'],'matching Cargo changed');load_compiler(root,compiler_key);installed_tools(key)
  record.update(status='passed',finished_at=time.time(),test_results=[line for line in out.splitlines() if line.startswith('test result:')]);write_json(work/'result.json',record);print(json.dumps(record))
except BaseException as error:
 record.update(status='failed',error=str(error),finished_at=time.time());write_json(work/'result.json',record);raise
