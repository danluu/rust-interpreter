"""Bounded saved evidence and current publication metadata; no provider imports."""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time

ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
R=Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
A=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
SOURCE=ROOT/'experiments/runtime-installation-after-preflight05-03'
PACKET=SOURCE/'installation-plan-01'
WORK=R/'.work/hir-options-hash-runtime-installation-07'
OUTER=R/'.work/experiments/hir-options-hash-runtime-installation-supervisor-07'
LAUNCHER=R/'.work/hir-options-hash-runtime-installation-launch-execution-07'
FIELDS=('dev','ino','mode','size','mtime_ns','ctime_ns','nlink')
checked={}
started=time.time()

def identity(path):
    s=Path(path).lstat()
    return [getattr(s,'st_'+k) for k in FIELDS]

def raw(path):
    path=Path(path);before=identity(path)
    assert path.resolve(strict=True)==path and stat.S_ISREG(before[2]) and before[3]<=16*2**20
    with path.open('rb') as stream:
        assert identity(path)==before
        data=stream.read(16*2**20+1)
        assert [getattr(os.fstat(stream.fileno()),'st_'+k) for k in FIELDS]==before
    assert len(data)==before[3] and identity(path)==before
    row=dict(identity=before,size=len(data),sha256=hashlib.sha256(data).hexdigest())
    assert str(path) not in checked or checked[str(path)]==row
    checked[str(path)]=row
    return data

def doc(path):return json.loads(raw(path))
def ref(path):
    raw(path)
    return dict(path=str(path),sha256=checked[str(path)]['sha256'])
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def loads(text,image):
    lines=text.splitlines()
    headers=[line for line in lines if line.startswith(str(image))]
    assert len(headers)==1 and headers[0] in [str(image)+':',str(image)+' (architecture arm64):']
    matches=list(re.finditer(r'(?m)^Load command (\d+)\s*$',text))
    assert matches and [int(m[1]) for m in matches]==list(range(len(matches)))
    value=dict(rpaths=[],loads=[])
    for i,m in enumerate(matches):
        block=text[m.end():matches[i+1].start() if i+1<len(matches) else len(text)]
        kind=re.search(r'(?m)^\s*cmd (LC_\w+)\s*$',block)[1]
        assert kind!='LC_DYLD_ENVIRONMENT'
        if kind=='LC_RPATH':value['rpaths'].append(re.search(r'(?m)^\s*path (.+) \(offset \d+\)\s*$',block)[1])
        elif kind in {'LC_LOAD_DYLIB','LC_LOAD_WEAK_DYLIB','LC_REEXPORT_DYLIB','LC_LOAD_UPWARD_DYLIB','LC_LAZY_LOAD_DYLIB','LC_LOAD_DYLINKER'}:
            value['loads'].append([kind,re.search(r'(?m)^\s*name (.+) \(offset \d+\)\s*$',block)[1]])
        else:assert not kind.endswith('_DYLIB') or kind=='LC_ID_DYLIB'
    return value

plan=doc(PACKET/'plan.json');spec=doc(PACKET/'specification.json')
terminal=doc(WORK/'receipt.json');outer=doc(OUTER/'status.json');launcher=doc(LAUNCHER/'record.json')
assert terminal['status']=='passed' and terminal['phase']=='installation' and 'error' not in terminal
assert len(terminal['children'])==len(plan['children'])==15
assert outer['status']=='finished' and outer['returncode']==0
assert launcher['status']=='terminal-observed' and launcher['returncode']==0 and launcher['launcher_returncode']==0
assert terminal['pid']==outer['child_pid']==launcher['controller_pid']==83231
assert terminal['parent_pid']==outer['supervisor_pid']==launcher['supervisor_pid']==83187
assert launcher['launcher_pid']==82289 and launcher['pid']==83177
assert terminal['finished_at']<=outer['finished_at']<=launcher['terminal_observed_at']<=launcher['finished_at']
assert launcher['started_at']<=outer['started_at']<=terminal['started_at']<=terminal['admitted_at']
assert ref(OUTER/'status.json')['sha256']==launcher['outer_sha256']
assert ref(OUTER/'plan.json')['sha256']==outer['plan_sha256']
assert ref(OUTER/'command.log')['sha256']==outer['log_sha256'] and raw(OUTER/'command.log')==b''
for name in ('stdout','stderr'):assert ref(LAUNCHER/name)['sha256']==launcher[name+'_sha256']
assert not raw(LAUNCHER/'stderr')
assert ref(LAUNCHER/'launcher.py')['sha256']==launcher['launcher_source_sha256']==ref(SOURCE/'launch.py')['sha256']=='21560018724dd9439648acbf68e61a05b9899c8e8fb66e2f1e605bf747e8da06'
assert ref(PACKET/'launch.json')['sha256']==launcher['launch_sha256']=='a917e8a23ea18587852dc416961956f32d89084b4bdf7a4ca251586fc5619168'
for name,field in [('inputs.json','inputs_sha256'),('plan.json','plan_sha256'),('snapshot-plan.json','snapshot_plan_sha256')]:assert ref(PACKET/name)['sha256']==terminal[field]
prep=R/'.work/hir-options-hash-runtime-installation-preparation-execution-07/record.json'
assert ref(prep)['sha256']=='61fe20cc4533fdff67f6336b62bc4bd0bf324a6c5d44ef6bf207ca716e0f39ce'
assert launcher['startup_environment_admission']['preparation']==ref(prep)
assert terminal['runtime_key']==terminal['installed_runtime_key']==plan['runtime_key']=='f031d981666f450f760ccf303dccba986053ec6b9a143a60f3d26680f9ac7c70'
prefix=R/'.work/runtime-compilers'/plan['runtime_key'];sysroot=prefix/'sysroot'
assert terminal['sysroot']==plan['sysroot']==str(sysroot)
assert spec['loader_probe']=={'policy':'darwin-native-loader-probe-v1','host':'aarch64-apple-darwin','architecture':'arm64'}
for field in ['application_qualified','performance_measurement','exporter_qualified','std_mir_prepared']:assert terminal[field] is False
result=doc(WORK/'source-probe/result.json');ready=doc(prefix/'ready.json');admission=doc(prefix/'admission.json');qualification=doc(prefix/'qualification.json')
assert raw(WORK/'source-probe/result.json')==raw(prefix/'qualification.json')
assert set(admission)=={'identity','snapshots'} and ready['identity']==admission['identity'] and admission['identity']['admission']==spec
installed=ready['identity'];assert digest(installed)==plan['runtime_key']
assert ready['status']=='installed' and ready['owner']==str(R) and ready['key']==plan['runtime_key'] and ready['sysroot']==str(sysroot)
assert ready['application_qualified'] is False and result['status']=='passed' and result['key']==plan['runtime_key'] and result['sysroot']==str(sysroot)
assert result['pid']==terminal['pid'] and result['parent_pid']==terminal['parent_pid']
assert result['application_qualified'] is False and result['std_mir_prepared'] is False and result['full_presentation_qualified'] is False
assert result['exact_source_paths_observed'] is True
assert ready['prepublication_qualification']==dict(policy='native-runtime-installed-source-v1',receipt='qualification.json',sha256=ref(prefix/'qualification.json')['sha256'],stamp=identity(prefix/'qualification.json'))
file_rows={}
for component in spec['components']:
    for name,row in component['files'].items():
        name=str(Path(component['destination'])/name)
        assert name not in file_rows;file_rows[name]=row
assert installed['files']=={name:row['sha256'] for name,row in file_rows.items()}
assert installed['source_sha256']==digest({k:v for k,v in installed['files'].items() if k.startswith('lib/rustlib/src/rust/library/')})
assert installed['compiler']==spec['compiler']==result['compiler']
assert result['files_sha256']==digest(installed['files']) and result['source_sha256']==installed['source_sha256']
observations=[];samples=[];unavailable_cwd=[];outputs=[]
for i,(declaration,childref) in enumerate(zip(plan['children'],terminal['children'],strict=True)):
    out=Path(declaration['output']);p=out/'receipt.json';child=doc(p)
    assert out==WORK/('commands/'+f'{i:03d}' if i<13 else 'source-probe/commands/'+str(i-13))
    assert childref==dict(path=str(p),sha256=ref(p)['sha256'],pid=child['pid'],returncode=child['returncode'])
    assert child['status']=='finished' and child['returncode']==(0 if i<13 else 1)
    assert child['expected']==declaration['expected']==[child['returncode']]
    assert child['command']==declaration['argv'] and child['cwd']==declaration['cwd'] and child['environment']==declaration['environment']
    assert child['supervisor_pid']==terminal['pid'] and child['parent_pid']==terminal['parent_pid']
    assert terminal['admitted_at']<=child['started_at']<=child['finished_at']<=terminal['finished_at']
    if observations:assert observations[-1]['finished_at']<=child['started_at']
    for stream in ('stdout','stderr'):assert ref(out/stream)['sha256']==child[stream+'_sha256']
    assert {p.name for p in out.iterdir()}=={'receipt.json','stdout','stderr'}
    stdout=raw(out/'stdout').decode();stderr=raw(out/'stderr').decode();outputs.append((stdout,stderr))
    if i<13:assert stderr==''
    if i<10:
        name=sorted(spec['loader'])[i]
        assert child['command']==['/usr/bin/otool','-arch','arm64','-l',str(sysroot/name)]
        assert loads(stdout,sysroot/name)==spec['loader'][name]==ready['probes']['loader'][name]
    if child['identity']['cwd_returncode']!=0:unavailable_cwd.append(dict(index=i,pid=child['pid'],observation=child['identity']))
    assert child['samples'];samples.extend(child['samples'])
    observations.append(dict(index=i,pid=child['pid'],returncode=child['returncode'],started_at=child['started_at'],finished_at=child['finished_at'],receipt=ref(p),stdout=ref(out/'stdout'),stderr=ref(out/'stderr')))
assert outputs[10][0]==spec['compiler']==ready['probes']['compiler']
assert outputs[11][0]==str(sysroot)+'\n'==ready['probes']['sysroot']
options=dict(probe='-Zhelp',output=outputs[12][0],sha256=hashlib.sha256(outputs[12][0].encode()).hexdigest(),supported=sorted(set(re.findall(r'(?m)^\s*(?:-Z\s+)?([a-z][a-z0-9-]*)\s*=',outputs[12][0]))))
assert options==spec['unstable_options']==ready['probes']['options']==installed['unstable_options']
retained={name:raw(row['path']) for name,row in result['retained_sources'].items()}
for name,row in result['retained_sources'].items():assert ref(row['path'])['sha256']==row['sha256']==installed['files']['lib/rustlib/src/rust/library/'+name]
probe_observations=[]
for index in range(2):
    assert outputs[index+13][0]==''
    diagnostics=[json.loads(line) for line in outputs[index+13][1].splitlines() if line.strip()]
    errors=[d for d in diagnostics if d.get('level')=='error' and d.get('code')]
    assert len(errors)==1 and errors[0]['code']['code']=='E0080' and 'std source lookup probe' in errors[0]['message']
    found=[]
    def visit(value):
        if isinstance(value,dict):
            if 'file_name' in value:
                name=value['file_name'];base=(str(sysroot/'lib/rustlib/src/rust/library')+'/' if index==0 else '/rustc/'+result['source_commit']+'/library/')
                if name.startswith(base):
                    relative=name[len(base):];assert relative in retained
                    has_text=bool(value.get('text'));assert has_text==(index==0)
                    if has_text:
                        lines=retained[relative].decode().splitlines()
                        assert [x['text'] for x in value['text']]==lines[value['line_start']-1:value['line_end']]
                    found.append(dict(file_name=name,source=relative,sha256=hashlib.sha256(retained[relative]).hexdigest(),has_text=has_text))
            for v in value.values():visit(v)
        elif isinstance(value,list):
            for v in value:visit(v)
    visit(diagnostics)
    expected=result['commands'][index]
    assert expected['path']==observations[index+13]['receipt']['path'] and expected['sha256']==observations[index+13]['receipt']['sha256']
    assert dict(sources=sorted(set(x['source'] for x in found)),spans=found)==expected['observed']
    probe_observations.append(expected)
assert terminal['installation_resources']['logical_bytes']==sum(x['size'] for x in file_rows.values())==636631680
assert terminal['installation_resources']['copied_files']==len(file_rows)==3708
assert terminal['installation_resources']['admission_json_bytes']==len(raw(prefix/'admission.json'))
assert len(raw(prefix/'ready.json'))<=terminal['installation_resources']['ready_json_upper_bytes']
assert terminal['installation_resources']['total_reserved_bytes']==822697984<2**30
assert terminal['free_bytes_before']>=16*2**30 and terminal['free_bytes_after']>=8*2**30
assert terminal['snapshot_admission']['existing_evidence_bytes']+terminal['snapshot_admission']['reserved_bytes']<=256*2**20
for sample in samples:
    assert sample['allocation_errors']==[] and sample['free_bytes']>=9*2**30
    assert sample['namespace_allocated_bytes']<=14*2**30 and sample['evidence_allocated_bytes']<=256*2**20
    assert sample['runtime_installation_allocation_sample']['bytes']<=2**30
    assert sample['namespace_allocated_bytes']==sample['compiler_namespace_allocated_bytes']+sample['runtime_installation_allocation_sample']['bytes']

def census():
    found={};pending=[prefix]
    while pending:
        path=pending.pop();s=identity(path);name='.' if path==prefix else str(path.relative_to(prefix))
        assert stat.S_ISDIR(s[2]) or stat.S_ISREG(s[2]);assert not s[2]&0o222
        if stat.S_ISREG(s[2]):assert s[6]==1
        found[name]=s;assert len(found)<=5000
        if stat.S_ISDIR(s[2]):pending.extend(sorted(path.iterdir(),reverse=True))
    return found

metadata=census();assert census()==metadata
assert {p.name for p in prefix.iterdir()}=={'sysroot','admission.json','qualification.json','ready.json'}
sysroot_stamps={'.' if name=='sysroot' else name.removeprefix('sysroot/'):value[:6] for name,value in metadata.items() if name=='sysroot' or name.startswith('sysroot/')}
assert sysroot_stamps==ready['stamps']
actual_files={name.removeprefix('sysroot/') for name,value in metadata.items() if name.startswith('sysroot/') and stat.S_ISREG(value[2])}
assert actual_files==set(file_rows)
for name,row in file_rows.items():
    s=metadata['sysroot/'+name];assert s[3]==row['size'] and stat.S_IMODE(s[2])==row['mode']&~0o222
for path,row in checked.items():assert identity(path)==row['identity']
report=dict(status='passed-bounded-saved-installation07-readback',installation_itself_passed=True,independent_saved_audit_qualified=False,
    reader=ref(Path(__file__).resolve()),pid=os.getpid(),parent_pid=os.getppid(),started_at=started,finished_at=time.time(),
    launcher=ref(LAUNCHER/'record.json'),outer=ref(OUTER/'status.json'),receipt=ref(WORK/'receipt.json'),result=ref(WORK/'source-probe/result.json'),
    preparation=ref(prep),publication={name:ref(prefix/(name+'.json')) for name in ('ready','admission','qualification')},
    runtime_key=plan['runtime_key'],actual_children=observations,source_probe_observations=probe_observations,
    installation_resources=terminal['installation_resources'],snapshot_admission=terminal['snapshot_admission'],
    resources=dict(sample_count=len(samples),minimum_sampled_free_bytes=min(s['free_bytes'] for s in samples),maximum_sampled_namespace_bytes=max(s['namespace_allocated_bytes'] for s in samples),maximum_sampled_evidence_bytes=max(s['evidence_allocated_bytes'] for s in samples),maximum_sampled_prefix_bytes=max(s['runtime_installation_allocation_sample']['bytes'] for s in samples),scope='Retained non-atomic observations only; no new namespace or provider walks.'),
    publication_metadata=metadata,metadata_stable_two_walks=True,installed_files=len(actual_files),
    limitations=dict(unavailable_contemporaneous_cwd=unavailable_cwd,wrapper_identity=launcher['wrapper_identity_limitation'],provider_payloads_rehashed=False,saved_audit_not_replayed=True),
    claims=dict(application_qualified=False,performance_measurement=False,exporter_qualified=False,std_mir_prepared=False),
    no_new_probes=True,no_provider_imports=True,no_source_or_prefix_mutations=True,evidence=checked)
output=A/'.work/runtime-installation07-closed-independent-readback-01.json'
payload=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode()
with output.open('xb') as stream:stream.write(payload)
print(json.dumps(dict(path=str(output),sha256=hashlib.sha256(payload).hexdigest(),bytes=len(payload),children=len(observations),installed_files=len(actual_files),metadata_entries=len(metadata),resources=report['resources'])))
