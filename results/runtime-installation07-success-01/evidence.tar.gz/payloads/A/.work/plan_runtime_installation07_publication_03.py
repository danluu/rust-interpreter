"""Add only closed audit12 failure provenance to the immutable publication scope01."""
import copy
import hashlib
import json
import os
from pathlib import Path
import stat
import time
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
A=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
R=Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
FIELDS=('dev','ino','mode','nlink','size','mtime_ns','ctime_ns')
seen={}

def stamp(path):
    s=path.lstat();return {k:getattr(s,'st_'+k) for k in FIELDS}


def read(path):
    assert path.resolve(strict=True)==path
    before=stamp(path);assert stat.S_ISREG(before['mode']) and before['nlink']==1 and before['size']<=16*2**20
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as f:
        assert {k:getattr(os.fstat(f.fileno()),'st_'+k) for k in FIELDS}==before
        data=f.read(16*2**20+1)
        assert {k:getattr(os.fstat(f.fileno()),'st_'+k) for k in FIELDS}==before
    assert stamp(path)==before and len(data)==before['size']
    row=dict(path=str(path),identity=before,size=len(data),sha256=hashlib.sha256(data).hexdigest())
    assert str(path) not in seen or seen[str(path)]==row
    seen[str(path)]=row;return data


def tree(root):
    found={};pending=[root]
    while pending:
        p=pending.pop();s=stamp(p);assert stat.S_ISREG(s['mode']) or stat.S_ISDIR(s['mode'])
        found['.' if p==root else str(p.relative_to(root))]=s
        if stat.S_ISDIR(s['mode']):pending.extend(sorted(p.iterdir(),reverse=True))
        assert len(found)<=400
    assert all(stamp(root/p)==s for p,s in found.items())
    return found


basepath=A/'.work/runtime-installation07-publication-scope-01.json'
base=json.loads(read(basepath));assert seen[str(basepath)]['sha256']=='2986ce6d70c6838dc524e10f484f6dc49a2d3ec4be1520b5feb73cd5f4a3ae7d'
assert base['selected_files']==315
execution=ROOT/'.work/runtime12-saved-audit-installation-execution-01'
preparation=ROOT/'.work/runtime12-saved-audit-installation-manifest-preparation-execution-01'
manifest=ROOT/'.work/runtime12-saved-audit-installation-manifest-01'
audit_source=ROOT/'experiments/hir-options-hash-runtime-audit-12'
additional_trees={str(p):tree(p) for p in [execution,preparation,manifest]}
additions={Path(p)/name for p,rows in additional_trees.items() for name,row in rows.items() if stat.S_ISREG(row['mode'])}
assert len([p for p in additions if p.parent==execution])==8
assert len([p for p in additions if p.parent in [preparation,manifest]])==10
additions.update([O/'.work/runtime12-manifest-preparation-independent-readback-01.json',
 A/'.work/runtime12-production07-binding-independent-review-01.json',
 O/'.work/runtime12-record-cap368-command-handoff-01.json',
 ROOT/'.work/runtime12-saved-audit-source-inventory-05.json'])
additions.update(audit_source/name for name in ['audit.py','bootstrap.py','prepare_manifest.py','execute.py','test_tail.py','test_completed_directories.py'])
for p in sorted(additions):read(p)
source_manifest=ROOT/'results/runtime12-installation-audit-source-01/manifest.json'
published=json.loads(read(source_manifest));assert seen[str(source_manifest)]['sha256']=='e7a53d4ffface73f39c61a3e6f8dccd54f62d773846e287bc58c43d282a0e19f'
lookup={r['original']:r for r in published['files']}
referenced_audit_sources=[]
reference_paths={p for p in additions if p.parent==audit_source or p.name=='runtime12-saved-audit-source-inventory-05.json'}
assert len(reference_paths)==7
for p in sorted(reference_paths):
 row=lookup[str(p)];copy_path=source_manifest.parent/row['relative']
 assert read(copy_path)==read(p) and seen[str(p)]['sha256']==row['source']['sha256']==row['destination']['sha256']
 referenced_audit_sources.append(dict(path=str(p),sha256=seen[str(p)]['sha256'],size=seen[str(p)]['size'],publication=str(copy_path.relative_to(ROOT)),commit='456a668ac3a93f8a3e21c630e9b6c51c1957e1c1',manifest_sha256=seen[str(source_manifest)]['sha256']))
additions-=reference_paths;additions.add(source_manifest)

record=json.loads(read(execution/'record.json'));prep=json.loads(read(preparation/'record.json'))
assert seen[str(execution/'record.json')]['sha256']=='96d752b4a031983cfbc4f8dc4c970be7a84e88597b3dae0c441516cf772019bc'
assert record['status']=='finished' and record['returncode']==1 and record['may_be_live'] is False and record['observation_errors']==[]
assert record['parent_pid']==45820 and record['pid']==46534 and record['finished_at']==1789832387.3178408
assert prep['status']=='finished' and prep['returncode']==0 and prep['may_be_live'] is False and prep['observation_errors']==[]
assert record['actual_closure_pins']['preparation_record_sha256']==seen[str(preparation/'record.json')]['sha256']
assert record['actual_closure_pins']['manifest_sha256']==seen[str(manifest/'manifest.json')]['sha256']==prep['manifest_sha256']
assert record['actual_closure_pins']['preparation_sha256']==seen[str(manifest/'preparation.json')]['sha256']==prep['result_sha256']
for folder,value in [(execution,record),(preparation,prep)]:
 for stream in ('stdout','stderr'):assert seen[str(folder/stream)]['sha256']==value[stream+'_sha256']
 for name,key in [('execution.py','execution_source_sha256'),('source.py','source_sha256'),('owned_stage.py','owned_source_sha256')]:assert seen[str(folder/name)]['sha256']==value[key]
assert not read(execution/'stdout')
trace=read(execution/'stderr').decode();assert 'final_runtime.py", line 140' in trace and 'RuntimeError: undeclared saved-evidence path' in trace
inventory=json.loads(read(ROOT/'.work/runtime12-saved-audit-source-inventory-05.json'))
for p in reference_paths:
 if p.parent==audit_source:assert seen[str(p)]['sha256']==inventory['sources'][str(p)]
report=Path(record['report']);assert not os.path.lexists(report)
for p in [execution,preparation,manifest]:assert tree(p)==additional_trees[str(p)]
# Retain every original selected row exactly; only revalidate its metadata here.
assert all(stamp(Path(row['path']))==row['identity'] for row in base['files'])
assert not set(row['path'] for row in base['files'])&set(map(str,additions))
scope=copy.deepcopy(base);scope['created_at']=time.time();scope['predecessor_scope']=seen[str(basepath)]
scope['files']=sorted([*base['files'],*(seen[str(p)] for p in additions)],key=lambda x:x['path'])
scope['selected_files']=len(scope['files']);scope['selected_bytes']=sum(row['size'] for row in scope['files'])
scope['source_trees'].update(additional_trees)
scope['published_source_references'].extend(referenced_audit_sources)
scope['published_audit12_sources_manifest']=seen[str(source_manifest)]
for root,rows in additional_trees.items():scope['tree_counts'][root]=dict(files=sum(stat.S_ISREG(s['mode']) for s in rows.values()),bytes=sum(s['size'] for s in rows.values() if stat.S_ISREG(s['mode'])))
scope['future_audit12']=dict(included=True,outcome='failed-closed1-no-report',execution=seen[str(execution/'record.json')],manifest_preparation=seen[str(preparation/'record.json')],manifest=seen[str(manifest/'manifest.json')],preparation=seen[str(manifest/'preparation.json')],report=dict(path=str(report),sha256=None,absent_observed_at=scope['created_at']),diagnostic='Saved traceback: final_runtime.py:140 provider identity lookup rejected by audit_io._scope as undeclared saved-evidence path. Exact raw stderr retained; no provider diagnosis claimed by this census.',observation_errors=[],may_be_live=False)
scope['scope']['independent_saved_audit_qualified']=False;scope['scope']['saved_audit12_failed']=True
scope['audit12_additions']=dict(files=len(additions),bytes=sum(seen[str(p)]['size'] for p in additions),execution_files=8,manifest_preparation_files=10,readback_and_source_files=len(additions)-18)
scope['publication_note']='Installation07 passed; the independent audit12 failed closed and produced no report. All downstream scopes remain false.'
assert scope['selected_files']<=scope['bounds']['source_files'] and scope['selected_bytes']<=scope['bounds']['source_bytes']
assert all(stamp(Path(p))==row['identity'] for p,row in seen.items())
out=A/'.work/runtime-installation07-publication-scope-03.json';data=(json.dumps(scope,sort_keys=True,indent=2)+'\n').encode()
with out.open('xb') as f:f.write(data)
print(json.dumps(dict(path=str(out),sha256=hashlib.sha256(data).hexdigest(),files=scope['selected_files'],bytes=scope['selected_bytes'],additions=scope['audit12_additions'])))
