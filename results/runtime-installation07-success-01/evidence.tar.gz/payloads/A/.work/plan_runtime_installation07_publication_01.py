"""Metadata/evidence-only finite publication selection; creates no capsule."""
import hashlib
import json
import os
from pathlib import Path
import stat
import time

ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
A=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
R=Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
SOURCE=ROOT/'experiments/runtime-installation-after-preflight05-03'
WORK=R/'.work/hir-options-hash-runtime-installation-07'
LAUNCH=R/'.work/hir-options-hash-runtime-installation-launch-execution-07'
OUTER=R/'.work/experiments/hir-options-hash-runtime-installation-supervisor-07'
PREP=R/'.work/hir-options-hash-runtime-installation-preparation-execution-07'
PACKET=SOURCE/'installation-plan-01'
PREFIX=R/'.work/runtime-compilers/f031d981666f450f760ccf303dccba986053ec6b9a143a60f3d26680f9ac7c70'
FIELDS=('dev','ino','mode','nlink','size','mtime_ns','ctime_ns')
seen={}

def stamp(path):
    s=path.lstat();return {k:getattr(s,'st_'+k) for k in FIELDS}

def read(path):
    assert path.resolve(strict=True)==path
    before=stamp(path);assert stat.S_ISREG(before['mode']) and before['nlink']==1 and before['size']<=16*2**20
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as f:
        assert {k:getattr(os.fstat(f.fileno()),'st_'+k) for k in FIELDS}==before
        data=f.read(16*2**20+1)
        assert {k:getattr(os.fstat(f.fileno()),'st_'+k) for k in FIELDS}==before
    assert stamp(path)==before and len(data)==before['size']
    row=dict(path=str(path),identity=before,size=len(data),sha256=hashlib.sha256(data).hexdigest())
    assert str(path) not in seen or seen[str(path)]==row
    seen[str(path)]=row;return data

def tree(root):
    found={};pending=[root]
    while pending:
        p=pending.pop();s=stamp(p);assert stat.S_ISREG(s['mode']) or stat.S_ISDIR(s['mode'])
        found['.' if p==root else str(p.relative_to(root))]=s
        if stat.S_ISDIR(s['mode']):pending.extend(sorted(p.iterdir(),reverse=True))
        assert len(found)<=400
    assert all(stamp(root/p)==s for p,s in found.items())
    return found

trees={str(root):tree(root) for root in (WORK,LAUNCH,OUTER,PREP,PACKET)}
paths={Path(root)/name for root,rows in trees.items() for name,row in rows.items() if stat.S_ISREG(row['mode'])}
tree_counts={root:dict(files=sum(stat.S_ISREG(s['mode']) for s in rows.values()),bytes=sum(s['size'] for s in rows.values() if stat.S_ISREG(s['mode']))) for root,rows in trees.items()}
assert sum(x['files'] for x in tree_counts.values())==304
assert sum(x['bytes'] for x in tree_counts.values())==16041810
paths.update(PREFIX/(name+'.json') for name in ('admission','ready','qualification'))
paths.update(A/'.work'/name for name in (
    'readback_runtime_installation07_closed_01.py','runtime-installation07-closed-independent-readback-01.json',
    'readback_runtime_installation07_preparation_01.py','readback_runtime_installation07_preparation_01.from-installation06.diff',
    'runtime-installation07-prepared-packet-independent-readback-01.json','runtime-installation07-launch-command-handoff-01.json'))
paths.add(ROOT/'.work/runtime-installation07-preparation-root-packet-review-01.json')
manifest=ROOT/'results/runtime-installation-controls-08/manifest.json';pub=json.loads(read(manifest))
assert seen[str(manifest)]['sha256']=='ff0d1d7b03c14e8093a2ddcae1aa0e1baf2c15fd18db58b5cdaceb74f3d1397e'
source_refs=[]
for row in pub['files']:
    path=Path(row['path'])
    if path.parent in (SOURCE,ROOT/'experiments/runtime-native-loader-probes-01') or path.name in (
        'bind_runtime_installation07_preparation_05.py','runtime-installation07-preparation-invocation-01.json',
        'runtime-installation07-preparation-source-binding-review-01.json','runtime-installation07-startup-qualified-source-manifest-01.json',
        'runtime-installation07-source-integration-handoff-01.json','runtime-installation07-source-development-independent-review-01.json'):
        current=read(path);assert seen[str(path)]['sha256']==row['sha256'] and len(current)==row['size']
        copy=ROOT/'results/runtime-installation-controls-08'/row['relative']
        assert read(copy)==current
        source_refs.append(dict(path=str(path),sha256=row['sha256'],size=row['size'],publication=str(copy.relative_to(ROOT)),commit='fd4b1b8728b1ac9113caa36e6a1fce5df3efde01',manifest_sha256=seen[str(manifest)]['sha256']))
assert len([r for r in source_refs if Path(r['path']).parent==SOURCE])==20
paths.add(manifest)
for p in sorted(paths):read(p)
catalog=json.loads(read(WORK/'source-snapshots.json'))
new={k:v for k,v in catalog['storage'].items() if v['kind']=='stored'}
reuse={k:v for k,v in catalog['storage'].items() if v['kind']=='reused'}
assert len(new)==230 and len(reuse)==302 and len(catalog['files'])==658
for key,value in new.items():
    p=Path(value['path']);assert p in paths and p.parent==WORK/'source-snapshots'
    assert seen[str(p)]['sha256']==catalog['blobs'][key]['sha256'] and seen[str(p)]['size']==catalog['blobs'][key]['compressed_bytes']
for value in reuse.values():assert Path(value['path']) not in paths
refs=json.loads(read(A/'.work/runtime-installation07-closed-independent-readback-01.json'))
assert refs['installation_itself_passed'] is True and refs['independent_saved_audit_qualified'] is False
current_files=[seen[str(p)] for p in sorted(paths)]
scope=dict(schema_version=1,status='source-plan-only-no-capsule-created',created_at=time.time(),
    output=str(ROOT/'results/runtime-installation07-success-01'),files=current_files,tree_counts=tree_counts,source_trees=trees,
    selected_files=len(current_files),selected_bytes=sum(row['size'] for row in current_files),
    published_source_references=source_refs,published_controls_manifest=seen[str(manifest)],
    completed_refs={k:refs[k] for k in ('launcher','outer','receipt','result','preparation','publication')},
    snapshot_retention=dict(catalog=seen[str(WORK/'source-snapshots.json')],logical_files=658,unique_blobs=532,new_copied_blobs=230,new_compressed_bytes=2004092,reused_external_blobs=302,reused_compressed_bytes=11513028,external_references='Exact saved catalog/reuse-selection/packet references retained unchanged; no external blob or provider payload copy.'),
    installed_prefix_metadata=dict(source=seen[str(A/'.work/runtime-installation07-closed-independent-readback-01.json')],entries=4654,installed_files=3708,scope='Previously verified current metadata, no payload hashes recomputed by this planning step.'),
    future_audit12=dict(included=False,report={'path':str(R/'.work/hir-options-hash-runtime-installation-independent-verification-07.json'),'sha256':None},execution={'path':str(ROOT/'.work/runtime12-saved-audit-installation-execution-01/record.json'),'sha256':None},gate='Require actual closed report/record, then review a fresh exact finite additive list before inclusion. No active audit outputs read.'),
    planned_format=dict(archive='evidence.tar.gz',gzip=dict(mtime=0,filename='',level=6),tar='PAX, sorted exact members, ordinary files mode0444, mtime0',readback='Full bounded gzip CRC/EOF, exact ordered tar membership, per-member SHA, original current stamps before/after.'),
    bounds=dict(source_files=384,source_bytes=32*2**20,single_file_bytes=16*2**20,expanded_tar_bytes=48*2**20,output_bytes=24*2**20),
    scope=dict(installation_itself_passed=True,independent_saved_audit_qualified=False,std_mir_prepared=False,exporter_qualified=False,application_qualified=False,performance_measurement=False),
    publication_execution=False,provider_payload_reads=False,compiler_commands=0,source_or_prefix_mutations=False,
    git_requirement='Parent must force-add exact finite capsule if needed and verify both Git index membership and every final HEAD blob against manifest; disk completeness alone is insufficient.',
    derivation={'path':str(ROOT/'results/runtime-installation06-failure-01/publication.py'),'sha256':hashlib.sha256(read(ROOT/'results/runtime-installation06-failure-01/publication.py')).hexdigest()})
assert scope['selected_files']<=scope['bounds']['source_files'] and scope['selected_bytes']<=scope['bounds']['source_bytes']
assert {str(root):tree(root) for root in (WORK,LAUNCH,OUTER,PREP,PACKET)}==trees
assert all(stamp(Path(p))==row['identity'] for p,row in seen.items())
out=A/'.work/runtime-installation07-publication-scope-01.json'
data=(json.dumps(scope,sort_keys=True,indent=2)+'\n').encode()
with out.open('xb') as f:f.write(data)
print(json.dumps(dict(path=str(out),sha256=hashlib.sha256(data).hexdigest(),files=scope['selected_files'],bytes=scope['selected_bytes'],published_refs=len(source_refs),tree_counts=tree_counts)))
