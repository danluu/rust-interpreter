#!/usr/bin/env python3
"""Run the fixed Python controls once under canonical owned supervision."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

OWNER = Path(__file__).resolve().parents[1]
WORK = OWNER / '.work/oxc-workflow-controls-03'
FROZEN = OWNER / '.work/oxc-workflow-controls-source-03/inputs.json'
PLAN = OWNER / 'experiments/oxc-plugin-normalization/controls-plan-03.json'
OWNED = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913/experiments/stable-cgu/owned_stage.py')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    path = Path(path)
    require(path.is_file() and path.resolve(strict=True) == path and not path.is_symlink(),
            'nonordinary control input: ' + str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--frozen-sha256', required=True)
    args = parser.parse_args()
    require(sha(FROZEN) == args.frozen_sha256, 'control freeze changed')
    frozen = json.loads(FROZEN.read_bytes())
    plan = json.loads(PLAN.read_bytes())
    require(frozen['owner'] == plan['owner'] == str(OWNER), 'foreign controls')
    def guard():
        require(sha(FROZEN) == args.frozen_sha256, 'control freeze changed')
        for path, expected in frozen['files'].items():
            require(sha(path) == expected, 'control input changed: ' + path)
        require(str(Path(sys.executable).resolve()) == frozen['python']['path'] and
                sha(frozen['python']['path']) == frozen['python']['sha256'], 'control Python changed')
    guard()
    spec = importlib.util.spec_from_file_location('oxc_owned_controls', OWNED)
    owned = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owned)
    require(not WORK.exists() and not WORK.is_symlink(), 'control work must be fresh')
    WORK.mkdir(parents=True)
    result = dict(status='waiting', owner=str(OWNER), pid=os.getpid(), parent_pid=os.getppid(),
                  started_at=time.time(), freeze_sha256=args.frozen_sha256, children=0,
                  native_execution=False, oxc_execution=False, benchmark=False)
    owned.write(WORK / 'summary.json', result)
    try:
        with owned.workload_lock(plan['canonical_lock'], plan['lock_wait_seconds']):
            result.update(status='running', admitted_at=time.time(), free_bytes_before=owned.disk(OWNER, 8))
            owned.write(WORK / 'summary.json', result)
            guard()
            require(sum(Path(p).stat().st_size for p in frozen['files']) < 16 * 2**20,
                    'control input retention exceeds budget')
            for path, expected in frozen['files'].items():
                payload = Path(path).read_bytes()
                destination = WORK / 'inputs' / path.lstrip('/')
                destination.parent.mkdir(parents=True, exist_ok=True)
                with destination.open('xb') as output:
                    output.write(payload)
                require(sha(destination) == expected, 'control input readback differs')
            child = owned.run(plan['command'], cwd=Path(plan['cwd']), env=frozen['environment'],
                              out=WORK / 'tests', capacity_root=OWNER)
            result['children'] = 1
            raw = (WORK / 'tests/stderr').read_text()
            require('\nRan 30 tests in ' in raw and raw.rstrip().endswith('\nOK'),
                    'controls did not report the complete unfiltered test set')
            require(' ... skipped ' not in raw, 'controls skipped a test')
            guard()
            result.update(status='passed', tests=30, child_pid=child['pid'],
                          free_bytes_after=owned.disk(OWNER, 8))
    except BaseException as error:
        result.update(status='failed', error=repr(error))
        raise
    finally:
        result['finished_at'] = time.time()
        owned.write(WORK / 'summary.json', result)


if __name__ == '__main__':
    main()
