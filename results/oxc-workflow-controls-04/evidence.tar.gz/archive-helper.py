import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results/oxc-workflow-controls-04'


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


def main():
    files = {}
    def add(name, path):
        path = Path(path)
        assert name not in files and path.resolve(strict=True) == path and path.is_file() and not path.is_symlink()
        payload = path.read_bytes()
        assert len(payload) <= 16 * 2**20
        files[name] = (path, payload)
    for attempt in ['03', '04']:
        work = ROOT / f'.work/oxc-workflow-controls-{attempt}'
        for path in sorted(work.rglob('*')):
            if path.is_file():
                add(f'attempt-{attempt}/run/' + str(path.relative_to(work)), path)
        outer = ROOT / f'.work/experiments/oxc-workflow-controls-supervisor-{attempt}'
        for path in sorted(outer.iterdir()):
            add(f'attempt-{attempt}/supervisor/' + path.name, path)
        for relative in [f'.work/run_oxc_workflow_controls_{attempt}.py',
                         f'.work/oxc-workflow-controls-source-{attempt}/inputs.json',
                         f'.work/oxc-workflow-controls-launch-{attempt}.json',
                         f'.work/oxc-workflow-controls-launch-record-{attempt}.json',
                         f'.work/oxc-workflow-controls-independent-verification-{attempt}.json']:
            add(f'attempt-{attempt}/execution/' + Path(relative).name, ROOT / relative)
    for attempt in ['01', '02']:
        for relative in [f'.work/run_oxc_workflow_controls_{attempt}.py',
                         f'.work/oxc-workflow-controls-source-{attempt}/inputs.json',
                         f'.work/oxc-workflow-controls-launch-{attempt}.json']:
            add(f'unrun-{attempt}/' + Path(relative).name, ROOT / relative)
    add('source-replay-check.json', ROOT / '.work/oxc-source-replay-check-01.json')
    add('archive-helper.py', Path(__file__).resolve())
    assert len(files) <= 256 and sum(len(payload) for _, payload in files.values()) <= 16 * 2**20
    manifest = {name: dict(source=str(path), bytes=len(payload), sha256=sha(payload))
                for name, (path, payload) in files.items()}
    OUT.mkdir(parents=True, exist_ok=False)
    with (OUT / 'evidence.tar.gz').open('xb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as archive:
                for name, (path, payload) in files.items():
                    assert path.read_bytes() == payload
                    info = tarfile.TarInfo(name)
                    info.size = len(payload)
                    info.mode = 0o644
                    archive.addfile(info, io.BytesIO(payload))
    with tarfile.open(OUT / 'evidence.tar.gz', 'r:gz') as archive:
        members = archive.getmembers()
        assert [m.name for m in members] == list(files)
        for member in members:
            assert member.isfile() and archive.extractfile(member).read() == files[member.name][1]
    with gzip.open(OUT / 'evidence.tar.gz', 'rb') as stream:
        while stream.read(1024**2):
            pass
    for path, payload in files.values():
        assert path.read_bytes() == payload
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    summary = dict(status='passed', tests=30, warning_free=True, earlier_passing_warning_retained=True,
        members=len(files), input_bytes=sum(len(payload) for _, payload in files.values()),
        archive_sha256=sha((OUT / 'evidence.tar.gz').read_bytes()),
        archive_bytes=(OUT / 'evidence.tar.gz').stat().st_size,
        manifest_sha256=sha((OUT / 'manifest.json').read_bytes()),
        native_execution=False, oxc_execution=False, benchmark=False)
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
