import gzip,hashlib,io,json,os,tarfile,time
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
sha=lambda b:hashlib.sha256(b).hexdigest()
with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('r+') as lock:
 acquire_lock(lock,600)
 py=root/'.work/mono-integration-python-tests-01';rs=root/'.work/mono-integration-rust-tests-01'
 p=json.loads((py/'summary.json').read_bytes());r=json.loads((rs/'summary.json').read_bytes())
 assert p['status']==r['status']=='passed' and p['reported_counts']==['111'] and r['test_totals']==dict(passed=490,failed=0,ignored=1)
 files=[]
 for directory in [py,rs]:
  files.extend(x for x in directory.iterdir() if x.is_file());files.extend(x for x in (directory/'sources').rglob('*') if x.is_file())
 for name in ['mono-integration-python-tests-supervisor-01','mono-integration-rust-tests-supervisor-01']:
  files.extend(x for x in (root/'.work/experiments'/name).iterdir() if x.is_file())
 for name in ['run-mono-python-tests-01.py','run-mono-rust-tests-01.py','archive-mono-source-tests-01.py']:files.append(root/'.work'/name)
 mapping={};buf=io.BytesIO()
 with tarfile.open(fileobj=buf,mode='w') as tar:
  for path in sorted(set(files)):
   data=path.read_bytes();name=str(path.relative_to(root));item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
   tar.addfile(item,io.BytesIO(data));mapping[name]=dict(bytes=len(data),sha256=sha(data))
 archive=gzip.compress(buf.getvalue(),mtime=0)
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
  assert set(tar.getnames())==set(mapping)
  for name,record in mapping.items():
   data=tar.extractfile(name).read();assert len(data)==record['bytes'] and sha(data)==record['sha256']
 out=root/'results/mono-production-integration-source-tests-01';out.mkdir(exist_ok=False)
 (out/'evidence.tar.gz').write_bytes(archive)
 summary=dict(schema_version=1,status='passed',source_revision=r['revision'],owner=str(root),created_at=time.time(),pid=os.getpid(),canonical_lock=str(Path(lock.name)),python_tests=111,rust_tests=r['test_totals'],custom_mono_compiler_tested=False,benchmark_commands=0,archive=dict(path='evidence.tar.gz',bytes=len(archive),sha256=sha(archive),members=len(mapping)),files=mapping)
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='files'}))
