import hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json,require_space
work=root/'.work/mono-integration-rust-tests-01';work.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=dict(owner=str(root),pid=os.getpid(),started_at=time.time(),status='waiting',benchmark_commands=0)
write_json(work/'summary.json',record)
with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('r+') as lock:
 acquire_lock(lock,600);require_space(root,8)
 record.update(lock_acquired_at=time.time(),canonical_lock=str(Path(lock.name)),revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip())
 names=subprocess.check_output(['git','ls-files','-z','--','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml'],cwd=root).decode().split('\0')
 files=[root/n for n in names if n]
 record['source_hashes']={str(p):sha(p) for p in files}
 for p in files:
  dest=work/'sources'/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
 env={k:v for k,v in os.environ.items() if not k.startswith('RUST_INTERP_')}
 command=['cargo','+nightly-2026-09-08','test','--workspace','--release','--locked','--offline','--jobs','2','--target-dir',str(work/'target')]
 record.update(command=command,environment_sha256=hashlib.sha256(json.dumps(env,sort_keys=True).encode()).hexdigest(),status='running');write_json(work/'summary.json',record)
 child,out,err=capture(command,cwd=root,env=env,receipt_path=work/'process.json',receipt={})
 (work/'stdout').write_text(out);(work/'stderr').write_text(err)
 totals=[list(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',out)]
 record.update(status='passed' if child.returncode==0 else 'failed',returncode=child.returncode,child_pid=child.pid,test_totals=dict(passed=sum(x[0] for x in totals),failed=sum(x[1] for x in totals),ignored=sum(x[2] for x in totals)),finished_at=time.time())
 assert all(sha(p)==record['source_hashes'][str(p)] for p in files)
 write_json(work/'summary.json',record);print(json.dumps({k:v for k,v in record.items() if k!='source_hashes'}));print(err);print(out)
 sys.exit(child.returncode)
