import hashlib,json,os,re,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json
work=root/'.work/mono-integration-python-tests-01';work.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=dict(owner=str(root),pid=os.getpid(),started_at=time.time(),status='waiting',benchmark_commands=0)
write_json(work/'summary.json',record)
with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('r+') as lock:
 acquire_lock(lock,600);record['lock_acquired_at']=time.time();record['canonical_lock']=str(Path(lock.name))
 files=sorted(set((root/'scripts').glob('*.py'))|set((root/'tests').glob('*.py'))|set((root/'benchmarks/experiments/strict-warm-build').glob('*.py')))
 record['source_hashes']={str(p):sha(p) for p in files}
 for p in files:
  dest=work/'sources'/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
 names=['test_custom_compiler','test_custom_compiler_launcher','test_stable_mono_cgu','test_std_mir_source_paths','test_standard_diagnostic_mapping','test_qualify_custom_compiler','test_mono_qualification','test_strict_warm_screen','test_strict_warm_cargo_screen','test_strict_warm_proc_macro_screen','test_strict_warm_mono_screen','test_host_proc_macro_launcher','test_owned_screen_assessment']
 command=[sys.executable,'-B','-m','unittest','-v',*names]
 env=dict(os.environ,PYTHONPATH=str(root/'tests'),PYTHONDONTWRITEBYTECODE='1')
 child,out,err=capture(command,cwd=root,env=env,receipt_path=work/'process.json',receipt={})
 (work/'stdout').write_text(out);(work/'stderr').write_text(err)
 record.update(status='passed' if child.returncode==0 else 'failed',returncode=child.returncode,child_pid=child.pid,command=command,reported_counts=re.findall(r'^Ran (\d+) tests? in [\d.]+s$',err,re.M),finished_at=time.time())
 assert all(sha(p)==record['source_hashes'][str(p)] for p in files)
 write_json(work/'summary.json',record);print(json.dumps({k:v for k,v in record.items() if k!='source_hashes'}));print(err)
 sys.exit(child.returncode)
