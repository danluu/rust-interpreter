import hashlib, json, os, tarfile, time, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import write_json
with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('r+') as lock:
    acquire_lock(lock, 600)
    out = root / 'results/mono-assessor-source-tests-01'
    out.mkdir(exist_ok=False)
    roots = [root / '.work/mono-assessor-tests-01',
             root / '.work/experiments/mono-assessor-tests-supervisor-01']
    files = {str(p.relative_to(root)): p for base in roots for p in base.rglob('*') if p.is_file()}
    files[str(Path(__file__).relative_to(root))] = Path(__file__)
    sha = lambda b: hashlib.sha256(b).hexdigest()
    manifest = {name: dict(bytes=p.stat().st_size, sha256=sha(p.read_bytes())) for name,p in files.items()}
    archive = out / 'evidence.tar.gz'
    with tarfile.open(archive, 'x:gz') as writer:
        for name, path in sorted(files.items()):
            assert path.is_file() and not path.is_symlink()
            writer.add(path, arcname=name, recursive=False)
    with tarfile.open(archive, 'r:gz') as reader:
        assert set(reader.getnames()) == set(manifest)
        for member in reader.getmembers():
            payload = reader.extractfile(member).read()
            assert manifest[member.name] == dict(bytes=len(payload), sha256=sha(payload))
    summary = json.loads((roots[0] / 'summary.json').read_text())
    assert summary['status'] == 'passed' and summary['reported_counts'] == ['119']
    write_json(out / 'manifest.json', manifest)
    write_json(out / 'summary.json', dict(source_revision=summary['revision'], status='passed',
        tests=119, reported_test_seconds=4.351, compiler_or_benchmark_commands=0,
        supervisor_pid=15006, helper_pid=15009, child_pid=15012,
        archive=dict(path='evidence.tar.gz', bytes=archive.stat().st_size,
                     sha256=sha(archive.read_bytes()), members=len(manifest)),
        archive_verification=dict(pid=os.getpid(), lock=str(Path(lock.name)), finished_at=time.time())))
    (out / 'README.md').write_text('''# MonoItem assessment source tests

All 119 Python tests passed at source `14e82016b5aac1c2e9beed5b0c4d3783947ac875`
(4.351 seconds reported by unittest). The selection covers the existing compiler,
launcher, std-source, strict-screen and saved-assessor contracts, plus saved v2
evidence validation and actual bytecode binding for original/edit/restoration.
No compiler build or benchmark was run by these tests.

The archive retains exact Python sources, child output and completion receipt,
the external supervisor, and its own packager. Every archived member was checked
against the manifest under the shared canonical workload lock. Real compiler
and source-observable qualification remains required before MonoItem timing.
''')
    print(json.dumps(dict(archive=str(archive), members=len(manifest), bytes=archive.stat().st_size)))
