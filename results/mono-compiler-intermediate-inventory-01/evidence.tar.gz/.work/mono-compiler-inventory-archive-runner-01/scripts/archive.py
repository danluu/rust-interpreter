"""Archive completed compiler-intermediate inspection only; never delete files."""
import gzip,hashlib,io,json,os,shutil,sys,tarfile,time
from pathlib import Path
from compare_saved_runtime import acquire_lock
from workflow_io import write_json
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
RUNNER=Path(__file__).resolve().parents[1]
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
WORK=ROOT/'.work/mono-compiler-intermediate-inventory-archive-01'
OUTPUT=ROOT/'results/mono-compiler-intermediate-inventory-01'
WORK.mkdir(exist_ok=False)
record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,builds=0,benchmarks=0,deletions=0)
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_bytes())
write_json(WORK/'summary.json',record)
try:
 with LOCK.open('r+') as lock:
  acquire_lock(lock,600);assert shutil.disk_usage(ROOT).free>=8*1024**3
  record.update(status='archiving',admitted_at=time.time());write_json(WORK/'summary.json',record)
  failed=ROOT/'.work/mono-compiler-intermediate-inventory-01'
  passed=ROOT/'.work/mono-compiler-intermediate-inventory-02'
  first=read(failed/'summary.json');last=read(passed/'summary.json')
  assert first['status']=='failed' and first['deleted']==[] and last['status']=='passed' and last['deleted']==[]
  assert sha((passed/'summary.json').read_bytes())=='a52e05c65c2d0063d158a7fcb042607a45e925c7dd8c52160f4cf0ab09105002'
  assert last['proposed_files']==404 and last['eligible_files']==258 and last['excluded_files']==146 and last['eligible_allocated_bytes']==3484483584
  for name,h in last['proof_files'].items():assert sha((passed/name).read_bytes())==h
  for name,item in read(passed/'proof-manifest.json').items():
   blob=passed/'proof-bytes'/item['sha256'];data=blob.read_bytes();assert sha(data)==item['sha256'] and len(data)==item['bytes']
  proposal=ROOT/'.work/mono-compiler-intermediate-proposal-01.json'
  assert sha(proposal.read_bytes())==last['proposal_sha256']=='99c6189c99656c9f97b68d88f07d7ab91886104209ebf454d51649ac89f16be1'
  assert not (ROOT/'.work/mono-compiler-intermediate-retirement-01').exists(),'compiler retirement unexpectedly executed'
  paths={proposal,Path(__file__),RUNNER/'scripts/workflow_io.py',RUNNER/'scripts/supervise_experiment.py',RUNNER/'scripts/compare_saved_runtime.py'}
  directories=[failed,passed]
  for index in ['01','02']:
   runner=ROOT/('.work/mono-compiler-intermediate-inventory-runner-'+index)
   supervisor=runner/'.work/experiments'/('inventory-supervisor-'+index)
   status=read(supervisor/'status.json');assert status['status']=='finished' and status['returncode']==(1 if index=='01' else 0)
   assert sha((supervisor/'plan.json').read_bytes())==status['plan_sha256'] and sha((supervisor/'command.log').read_bytes())==status['log_sha256']
   directories.extend([runner/'scripts',supervisor])
  directories.append(ROOT/'.work/mono-compiler-intermediate-retirement-runner-01/scripts')
  for directory in directories:
   for p in directory.rglob('*'):
    assert not p.is_symlink()
    if p.is_file() and '__pycache__' not in p.parts:paths.add(p)
  files={str(path.relative_to(ROOT)):path.read_bytes() for path in sorted(paths)}
  manifest={name:dict(bytes=len(data),sha256=sha(data)) for name,data in files.items()}
  assert shutil.disk_usage(ROOT).free-sum(map(len,files.values()))>=8*1024**3
  OUTPUT.mkdir(exist_ok=False)
  with (OUTPUT/'evidence.tar.gz').open('xb') as raw:
   with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as tar:
     for name,data in files.items():
      member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o444;member.mtime=0;tar.addfile(member,io.BytesIO(data))
  seen=set()
  with tarfile.open(OUTPUT/'evidence.tar.gz','r:gz') as tar:
   for member in tar:
    assert member.isfile() and member.name not in seen and member.name in manifest
    data=tar.extractfile(member).read();assert len(data)==manifest[member.name]['bytes'] and sha(data)==manifest[member.name]['sha256'];seen.add(member.name)
  assert seen==set(manifest)
  archive=dict(path='evidence.tar.gz',bytes=(OUTPUT/'evidence.tar.gz').stat().st_size,sha256=sha((OUTPUT/'evidence.tar.gz').read_bytes()),members=len(manifest),all_member_hashes_verified=True,gzip_mtime=0)
  summary=dict(schema_version=1,status='passed',kind='compiler intermediate inspection only',attempts=[dict(status=first['status'],pid=first['pid'],error=first['error']),dict(status=last['status'],pid=last['pid'])],source_commit='58e1e1f5311f4424ea81def4763081f6da62d9b3',proposed_files=404,eligible_files=258,excluded_files=146,exclusions=last['exclusions'],eligible_allocated_bytes=last['eligible_allocated_bytes'],preserved_dependencies=last['preserved_dependencies'],actual_compiler_files_deleted=0,retirement_script_status='prepared, paused, never executed',allocation_limit=last['allocation_limit'],archive=archive,packager_sha256=sha(Path(__file__).read_bytes()),finished_at=time.time())
  write_json(OUTPUT/'manifest.json',manifest);write_json(OUTPUT/'summary.json',summary)
  (OUTPUT/'README.md').write_text('# Compiler intermediate inspection\\n\\n'
   'No compiler file was deleted. The exact404 proposed rlib/rmeta paths came from the completed Cmono twelve-stage receipts and actual stage1/stage2/option-hash compiler commands. '
   'Attempt01 stopped before candidate hashing because its preservation-root parser omitted the recorded dist image roots; attempt02 corrected that bounded parser and passed.\\n\\n'
   'All404 files were hashed.258 ordinary files had3,484,483,584 allocated bytes by unique inode;73 were excluded for outside hardlinks and73 for preserved dependency inode overlap. '
   'All63,448 preserved dependency identities remained unchanged, and fresh ps/lsof checks found no users. Raw global process tables stayed in memory. '
   'Allocated blocks do not guarantee reclaimable APFS space.\\n\\n'
   'A retirement script was prepared but paused before execution. The campaign instead retired the independently reviewed completed Mono screen02 targets. '
   'The archive contains both inspection attempts, exact source helpers/proposals/receipts/guard manifests and the unexecuted script, with every member hash verified. '
   'Compiled binaries and artifact payloads are excluded. This record makes no performance claim.\\n'.replace('\\n','\n'))
  record.update(status='passed',finished_at=time.time(),output=str(OUTPUT),archive=archive);write_json(WORK/'summary.json',record);print(json.dumps(record))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());write_json(WORK/'summary.json',record);raise
