#!/usr/bin/env python3
"""Archive completed12 controls and five planning guards, never rerun workloads."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
OWNER = Path('/Users/danluu/dev/rust-interp-hir-arena-native-20260913')
CONTROLS = OWNER / '.work/hir-arena-native-controls-01'
PLAN_STAGE = OWNER / '.work/hir-arena-native-01/stages/plan-01'
PLAN = OWNER / 'experiments/hir-arena-native/planned-native-01.json'
PLAN_SHA = 'c30a65cfb2c00ce67bdbea27df460f248a3f9b4ae324333a590b1aaea5301819'
CONTROL_SHA = '67df7aa862052d82bf048f2b793b5776cff3872711838f52366f28061bdc875d'
PLAN_RECEIPT_SHA = 'ac7c77e94e0e5d7ad53a605248f4529d1230b353579ef8876973abf0a4eb0a14'
WORK = ROOT / '.work/hir-arena-native-controls-plan-archive-01'
OUT = ROOT / 'results/hir-arena-native-controls-plan-01'
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    WORK.mkdir(parents=True, exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
                  canonical_lock=str(CANONICAL_LOCK), lock_wait_seconds=600)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            payloads, excluded, verified = {}, {}, []

            def capture(path, expected=None):
                path = Path(path)
                require(path.is_absolute() and path.is_file() and not path.is_symlink()
                        and path.resolve(strict=True) == path, 'nonordinary archive input')
                data = path.read_bytes()
                require(expected is None or digest(data) == expected, 'changed archive input: ' + str(path))
                require(str(path) not in payloads or payloads[str(path)] == data, 'changed capture bytes')
                payloads[str(path)] = data
                return data

            plan = json.loads(capture(PLAN, PLAN_SHA))
            require(plan['owner'] == str(OWNER) and plan['previous']['source']['revision'] ==
                    '7efc0d9484da82cd327deb3b48616f8ec81eaf8d' and len(plan['required_units']) == 27
                    and len(plan['inputs']) == 47 and len(plan['configurations']) == 34
                    and not any(plan['configurations'].values()), 'reviewed native plan changed')
            refs = [dict(paths=plan['archive_paths'], hashes=plan['archive_hashes'], required=plan['archive_required']),
                    *plan['previous']['historical_archives']]
            counts = [334, 322, 250, 324, 203, 314, 318]
            require(len(refs) == len(counts), 'seven complete archive proofs required')
            for ref, count in zip(refs, counts, strict=True):
                paths, hashes = ref['paths'], ref['hashes']
                archive = Path(paths['archive'])
                require(archive.is_file() and not archive.is_symlink() and archive.resolve(strict=True) == archive
                        and sha(archive) == hashes[str(archive)], 'referenced archive changed')
                manifest = json.loads(capture(paths['manifest'], hashes[paths['manifest']]))
                summary = json.loads(capture(paths['summary'], hashes[paths['summary']]))
                require(summary['archive']['sha256'] == hashes[str(archive)] and len(manifest) == count,
                        'referenced archive summary changed')
                pending, seen = dict(ref['required']), set()
                with tarfile.open(archive, 'r:gz') as tar:
                    for member in tar:
                        disk(ROOT)
                        require(member.isfile() and member.name not in seen and member.name in manifest,
                                'unexpected prior archive member')
                        item = manifest[member.name]; data = tar.extractfile(member).read(); source = item['source']
                        require(member.name == source.lstrip('/') and Path(source).is_absolute()
                                and '..' not in Path(member.name).parts and len(data) == item['bytes']
                                and digest(data) == item['sha256'], 'prior archive source or bytes changed')
                        if source in pending:
                            require(pending.pop(source) == item['sha256'], 'prior required source changed')
                        seen.add(member.name)
                require(not pending and seen == set(manifest), 'incomplete prior archive')
                excluded[str(archive)] = hashes[str(archive)]
                verified.append(dict(ref, members=count, all_member_hashes_verified=True, payload_not_duplicated=True))

            controls = json.loads(capture(CONTROLS / 'summary.json', CONTROL_SHA))
            require(controls['status'] == 'passed' and controls['expected_controls'] == 12
                    and controls['source_revision'] == 'd4064e811c7413c3584ecad2068a903f3c57c3cb'
                    and controls['all_inputs_unchanged'] and len(controls['inputs']) == 57
                    and len(controls['snapshots']) == 57 and len(controls['required_tests']) == 12,
                    'completed12 controls/source guards changed')
            require(all(controls['inputs'].get(p) == h for p, h in plan['inputs'].items()),
                    'plan inputs differ from actual passing test bytes')
            snapshot_count, archive_count = 0, 0
            for path, expected in controls['inputs'].items():
                snapshot = controls['snapshots'][path]
                require(snapshot['sha256'] == expected, 'snapshot identity changed')
                if path in excluded:
                    require(snapshot['archive_reference'] and excluded[path] == expected, 'archive input differs')
                    archive_count += 1
                else:
                    data = capture(path, expected)
                    require(capture(snapshot['path'], expected) == data and len(data) == snapshot['bytes'],
                            'original passing snapshot differs')
                    snapshot_count += 1
            require((snapshot_count, archive_count) == (52, 5), 'control snapshot scope changed')
            child = json.loads(capture(CONTROLS / 'command/receipt.json', controls['command_receipt_sha256']))
            require(child['status'] == 'finished' and child['returncode'] == 0 and child['cwd'] == str(OWNER)
                    and child['command'][1:] == ['-B', '-m', 'unittest', '-v',
                                                 'test_hir_arena_native', 'test_hir_native_correctness']
                    and child['environment']['PYTHONPATH'] == str(OWNER / 'tests')
                    and child['environment']['PYTHONDONTWRITEBYTECODE'] == '1', 'actual control route changed')
            stderr = capture(CONTROLS / 'command/stderr', child['stderr_sha256']).decode()
            capture(CONTROLS / 'command/stdout', child['stdout_sha256'])
            actual = re.findall(r'^test_[^\n]* \(([^)]+)\) \.\.\. ok$', stderr, re.M)
            require(sorted(actual) == controls['required_tests'] == sorted(controls['actual_tests'])
                    and len(actual) == 12 and re.search(r'^Ran 12 tests in [0-9.]+s$', stderr, re.M)
                    and stderr.rstrip().endswith('OK'), 'exact12 passes without skips required')

            stage = json.loads(capture(PLAN_STAGE / 'receipt.json', PLAN_RECEIPT_SHA))
            require(stage['status'] == 'passed' and stage['stage'] == 'plan' and stage['owner'] == str(OWNER)
                    and stage['plan_sha256'] == PLAN_SHA and len(stage['commands']) == 5,
                    'successful five-command plan changed')
            source = Path(plan['source'])
            expected_commands = [['git', 'rev-parse', 'HEAD'], ['git', 'diff', 'HEAD', '--'],
                                 ['git', 'ls-files', '--stage', '-z'], ['git', 'rev-parse', 'HEAD'],
                                 ['git', 'ls-files', '--stage', '-z']]
            for i, ref in enumerate(stage['commands']):
                path = Path(ref['path'])
                require(path == PLAN_STAGE / 'commands' / f'{i:03d}' / 'receipt.json', 'unexpected planning child')
                row = json.loads(capture(path, ref['sha256']))
                require(row['status'] == 'finished' and row['returncode'] == 0
                        and row['command'] == ref['command'] == expected_commands[i]
                        and row['cwd'] == str(source if i < 3 else source / 'library/backtrace')
                        and row['environment'] == plan['previous']['old_plan']['environment'],
                        'planning command/route/environment changed')
                for stream in ['stdout', 'stderr']: capture(path.parent / stream, row[stream + '_sha256'])
            for label, row in [('controls', controls), ('plan', stage)]:
                outer = OWNER / '.work/experiments' / ('hir-arena-native-' + label + '-supervisor-01')
                status = json.loads(capture(outer / 'status.json'))
                require(status['status'] == 'finished' and status['returncode'] == 0
                        and status['child_pid'] == row['pid'] and status['supervisor_pid'] == row['parent_pid'],
                        'completed supervisor association changed')
                capture(outer / 'plan.json', status['plan_sha256'])
                capture(outer / 'command.log', status['log_sha256'])
                capture(outer / 'supervisor.log')
            for path in [Path(__file__), ROOT / 'experiments/stable-cgu/owned_stage.py',
                         ROOT / 'scripts/supervise_experiment.py']: capture(path)

            OUT.mkdir(parents=True, exist_ok=False)
            target = OUT / 'evidence.tar.gz'; manifest = {}
            with target.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for source, data in sorted(payloads.items()):
                            disk(ROOT)
                            name = source.lstrip('/'); member = tarfile.TarInfo(name)
                            member.size = len(data); member.mode = 0o444
                            tar.addfile(member, io.BytesIO(data))
                            manifest[name] = dict(source=source, bytes=len(data), sha256=digest(data))
            seen = set()
            with tarfile.open(target, 'r:gz') as tar:
                for member in tar:
                    require(member.isfile() and member.name not in seen and member.name in manifest,
                            'invalid new archive member')
                    item = manifest[member.name]; data = tar.extractfile(member).read()
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback changed')
                    seen.add(member.name)
            require(seen == set(manifest) and all(Path(p).read_bytes() == b for p, b in payloads.items())
                    and all(sha(p) == h for p, h in excluded.items()), 'final archive/input guard failed')
            write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed controls and metadata plan archived', owner=str(OWNER),
                source_commit='d4064e811c7413c3584ecad2068a903f3c57c3cb', plan_commit='91cfdfc1859e6add12fcda10fd97bd781bb28ef9',
                plan=dict(path=str(PLAN), sha256=PLAN_SHA), controls=12, skipped=0,
                test_pid=child['pid'], control_helper_pid=controls['pid'], control_supervisor_pid=controls['parent_pid'],
                plan_helper_pid=stage['pid'], plan_supervisor_pid=stage['parent_pid'], plan_commands=5,
                test_source_inputs=57, copied_test_snapshots=52, test_archive_references=5,
                compiler_source_revision=plan['previous']['source']['revision'], required_compiler_units=27,
                control_summary_sha256=CONTROL_SHA, plan_receipt_sha256=PLAN_RECEIPT_SHA,
                historical_archives=verified, native_qualification_claim=False, performance_claim=False,
                archive=dict(path=target.name, sha256=sha(target), bytes=target.stat().st_size,
                    members=len(manifest), all_member_hashes_verified=True, gzip_mtime=0),
                manifest_sha256=sha(OUT / 'manifest.json'))
            write(OUT / 'summary.json', summary)
            (OUT / 'README.md').write_text(
                '# Arena native driver controls and plan\n\n'
                'All12 Python controls passed with no skips at d4064e81. The independently reviewed '
                'native plan c30a65cf then passed all five source guards. The archive retains exact '
                'raw outputs, environments, child/outer receipts, 57 frozen input associations and '
                '52 copied source snapshots. The five archive inputs and all seven current/historical '
                'archives were verified in full and referenced without nesting their tar payloads.\n\n'
                'The plan binds actual compiler source7efc and its passed27 units, full native '
                'build/option/run-make commands, three probes and original capacity/bootstrap policy. '
                'These controls and planning commands do not establish native cache-hit qualification '
                'or a performance result. The separate native history is outside this archive. '
                'All new archive members and original inputs were checked after packaging.\n')
            record.update(status='passed', finished_at=time.time(), free_bytes_after=disk(ROOT), result=str(OUT),
                archive=summary['archive'], summary_sha256=sha(OUT / 'summary.json'))
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', error=repr(error), finished_at=time.time())
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__': main()
