#!/usr/bin/env python3
"""Archive saved public build03 and failed worker qualification01, without caches."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
import tarfile
import time

PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
WORKER = Path('/Users/danluu/dev/rust-interp-frontend-worker-publication-20260913')
BUILD = WORKER / '.work/frontend-worker-build-03'
QUAL = PRIMARY / '.work/frontend-worker-qualification-01'
TESTS = PRIMARY / '.work/worker-prerequisite-tests-02'
SOURCE_PREP = PRIMARY / '.work/strict-warm-build/worker-screen-source-setup-01'
OUT = PRIMARY / 'results/frontend-worker-build03-qualification01'
RUN = Path(__file__).resolve().parent
KEY = '7191cec48448ea59dd85f330a417074d07390e6a1b1bf4f33f75c8a8a1172c02'
sys.path.insert(0, '/Users/danluu/dev/rust-interp-stable-mono-compiler-build-20260913/experiments/stable-cgu')
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write


def read(path):
    return json.loads(Path(path).read_bytes())


def main():
    receipt = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
        lock=str(CANONICAL_LOCK), lock_wait_seconds=1800, action='archive immutable completed worker history',
        runner_sha256=sha(__file__), builds=0, tests=0, benchmarks=0)
    require(not (RUN / 'receipt.json').exists(), 'archive attempt already exists')
    write(RUN / 'receipt.json', receipt)
    try:
        with workload_lock(CANONICAL_LOCK, 1800):
            receipt.update(status='admitted', admitted_at=time.time(), free_bytes_before=disk(PRIMARY))
            write(RUN / 'receipt.json', receipt)
            require(not OUT.exists(), 'archive destination already exists')
            sources, members = {}, {}

            def add(name, path, expected=None):
                path = Path(path)
                require(name not in sources and path.is_file() and not path.is_symlink(), 'invalid archive member')
                actual = sha(path)
                require(expected is None or actual == expected, 'saved bytes differ: ' + str(path))
                sources[name] = path
                members[name] = dict(source=str(path), bytes=path.stat().st_size, sha256=actual)

            def tree(label, root):
                for path in sorted(root.rglob('*')):
                    require(not path.is_symlink(), 'linked evidence file')
                    if path.is_file():
                        add(label + '/' + str(path.relative_to(root)), path)

            result, composition = read(BUILD / 'result.json'), read(BUILD / 'composition.json')
            require(result['status'] == 'public-build-published-worker-qualification-pending'
                    and result['tool_key'] == KEY and result['commands'] == 8, 'public build outcome differs')
            require(hashlib.sha256(json.dumps(composition, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == KEY
                    and composition['qualification_policy'] == 'frontend-workers-public-build-v1', 'public build key/policy differs')
            # Top-level receipts/logs only; never recurse into the build target.
            for path in sorted(BUILD.iterdir()):
                if path.is_file():
                    require(path.suffix in ['.json', '.stdout', '.stderr'], 'unexpected build evidence kind')
                    add('build03/' + path.name, path)
            tree('build03/metadata', BUILD / 'metadata')
            for name, expected in composition['payloads'].items():
                require(name.startswith('provenance/') and '..' not in Path(name).parts, 'payload escapes proof directory')
                add('build03/payload/' + name, BUILD / 'payload' / name, expected)
            commands = read(BUILD / 'payload/provenance/commands.json')
            require(len(commands) == 8, 'public build command history differs')
            for row in commands:
                child = read(BUILD / 'payload' / row['receipt'])
                require(child['status'] == 'finished' and child['returncode'] == 0
                        and child['command'] == row['argv'], 'public build child failed or differs')
            published = read(BUILD / 'published.json')
            require(published['tool_key'] == KEY and len(published['installations']) == 2, 'publication copies differ')
            for index, item in enumerate(published['installations']):
                directory = Path(item['directory'])
                require(item['owner'] in [str(PRIMARY), str(WORKER)] and
                    directory == Path(item['owner']) / '.work/interpreter-tools' / KEY, 'publication prefix differs')
                require(sha(directory / 'publication.json') == item['publication_sha256'], 'publication proof changed')
                require(read(directory / 'source.json')['composition'] == composition
                        and read(directory / 'ready.json') == composition['binaries'], 'installed manifests differ')
                for name in ['source.json', 'ready.json', 'capabilities.json', 'publication.json', 'publication-guard.json']:
                    add(f'publication/{index}/' + name, directory / name)

            plan = read(QUAL / 'plan.json')
            require(plan['tool_key'] == KEY and read(QUAL / 'admission.json')['status'] == 'failed'
                    and read(QUAL / 'failure.json')['status'] == 'failed' and not (QUAL / 'result.json').exists(),
                    'expected failed qualification without a passing receipt')
            for name in ['plan.json', 'admission.json', 'failure.json', 'public-before.json', 'diagnostic.rs']:
                add('qualification01/' + name, QUAL / name)
            for name in ['logs', 'artifacts', 'fixture']:
                tree('qualification01/' + name, QUAL / name)
            logs = []
            for path in sorted((QUAL / 'logs').glob('*-process.json')):
                child, row = read(path), read(path.with_name(path.name.replace('-process.json', '.json')))
                require(child['status'] == 'finished' and child['returncode'] == row['returncode']
                        and child['command'] == row['command'] and child['label'] == row['label'],
                        'qualification child/row differs')
                logs.append((child['started_at'], row))
            require(len(logs) == 27, 'failed qualification command count differs')
            last = sorted(logs, key=lambda item: item[0])[-1][1]
            require(last['label'] == 'assembly-rejection-1' and last['returncode'] == 101 and last['stdout'] == ''
                    and 'assembly: unsupported terminator asm!' in last['stderr'], 'assembly failure diagnosis differs')
            tests = read(TESTS / 'summary.json')
            require(tests['status'] == 'passed' and tests['expected_tests'] == 159
                    and tests['sources_unchanged'] is True, 'old frozen-source test snapshot is not complete')
            add('source-snapshot-origin/test-summary.json', TESTS / 'summary.json')
            frozen_proofs = {}
            for name, expected in plan['frozen'].items():
                path = Path(name)
                require(path.is_relative_to(PRIMARY), 'unexpected old qualifier source root')
                relative = path.relative_to(PRIMARY)
                options = [BUILD / 'payload/provenance/source' / relative,
                           BUILD / 'payload/provenance/harness' / relative]
                if tests['source_hashes'].get(name) == expected:
                    options.append(TESTS / 'sources' / relative)
                selected = next((p for p in options if p.is_file() and not p.is_symlink() and sha(p) == expected), None)
                require(selected is not None, 'old frozen source snapshot is missing: ' + str(relative))
                add('qualification-frozen-source/' + str(relative), selected, expected)
                frozen_proofs[name] = dict(snapshot=str(selected), sha256=expected)
            write(RUN / 'frozen-source-proof.json', frozen_proofs)
            add('qualification01/frozen-source-proof.json', RUN / 'frozen-source-proof.json')
            qualifier = sources['qualification-frozen-source/experiments/frontend-workers/qualify.py'].read_text()
            require('"InlineAsm"' in qualifier or "'InlineAsm'" in qualifier, 'saved qualifier no longer has the diagnosed old expectation')

            prep = read(SOURCE_PREP / 'summary.json')
            require(prep['status'] == 'passed' and prep['benchmark_commands'] == 0
                    and prep['plan_sha256'] == composition['build']['plan_sha256'], 'source preparation plan/outcome differs')
            tree('source-preparation01', SOURCE_PREP)
            add('source-preparation01/runner.py', PRIMARY / '.work/prepare-worker-screen-source-01.py')
            for owner, name, code in [(WORKER, 'frontend-worker-build-supervisor-03', 0),
                (WORKER, 'frontend-worker-qualification-supervisor-01', 1),
                (PRIMARY, 'worker-screen-source-supervisor-01', 0)]:
                directory = owner / '.work/experiments' / name
                supervisor = read(directory / 'status.json')
                require(supervisor['status'] == 'finished' and supervisor['returncode'] == code
                        and sha(directory / 'command.log') == supervisor['log_sha256']
                        and sha(directory / 'plan.json') == supervisor['plan_sha256'], 'outer supervisor proof differs')
                for filename in ['status.json', 'plan.json', 'command.log', 'supervisor.log']:
                    add('supervisors/' + name + '/' + filename, directory / filename)
            add('packaging/archive_worker_history.py', __file__)
            OUT.mkdir()
            archive_path = OUT / 'evidence.tar.gz'
            with archive_path.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0) as zipped:
                with tarfile.open(fileobj=zipped, mode='w') as archive:
                    for name, path in sorted(sources.items()):
                        info = archive.gettarinfo(str(path), arcname=name)
                        info.uid = info.gid = info.mtime = 0
                        info.uname = info.gname = ''
                        with path.open('rb') as stream:
                            archive.addfile(info, stream)
            with tarfile.open(archive_path, 'r:gz') as archive:
                require(archive.getnames() == sorted(sources), 'archive member list differs')
                for item in archive:
                    data = archive.extractfile(item)
                    checksum = hashlib.sha256()
                    for block in iter(lambda: data.read(1024 * 1024), b''):
                        checksum.update(block)
                    require(checksum.hexdigest() == members[item.name]['sha256'], 'archived bytes differ')
            require(all(sha(sources[name]) == item['sha256'] for name, item in members.items()), 'saved evidence changed during archival')
            write(OUT / 'members.json', members)
            summary = dict(status='archived-successful-build-and-failed-qualification', tool_key=KEY,
                build_status=result['status'], build_commands=8, qualification_status='failed', qualification_commands=27,
                worker_30_qualified=False, screen_executed=False, performance_claim=False,
                source_preparation='passed independent pinned Git clone', frozen_source_files=len(frozen_proofs),
                current_root_source_substituted=False, native_binaries_targets_caches_archived=False,
                failure=dict(label=last['label'], returncode=101, guest_stdout_bytes=0,
                             actual='assembly: unsupported terminator asm!', stale_expected='InlineAsm'),
                archive=dict(path='evidence.tar.gz', bytes=archive_path.stat().st_size, sha256=sha(archive_path),
                             members=len(members), uncompressed_bytes=sum(item['bytes'] for item in members.values())))
            write(OUT / 'summary.json', summary)
            receipt.update(status='passed', finished_at=time.time(), free_bytes_after=disk(PRIMARY),
                archive_sha256=summary['archive']['sha256'], members=len(members), summary_sha256=sha(OUT / 'summary.json'))
            write(RUN / 'receipt.json', receipt)
            write(OUT / 'packaging-receipt.json', receipt)
            print(json.dumps(receipt))
    except BaseException as error:
        receipt.update(status='failed', finished_at=time.time(), error=repr(error))
        write(RUN / 'receipt.json', receipt)
        raise


if __name__ == '__main__':
    main()
