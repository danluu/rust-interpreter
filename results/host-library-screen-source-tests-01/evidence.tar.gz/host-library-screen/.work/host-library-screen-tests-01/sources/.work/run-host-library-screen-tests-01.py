import hashlib, json, os, re, subprocess, sys, time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture, write_json

work = root / '.work/host-library-screen-tests-01'
work.mkdir(exist_ok=False)
lock_path = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
names = ['test_qualified_public_tools', 'test_public_tool_publication', 'test_frontend_worker_publication', 'test_host_library_publication', 'test_host_library_screen', 'test_owned_host_library_screen', 'test_strict_warm_screen', 'test_strict_warm_cargo_screen', 'test_strict_warm_proc_macro_screen', 'test_strict_warm_mono_screen', 'test_frontend_worker_screen', 'test_owned_screen_assessment', 'test_owned_mono_screen_assessment']
record = dict(owner=str(root), pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
              status='waiting', canonical_lock=str(lock_path), lock_wait_seconds=1800,
              expected_tests=84, suites=names, rust_builds=0, benchmarks=0)
write_json(work / 'summary.json', record)
try:
    with lock_path.open('r+') as lock:
        acquire_lock(lock, 1800)
        record.update(status='running', lock_acquired_at=time.time(),
                      revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip())
        files = sorted(set((root / 'scripts').glob('*.py')) | set((root / 'tests').glob('*.py'))
                       | set((root / 'benchmarks/experiments/strict-warm-build').glob('*.py'))
                       | {root / 'experiments/stable-cgu/owned_stage.py',
                          root / 'benchmarks/experiments/host-proc-macro/build.py', root / 'docs/HOST-LIBRARY-OPT.md', Path(__file__)}
                       | {p for p in (root / 'experiments/host-library-opt').rglob('*')
                          if p.is_file() and p.suffix in ['.py', '.md', '.rs', '.toml', '.lock']})
        record['source_hashes'] = {}
        for p in files:
            if p.is_symlink():raise RuntimeError('source snapshot contains a symlink: ' + str(p))
            data = p.read_bytes()
            record['source_hashes'][str(p)] = hashlib.sha256(data).hexdigest()
            dest = work / 'sources' / p.relative_to(root)
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        write_json(work / 'summary.json', record)
        command = [sys.executable, '-B', '-m', 'unittest', '-v', *names]
        env = dict(os.environ, PYTHONPATH=str(root / 'tests'), PYTHONDONTWRITEBYTECODE='1')
        child, out, err = capture(command, cwd=root, env=env, receipt_path=work / 'process.json',
                                  receipt=dict(expected_tests=84, suites=names))
        (work / 'stdout').write_text(out)
        (work / 'stderr').write_text(err)
        counts = re.findall(r'^Ran (\d+) tests? in [\d.]+s$', err, re.M)
        complete = child.returncode == 0 and counts == ['84'] and re.search(r'^OK$', err, re.M) is not None
        unchanged = all(sha(p) == record['source_hashes'][str(p)] for p in files)
        record.update(status='passed' if complete and unchanged else 'failed', returncode=child.returncode,
                      child_pid=child.pid, command=command, reported_counts=counts, complete_expected_suite=complete,
                      sources_unchanged=unchanged, finished_at=time.time())
        write_json(work / 'summary.json', record)
        print(err)
        sys.exit(0 if complete and unchanged else child.returncode or 1)
except BaseException as error:
    if not isinstance(error, SystemExit):
        record.update(status='failed', error=repr(error), finished_at=time.time())
        write_json(work / 'summary.json', record)
    raise
