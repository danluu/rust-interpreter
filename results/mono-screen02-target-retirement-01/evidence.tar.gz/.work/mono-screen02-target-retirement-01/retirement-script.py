"""Retire only three reviewed completed-screen targets after fresh checks.

This file is prepared for root review. It must not be launched before the
explicit retirement admission; it performs no process controls.
"""
import gzip,hashlib,json,os,shutil,stat,sys,time
from pathlib import Path
RUNNER=Path(__file__).resolve().parents[1]
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
sys.path.insert(0,str(RUNNER/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json
from custom_compiler import load_compiler,validate_tool_compiler
import interpreter
interpreter.ROOT=ROOT
from interpreter import installed_tools
from std_mir_source_paths import load as load_std
PROOF=ROOT/'.work/mono-screen02-target-inspection-01'
WORK=ROOT/'.work/mono-screen02-target-retirement-01'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
KEY='ee858a5c30c2052959de7e9e132a4e4f39cec9b38fa3fac85777cf69ee6d9f21'
NAMESPACE='rust-interp-061a1db840c03ee05d177a5e'
RAW=ROOT/'.work/strict-warm-mono-production-screen-02'
SUFFIXES={'baseline':'badad7f8ff6caca56fe9b864','candidate':'af734d4b26ed6a8c5be936b6','duplicate':'8be5c671b32a83804a60d631'}
TARGETS={arm:RAW/'caches'/arm/NAMESPACE/'workspaces'/KEY/suffix/'target' for arm,suffix in SUFFIXES.items()}
INSPECTION_SHA='f64167aae4e96ed8ed9394bc24c233557392df333b0087f563e11d4d99cf09be'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def ordinary(path):assert path.resolve(strict=True)==path and not path.is_symlink(),str(path)
def save():write_json(WORK/'summary.json',record)
def space():
 free=shutil.disk_usage(ROOT).free
 assert free>=8*1024**3,'retirement requires 8 GiB free space'
 return free
def dependency_state(path):
 path=Path(path)
 if not path.exists() and not path.is_symlink():return None
 s=path.stat();link=path.lstat()
 return dict(resolved=str(path.resolve(strict=True)),device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,logical=[link.st_dev,link.st_ino,link.st_mode,link.st_size,link.st_mtime_ns,link.st_ctime_ns],symlink=os.readlink(path) if path.is_symlink() else None)
def entries(target):
 result=[target]
 for directory,dirs,names in os.walk(target,followlinks=False):
  result.extend(Path(directory)/name for name in sorted(dirs+names))
 return result
def entry_stat(path):
 s=path.lstat()
 return dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,blocks=s.st_blocks,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink,link=os.readlink(path) if stat.S_ISLNK(s.st_mode) else None)
WORK.mkdir(exist_ok=False)
record=dict(schema_version=1,status='waiting',owner=str(ROOT),pid=os.getpid(),parent_pid=os.getppid(),
 started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,deleted=[],builds=0,benchmarks=0,
 scope='only the three exact reviewed completed negative Mono27 screen02 inner Cargo targets',script_sha256=sha(Path(__file__)))
save()
try:
 with LOCK.open('r+') as lock:
  acquire_lock(lock,600)
  record.update(status='revalidating',lock_acquired_at=time.time(),free_bytes_before=space());save()
  assert sha(PROOF/'summary.json')==INSPECTION_SHA
  inspection=json.loads((PROOF/'summary.json').read_bytes())
  assert inspection['status']=='passed' and inspection['no_users_proved'] and inspection['deleted']==[]
  assert inspection['screen_status']=='passed correctness; negative performance' and inspection['screen_commands']==27
  assert inspection['archive_sha256']=='b405fb003d29b4d5d33174f4d51315710a9c4482f86fb78b2d9eaa2b95585c5c'
  assert inspection['inventory_entries']==50991 and inspection['external_hardlink_inodes']==0
  assert {arm:row['path'] for arm,row in inspection['candidates'].items()}=={arm:str(path) for arm,path in TARGETS.items()}
  for name,digest in inspection['proof_files'].items():assert sha(PROOF/name)==digest,name
  retained=json.loads((PROOF/'retained-proof-manifest.json').read_bytes())
  copies=json.loads((PROOF/'retained-target-inputs.json').read_bytes())
  assert len(retained)==1006 and len(copies)==8025
  def retained_check():
   for name,item in retained.items():
    path=Path(name);ordinary(path)
    assert not any(path==target or path.is_relative_to(target) for target in TARGETS.values())
    assert sha(path)==item['sha256'] and path.stat().st_size==item['bytes'],name
   for item in copies.values():
    path=Path(item['path']);ordinary(path)
    assert path.is_relative_to(PROOF/'retained-target-inputs')
    assert sha(path)==item['sha256'] and path.stat().st_size==item['bytes'],str(path)
   for name,digest in inspection['proof_files'].items():assert sha(PROOF/name)==digest,name
   assert sha(PROOF/'summary.json')==INSPECTION_SHA
  retained_check()
  supervisor=ROOT/'.work/mono-screen02-target-inspection-runner-01/.work/experiments/inventory-supervisor-01'
  completion=json.loads((supervisor/'status.json').read_bytes())
  assert completion['status']=='finished' and completion['returncode']==0 and completion['child_pid']==inspection['pid']
  assert sha(supervisor/'plan.json')==completion['plan_sha256'] and sha(supervisor/'command.log')==completion['log_sha256']
  sources={Path(__file__),RUNNER/'scripts/supervise_experiment.py'}|{Path(m.__file__) for m in tuple(sys.modules.values()) if getattr(m,'__file__',None) and str(m.__file__).startswith(str(RUNNER/'scripts')+'/')}
  source_hashes={}
  for path in sources:
   ordinary(path);data=path.read_bytes();h=hashlib.sha256(data).hexdigest();destination=WORK/'sources'/path.relative_to(RUNNER)
   destination.parent.mkdir(parents=True,exist_ok=True);assert space()-len(data)>=8*1024**3;destination.write_bytes(data);source_hashes[str(path)]=h
  write_json(WORK/'source-inputs.json',source_hashes)
  snapshots={target:{} for target in TARGETS.values()};inodes=set()
  with gzip.open(PROOF/'inventory.jsonl.gz','rt') as stream:
   for line in stream:
    row=json.loads(line);target=Path(row['root']);assert target in snapshots
    assert row['path'] not in snapshots[target]
    snapshots[target][row['path']]=row
    inodes.add((row['device'],row['inode']))
  def target_check(target):
   ordinary(target);assert target.is_dir()
   actual=entries(target);expected=snapshots[target]
   assert {str(path.relative_to(target)) for path in actual}==set(expected),'candidate entry set changed'
   for path in actual:
    row=expected[str(path.relative_to(target))]
    assert all(row[name]==value for name,value in entry_stat(path).items()),str(path)
  for arm,target in TARGETS.items():
   target_check(target)
   marker=RAW/'caches'/arm/NAMESPACE/'.rust-interp-cache.json'
   assert json.loads(marker.read_bytes())==dict(schema_version=1,kind='rust-interp-cache',owner=str(ROOT))
  for original,item in copies.items():
   path=Path(original);assert any(path.is_relative_to(target) for target in TARGETS.values())
   assert sha(path)==item['sha256'] and path.stat().st_size==item['bytes'],original
  guard=json.loads((PROOF/'custom-input-guard.json').read_bytes())
  dependency_proof=json.loads((PROOF/'publication-dependencies.json').read_bytes())
  assert guard['tool_key']==dependency_proof['tool_key']==KEY
  assert all(x['key']=='e51184b28521ec446ce759d2f6e8334d554a1d1186334c2e872dec9c45763b48' and x['namespace']=='immutable-source-paths-v2:shared' for x in guard['std'].values())
  compiler_key='f9fb3e5f59b8567fffd32c936a9864d0baee77038574236710fbcec75a57d33f'
  assert guard['compiler_key']==dependency_proof['compiler_key']==compiler_key
  tool=ROOT/'.work/interpreter-tools'/KEY
  def custom_check():
   assert sha(guard['compiler_manifest'])==guard['compiler_manifest_sha256']
   assert sha(tool/'compiler.json')==guard['tool_composition_sha256']
   compiler=load_compiler(ROOT,compiler_key)
   assert installed_tools(KEY)==(tool,KEY)
   validate_tool_compiler(tool,KEY,compiler)
   assert json.loads((tool/'ready.json').read_bytes())==guard['tool_binaries']
   for item in guard['std'].values():
    assert sha(item['ready'])==item['ready_sha256']
    sysroot,host,key,ready=load_std(ROOT,item['key'],compiler,item['namespace'],rehash=False)
    assert key==item['key'] and str(sysroot)==str(Path(item['ready']).parent/'sysroot')
   for path,h in source_hashes.items():assert sha(path)==h,'retirement helper source changed: '+path
   return guard
  def dependency_check():
   for name,expected in dependency_proof['files'].items():assert dependency_state(name)==expected,'retained dependency changed: '+name
  before=custom_check();dependency_check();write_json(WORK/'custom-before.json',before)
  dependencies=set(dependency_proof['files'])|set(retained)|{item['path'] for item in copies.values()}
  for name in dependencies:
   path=Path(name)
   assert not any(path==target or path.is_relative_to(target) for target in TARGETS.values()),name
   if path.exists():
    assert not any(path.resolve().is_relative_to(target) for target in TARGETS.values()),name
    s=path.stat();assert (s.st_dev,s.st_ino) not in inodes,('retained inode alias',name)
  checks={}
  for label,argv in [('processes',['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,tty=,command=']),('handles',['/usr/sbin/lsof','-nP','-FpcftDin'])]:
   child,out,err=capture(argv,cwd=ROOT,env=dict(os.environ),receipt_path=WORK/(label+'-process.json'),receipt={})
   found=[]
   if label=='processes':found=[line for line in out.splitlines() if any(str(path) in line for path in TARGETS.values())]
   else:
    process={};entry={}
    def finish():
     name=entry.get('n','')
     try:inode=(int(entry.get('D',''),16),int(entry.get('i','')))
     except ValueError:inode=None
     path_match=any(name==str(path) or name.startswith(str(path)+'/') for path in TARGETS.values())
     if inode in inodes or path_match:found.append(dict(process=process.copy(),file=entry.copy(),inode_match=inode in inodes,path_match=path_match))
    for line in out.splitlines():
     if not line:continue
     k,v=line[0],line[1:]
     if k=='p':finish();process={'pid':v};entry={}
     elif k=='c':process['command']=v
     elif k=='f':finish();entry={'fd':v}
     else:entry[k]=v
    finish()
   checks[label]=dict(pid=child.pid,returncode=child.returncode,stdout_sha256=hashlib.sha256(out.encode()).hexdigest(),stderr_sha256=hashlib.sha256(err.encode()).hexdigest(),stdout_lines=len(out.splitlines()),stderr_lines=len(err.splitlines()),matches=found,raw_output_retained=False)
   write_json(WORK/'quiescence.json',checks)
   assert child.returncode==0 and not err.strip(),label+' inspection incomplete'
   assert not found,label+' has candidate users'
  # Preserve this exact script and its inspection/proof identities before mutation.
  (WORK/'retirement-script.py').write_bytes(Path(__file__).read_bytes())
  assert sha(WORK/'retirement-script.py')==record['script_sha256']
  record.update(status='retiring',quiescence=checks,quiescent_at=time.time(),
   inspection_sha256=INSPECTION_SHA,proof_files=inspection['proof_files'],target_paths={arm:str(path) for arm,path in TARGETS.items()},
   inventory_entries_verified=50991,retained_files_verified=len(retained),retained_target_inputs_verified=len(copies),
   archive_sha256=inspection['archive_sha256'],estimated_allocated_bytes=inspection['allocated_bytes_unique_all_targets'])
  save()
  retained_check();dependency_check();custom_check()
  for arm,target in TARGETS.items():
   space()
   # The inventory/ordinary-directory check is repeated immediately before each exact rmtree.
   target_check(target)
   assert target==RAW/'caches'/arm/NAMESPACE/'workspaces'/KEY/SUFFIXES[arm]/'target'
   shutil.rmtree(target)
   assert not target.exists() and not target.is_symlink()
   record['deleted'].append(dict(arm=arm,path=str(target),finished_at=time.time(),free_bytes=shutil.disk_usage(ROOT).free));save()
  retained_check()
  dependency_check();after=custom_check();assert after==before
  write_json(WORK/'custom-after.json',after)
  record.update(status='passed',finished_at=time.time(),free_bytes_after=shutil.disk_usage(ROOT).free,
   retained_proofs_and_copies_preserved=True,custom_compiler_tool_std_inputs_preserved=True,
   source_inventory_and_helpers_preserved=True,
   all_27_commands_14_tests_9_states_and_artifact_parity_preserved=True,
   prior_failed_screen01_evidence_untouched=True,
   compiler_intermediate_proposals_untouched=True,
   cache_namespaces_workspaces_and_program_artifacts_preserved=True,
   original_screen_and_assessment_preserved=True,source_restoration_preserved=True)
  save()
  print(json.dumps({k:record[k] for k in ['status','pid','deleted','free_bytes_before','free_bytes_after','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());save();raise
