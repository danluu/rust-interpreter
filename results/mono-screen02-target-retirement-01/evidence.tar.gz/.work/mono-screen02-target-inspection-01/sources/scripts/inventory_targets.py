import base64,collections,gzip,hashlib,json,os,shutil,stat,subprocess,sys,time
from pathlib import Path
RUNNER=Path(__file__).resolve().parents[1]
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
sys.path.insert(0,str(RUNNER/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json
from custom_compiler import load_compiler,validate_tool_compiler
import interpreter
interpreter.ROOT=ROOT
from interpreter import installed_tools
from std_mir_source_paths import load as load_std
WORK=ROOT/'.work/mono-screen02-target-inspection-01'
RAW=ROOT/'.work/strict-warm-mono-production-screen-02'
RESULT=ROOT/'results/strict-warm-mono-production-screen-02'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
WORK.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
def digest(path):return sha(Path(path).read_bytes())
def write(name,value):write_json(WORK/name,value)
def space():
 free=shutil.disk_usage(ROOT).free
 assert free>=8*1024**3,'inspection requires 8 GiB free space'
 return free
def ordinary(path):
 assert path.resolve(strict=True)==path and not path.is_symlink(),str(path)
def walk(base,exclude=()):
 for directory,dirs,names in os.walk(base,followlinks=False):
  dirs[:]=sorted(n for n in dirs if Path(directory)/n not in exclude)
  for name in dirs:assert not (Path(directory)/name).is_symlink(),str(Path(directory)/name)
  for name in sorted(names):yield Path(directory)/name
retained={}
def retain(path):
 path=Path(path);ordinary(path);assert path.is_file(),str(path)
 data=path.read_bytes();proof=dict(sha256=sha(data),bytes=len(data))
 if str(path) in retained:assert retained[str(path)]==proof,'retained file changed: '+str(path)
 retained[str(path)]=proof;return data
def dependency_state(path):
 path=Path(path)
 if not path.exists() and not path.is_symlink():return None
 s=path.stat();link=path.lstat()
 return dict(resolved=str(path.resolve(strict=True)),device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,logical=[link.st_dev,link.st_ino,link.st_mode,link.st_size,link.st_mtime_ns,link.st_ctime_ns],symlink=os.readlink(path) if path.is_symlink() else None)
record=dict(schema_version=1,status='waiting',owner=str(ROOT),pid=os.getpid(),parent_pid=os.getppid(),
 started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,deleted=[],workloads_executed=0,
 scope='inspection only: three completed negative Mono27 screen02 inner Cargo targets',screen_status='passed correctness; negative performance',screen_commands=27)
write('summary.json',record)
try:
 with LOCK.open('r+') as lock:
  acquire_lock(lock,600)
  record.update(status='inspecting',lock_acquired_at=time.time(),free_bytes_before=space())
  record['revision']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
  write('summary.json',record)
  source_paths={Path(__file__),RUNNER/'scripts/supervise_experiment.py'}|{Path(m.__file__) for m in tuple(sys.modules.values()) if getattr(m,'__file__',None) and str(m.__file__).startswith(str(RUNNER/'scripts')+'/')}
  for path in source_paths:
   data=retain(path);dest=WORK/'sources'/path.relative_to(RUNNER);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  completed=json.loads(retain(RAW/'summary.json'));plan=json.loads(retain(RAW/'plan.json'));rows=json.loads(retain(RAW/'records.json'))
  assessed=json.loads(retain(RESULT/'summary.json'))
  assert completed['status']==assessed['status']=='passed' and completed['source_restored'] and assessed['source_restored']
  assert len(rows)==completed['commands']==assessed['commands']==27 and completed['edited_pairs']==5
  assert completed['all_five_screen_commands_below_0_5'] is False and assessed['candidate_observations_below_half_second']==0
  archive=RESULT/assessed['archive']['path'];payload=retain(archive)
  assert sha(payload)==assessed['archive']['sha256']=='b405fb003d29b4d5d33174f4d51315710a9c4482f86fb78b2d9eaa2b95585c5c'
  assert assessed['archive']['all_member_hashes_verified'] is True
  unpacked=gzip.decompress(payload);assert sha(unpacked)==assessed['archive']['uncompressed_sha256']
  archive_members={}
  for item in json.loads(unpacked)['files']:
   data=item['utf8'].encode() if 'utf8' in item else base64.b64decode(item['base64'],validate=True)
   assert sha(data)==item['sha256'] and len(data)==item['bytes'] and item['path'] not in archive_members
   archive_members[item['path']]=item
  assert len(archive_members)==991==assessed['archive']['members']
  for name in ['summary.json','plan.json','records.json','transitions.json']:
   assert sha(retain(RAW/name))==archive_members[str(RAW/name)]['sha256']
  assert sha(retain(RAW/'plan.json'))==completed['plan_sha256']
  assert sha(retain(RAW/'records.json'))==completed['records_sha256']
  completion={}
  supervisors=[(ROOT/'.work/experiments/mono-production-screen-supervisor-02',0),
    (ROOT/'.work/experiments/mono-production-screen-assessment-supervisor-02',0)]
  for directory,expected in supervisors:
   value=json.loads(retain(directory/'status.json'));assert value['status']=='finished' and value['returncode']==expected
   assert sha(retain(directory/'plan.json'))==value['plan_sha256']
   assert sha(retain(directory/'command.log'))==value['log_sha256']
   completion[str(directory)]=value
   for path in walk(directory):retain(path)
  frozen_helpers=json.loads(retain(RUNNER/'source-inputs.json'))
  for path,item in frozen_helpers.items():assert sha(retain(Path(path)))==item['sha256']
  for row in rows:
   receipt=json.loads(retain(RAW/'receipts'/f"{row['index']}-{row['mode']}.json"))
   assert receipt['status']=='finished' and receipt['pid']==row['pid'] and receipt['returncode']==row['returncode']
  source=Path(plan['source'])/plan['case']['file'];assert sha(retain(source))==plan['original_source_sha256']
  retain(Path(plan['source'])/'.rust-interp-owned.json')
  cache=RAW/'caches';ordinary(cache)
  assert {p.name for p in cache.iterdir()}=={'baseline','candidate','duplicate'}
  namespace='rust-interp-'+sha(str(ROOT).encode())[:24]
  candidates={}
  workspaces={row['mode']:row['launch']['workspace_path'] for row in rows}
  assert set(workspaces)=={'baseline','candidate','duplicate'}
  for arm,workspace in workspaces.items():
   assert arm in ('baseline','candidate','duplicate')
   parent=cache/arm;ordinary(parent);assert {p.name for p in parent.iterdir()}=={namespace}
   marker=parent/namespace/'.rust-interp-cache.json'
   assert json.loads(retain(marker))==dict(schema_version=1,kind='rust-interp-cache',owner=str(ROOT))
   workspace=Path(workspace);ordinary(workspace)
   expected_leaf={'baseline':'badad7f8ff6caca56fe9b864','candidate':'af734d4b26ed6a8c5be936b6','duplicate':'8be5c671b32a83804a60d631'}
   assert workspace==parent/namespace/'workspaces'/'ee858a5c30c2052959de7e9e132a4e4f39cec9b38fa3fac85777cf69ee6d9f21'/expected_leaf[arm]
   target=workspace/'target';ordinary(target);assert target.is_dir()
   candidates[arm]=target
  selected=list(candidates.values())
  assert len(selected)==3 and len(set(selected))==3
  for path in walk(RAW,exclude=(cache,)):retain(path)
  for path in walk(RESULT):retain(path)
  for path in walk(cache,exclude=tuple(selected)):retain(path)
  artifact_paths=set()
  for row in rows:
   assert row['validated'] and len(row['outcomes'])==14
   assert row['source_sha256']==plan['states'][row['index']]['source_sha256']
   if row['phase']=='wrong-edit':assert row['returncode']==1 and row['stdout']=='' and sum(v=='failed' for _,v in row['outcomes'])==2
   else:assert row['returncode']==0 and row['stdout']=='0\n' and all(v=='passed' for _,v in row['outcomes'])
   for item in row['artifacts']:
    path=ROOT/item['path'];assert path.is_relative_to(RAW/'artifacts')
    data=retain(path);assert sha(data)==item['sha256'] and len(data)==item['bytes'];artifact_paths.add(path)
   assert digest(Path(row['launch']['suite_report_path']))==row['suite_sha256']==row['launch']['suite_report_sha256']
  for index in range(9):
   group=[r for r in rows if r['index']==index];assert len(group)==3
   assert len({tuple(x['sha256'] for x in r['artifacts']) for r in group})==1,'saved arm artifact parity differs'
  artifact_count=len(artifact_paths)
  key='ee858a5c30c2052959de7e9e132a4e4f39cec9b38fa3fac85777cf69ee6d9f21'
  compiler_key='f9fb3e5f59b8567fffd32c936a9864d0baee77038574236710fbcec75a57d33f'
  assert set(plan['tools'].values())=={key} and plan['custom_compiler']['key']==compiler_key
  compiler=load_compiler(ROOT,compiler_key)
  assert compiler.identity==plan['custom_compiler']['identity']
  tool,actual_key=installed_tools(key);assert actual_key==key
  validate_tool_compiler(tool,key,compiler)
  composition=json.loads(retain(tool/'compiler.json'))
  for name in ['ready.json','capabilities.json']:retain(tool/name)
  compiler_ready=json.loads(retain(ROOT/'.work/compilers'/compiler_key/'ready.json'))
  dependencies={str(tool/name) for name in composition['binaries']}|{str(compiler.sysroot)}
  dependencies.update(str(compiler.sysroot/name) for name in compiler_ready['stamps'])
  standards={}
  for arm in ['baseline','candidate']:
   expected=plan['std_mir_by_mode'][arm];std_key=expected['key'];mode='on' if arm=='candidate' else 'off'
   ready_path=Path(expected['path']);assert digest(ready_path)==expected['sha256']
   sysroot,target,actual,ready=load_std(ROOT,std_key,compiler,'immutable-source-paths-v2:shared',rehash=True)
   assert actual==std_key and str(sysroot)==str(ready_path.parent/'sysroot')
   retain(ready_path);retain(ready_path.parent/'owner.json')
   for folder,field in [('sysroot','sysroot_stamps'),('library','snapshot_stamps'),('evidence','evidence_stamps')]:
    base=ready_path.parent/folder;dependencies.add(str(base));dependencies.update(str(base/name) for name in ready[field])
   for path in walk(ready_path.parent/'evidence'):retain(path)
   cargo=ready['identity']['cargo'];dependencies.add(cargo['executable'])
   dependencies.update(x['path'] for x in ready['cargo_state']['route'].values() if isinstance(x,dict) and 'path' in x)
   for item in cargo['libraries']['libraries']:
    dependencies.update(str(v) for k,v in item.items() if k in ['path','resolved_path','logical_path'])
   dependencies.update(cargo['libraries']['searches'])
   standards[arm]=dict(key=std_key,ready=str(ready_path),ready_sha256=expected['sha256'],namespace='immutable-source-paths-v2:shared')
  for label in ['compiler_qualification','source_observables']:
   proof=plan[label];path=Path(proof['path']);assert sha(retain(path))==proof['sha256']
   result=json.loads(retain(path));assert result['status']=='passed' and result['tool_key']==key and result['compiler_key']==compiler_key
   for relative,expected in result['evidence_files'].items():assert sha(retain(path.parent/relative))==expected
  # Past main source/harness bytes are retained in the exact verified archive.
  # Live source guards cover the owned Nushell checkout and immutable inputs only.
  dependencies.update(path for path in plan['frozen'] if Path(path).is_relative_to(Path(plan['source'])))
  assert plan['std_mir_by_mode']['baseline']==plan['std_mir_by_mode']['candidate']==plan['std_mir_by_mode']['duplicate']
  assert standards['baseline']['key']=='e51184b28521ec446ce759d2f6e8334d554a1d1186334c2e872dec9c45763b48'
  # Include helpers imported lazily during immutable input validation.
  source_paths|={Path(m.__file__) for m in tuple(sys.modules.values()) if getattr(m,'__file__',None) and str(m.__file__).startswith(str(RUNNER/'scripts')+'/')}
  for path in source_paths:
   data=retain(path);dest=WORK/'sources'/path.relative_to(RUNNER);dest.parent.mkdir(parents=True,exist_ok=True)
   if dest.exists():assert dest.read_bytes()==data
   else:dest.write_bytes(data)
  input_guard=dict(compiler_key=compiler_key,tool_key=key,compiler_manifest=str(ROOT/'.work/compilers'/compiler_key/'ready.json'),
    compiler_manifest_sha256=digest(ROOT/'.work/compilers'/compiler_key/'ready.json'),tool_composition_sha256=digest(tool/'compiler.json'),
    tool_binaries=composition['binaries'],std=standards)
  write('custom-input-guard.json',input_guard)
  for dependency in dependencies|set(retained):
   path=Path(dependency)
   assert not any(path==target or path.is_relative_to(target) for target in selected),('retained dependency enters target',dependency)
   if path.exists():assert not any(path.resolve().is_relative_to(target) for target in selected),('retained dependency alias enters target',dependency)
  inventory=[];inodes=set();inode_rows=collections.defaultdict(list);copies={};allocations={}
  for arm,target in candidates.items():
   entries=[target]
   for directory,dirs,names in os.walk(target,followlinks=False):
    for name in sorted(dirs+names):entries.append(Path(directory)/name)
   for path in entries:
    s=path.lstat();kind='directory' if stat.S_ISDIR(s.st_mode) else 'file' if stat.S_ISREG(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'special'
    assert kind!='special',str(path)
    row=dict(root=str(target),path=str(path.relative_to(target)),arm=arm,kind=kind,device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,blocks=s.st_blocks,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink,link=os.readlink(path) if kind=='symlink' else None)
    inventory.append(row);inodes.add((s.st_dev,s.st_ino));inode_rows[(s.st_dev,s.st_ino)].append(row)
    if kind=='file' and (path.suffix in ('.rbc','.json','.jsonl','.rs','.toml','.lock','.txt','.d','.h','.c','.cc','.cpp','.S','.inc') or '.fingerprint' in path.relative_to(target).parts or 'history' in path.name or path.name in ('CACHEDIR.TAG','.cargo-lock','output','stderr','root-output','invoked.timestamp')):
     space();data=path.read_bytes();h=sha(data);destination=WORK/'retained-target-inputs'/h
     destination.parent.mkdir(exist_ok=True)
     if not destination.exists():
      assert space()-len(data)>=8*1024**3,'retained copy would cross the 8 GiB floor'
      destination.write_bytes(data)
     space()
     assert digest(destination)==h
     copies[str(path)]=dict(path=str(destination),sha256=h,bytes=len(data),role='bytecode' if '.rbc' in path.name else 'generated source, history or target metadata')
   armrows=[r for r in inventory if r['arm']==arm]
   unique={(r['device'],r['inode']):r for r in armrows}
   allocations[arm]=dict(path=str(target),entries=len(armrows),regular_files=sum(r['kind']=='file' for r in armrows),symlinks=sum(r['kind']=='symlink' for r in armrows),logical_bytes=sum(r['bytes'] for r in armrows if r['kind']=='file'),allocated_bytes_unique_inodes=sum(r['blocks']*512 for r in unique.values()),root_identity=armrows[0])
  dependency_inode_matches=[]
  for dependency in dependencies|set(retained):
   path=Path(dependency)
   if path.exists():
    s=path.stat()
    if (s.st_dev,s.st_ino) in inodes:dependency_inode_matches.append(dependency)
  assert not dependency_inode_matches,'retained input shares a target inode'
  for original,item in copies.items():
   assert digest(Path(original))==digest(Path(item['path']))==item['sha256']
  inventory_bytes=''.join(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n' for row in inventory).encode()
  packed=gzip.compress(inventory_bytes,mtime=0);(WORK/'inventory.jsonl.gz').write_bytes(packed)
  write('retained-target-inputs.json',copies)
  dependency_records={}
  for name in sorted(dependencies):
   dependency_records[name]=dependency_state(name)
  write('publication-dependencies.json',dict(tool_key=key,compiler_key=compiler_key,files=dependency_records,live_guard=str(WORK/'custom-input-guard.json')))
  quiescence={}
  for label,argv in [('processes',['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,tty=,command=']),('handles',['/usr/sbin/lsof','-nP','-FpcftDin'])]:
   child,out,err=capture(argv,cwd=ROOT,env=dict(os.environ),receipt_path=WORK/(label+'-process.json'),receipt={})
   found=[]
   if label=='processes':
    found=[line for line in out.splitlines() if any(str(path) in line for path in selected)]
   else:
    process={};entry={}
    def finish():
     name=entry.get('n','')
     try:inode=(int(entry.get('D',''),16),int(entry.get('i','')))
     except ValueError:inode=None
     path_match=any(name==str(path) or name.startswith(str(path)+'/') for path in selected)
     if inode in inodes or path_match:found.append(dict(process=process.copy(),file=entry.copy(),inode_match=inode in inodes,path_match=path_match))
    for line in out.splitlines():
     if not line:continue
     k,v=line[0],line[1:]
     if k=='p':finish();process={'pid':v};entry={}
     elif k=='c':process['command']=v
     elif k=='f':finish();entry={'fd':v}
     else:entry[k]=v
    finish()
   quiescence[label]=dict(pid=child.pid,returncode=child.returncode,stdout_sha256=sha(out.encode()),stderr_sha256=sha(err.encode()),stdout_lines=len(out.splitlines()),stderr_lines=len(err.splitlines()),matches=found,raw_output_retained=False)
   write('quiescence.json',quiescence)
   assert child.returncode==0 and not err.strip(),label+' inspection incomplete'
   assert not found,label+' has candidate users'
  # Re-stat every inventoried entry after handle inspection; no candidate was modified.
  for row in inventory:
   path=Path(row['root'])/row['path'];s=path.lstat()
   assert (s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_blocks,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink)==tuple(row[k] for k in ['device','inode','mode','bytes','blocks','mtime_ns','ctime_ns','nlink']),str(path)
  for path,proof in retained.items():assert digest(Path(path))==proof['sha256'],path
  assert load_compiler(ROOT,compiler_key)==compiler
  assert installed_tools(key)==(tool,key)
  validate_tool_compiler(tool,key,compiler)
  for item in standards.values():
   assert digest(item['ready'])==item['ready_sha256']
   load_std(ROOT,item['key'],compiler,item['namespace'],rehash=False)
  for name,expected in dependency_records.items():assert dependency_state(name)==expected,'dependency changed: '+name
  for original,item in copies.items():assert digest(original)==digest(item['path'])==item['sha256']
  write('retained-proof-manifest.json',retained)
  unique={key:values[0] for key,values in inode_rows.items()}
  external_links=[dict(device=dev,inode=ino,observed_paths=len(values),nlink=values[0]['nlink']) for (dev,ino),values in inode_rows.items() if values[0]['kind']=='file' and values[0]['nlink']>len(values)]
  write('external-hardlinks.json',external_links)
  record.update(status='passed',finished_at=time.time(),candidates=allocations,inventory_entries=len(inventory),
   inventory_sha256=sha(packed),inventory_bytes=len(packed),retained_proof_manifest_sha256=digest(WORK/'retained-proof-manifest.json'),
   retained_files=len(retained),retained_target_inputs=len(copies),retained_target_input_bytes=sum(x['bytes'] for x in copies.values()),
   publication_dependencies=len(dependencies),dependency_inode_matches=dependency_inode_matches,quiescence=quiescence,
   no_users_proved=True,all_target_entries_unchanged=True,retained_inputs_unchanged=True,completion=completion,
   artifacts_preserved=artifact_count,allocated_bytes_unique_all_targets=sum(row['blocks']*512 for row in unique.values()),
   external_hardlink_inodes=len(external_links),allocation_limit='st_blocks by unique inode; APFS shared extents can make actual reclaimed space smaller',
   archive_sha256=assessed['archive']['sha256'],archive_members_verified=len(archive_members),states=9,edited_pairs=5,all_27_artifact_and_suite_records_preserved=True,old_failed_screen01_untouched=True,free_bytes_after=shutil.disk_usage(ROOT).free,
   retirement_requires='fresh canonical admission, exact inventory/retained-proof revalidation and fresh path/inode/handle/cwd checks; no deletion authorized by this inspection')
  record['proof_files']={name:digest(WORK/name) for name in ['inventory.jsonl.gz','retained-proof-manifest.json','retained-target-inputs.json','publication-dependencies.json','custom-input-guard.json','quiescence.json','external-hardlinks.json']}
  write('summary.json',record)
  print(json.dumps({k:record[k] for k in ['status','pid','inventory_entries','retained_files','retained_target_inputs','allocated_bytes_unique_all_targets','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());write('summary.json',record);raise
