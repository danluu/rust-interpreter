import gzip,hashlib,io,json,os,shutil,sys,tarfile,time
from pathlib import Path
RUNNER=Path(__file__).resolve().parents[1]
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
sys.path.insert(0,str(RUNNER/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import write_json
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
INSPECTION=ROOT/'.work/mono-screen02-target-inspection-01'
RETIREMENT=ROOT/'.work/mono-screen02-target-retirement-01'
OUTPUT=ROOT/'results/mono-screen02-target-retirement-01'
WORK=ROOT/'.work/mono-screen02-target-retirement-archive-01'
WORK.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_bytes())
record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,builds=0,benchmarks=0,deletions=0)
write_json(WORK/'summary.json',record)
try:
 with LOCK.open('r+') as lock:
  acquire_lock(lock,600);record.update(status='archiving',lock_acquired_at=time.time());write_json(WORK/'summary.json',record)
  assert shutil.disk_usage(ROOT).free>=8*1024**3,'archive requires 8 GiB free space'
  inspection=read(INSPECTION/'summary.json');retirement=read(RETIREMENT/'summary.json')
  assert sha((INSPECTION/'summary.json').read_bytes())==retirement['inspection_sha256']=='f64167aae4e96ed8ed9394bc24c233557392df333b0087f563e11d4d99cf09be'
  assert inspection['status']==retirement['status']=='passed' and len(retirement['deleted'])==3
  assert retirement['retained_proofs_and_copies_preserved'] and retirement['custom_compiler_tool_std_inputs_preserved']
  assert all(not Path(x['path']).exists() and not Path(x['path']).is_symlink() for x in retirement['deleted'])
  for name,h in inspection['proof_files'].items():assert sha((INSPECTION/name).read_bytes())==h
  copies=read(INSPECTION/'retained-target-inputs.json')
  for item in copies.values():
   p=Path(item['path']);assert p.is_relative_to(INSPECTION/'retained-target-inputs') and not p.is_symlink()
   b=p.read_bytes();assert sha(b)==item['sha256'] and len(b)==item['bytes']
  screen=ROOT/'results/strict-warm-mono-production-screen-02';screen_summary=read(screen/'summary.json')
  assert screen_summary['status']=='passed' and screen_summary['commands']==27 and screen_summary['edited_pairs']==5
  assert screen_summary['candidate_observations_below_half_second']==0 and screen_summary['source_restored']
  assert sha((screen/screen_summary['archive']['path']).read_bytes())==retirement['archive_sha256']==screen_summary['archive']['sha256']
  paths={Path(__file__),RUNNER/'scripts/supervise_experiment.py',RUNNER/'scripts/workflow_io.py',RUNNER/'scripts/compare_saved_runtime.py'}
  supervisors=[ROOT/'.work/mono-screen02-target-inspection-runner-01/.work/experiments/inventory-supervisor-01',ROOT/'.work/mono-screen02-target-retirement-runner-01/.work/experiments/retirement-supervisor-01']
  paths.add(ROOT/'.work/mono-screen02-target-inspection-runner-01/source-inputs.json')
  directories=[INSPECTION,RETIREMENT,ROOT/'.work/mono-screen02-target-inspection-runner-01/scripts',ROOT/'.work/mono-screen02-target-retirement-runner-01/scripts',*supervisors]
  for directory in directories:
   for p in directory.rglob('*'):
    assert not p.is_symlink()
    if p.is_file() and '__pycache__' not in p.parts:paths.add(p)
  for directory in supervisors:
   s=read(directory/'status.json');assert s['status']=='finished' and s['returncode']==0
   assert sha((directory/'plan.json').read_bytes())==s['plan_sha256'] and sha((directory/'command.log').read_bytes())==s['log_sha256']
  files={str(p.relative_to(ROOT)):p.read_bytes() for p in sorted(paths)}
  manifest={name:dict(bytes=len(data),sha256=sha(data)) for name,data in files.items()}
  assert not OUTPUT.exists();OUTPUT.mkdir()
  assert shutil.disk_usage(ROOT).free-sum(map(len,files.values()))>=8*1024**3,'archive bound would cross 8 GiB floor'
  with (OUTPUT/'evidence.tar.gz').open('xb') as stream:
   with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as archive:
     for name,data in files.items():
      info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o444;info.mtime=0
      archive.addfile(info,io.BytesIO(data))
  verified=set()
  with tarfile.open(OUTPUT/'evidence.tar.gz','r:gz') as archive:
   for member in archive:
    assert member.isfile() and member.name not in verified and member.name in manifest
    data=archive.extractfile(member).read();assert len(data)==manifest[member.name]['bytes'] and sha(data)==manifest[member.name]['sha256']
    verified.add(member.name)
  assert verified==set(manifest)
  summary=dict(schema_version=1,status='passed',kind='completed-negative-mono-screen02-target-retirement',
   inspection_pid=inspection['pid'],retirement_pid=retirement['pid'],archive_pid=os.getpid(),
   inspection_sha256=retirement['inspection_sha256'],retirement_sha256=sha((RETIREMENT/'summary.json').read_bytes()),
   targets=retirement['deleted'],entries_verified=retirement['inventory_entries_verified'],
   retained_proof_files=retirement['retained_files_verified'],retained_target_input_paths=len(copies),
   retained_target_input_content_files=len({x['sha256'] for x in copies.values()}),
   allocated_bytes_before=inspection['allocated_bytes_unique_all_targets'],
   free_bytes_before=retirement['free_bytes_before'],free_bytes_after=retirement['free_bytes_after'],
   observed_free_byte_change=retirement['free_bytes_after']-retirement['free_bytes_before'],
   allocation_limit='Observed global filesystem difference can include concurrent unrelated allocation; st_blocks does not expose APFS shared extents.',
   inspection_and_fresh_retirement_quiescence=True,raw_global_process_tables_retained=False,
   screen_evidence=dict(path=str(screen),archive_sha256=retirement['archive_sha256'],commands=27,status='passed correctness; negative performance',states=9,original_tests=14),
   source_restoration_and_all_retained_proofs_preserved=True,cache_metadata_and_program_artifacts_preserved=True,
   publication_guard_preserved=True,process_controls=0,compiler_builds=0,benchmarks=0,performance_claim=False,
   archive=dict(path='evidence.tar.gz',sha256=sha((OUTPUT/'evidence.tar.gz').read_bytes()),bytes=(OUTPUT/'evidence.tar.gz').stat().st_size,members=len(manifest),all_member_hashes_verified=True,gzip_mtime=0),
   packager_sha256=sha(Path(__file__).read_bytes()),finished_at=time.time())
  write_json(OUTPUT/'manifest.json',manifest);write_json(OUTPUT/'summary.json',summary)
  (OUTPUT/'README.md').write_text('# Completed Mono screen02 target retirement\n\n'
   'Only the three reviewed inner Cargo target directories from completed Mono screen02 were retired. '
   'Cache namespaces, workspace metadata, all27 command records, all14 tests in each of9states, '
   'all21 bytecode/catalog/call snapshots, exact arm artifact parity and the saved assessment remain intact. '
   'The compiler intermediate proposals and failed screen01 evidence were untouched.\n\n'
   f"Fresh checks reconciled {summary['entries_verified']:,} entries, {summary['retained_proof_files']} proof files and "
   f"{summary['retained_target_input_paths']:,} generated-source/metadata copy bindings. "
   'Custom compiler f9, toolsee858 and shared stde511 identities were unchanged and disjoint by path and inode. '
   'No outside hardlinks or matching ps/lsof path, inode, cwd or handle users were found; raw global tables stayed in memory. '
   'No process was controlled.\n\n'
   f"Allocated blocks totaled {summary['allocated_bytes_before']/1024**3:.3f} GiB. "
   f"Observed free space changed from {summary['free_bytes_before']:,} to {summary['free_bytes_after']:,} bytes "
   f"({summary['observed_free_byte_change']/1024**3:.3f} GiB); APFS shared extents and unrelated allocation limit attribution.\n\n"
   'The archive preserves exact independent helper sources, receipts, inventories, dependency guards and retained target-input copies. '
   'Every member was read back and hash checked. Compiled binaries and retired native cache artifacts are excluded. '
   'The [screen assessment](../strict-warm-mono-production-screen-02/assessment.md) retains the negative performance result. '
   'This retirement makes no speed claim.\n')
  record.update(status='passed',finished_at=time.time(),output=str(OUTPUT),archive=summary['archive']);write_json(WORK/'summary.json',record)
  print(json.dumps(record))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());write_json(WORK/'summary.json',record);raise
