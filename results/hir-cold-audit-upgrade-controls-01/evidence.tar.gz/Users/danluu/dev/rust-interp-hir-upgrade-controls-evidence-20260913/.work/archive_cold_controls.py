#!/usr/bin/env python3
"""Package the ten completed cold-audit continuation controls; never execute its test commands."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
UPGRADE = Path('/Users/danluu/dev/rust-interp-hir-cold-audit-upgrade-20260913')
HIRC = Path('/Users/danluu/dev/rust-interp-hir-capture-check-20260913')
PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
RAW = UPGRADE / '.work/hir-cold-audit-upgrade-controls-01'
SUPERVISOR = UPGRADE / '.work/experiments/hir-cold-audit-upgrade-controls-supervisor-01'
HISTORY = PRIMARY / 'results/hir-capture-check-failed-01'
OUT = ROOT / 'results/hir-cold-audit-upgrade-controls-01'
WORK = ROOT / '.work/hir-cold-audit-upgrade-controls-archive-01'
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    WORK.mkdir(parents=True, exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
                  started_at=time.time(), lock=str(CANONICAL_LOCK), lock_wait_seconds=600)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            payloads = {}

            def capture(path, expected=None):
                path = Path(path)
                require(path.is_absolute() and path.resolve(strict=True) == path
                        and path.is_file() and not path.is_symlink(), 'nonordinary evidence path')
                data = path.read_bytes()
                require(expected is None or digest(data) == expected, 'evidence source changed: ' + str(path))
                if str(path) in payloads:
                    require(payloads[str(path)] == data, 'evidence changed during capture')
                payloads[str(path)] = data
                return data

            test = json.loads(capture(RAW / 'summary.json'))
            require(test['status'] == 'passed' and len(test['inputs']) == 26, 'controls or exact 26-input guard map differ')
            for path, expected in test['inputs'].items():
                capture(path, expected)
            child = json.loads(capture(RAW / 'command/receipt.json', test['command_receipt_sha256']))
            require(child['status'] == 'finished' and child['returncode'] == 0
                    and child['cwd'] == str(UPGRADE)
                    and child['command'][1:] == ['-m', 'unittest', 'discover', '-s', 'tests',
                                                '-p', 'test_hir_*upgrade.py', '-v'],
                    'unexpected completed test command')
            stderr = capture(RAW / 'command/stderr', child['stderr_sha256']).decode()
            capture(RAW / 'command/stdout', child['stdout_sha256'])
            successes = re.findall(r'^test_[^\n]+ \.\.\. ok$', stderr, re.M)
            require(len(successes) == 10 and re.search(r'^Ran 10 tests in [0-9.]+s$', stderr, re.M)
                    and stderr.rstrip().endswith('OK'), 'ten passing controls without skips required')
            supervisor = json.loads(capture(SUPERVISOR / 'status.json'))
            require(supervisor['status'] == 'finished' and supervisor['returncode'] == 0
                    and supervisor['child_pid'] == test['pid'], 'test supervisor association changed')
            capture(SUPERVISOR / 'plan.json', supervisor['plan_sha256'])
            capture(SUPERVISOR / 'command.log', supervisor['log_sha256'])
            capture(SUPERVISOR / 'supervisor.log')

            for path in [Path(__file__), ROOT / 'experiments/stable-cgu/owned_stage.py',
                         ROOT / 'scripts/supervise_experiment.py']:
                capture(path)

            OUT.mkdir(parents=True, exist_ok=False)
            archive = OUT / 'evidence.tar.gz'
            manifest = {}
            with archive.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for source, data in sorted(payloads.items()):
                            disk(ROOT)
                            name = source.lstrip('/')
                            member = tarfile.TarInfo(name)
                            member.size = len(data)
                            member.mode = 0o644
                            tar.addfile(member, io.BytesIO(data))
                            manifest[name] = dict(source=source, bytes=len(data), sha256=digest(data))
            seen = set()
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    require(member.isfile() and member.name not in seen, 'invalid archive member')
                    seen.add(member.name)
                    item = manifest[member.name]
                    data = tar.extractfile(member).read()
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'],
                            'archive readback differs')
            require(seen == set(manifest), 'archive readback incomplete')
            require(all(Path(path).read_bytes() == data for path, data in payloads.items()),
                    'retained source changed during archive')
            write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed',
                source_commit='a36a1e7040ae50d1e7bad96281657deed6158219',
                raw=str(RAW), supervisor=str(SUPERVISOR), controls=10, skipped=0,
                test_pid=child['pid'], helper_pid=test['pid'], supervisor_pid=supervisor['supervisor_pid'],
                test_command=child['command'], test_seconds=child['finished_at'] - child['started_at'],
                actual_test_summary_sha256=digest(payloads[str(RAW / 'summary.json')]),
                test_run_frozen_inputs=test['inputs'],
                all_26_inputs_guarded_during_tests=True,
                archive=dict(path=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
                             members=len(manifest), all_member_hashes_verified=True, gzip_mtime=0),
                manifest_sha256=sha(OUT / 'manifest.json'),
                scope='ten Python controls only; no compiler, unit, capture execution or cache-performance qualification')
            write(OUT / 'summary.json', summary)
            (OUT / 'README.md').write_text(
                '# Cold-audit continuation source controls\n\n'
                'All ten Python controls passed with no skips at source `a36a1e70`: '
                'the six original upgrade controls plus four successor controls. '
                'They cover preserved failure history, exact predecessor and archive binding, '
                'reviewed plan and fixed-command/capacity rules, all twenty earlier and two '
                'cold-audit test names, and unchanged default engine behavior. No compiler '
                'or benchmark ran as part of these controls.\n\n'
                'The archive preserves exact command/stdout/stderr/process and supervisor '
                'receipts, with all 26 source inputs guarded before and after the actual '
                'test run, including the imported original HIRC inputs. All archive members '
                'were read back and hash verified. Compiler sources, targets and previous '
                'receipts were unchanged.\n')
            record.update(status='passed', finished_at=time.time(), free_bytes_after=disk(ROOT),
                          result=str(OUT), archive=summary['archive'],
                          summary_sha256=sha(OUT / 'summary.json'))
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
