import gzip,hashlib,io,json,os,tarfile,time
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
sha=lambda b:hashlib.sha256(b).hexdigest()
with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('r+') as lock:
 acquire_lock(lock,600)
 paths=[]
 directories=['.work/macro-merged-harness-tests-01','.work/experiments/macro-merged-harness-tests-supervisor-01','.work/strict-warm-build/cargo-cache-retirement-02','.work/experiments/cargo-cache-retirement-supervisor-02','.work/strict-warm-build/macro-screen-source-setup-01','.work/experiments/macro-screen-source-setup-supervisor-01','.work/strict-warm-proc-macro-screen-01','.work/experiments/strict-warm-proc-macro-screen-supervisor-01','.work/strict-warm-build/macro-screen-retry-02','.work/experiments/strict-warm-proc-macro-screen-supervisor-02','.work/macro-assessment-02','.work/experiments/strict-warm-proc-macro-assessment-supervisor-02']
 for directory in directories:
  p=root/directory;assert p.is_dir()
  paths.extend(x for x in p.rglob('*') if x.is_file())
 for name in ['.work/run-macro-merged-harness-tests-01.py','.work/retire-completed-cargo-cache-02.py','.work/prepare-macro-screen-source-01.py','.work/run-macro-assessment-02.py','.work/strict-warm-build/macro-build-05-archive-review-01.json','.work/strict-warm-build/macro-screen-02-archive-review-01.json']:
  paths.append(root/name)
 paths.append(Path(__file__).resolve())
 command=Path('/Users/danluu/dev/rust-interp-proc-macro-opt-20260913/.work/host-proc-macro-build-05/screen-command.json')
 paths.append(command)
 members={}
 content=io.BytesIO()
 with tarfile.open(fileobj=content,mode='w') as tar:
  for path in sorted(set(paths)):
   assert not path.is_symlink()
   data=path.read_bytes();assert len(data)<20000000
   name=('primary/'+str(path.relative_to(root))) if path.is_relative_to(root) else 'macro/screen-command.json'
   item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
   tar.addfile(item,io.BytesIO(data));members[name]=dict(source=str(path),bytes=len(data),sha256=sha(data))
 archive=gzip.compress(content.getvalue(),mtime=0)
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
  assert set(tar.getnames())==set(members)
  for name,item in members.items():
   data=tar.extractfile(name).read();assert len(data)==item['bytes'] and sha(data)==item['sha256']
 out=root/'results/strict-warm-proc-macro-screen-02'
 destination=out/'setup-support.tar.gz';assert not destination.exists();destination.write_bytes(archive)
 manifest=dict(schema_version=1,owner=str(root),created_at=time.time(),pid=os.getpid(),canonical_lock=str(Path(lock.name)),archive=dict(path=destination.name,bytes=len(archive),sha256=sha(archive),members=len(members)),files=members)
 (out/'setup-support.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps(manifest['archive']))
