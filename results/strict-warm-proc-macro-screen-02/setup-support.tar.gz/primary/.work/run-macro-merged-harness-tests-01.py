import fcntl, hashlib, json, os, re, signal, subprocess, sys, time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from workflow_io import capture
work=root/'.work/macro-merged-harness-tests-01'
work.mkdir(exist_ok=False)
lock_path=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
assert (root/'.work/benchmark.lock').samefile(lock_path)
paths=sorted(set((root/'scripts').glob('*.py')) | set((root/'tests').glob('*.py')) | set((root/'benchmarks/experiments/strict-warm-build').glob('*.py')) | set((root/'benchmarks/experiments/host-proc-macro').glob('*.py')))
summary=dict(owner=str(root),supervisor_pid=os.getpid(),started_at=time.time(),performance_measurement=False,canonical_lock=str(lock_path),lock_wait_seconds=1800,revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
def save(): (work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
save()
try:
 with lock_path.open('a') as lock:
  def timeout(signum, frame): raise TimeoutError('1800-second lock admission expired; no test child started')
  signal.signal(signal.SIGALRM,timeout); signal.alarm(1800)
  try: fcntl.flock(lock,fcntl.LOCK_EX)
  finally: signal.alarm(0)
  summary['lock_acquired_at']=time.time(); summary['lock_identity']={'device':os.fstat(lock.fileno()).st_dev,'inode':os.fstat(lock.fileno()).st_ino}; save()
  snapshots=work/'sources';snapshots.mkdir()
  for p in paths:
   destination=snapshots/p.relative_to(root); destination.parent.mkdir(parents=True,exist_ok=True); destination.write_bytes(p.read_bytes())
  command=[sys.executable,'-m','unittest','-v','test_custom_compiler_launcher','test_host_proc_macro_launcher','test_strict_warm_screen','test_strict_warm_cargo_screen','test_strict_warm_proc_macro_screen','test_owned_screen_assessment']
  env={k:v for k,v in os.environ.items() if not k.startswith('RUST_INTERP_')}; env['PYTHONPATH']=str(root/'tests'); env['PYTHONDONTWRITEBYTECODE']='1'
  child,out,err=capture(command,cwd=root,env=env,receipt_path=work/'process.json',receipt={})
  (work/'stdout').write_text(out);(work/'stderr').write_text(err)
  counts=re.findall(r'^Ran (\d+) tests? in [\d.]+s$',err,re.M)
  qualified=child.returncode==0 and counts==['43'] and re.search(r'^OK$',err,re.M) and not re.search(r'\b(skipped|FAILED|ERROR|FAIL:)\b',err)
  summary.update(command=command,pid=child.pid,returncode=child.returncode,finished_at=time.time(),expected_tests=43,reported_counts=counts,status='passed' if qualified else 'failed')
  assert all(hashlib.sha256(p.read_bytes()).hexdigest()==summary['source_hashes'][str(p)] for p in paths)
  save();print(json.dumps({k:v for k,v in summary.items() if k!='source_hashes'}));print(err,end='')
  sys.exit(0 if qualified else 1)
except BaseException as error:
 if 'status' not in summary:summary.update(status='failed',error=repr(error),finished_at=time.time());save()
 raise
