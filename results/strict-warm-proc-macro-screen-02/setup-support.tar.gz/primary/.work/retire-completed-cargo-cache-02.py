import gzip,hashlib,json,os,shutil,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json
work=root/'.work/strict-warm-build/cargo-cache-retirement-02';work.mkdir(exist_ok=False)
raw=root/'.work/strict-warm-cargo-info-cache-screen-01';cache=raw/'caches'
summary=dict(status='waiting',owner=str(root),pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),cache=str(cache),canonical_lock='/Users/danluu/dev/rust-interp/.work/benchmark.lock',reason='Completed archived negative Cargo screen; free only owned generated cache space for next fresh screen')
def save():write_json(work/'summary.json',summary)
def sha(b):return hashlib.sha256(b).hexdigest()
def command(argv,label):
 child,out,err=capture(argv,cwd=root,env=os.environ.copy(),receipt_path=work/(label+'-process.json'),receipt={})
 (work/(label+'.stdout')).write_text(out);(work/(label+'.stderr')).write_text(err)
 return child.returncode,out,err
save()
try:
 with Path(summary['canonical_lock']).open('a') as lock:
  acquire_lock(lock,600);summary.update(status='verifying',lock_acquired_at=time.time(),free_bytes_before=shutil.disk_usage(root).free);save()
  assert cache.resolve(strict=True)==cache and cache.is_dir() and not cache.is_symlink()
  cache_identity=(cache.stat().st_dev,cache.stat().st_ino)
  result=root/'results/strict-warm-cargo-info-cache-screen-01'; report=json.loads((result/'summary.json').read_bytes()); archive=result/report['archive']['path']; data=archive.read_bytes()
  assert sha(data)==report['archive']['sha256']; members=json.loads(gzip.decompress(data))['files']; assert len(members)==report['archive']['members']
  for m in members:
   b=m['utf8'].encode();assert sha(b)==m['sha256'] and len(b)==m['bytes']
  completed=json.loads((raw/'summary.json').read_bytes());plan=json.loads((raw/'plan.json').read_bytes());rows=json.loads((raw/'records.json').read_bytes())
  assert completed['status']=='passed' and completed['source_restored'] and len(rows)==completed['commands']==27
  assert sha((raw/'plan.json').read_bytes())==report['plan_sha256']==completed['plan_sha256']
  assert sha((raw/'records.json').read_bytes())==report['records_sha256']==completed['records_sha256']
  supervisor=json.loads((root/'.work/experiments/cargo-info-cache-screen-supervisor-01/status.json').read_bytes());assert supervisor['status']=='finished' and supervisor['returncode']==0
  source=Path(plan['source'])/plan['case']['file']; assert sha(source.read_bytes())==plan['original_source_sha256']
  artifacts={}
  for row in rows:
   receipt=json.loads((raw/'receipts'/f"{row['index']}-{row['mode']}.json").read_bytes());assert receipt['status']=='finished' and receipt['pid']==row['pid'] and receipt['returncode']==row['returncode']
   for item in row['artifacts']:
    path=root/item['path'];assert path.resolve(strict=True).is_relative_to(raw/'artifacts') and not path.is_symlink();b=path.read_bytes();assert sha(b)==item['sha256'] and len(b)==item['bytes'];artifacts[str(path)]=item['sha256']
  expected=dict(schema_version=1,kind='rust-interp-cache',owner=str(root));namespace='rust-interp-'+sha(str(root).encode())[:24]
  assert {p.name for p in cache.iterdir()}=={'baseline','candidate','duplicate'}
  markers={}
  for arm in ('baseline','candidate','duplicate'):
   directory=cache/arm;assert directory.resolve(strict=True)==directory and {p.name for p in directory.iterdir()}=={namespace}
   marker=directory/namespace/'.rust-interp-cache.json';assert not marker.is_symlink() and json.loads(marker.read_bytes())==expected;markers[str(marker)]=expected
  inventory=[]
  for directory,subdirs,names in os.walk(cache,followlinks=False):
   for name in sorted(subdirs+names):
    p=Path(directory)/name;s=p.lstat();assert s.st_dev==cache_identity[0];inventory.append(dict(path=str(p.relative_to(cache)),device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,mtime_ns=s.st_mtime_ns,link=os.readlink(p) if p.is_symlink() else None))
  packed=gzip.compress((json.dumps(inventory,sort_keys=True)+'\n').encode(),mtime=0);(work/'inventory.json.gz').write_bytes(packed)
  code,out,err=command(['/bin/ps','-axo','pid,ppid,lstart,tty,command'],'process-check');assert code==0 and not err
  matches=[line for line in out.splitlines()[1:] if str(cache) in line or raw.name in line]
  (work/'process-check.stdout').write_text('\n'.join(matches)+'\n')
  assert not matches,'active process references completed cache'
  code,out,err=command(['/usr/sbin/lsof','-nP','+D',str(cache)],'open-handle-check');assert code in (0,1) and not err and not out.strip(),'open or unverified cache handles'
  assert (cache.stat().st_dev,cache.stat().st_ino)==cache_identity
  summary.update(status='retiring',quiescence_checked_at=time.time(),archive_sha256=sha(data),archive_members_verified=len(members),artifacts_verified=len(artifacts),markers=markers,inventory_entries=len(inventory),inventory_sha256=sha(packed),matching_processes=matches,matching_open_handles=[]);save()
  shutil.rmtree(cache)
  assert not cache.exists() and all(sha(Path(p).read_bytes())==h for p,h in artifacts.items()) and sha(source.read_bytes())==plan['original_source_sha256']
  summary.update(status='finished',finished_at=time.time(),free_bytes_after=shutil.disk_usage(root).free,artifact_snapshots_preserved=True,original_source_preserved=True);save()
  print(json.dumps({k:v for k,v in summary.items() if k!='markers'}))
except BaseException as error:
 summary.update(status='failed',error=repr(error),finished_at=time.time());save();raise
