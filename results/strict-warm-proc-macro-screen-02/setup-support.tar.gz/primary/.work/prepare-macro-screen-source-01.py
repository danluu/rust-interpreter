import hashlib,json,os,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json,require_space
plan_path=Path('/Users/danluu/dev/rust-interp-proc-macro-opt-20260913/benchmarks/experiments/host-proc-macro/planned-build-05.json')
assert hashlib.sha256(plan_path.read_bytes()).hexdigest()=='765d10c26ea67840752c217cb0207ccae40cc08243fc71ed0a6544890c97cf91'
plan=json.loads(plan_path.read_bytes());prep=plan['project_preparation'];destination=Path(prep['destination'])
work=root/'.work/strict-warm-build/macro-screen-source-setup-01';work.mkdir(exist_ok=False)
summary=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),owner=str(root),started_at=time.time(),plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),canonical_lock='/Users/danluu/dev/rust-interp/.work/benchmark.lock')
def save():write_json(work/'summary.json',summary)
def run(argv,label):
 child,out,err=capture(argv,cwd=root,env=os.environ.copy(),receipt_path=work/(label+'-process.json'),receipt={})
 (work/(label+'.stdout')).write_text(out);(work/(label+'.stderr')).write_text(err)
 assert child.returncode==0,label+' failed'
 return out
save()
try:
 with Path(summary['canonical_lock']).open('a') as lock:
  acquire_lock(lock,600);require_space(root,16)
  assert destination==root/'.work/sources/nushell-proc-macro-opt' and not destination.exists() and not destination.is_symlink()
  assert destination.parent.resolve(strict=True)==destination.parent
  summary.update(status='preparing',lock_acquired_at=time.time());save()
  run(prep['clone_argv'],'clone');run(prep['checkout_argv'],'checkout')
  assert not (destination/'.git/objects/info/alternates').exists()
  assert run(['git','-C',str(destination),'rev-parse','HEAD'],'revision').strip()==prep['revision']
  assert not run(['git','-C',str(destination),'status','--porcelain'],'clean-status').strip()
  write_json(destination/'.rust-interp-owned.json',prep['owner_marker'])
  assert not (destination/'target').exists()
  summary.update(status='passed',finished_at=time.time(),source=str(destination),revision=prep['revision'],marker_sha256=hashlib.sha256((destination/'.rust-interp-owned.json').read_bytes()).hexdigest(),benchmark_commands=0);save()
  print(json.dumps(summary))
except BaseException as error:
 summary.update(status='failed',error=repr(error),finished_at=time.time());save();raise
