import hashlib,json,os,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json
work=root/'.work/macro-assessment-02'
work.mkdir(exist_ok=False)
lock_path=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
record=dict(owner=str(root),pid=os.getpid(),started_at=time.time(),canonical_lock=str(lock_path),status='waiting',benchmark_commands=0)
write_json(work/'status.json',record)
try:
 with lock_path.open('r+') as lock:
  acquire_lock(lock,600)
  record.update(status='running',lock_acquired_at=time.time());write_json(work/'status.json',record)
  raw=root/'.work/strict-warm-proc-macro-screen-02'
  summary=json.loads((raw/'summary.json').read_bytes())
  assert summary['status']=='passed' and summary['commands']==27 and summary['source_restored']
  command=[sys.executable,'-B',str(root/'benchmarks/experiments/strict-warm-build/assess_owned_screen.py'),str(raw),'--run-id','strict-warm-proc-macro-screen-02']
  child,out,err=capture(command,cwd=root,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),receipt_path=work/'process.json',receipt={})
  (work/'stdout').write_text(out);(work/'stderr').write_text(err)
  record.update(status='passed' if child.returncode==0 else 'failed',returncode=child.returncode,child_pid=child.pid,finished_at=time.time(),command=command)
  write_json(work/'status.json',record);print(json.dumps(record));print(out);print(err)
  sys.exit(child.returncode)
except BaseException as error:
 if record['status'] not in ['passed','failed']:
  record.update(status='failed',error=repr(error),finished_at=time.time());write_json(work/'status.json',record)
 raise
