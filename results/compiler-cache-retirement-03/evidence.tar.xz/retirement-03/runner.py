import gzip,hashlib,json,os,shutil,stat,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
from custom_compiler import load_compiler
from workflow_io import capture,write_json
proof=Path('/Users/danluu/dev/rust-interp-std-source-v2-20260913/.work/cache-retirement-admission-04')
work=root/'.work/strict-warm-build/compiler-cache-retirement-03'
work.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=dict(status='waiting',owner=str(root),pid=os.getpid(),started_at=time.time(),deleted=[],benchmark_commands=0)
write_json(work/'summary.json',record)
try:
 with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('r+') as lock:
  acquire_lock(lock,600)
  record.update(lock_acquired_at=time.time(),free_bytes_before=shutil.disk_usage(root).free,canonical_lock=str(Path(lock.name)))
  rec=json.loads((proof/'recommendations.json').read_bytes());plan=json.loads((proof/'plan.json').read_bytes());inspection=json.loads((proof/'inspection.json').read_bytes())
  assert sha(proof/'inspection.json')==rec['inspection_sha256']=='8b15336e246d171b7af7c1000d84cef9331536adcccbf1bdb68ed111e332da9a'
  assert sha(proof/'inventory.jsonl.gz')==rec['inventory_sha256']=='9ee124c389ca1ee1e86caa964c07ecba729fd3a1934a81f5a432136efc145b37'
  choices=[x for x in rec['alternatives'] if x['margin_gib']==0.5];assert len(choices)==1
  selected=[Path(x['path']) for x in choices[0]['sequence']];assert len(selected)==9
  allowed={Path(x['path']) for x in plan['candidates']};assert set(selected)<=allowed
  assert {p.name for p in selected if p.name!='target'}=={'stage1-rustc','stage2-rustc','stage1-tools'}
  assert sum(p.name=='target' for p in selected)==6
  for p in selected:
   assert p.resolve(strict=True)==p and p.is_dir() and not p.is_symlink()
   for retained in map(Path,plan['preserve']):assert p!=retained and not p.is_relative_to(retained) and not retained.is_relative_to(p)
  for p,h in plan['ownership_receipts'].items():assert sha(Path(p))==h
  retained=dict(inspection['macro_guard_files'])|dict(inspection['retained_artifacts'])
  for name in ['strict-warm-stable-cgu-screen-01','strict-warm-proc-macro-screen-02']:
   summary=json.loads((root/'results'/name/'summary.json').read_bytes())
   assert summary['source_restored'] and summary['commands']==27
   archive=root/'results'/name/summary['archive']['path'];assert sha(archive)==summary['archive']['sha256'];retained[str(archive)]=sha(archive)
   for item in summary['artifact_inventory']:
    p=root/item['path'];assert sha(p)==item['sha256'];assert not any(p.is_relative_to(s) for s in selected);retained[str(p)]=item['sha256']
  for p,h in retained.items():assert sha(Path(p))==h
  compiler=load_compiler(root,'60096d7efe02d38269c5694bfd046d4f9facfb65139b2d82173d12345a1c9c46')
  snapshots={p:{} for p in selected};inodes=set()
  with gzip.open(proof/'inventory.jsonl.gz','rt') as stream:
   for line in stream:
    row=json.loads(line);base=Path(row['root'])
    if base in snapshots:snapshots[base][row['path']]=row
  count=0
  for base,expected in snapshots.items():
   entries=[base,*base.rglob('*')];assert {str(p.relative_to(base)) for p in entries}==set(expected)
   for p in entries:
    row=expected[str(p.relative_to(base))];s=p.lstat()
    actual=dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink,blocks=s.st_blocks,link=os.readlink(p) if stat.S_ISLNK(s.st_mode) else None)
    assert all(actual[k]==row[k] for k in actual),(str(p),'candidate changed')
    inodes.add((s.st_dev,s.st_ino));count+=1
  # Inspect active handles and cwd aliases by both path and inode. Keep raw
  # host output local to memory; publish only its digest/count and matching rows.
  matches={}
  for label,argv in [('processes',['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,command=']),('handles',['/usr/sbin/lsof','-nP','-FpcftDin'])]:
   child,out,err=capture(argv,cwd=root,env=os.environ.copy(),receipt_path=work/(label+'-process.json'),receipt={})
   assert child.returncode==0 and not err.strip()
   found=[]
   if label=='processes':found=[line for line in out.splitlines() if any(str(p) in line for p in selected)]
   else:
    process={};entry={}
    def finish():
     name=entry.get('n','')
     try: inode=(int(entry.get('D',''),16),int(entry.get('i','')))
     except ValueError:inode=None
     if inode in inodes or any(name==str(p) or name.startswith(str(p)+'/') for p in selected):found.append(dict(process=process.copy(),file=entry.copy()))
    for line in out.splitlines():
     if not line:continue
     k,v=line[0],line[1:]
     if k=='p':finish();process={'pid':v};entry={}
     elif k=='c':process['command']=v
     elif k=='f':finish();entry={'fd':v}
     else:entry[k]=v
    finish()
   matches[label]=dict(returncode=child.returncode,raw_sha256=hashlib.sha256(out.encode()).hexdigest(),raw_lines=len(out.splitlines()),matching=found,public_output='only candidate matches; complete host output was not retained')
   assert not found,'active candidate user'
  record.update(status='retiring',paths=list(map(str,selected)),entries_verified=count,quiescence=matches,quiescent_at=time.time(),retained_files=retained,proof_files={str(proof/n):sha(proof/n) for n in ['plan.json','inspection.json','recommendations.json','inventory.jsonl.gz']})
  write_json(work/'summary.json',record)
  for p in selected:
   assert p.resolve(strict=True)==p and p.is_dir() and not p.is_symlink()
   shutil.rmtree(p);record['deleted'].append(dict(path=str(p),finished_at=time.time(),free_bytes=shutil.disk_usage(root).free));write_json(work/'summary.json',record)
  for p,h in retained.items():assert sha(Path(p))==h
  assert load_compiler(root,compiler.key)==compiler
  record.update(status='passed',finished_at=time.time(),free_bytes_after=shutil.disk_usage(root).free,compiler_installation_retained=True,retained_files_verified_after=True)
  write_json(work/'summary.json',record)
  print(json.dumps({k:record[k] for k in ['status','pid','free_bytes_before','free_bytes_after','entries_verified','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());write_json(work/'summary.json',record);raise
