import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import time

ROOT = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture, write_json


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


plan = json.loads((WORK / 'plan.json').read_text())
summary = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
    started_at=time.time(), cwd=str(Path.cwd()), argv=sys.argv, lock=plan['canonical_lock'],
    mutation_policy='read-only candidate inspection; no deletion or process control')
write_json(WORK / 'inspection.json', summary)
try:
    with Path(plan['canonical_lock']).open('r+') as lock:
        acquire_lock(lock, 1800)
        summary.update(status='inspecting', lock_acquired_at=time.time(), free_bytes_before=shutil.disk_usage(ROOT).free)
        write_json(WORK / 'inspection.json', summary)
        for name, expected in plan['ownership_receipts'].items():
            if sha(Path(name)) != expected:
                raise RuntimeError('saved ownership receipt changed: ' + name)
        candidates = [Path(row['path']) for row in plan['candidates']]
        for path in candidates:
            if path.resolve(strict=True) != path or not path.is_dir():
                raise RuntimeError('candidate root is missing/indirect: ' + str(path))
            if any(path == other or path.is_relative_to(other) for other in candidates if other != path):
                raise RuntimeError('overlapping candidate roots')
        macro_key = '4dd88495a41b36ba96c8784e2bf82f77de0be5b185ff408e910fdb9e0218ddc1'
        macro_root = Path('/Users/danluu/dev/rust-interp-proc-macro-opt-20260913')
        protected = [Path(p) for p in plan['preserve']]
        protected += [macro_root / '.work/host-proc-macro-build-05',
            macro_root / '.work/interpreter-tools' / macro_key,
            ROOT / '.work/interpreter-tools' / macro_key]
        for path in candidates:
            for keep in protected:
                if path == keep or path.is_relative_to(keep) or keep.is_relative_to(path):
                    raise RuntimeError('candidate overlaps retained dependency: ' + str(path))
        guards = {}
        for owner in [ROOT, macro_root]:
            directory = owner / '.work/interpreter-tools' / macro_key
            for name in ['source.json', 'publication.json', 'publication-guard.json',
                         'provenance/compiler-inputs.json', 'provenance/libraries.json',
                         'provenance/dependencies.json', 'provenance/correctness.json',
                         'provenance/std-ready.json']:
                path = directory / name
                guards[str(path)] = sha(path)
                def check(value):
                    if isinstance(value, str) and value.startswith('/'):
                        p = Path(value)
                        if any(p == c or p.is_relative_to(c) for c in candidates):
                            raise RuntimeError('live macro proof depends on candidate: ' + value)
                    elif isinstance(value, dict):
                        for k, v in value.items():
                            check(k); check(v)
                    elif isinstance(value, list):
                        for v in value:
                            check(v)
                check(json.loads(path.read_text()))
        summary['macro_guard_files'] = guards
        from custom_compiler import load_compiler
        compiler = load_compiler(ROOT, '60096d7efe02d38269c5694bfd046d4f9facfb65139b2d82173d12345a1c9c46')
        archive = Path('/Users/danluu/dev/rust-interp-stable-cgu-20260913/.work/stable-cgu-compiler-setup-01/rust-dev-nightly-aarch64-apple-darwin.tar.xz')
        actual = sha(archive)
        if actual != '0035445cb01c652999862c240d3c8ce663247abdc410482dde10f9e9c264bf8f':
            raise RuntimeError('preserved exact-base LLVM archive changed')
        summary['preserved_llvm_archive'] = dict(path=str(archive), sha256=actual)
        summary['preserved_installed_compiler'] = dict(key=compiler.key, sysroot=str(compiler.sysroot), files=len(compiler.identity['files']))
        llvm_files = ['lib/libLLVM.dylib','lib/rustlib/aarch64-apple-darwin/lib/libLLVM.dylib','lib/rustlib/aarch64-apple-darwin/bin/rust-objcopy']
        for name in llvm_files:
            if sha(compiler.sysroot / name) != compiler.identity['files'][name]:
                raise RuntimeError('retained compiler LLVM/support bytes changed')
        summary['verified_retained_llvm_support_files'] = llvm_files
        screen = json.loads((ROOT / 'results/strict-warm-stable-cgu-screen-01/summary.json').read_text())
        artifacts = {}
        for row in screen['artifact_inventory']:
            path = ROOT / row['path']
            actual = sha(path)
            if actual != row['sha256']:
                raise RuntimeError('retained screen artifact changed')
            artifacts[str(path)] = actual
        for name, expected in [
            ('results/strict-warm-stable-cgu-screen-01/evidence.json.gz', '678c4d13129871a58197ed0361d7cfd7e83ed87183839f9908d81332eda4d3aa'),
            ('results/stable-cgu-activation-01/evidence.tar.xz', '184b3ee547ea27587aeeb5a08052a38f595d048d908573cda16cc87a162c8234')]:
            if sha(ROOT / name) != expected:
                raise RuntimeError('verified archive changed')
        summary['retained_artifacts'] = artifacts
        rows, inodes = [], {}
        with gzip.open(WORK / 'inventory.jsonl.gz', 'wt') as output:
            for path in candidates:
                totals = dict(path=str(path), entries=0, files=0, symlinks=0, logical_bytes=0, allocated_bytes=0)
                for directory, dirs, files in os.walk(path, followlinks=False):
                    current = Path(directory)
                    names = [current] if current == path else []
                    names += [current / name for name in [*dirs, *files]]
                    for item in names:
                        st = item.lstat()
                        row = dict(root=str(path), path=str(item.relative_to(path)), device=st.st_dev,
                            inode=st.st_ino, mode=st.st_mode, bytes=st.st_size, blocks=st.st_blocks,
                            nlink=st.st_nlink, mtime_ns=st.st_mtime_ns, ctime_ns=st.st_ctime_ns,
                            link=os.readlink(item) if stat.S_ISLNK(st.st_mode) else None)
                        output.write(json.dumps(row, sort_keys=True) + '\n')
                        totals['entries'] += 1
                        if stat.S_ISREG(st.st_mode):
                            totals['files'] += 1
                            totals['logical_bytes'] += st.st_size
                            totals['allocated_bytes'] += st.st_blocks * 512
                            identity = (st.st_dev, st.st_ino)
                            inode = inodes.setdefault(identity, dict(blocks=st.st_blocks, nlink=st.st_nlink, count=0))
                            inode['count'] += 1
                        elif stat.S_ISLNK(st.st_mode):
                            totals['symlinks'] += 1
                        elif not stat.S_ISDIR(st.st_mode):
                            raise RuntimeError('unsupported candidate entry: ' + str(item))
                rows.append(totals)
        summary['candidates'] = rows
        summary['unique_inode_allocated_bytes'] = sum(v['blocks'] * 512 for v in inodes.values())
        summary['candidate_only_link_allocated_bytes'] = sum(v['blocks'] * 512 for v in inodes.values() if v['count'] == v['nlink'])
        summary['shared_external_link_inodes'] = sum(v['count'] < v['nlink'] for v in inodes.values())
        summary['inventory_sha256'] = sha(WORK / 'inventory.jsonl.gz')
        for label, command in [('processes', ['/bin/ps', '-axo', 'pid=,ppid=,pgid=,lstart=,command=']),
                               ('handles', ['/usr/sbin/lsof', '-nP', '-FpcftDin'])]:
            child, stdout, stderr = capture(command, cwd=WORK, env=os.environ.copy(),
                receipt_path=WORK / (label + '-process.json'), receipt=dict(phase=label))
            (WORK / (label + '.stdout')).write_text(stdout)
            (WORK / (label + '.stderr')).write_text(stderr)
            summary[label + '_returncode'] = child.returncode
            summary[label + '_stderr_nonempty'] = bool(stderr.strip())
            if label == 'processes':
                summary['matching_process_lines'] = [line for line in stdout.splitlines()
                    if any(str(p) in line for p in candidates)]
            else:
                matches, process, file = [], {}, {}
                def finish():
                    path = file.get('n', '')
                    exact = any(path == str(p) or path.startswith(str(p) + '/') for p in candidates)
                    try:
                        inode = (int(file.get('D', ''), 16), int(file.get('i', '')))
                    except ValueError:
                        inode = None
                    if exact or inode in inodes:
                        matches.append(dict(process=process.copy(), file=file.copy(), path_match=exact, inode_match=inode in inodes))
                for line in stdout.splitlines():
                    if not line: continue
                    field, value = line[0], line[1:]
                    if field == 'p':
                        finish(); file = {}; process = {'pid': value}
                    elif field == 'c': process['command'] = value
                    elif field == 'f':
                        finish(); file = {'fd': value}
                    else: file[field] = value
                finish()
                summary['matching_open_handles'] = matches
        summary.update(status='inspection completed; no retirement performed', finished_at=time.time(),
            free_bytes_after=shutil.disk_usage(ROOT).free,
            handle_evidence_scope='current user visibility only; stderr/permission gaps remain unresolved',
            reclamation_scope='allocated blocks deduplicated by inode; APFS shared extents mean actual reclaimed space is not guaranteed',
            no_users_proved=not summary['matching_process_lines'] and not summary['matching_open_handles']
                and summary['processes_returncode'] == 0 and summary['handles_returncode'] == 0
                and not summary['handles_stderr_nonempty'],
            recheck_required_before_any_retirement=True)
        write_json(WORK / 'inspection.json', summary)
        print(json.dumps({k: summary[k] for k in ['status', 'pid', 'lock_acquired_at', 'finished_at',
            'free_bytes_after', 'unique_inode_allocated_bytes', 'candidate_only_link_allocated_bytes', 'no_users_proved']}), flush=True)
except BaseException as error:
    summary.update(status='failed inspection; no retirement performed', error=repr(error), finished_at=time.time())
    write_json(WORK / 'inspection.json', summary)
    raise
