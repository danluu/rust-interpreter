#!/usr/bin/env python3
"""Run only the three pure B2 metadata-plan controls; no real compiler inputs."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

ROOT=Path('/Users/danluu/dev/rust-interp-beta-auxiliary-sysroot-20260913')
HERE=ROOT/'.work/beta-auxiliary-metadata-source-01'
WORK=ROOT/'.work/beta-auxiliary-metadata-controls-01'
FREEZE=ROOT/'.work/beta-auxiliary-metadata-controls-source-01/inputs.json'
FREEZE_SHA='317842daada49095eb23ef3ff09213ef47a7fe655cbaa9fbe0570c044b85690c'
OWNED=Path('/Users/danluu/dev/rust-interp-beta-auxiliary-sysroot-20260913/experiments/stable-cgu/owned_stage.py')
OWNED_SHA='7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e'
ADMISSION=ROOT/'.work/beta-auxiliary-metadata-controls-admission-01.json'
PYTHON=Path('/opt/homebrew/bin/python3')
NAMES=['test_future_stock_roles_and_debug_object_strip_are_distinct', 'test_macho_declarations_retain_raw_and_reject_hidden_environment', 'test_only_exact_original_closure_plus_beta_copy_passes']


def require(ok,message):
    if not ok:raise RuntimeError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ordinary(path):
    path=Path(path)
    require(path.is_absolute() and path.is_file() and not path.is_symlink() and path.resolve(strict=True)==path,
        'expected ordinary control input: '+str(path))
    return path


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--helper-sha',required=True)
    parser.add_argument('--admission-sha',required=True)
    args=parser.parse_args()
    require(sys.dont_write_bytecode and not sys.flags.optimize and Path.cwd()==ROOT,'fixed cwd and Python -B required')
    require(Path(__file__).resolve()==ROOT/'.work/run_beta_auxiliary_metadata_controls_01.py','fixed helper path required')
    require(sha(ordinary(__file__))==args.helper_sha and sha(ordinary(ADMISSION))==args.admission_sha,'reviewed helper/admission changed')
    require(sha(ordinary(FREEZE))==FREEZE_SHA and sha(ordinary(OWNED))==OWNED_SHA,'source freeze or owned supervisor changed')
    freeze=json.loads(FREEZE.read_bytes())
    require(freeze['controls']==3 and len(freeze['files'])==7 and freeze['compositor_source_commit']=='95d9501b43848fdbe640fd14c2a88da95da48903' and set(freeze['files'])==set(freeze['snapshots']),
        'exact independent source closure required')
    require(str(Path(sys.executable).resolve(strict=True))==freeze['python']['resolved']
        and sha(sys.executable)==freeze['python']['sha256'] and PYTHON.resolve(strict=True)==Path(freeze['python']['resolved']),
        'exact retained Python identity required')
    sources=dict(freeze['files'])|{str(FREEZE):FREEZE_SHA,str(Path(__file__).resolve()):args.helper_sha,str(ADMISSION):args.admission_sha}
    for path,snapshot in freeze['snapshots'].items():sources[snapshot]=freeze['files'][path]
    def guard():
        for path,expected in sources.items():require(sha(ordinary(path))==expected,'frozen control input changed: '+path)
        require(sha(sys.executable)==freeze['python']['sha256'],'Python changed')
    guard()
    spec=importlib.util.spec_from_file_location('split_role_controls_owned',OWNED)
    owned=importlib.util.module_from_spec(spec);sys.modules[spec.name]=owned;spec.loader.exec_module(owned)
    WORK.mkdir(exist_ok=False);(WORK/'tmp').mkdir()
    record=dict(schema_version=1,status='waiting',owner=str(ROOT),pid=os.getpid(),parent_pid=os.getppid(),
        started_at=time.time(),helper_sha256=args.helper_sha,admission_sha256=args.admission_sha,source_freeze_sha256=FREEZE_SHA,
        canonical_lock=str(owned.CANONICAL_LOCK),wait_seconds=600,python=freeze['python'],
        compiler_commands=0,stock_guard_calls=0,exporter_execution=False,benchmark=False,real_archive_reads=0,real_compiler_input_reads=0,compositor_source_commit=freeze['compositor_source_commit'])
    owned.write(WORK/'summary.json',record)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK,600):
            record.update(status='running',admitted_at=time.time(),free_bytes_before=owned.disk(ROOT));owned.write(WORK/'summary.json',record)
            guard()
            tree=ast.parse((HERE/'test_controls.py').read_bytes())
            names=sorted(node.name for cls in tree.body if isinstance(cls,ast.ClassDef) and cls.name=='MetadataTests'
                for node in cls.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_'))
            require(names==NAMES,'reviewed three test definitions differ')
            snapshots={}
            for path,expected in sorted(sources.items()):
                owned.disk(ROOT)
                raw=Path(path).read_bytes();require(hashlib.sha256(raw).hexdigest()==expected,'input changed while copying')
                dest=WORK/'sources'/path.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True)
                with dest.open('xb') as output:output.write(raw)
                snapshots[path]=dict(path=str(dest),sha256=expected,bytes=len(raw))
            env=dict(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',HOME='/Users/danluu',
                TMPDIR=str(WORK/'tmp')+'/',LANG='C',LC_ALL='C',TZ='UTC',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
            command=[str(PYTHON),'-B','-m','unittest','discover','-s',str(HERE),'-p','test_controls.py','-v']
            record.update(sources=sources,snapshots=snapshots,required_tests=NAMES,environment=env,command=command)
            owned.write(WORK/'summary.json',record)
            try:
                child=owned.run(command,cwd=ROOT,env=env,out=WORK/'command',capacity_root=ROOT)
            finally:
                if (WORK/'command/receipt.json').exists():record['command_receipt_sha256']=sha(WORK/'command/receipt.json')
                guard()
                for row in snapshots.values():require(sha(ordinary(row['path']))==row['sha256'],'retained control source changed')
                record['all_inputs_unchanged']=True;owned.write(WORK/'summary.json',record)
            require(not (WORK/'command/stdout').read_bytes(),'unexpected pure-control stdout')
            text=(WORK/'command/stderr').read_text()
            actual=re.findall(r'^test_[^\n]* \(test_controls\.MetadataTests\.([^)]+)\) \.\.\. ok$',text,re.M)
            require(sorted(actual)==NAMES and len(actual)==3 and re.search(r'^Ran 3 tests in [0-9.]+s$',text,re.M)
                and text.rstrip().endswith('OK') and 'skipped' not in text,'exact three passing unfiltered controls required')
            record.update(status='passed',finished_at=time.time(),free_bytes_after=owned.disk(ROOT),actual_tests=actual,
                source_files=7,retained_inputs=len(sources),driver_imported=False,compiler_or_sysroot_inspected=False)
            owned.write(WORK/'summary.json',record)
    except BaseException as error:
        record.update(status='failed',error=repr(error),finished_at=time.time());owned.write(WORK/'summary.json',record);raise


if __name__=='__main__':main()
