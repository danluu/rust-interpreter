"""Three pure AST-extracted controls; no driver imports or real input reads."""
import ast
import copy
import hashlib
from pathlib import Path
import re
from types import SimpleNamespace
import unittest


class MetadataTests(unittest.TestCase):
    def setUp(self):
        source = Path(__file__).with_name('check.py')
        tree = ast.parse(source.read_bytes())
        names = {'require', 'declarations', 'check_composition', 'future_commands'}
        selected = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
        self.assertEqual({node.name for node in selected}, names)
        self.ns = dict(Path=Path, re=re, hashlib=hashlib, B2=Path('/fresh/build-sysroot'),
                       OUTPUT=Path('/fresh'), HOST='aarch64-apple-darwin', LLVM_SHA='a' * 64,
                       TOOL='lib/rustlib/aarch64-apple-darwin/bin/rust-objcopy',
                       COPY=dict(source_destination='lib/libLLVM.dylib',
                                 destination='lib/rustlib/aarch64-apple-darwin/lib/libLLVM.dylib'),
                       DEBUG_SOURCE=b'fn main() {}\n')
        exec(compile(ast.Module(body=selected, type_ignores=[]), str(source), 'exec'), self.ns)

    def test_only_exact_original_closure_plus_beta_copy_passes(self):
        original = dict(files={f'lib/member{i}': dict(sha256=str(i)) for i in range(333)},
                        private=[dict(index=i) for i in range(256)], stamp_hex='00',
                        build_compiler={'path': '/D'}, runtime_driver={'path': '/E/driver'},
                        archives=[{'path': '/beta'}], runtime_source_commit='1' * 40)
        original['files']['lib/libLLVM.dylib'] = dict(sha256='a' * 64, size=2)
        new = copy.deepcopy(original)
        new['archive_copies'] = [self.ns['COPY']]
        destination = self.ns['COPY']['destination']
        new['files'][destination] = copy.deepcopy(original['files']['lib/libLLVM.dylib'])
        self.ns['check_composition'](original, new)
        for field in ['copy', 'private', 'archive', 'omission']:
            changed = copy.deepcopy(new)
            if field == 'copy':
                changed['files'][destination]['sha256'] = 'b' * 64
            elif field == 'private':
                changed['private'][0]['index'] = 99
            elif field == 'archive':
                changed['archives'][0]['path'] = '/other'
            else:
                changed['files']['lib/different'] = changed['files'].pop('lib/member0')
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                self.ns['check_composition'](original, changed)

    def test_future_stock_roles_and_debug_object_strip_are_distinct(self):
        stock = SimpleNamespace(D=Path('/D/bin/rustc'), B=Path('/B'), E=Path('/E'), OUTPUT_ROOT=Path('/old-smoke'))
        before = ['/D/bin/rustc', '--sysroot=/B', '--extern', 'rustc_driver=/B/lib/driver.dylib',
                  '--extern', 'rustc_driver=/B/lib/driver.rmeta', '-Lnative=/E/lib',
                  '-C', 'link-arg=-Wl,-rpath,/E/lib', '-o', '/old-smoke/smoke-rustc']
        old = dict(source='/source/main.rs', source_sha256='c' * 64, sdk={'clang': '/SDK/clang'},
                   build_environment={'RUSTC_BOOTSTRAP': '1'}, application_environment={'LANG': 'C'})
        result = self.ns['future_commands'](old, before, stock)
        self.assertEqual(result['stock_build'][0], '/D/bin/rustc')
        self.assertEqual(result['stock_build'][-1], '/fresh/stock-smoke/smoke-rustc')
        self.assertIn('--sysroot=/fresh/build-sysroot', result['stock_build'])
        self.assertIn('-Lnative=/E/lib', result['stock_build'])
        self.assertIn('link-arg=-Wl,-rpath,/E/lib', result['stock_build'])
        self.assertEqual(result['application_sysroot'], '/E')
        self.assertIn('--emit=obj', result['debug_build'])
        self.assertIn('-Cdebuginfo=2', result['debug_build'])
        self.assertIn('-Cstrip=none', result['debug_build'])
        self.assertEqual(result['strip'][1:], ['--strip-debug', '/fresh/strip-control/before.o', '/fresh/strip-control/after.o'])
        self.assertEqual(result['strip_environment'], {'LANG': 'C', 'DYLD_PRINT_LIBRARIES': '1'})
        self.assertFalse(result['object_execution'])
        self.assertFalse(result['commands_executed'])
        self.assertEqual(before[-1], '/old-smoke/smoke-rustc')

    def test_macho_declarations_retain_raw_and_reject_hidden_environment(self):
        raw = ('binary:\nLoad command 0\n cmd LC_ID_DYLIB\n name @rpath/self (offset 24)\n'
               'Load command 1\n cmd LC_RPATH\n path @loader_path/../lib (offset 12)\n'
               'Load command 2\n cmd LC_LOAD_DYLIB\n name @rpath/libLLVM.dylib (offset 24)\n')
        result = self.ns['declarations'](raw)
        self.assertEqual(result['raw'], raw)
        self.assertEqual(result['sha256'], hashlib.sha256(raw.encode()).hexdigest())
        self.assertEqual(result['rpaths'], ['@loader_path/../lib'])
        self.assertEqual(result['loads'], [['LC_LOAD_DYLIB', '@rpath/libLLVM.dylib']])
        for changed in ['', raw.replace('LC_RPATH', 'LC_DYLD_ENVIRONMENT'),
                        raw.replace('LC_LOAD_DYLIB', 'LC_UNKNOWN_DYLIB'), raw.replace('name @rpath/libLLVM', 'missing @rpath/libLLVM')]:
            with self.subTest(changed=changed), self.assertRaises(RuntimeError):
                self.ns['declarations'](changed)


if __name__ == '__main__':
    unittest.main(verbosity=2)
