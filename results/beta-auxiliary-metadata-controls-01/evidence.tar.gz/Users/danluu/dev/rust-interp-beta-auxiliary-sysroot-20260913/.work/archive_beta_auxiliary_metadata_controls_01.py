#!/usr/bin/env python3
"""Retain completed pure metadata controls using the existing tar route."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-beta-auxiliary-sysroot-20260913')
RAW = ROOT / '.work/beta-auxiliary-metadata-controls-01'
SUPERVISOR = ROOT / '.work/experiments/beta-auxiliary-metadata-controls-supervisor-01'
LAUNCH = ROOT / '.work/beta-auxiliary-metadata-controls-launch-01.json'
OUT = ROOT / 'results/beta-auxiliary-metadata-controls-01'
WORK = ROOT / '.work/beta-auxiliary-metadata-controls-archive-01'
OWNED = ROOT / 'experiments/stable-cgu/owned_stage.py'
EXPECTED_SUMMARY = 'a5ab8d9245f238f07855ac9ac485d97fb198bddc7939e85950b297db5248203e'
EXPECTED_CHILD = '837a3ff32bbaf731ff3ba536a118f854d5f51000b22ff395657aa960a83b16fd'
REVISION = '95d9501b43848fdbe640fd14c2a88da95da48903'


def digest(data):
    return hashlib.sha256(data).hexdigest()


assert digest(OWNED.read_bytes()) == '7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e'
sys.path.insert(0, str(OWNED.parent))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--helper-sha', required=True)
    args = parser.parse_args()
    require(sys.dont_write_bytecode and not sys.flags.optimize and Path.cwd() == ROOT,
            'fixed cwd and Python -B required')
    require(Path(__file__).resolve() == ROOT / '.work/archive_beta_auxiliary_metadata_controls_01.py'
            and sha(__file__) == args.helper_sha, 'reviewed archive source changed')
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
                  started_at=time.time(), helper_sha256=args.helper_sha,
                  lock=str(CANONICAL_LOCK), lock_wait_seconds=600)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            payloads = {}

            def capture(path, expected=None):
                path = Path(path)
                require(path.is_absolute() and path.resolve(strict=True) == path
                        and path.is_file() and not path.is_symlink(), 'nonordinary evidence path')
                data = path.read_bytes()
                require(expected is None or digest(data) == expected, 'evidence source changed: ' + str(path))
                if str(path) in payloads:
                    require(payloads[str(path)] == data, 'evidence changed during capture')
                payloads[str(path)] = data
                return data

            test = json.loads(capture(RAW / 'summary.json', EXPECTED_SUMMARY))
            require(test['status'] == 'passed' and test['compositor_source_commit'] == REVISION
                    and test['source_files'] == 7 and len(test['sources']) == 17
                    and test['all_inputs_unchanged'] and test['command_receipt_sha256'] == EXPECTED_CHILD
                    and test['real_archive_reads'] == test['real_compiler_input_reads'] == 0
                    and test['stock_guard_calls'] == test['compiler_commands'] == 0
                    and not test['driver_imported'] and not test['compiler_or_sysroot_inspected'],
                    'exact passing pure-control history required')
            for path, expected in test['sources'].items():
                capture(path, expected)
            for path, row in test['snapshots'].items():
                require(row['sha256'] == test['sources'][path], 'test snapshot association differs')
                require(len(capture(row['path'], row['sha256'])) == row['bytes'], 'snapshot size differs')
            require(set(test['snapshots']) == set(test['sources']), 'test source snapshots incomplete')
            child = json.loads(capture(RAW / 'command/receipt.json', EXPECTED_CHILD))
            require(child['status'] == 'finished' and child['returncode'] == 0
                    and child['cwd'] == str(ROOT) and child['command'] == test['command']
                    and child['environment'] == test['environment'] and child['supervisor_pid'] == test['pid']
                    and child['parent_pid'] == test['parent_pid']
                    and test['admitted_at'] <= child['started_at'] <= child['finished_at'] <= test['finished_at'],
                    'completed test command/environment/process association differs')
            require(not capture(RAW / 'command/stdout', child['stdout_sha256']), 'unexpected test stdout')
            stderr = capture(RAW / 'command/stderr', child['stderr_sha256']).decode()
            actual = re.findall(r'^test_[^\n]* \(test_controls\.MetadataTests\.([^)]+)\) \.\.\. ok$', stderr, re.M)
            require(len(actual) == 3 and actual == test['actual_tests'] == test['required_tests']
                    and re.search(r'^Ran 3 tests in [0-9.]+s$', stderr, re.M)
                    and stderr.rstrip().endswith('OK') and 'skipped' not in stderr,
                    'three actual unfiltered passing names required')
            outer = json.loads(capture(SUPERVISOR / 'status.json', '10b73a85ac23c46f9473f8a7bf34dbed28aed7d7dcd42a6bbbae1d0c4f52d836'))
            plan = json.loads(capture(SUPERVISOR / 'plan.json', outer['plan_sha256']))
            require(outer['status'] == 'finished' and outer['returncode'] == 0
                    and outer['child_pid'] == test['pid'] and outer['supervisor_pid'] == test['parent_pid']
                    and outer['started_at'] <= test['started_at'] <= test['finished_at'] <= outer['finished_at']
                    and outer['command'] == plan['command'] and outer['cwd'] == plan['owner'] == str(ROOT),
                    'outer supervisor association differs')
            capture(SUPERVISOR / 'command.log', outer['log_sha256'])
            capture(SUPERVISOR / 'supervisor.log')
            launch = json.loads(capture(LAUNCH, '9d0ef9bde06a0123f2a5a46f0aa89e3f949dde10f24452065d6b7a0216740f0c'))
            admission = json.loads(capture(launch['admission'], launch['admission_sha256']))
            require(plan['command'] == launch['command'][launch['command'].index('--') + 1:]
                    and admission['helper_sha256'] == test['helper_sha256']
                    and launch['admission_sha256'] == test['admission_sha256']
                    and admission['source_freeze_sha256'] == test['source_freeze_sha256'],
                    'saved launch/admission/helper association differs')
            for suffix in ('.stdout', '.stderr'):
                capture(LAUNCH.with_suffix(suffix))
            metadata_launch = json.loads(capture(ROOT / '.work/beta-auxiliary-metadata-launch-01.json',
                '6dbbf314211012a6a48d20c2315dad81967e090ab95ba426a86f180332228ba3'))
            capacity = json.loads(capture(ROOT / '.work/beta-auxiliary-metadata-capacity-01.json',
                'bd6c86419d40be7931b97afd9214aa2f847e2167c94ec2ac6aada26daf36488d'))
            readiness = json.loads(capture(ROOT / '.work/beta-auxiliary-metadata-readiness-01.json',
                '07c1307ec2d01166bdbca133f9bd75df39fb98a4b7a7d9b729fc1213eb983f6c'))
            require(metadata_launch['stage'] == 'metadata-only'
                    and metadata_launch['capacity'] == dict(entry_gib=16, stop_gib=9, floor_gib=8)
                    and metadata_launch['helper']['sha256'] == test['sources'][metadata_launch['helper']['path']]
                    and metadata_launch['inputs']['sha256'] == test['sources'][metadata_launch['inputs']['path']]
                    and capacity['status'] == 'metadata-not-launched-capacity-low'
                    and capacity['controls_summary_sha256'] == EXPECTED_SUMMARY
                    and capacity['metadata_launch_sha256'] == readiness['metadata_launch']['sha256']
                    and not capacity['metadata_attempt_started']
                    and capacity['free_bytes'] < capacity['required_bytes'] == 16 * (1 << 30)
                    and readiness['as_of'] == capacity['checked_at'],
                    'metadata candidate or dated capacity observation changed')
            readme = capture(ROOT / '.work/beta-auxiliary-metadata-controls-archive-README-01.md',
                'b920bc4fccd71db07b9a5fafa560c3c3d9482c2e2752e22e822304cadf5cedaa')
            for path in [Path(__file__), ROOT / '.work/beta-auxiliary-metadata-source-01/debug-object-plan.diff',
                         ROOT / '.work/beta-auxiliary-metadata-controls-archive-launch-01.json']:
                capture(path)
            OUT.mkdir(parents=True, exist_ok=False)
            archive = OUT / 'evidence.tar.gz'
            manifest = {}
            with archive.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for source, data in sorted(payloads.items()):
                            disk(ROOT)
                            name = source.lstrip('/')
                            member = tarfile.TarInfo(name)
                            member.size, member.mode = len(data), 0o644
                            tar.addfile(member, io.BytesIO(data))
                            manifest[name] = dict(source=source, bytes=len(data), sha256=digest(data))
            seen = set()
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    disk(ROOT)
                    require(member.isfile() and member.name not in seen, 'invalid archive member')
                    seen.add(member.name)
                    item = manifest[member.name]
                    with tar.extractfile(member) as stream:
                        data = stream.read()
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback differs')
            require(seen == set(manifest), 'archive readback incomplete')
            require(all(capture(path) == data for path, data in list(payloads.items())), 'retained input changed')
            write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed', compositor_source_commit=REVISION, raw=str(RAW),
                supervisor=str(SUPERVISOR), controls=3, skipped=0, actual_tests=actual,
                test_pid=child['pid'], helper_pid=test['pid'], supervisor_pid=outer['supervisor_pid'],
                test_command=child['command'], test_seconds=child['finished_at'] - child['started_at'],
                actual_test_summary_sha256=EXPECTED_SUMMARY, actual_test_receipt_sha256=EXPECTED_CHILD,
                tested_sources=test['sources'], all_sources_unchanged=True,
                archive=dict(path=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
                             members=len(manifest), all_member_hashes_verified=True, gzip_mtime=0),
                manifest_sha256=sha(OUT / 'manifest.json'), archive_helper_sha256=args.helper_sha,
                archive_pid=os.getpid(), archive_parent_pid=os.getppid(), archive_admitted_at=record['admitted_at'],
                real_archive_reads=0, real_compiler_input_reads=0, assembly_performed=False,
                compiler_commands=0, runtime_qualification=False, performance_claim=False,
                metadata_candidate=metadata_launch['helper'], metadata_readiness=readiness,
                scope='three AST-extracted pure metadata controls; no workload import or real input inspection')
            write(OUT / 'summary.json', summary)
            (OUT / 'README.md').write_bytes(readme)
            record.update(status='passed', finished_at=time.time(), free_bytes_after=disk(ROOT),
                          result=str(OUT), archive=summary['archive'], summary_sha256=sha(OUT / 'summary.json'))
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
