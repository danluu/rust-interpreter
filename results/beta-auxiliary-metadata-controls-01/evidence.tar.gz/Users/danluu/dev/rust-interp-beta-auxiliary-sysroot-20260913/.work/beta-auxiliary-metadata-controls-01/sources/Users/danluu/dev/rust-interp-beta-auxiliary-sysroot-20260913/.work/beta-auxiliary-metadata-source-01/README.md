# B2 metadata successor (not executed)

The compositor source is qualified by ten passing synthetic controls at
`95d9501b43848fdbe640fd14c2a88da95da48903`, retained in the 49-member archive
`6090f8f8e39d782eb278275751750c61b796163ef67c2721bb07bfbeba2be215`.
The frozen historical B2-PLAN.md and proposal predate those tests; their
"unrun" wording describes that earlier source checkpoint. This new metadata
runner and its three pure controls are unrun. No real B2 composition, auxiliary
loader/strip operation or exporter rebuild is qualified.

Only metadata is callable. The new helper composes the unchanged stock03
guard/check_plan/b_guard/probe/amended-command methods using a separate adapter;
it does not invoke the old constructor or modify old module globals/paths.
Before accepting the new composition it revalidates original675 inputs, all
native005/stamp/producer/source/E proofs, B334 and the actual passing stock340c
history. It then invokes the qualified compositor with the one explicit beta
LLVM member copy. The original334 rows and full256 private entries must remain
exactly equal; only the new target-library destination is added.

Metadata records actual D/E version/sysroot/loaded-library probes, unchanged SDK
discovery, and original auxiliary/LLVM Mach-O declarations. The future B2
helper must load beta LLVM0d514b73 at the new target-lib destination. The
exporter/stock compiler's explicit native link search and runtime rpath remain
E/lib, with the two exact driver dylib+rmeta externs rebased to B2. Their actual
new loader proofs remain separate requirements after approved assembly/build.

The future strip control explicitly compiles a debug-bearing Mach-O object
with `--emit=obj`, full debug info and stripping disabled. It must prove DWARF
sections exist before `rust-objcopy --strip-debug`, disappear afterward, and
that the original source/object remain unchanged. The strip command has its
own frozen environment including DYLD_PRINT_LIBRARIES=1. An object is not
executed; native behavior belongs to the separate stock fixture controls.
This avoids assuming Apple's linked executable embeds its object DWARF.

The helper writes only its fresh metadata directory and input snapshots. The
proposed assembly/output directory must remain absent throughout metadata.
It retains per-child argv/environment/PID/raw receipts, source/runtime guards
and the full335 composition hash. Entry16GiB, active9GiB stop and8GiB floor,
canonical600 and exact original environments remain unchanged. A future
assembly needs a separately reviewed materialized plan and capacity admission.
There is no compiler build or assembly method, implicit retry, B334 mutation,
version override, warning suppression, publication or performance claim.
