#!/usr/bin/env python3
"""Metadata only: freeze a fresh B2 plan using the qualified predecessor guards."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
from types import SimpleNamespace

OWNER = Path('/Users/danluu/dev/rust-interp-beta-auxiliary-sysroot-20260913')
HERE = OWNER / '.work/beta-auxiliary-metadata-source-01'
WORK = OWNER / '.work/beta-auxiliary-metadata-01'
OUTPUT = OWNER / '.work/beta-auxiliary-sysroot-01'
B2 = OUTPUT / 'build-sysroot'
PLAN = WORK / 'planned.json'
FROZEN = HERE / 'inputs.json'
COMPOSITOR = OWNER / 'experiments/embedded-frontend-bootstrap/compose_sysroot.py'
PROPOSAL = OWNER / 'experiments/embedded-frontend-bootstrap/B2-PROPOSAL.json'
EMBED = Path('/Users/danluu/dev/rust-interp-embedded-frontend-bootstrap-20260913')
STOCK_CODE = EMBED / '.work/embedded-frontend-compatibility-source-03/run.py'
STOCK_FREEZE = EMBED / '.work/embedded-frontend-compatibility-source-03/frozen.json'
STOCK_RECEIPT = EMBED / '.work/embedded-frontend-compatibility-smoke-02/stages/smoke-02/receipt.json'
STOCK_PINS = dict(frozen_sha='010a3cd179c22ce9335c0992796dabbd7d22eefe91e1daed697eb840ace7f6ec',
    plan_sha='7af688db0a0881b22bf5257b808e921697a338bd77ae81bd8ed2ca32c3f1c029',
    assembly_sha='5995f293871e5de5cc8d90caa3adaf5d463bf9f51f618b7e3fc88be04dd8f0b9')
STOCK_SHA = '340c7e7b7e2fd96412fc1584f5de31f2d752a8bed924b4d0ff91841aadf02374'
HOST = 'aarch64-apple-darwin'
COPY = dict(source_destination='lib/libLLVM.dylib', destination=f'lib/rustlib/{HOST}/lib/libLLVM.dylib')
TOOL = f'lib/rustlib/{HOST}/bin/rust-objcopy'
LLVM_SHA = '0d514b73a257a599a433ea7076945639c326cb8483cb06d0dae91d7ceebd842a'
POLICY = 'beta-auxiliary-sysroot-metadata-v1'
DEBUG_SOURCE = b'#[inline(never)] fn value() -> u32 { 42 }\nfn main() { println!("{}", value()); }\n'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path, expected=None):
    require(expected is None or sha(path) == expected, 'JSON input changed: ' + str(path))
    return json.loads(Path(path).read_bytes())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def declarations(text):
    """Retain all raw commands; classify only rpaths/load edges needed here."""
    blocks = re.split(r'(?m)^Load command \d+\s*$', text)[1:]
    require(blocks, 'missing Mach-O commands')
    result = dict(rpaths=[], loads=[], raw=text, sha256=hashlib.sha256(text.encode()).hexdigest())
    kinds = {'LC_LOAD_DYLIB', 'LC_LOAD_WEAK_DYLIB', 'LC_REEXPORT_DYLIB',
             'LC_LOAD_UPWARD_DYLIB', 'LC_LAZY_LOAD_DYLIB', 'LC_LOAD_DYLINKER'}
    for block in blocks:
        match = re.search(r'(?m)^\s*cmd (LC_\w+)\s*$', block)
        require(match is not None and match[1] != 'LC_DYLD_ENVIRONMENT', 'unsupported Mach-O command')
        kind = match[1]
        if kind == 'LC_ID_DYLIB':
            continue
        require(not kind.endswith('_DYLIB') or kind in kinds, 'unknown Mach-O load kind')
        if kind == 'LC_RPATH':
            match = re.search(r'(?m)^\s*path (.+) \(offset \d+\)\s*$', block)
            require(match is not None, 'malformed Mach-O rpath')
            result['rpaths'].append(match[1])
        elif kind in kinds:
            match = re.search(r'(?m)^\s*name (.+) \(offset \d+\)\s*$', block)
            require(match is not None, 'malformed Mach-O dependency')
            result['loads'].append([kind, match[1]])
    return result


def check_composition(old, new):
    require(len(old['files']) == 334 and len(new['files']) == 335
            and new.get('archive_copies') == [COPY], 'exact one-copy composition required')
    expected = dict(old['files'])
    require(COPY['destination'] not in expected and expected[COPY['source_destination']]['sha256'] == LLVM_SHA,
            'original beta LLVM provider differs')
    expected[COPY['destination']] = dict(expected[COPY['source_destination']])
    require(new['files'] == expected and new['private'] == old['private']
            and len(new['private']) == 256 and new['stamp_hex'] == old['stamp_hex']
            and new['build_compiler'] == old['build_compiler'] and new['runtime_driver'] == old['runtime_driver']
            and new['archives'] == old['archives'] and new['runtime_source_commit'] == old['runtime_source_commit'],
            'beta/private/driver closure changed beyond explicit copy')


def future_commands(old, amended, stock):
    before = list(amended)
    argv = []
    for word in before:
        if word == '--sysroot=' + str(stock.B):
            word = '--sysroot=' + str(B2)
        elif word.startswith('rustc_driver=' + str(stock.B) + '/'):
            word = 'rustc_driver=' + str(B2 / Path(word.split('=', 1)[1]).relative_to(stock.B))
        argv.append(word)
    require(argv[-2:] == ['-o', str(stock.OUTPUT_ROOT / 'smoke-rustc')], 'amended stock output differs')
    argv[-1] = str(OUTPUT / 'stock-smoke/smoke-rustc')
    require(sum(word.startswith('rustc_driver=' + str(B2)) for word in argv) == 2
            and '--sysroot=' + str(B2) in argv and '-Lnative=' + str(stock.E / 'lib') in argv,
            'future stock compiler roles differ')
    debug = OUTPUT / 'strip-control'
    build_debug = [str(stock.D), '--sysroot=' + str(B2), '--edition=2024', '--crate-name', 'strip_control', '--emit=obj',
        str(debug / 'input.rs'), '-Cdebuginfo=2', '-Cstrip=none', '-Csplit-debuginfo=off',
        '-Copt-level=0', '-o', str(debug / 'before.o')]
    return dict(stock_build=argv, stock_source=old['source'], stock_source_sha256=old['source_sha256'],
        stock_build_environment=old['build_environment'], application_sysroot=str(stock.E),
        auxiliary_declarations=[['/usr/bin/otool', '-arch', 'arm64', '-l', str(B2 / path)]
                               for path in [TOOL, COPY['destination']]],
        auxiliary_version=[str(B2 / TOOL), '--version'],
        auxiliary_environment=old['application_environment'] | {'DYLD_PRINT_LIBRARIES': '1'},
        required_auxiliary_llvm=dict(path=str(B2 / COPY['destination']), sha256=LLVM_SHA),
        debug_source=dict(path=str(debug / 'input.rs'), text=DEBUG_SOURCE.decode(),
                          sha256=hashlib.sha256(DEBUG_SOURCE).hexdigest()),
        debug_build=build_debug, debug_environment=old['build_environment'],
        strip=[str(B2 / TOOL), '--strip-debug', str(debug / 'before.o'), str(debug / 'after.o')],
        strip_environment=old['application_environment'] | {'DYLD_PRINT_LIBRARIES': '1'},
        debug_declarations=[['/usr/bin/otool', '-arch', 'arm64', '-l', str(debug / name)] for name in ['before.o', 'after.o']],
        object_execution=False, native_behavior_proof='separate unchanged stock compiler/fixture controls required',
        required_debug_evidence='Mach-O object before has embedded DWARF; after has none; source and before-object unchanged; exact hashes/raw output retained',
        later_build_requirement='fresh exporter target/binding and zero strip failures; current binaries stay bound to B334',
        commands_executed=False)


class Stage:
    def __init__(self, args):
        self.args = args
        self.freeze = read(FROZEN, args.inputs_sha)
        for path in self.freeze['import_sources']:
            require(sha(path) == self.freeze['files'][path], 'import source changed')
        self.owned = load('b2_owned', OWNER / 'experiments/stable-cgu/owned_stage.py')
        self.stock = load('b2_stock', STOCK_CODE)
        self.comp = load('b2_compositor', COMPOSITOR)
        sys.path.insert(0, str(EMBED / 'scripts'))
        libs = load('b2_libraries', EMBED / 'scripts/custom_cargo_libraries.py')
        stage2 = load('b2_stage2', self.stock.STAGE2 / 'experiments/hir-stage2-package/check.py')
        self.env = self.stock.environment()
        require(not WORK.exists() and not OUTPUT.exists(), 'fresh metadata and future output roots required')
        WORK.mkdir()
        self.record = dict(schema_version=1, policy=POLICY, status='waiting', stage='plan', owner=str(OWNER),
            pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(), command=sys.argv, cwd=os.getcwd(),
            inputs_sha256=args.inputs_sha, commands=[], environment=self.env,
            canonical_lock=str(self.owned.CANONICAL_LOCK), wait_seconds=600,
            capacity=dict(entry_gib=16, stop_gib=9, floor_gib=8), assemblies=0, compiler_builds=0, benchmark=False)
        g = SimpleNamespace(args=SimpleNamespace(**STOCK_PINS), frozen=read(STOCK_FREEZE, STOCK_PINS['frozen_sha']),
            owned=self.owned, comp=load('b2_old_compositor', EMBED / 'experiments/embedded-frontend-bootstrap/compose_sysroot.py'),
            libs=libs, stage2=stage2, record=self.record, env=self.env)
        g.save = self.save
        g.run = self.command
        g.check_sources = lambda: (self.check_sources(), self.stock.Stage.check_sources(g))
        for name in ['file', 'inspect', 'load_check', 'amendment', 'amended_build_argv']:
            setattr(g, name, lambda *a, _name=name, **kw: getattr(self.stock.Stage, _name)(g, *a, **kw))
        self.g = g
        self.save()

    def save(self):
        self.owned.write(WORK / 'receipt.json', self.record)

    def check_sources(self):
        require(sha(FROZEN) == self.args.inputs_sha, 'metadata source freeze changed')
        for path, expected in self.freeze['files'].items():
            p = Path(path)
            require(p.is_file() and not p.is_symlink() and p.resolve(strict=True) == p and sha(p) == expected,
                    'frozen source/proof changed: ' + path)
        require(str(Path(sys.executable).resolve()) == self.freeze['python']['resolved']
                and sha(sys.executable) == self.freeze['python']['sha256'], 'actual Python differs')
        for module in list(sys.modules.values()):
            path = getattr(module, '__file__', None)
            if path and str(path).startswith('/Users/danluu/dev/rust-interp'):
                require(str(Path(path).resolve()) in self.freeze['files'], 'unfrozen local import: ' + path)

    def command(self, argv, *, env=None, cwd=None, expected=(0,), role='metadata'):
        self.check_sources()
        self.owned.disk(OWNER, 9)
        # Only read-only metadata commands are callable by this source checkpoint.
        program = argv[0]
        compiler_probe = program in [str(self.stock.D), str(self.stock.E / 'bin/rustc')] and argv[1:] in [['-vV'], ['--print', 'sysroot']]
        require(program in ['git', '/usr/bin/otool', '/usr/bin/xcode-select', '/usr/bin/xcrun'] or compiler_probe
                or argv == [self.old['sdk']['clang'], '--version'], 'non-metadata command rejected')
        out = WORK / 'commands' / f'{len(self.record["commands"]):03d}'
        try:
            child = self.owned.run(argv, cwd=cwd or self.stock.ROOT, env=env or self.env,
                                   out=out, capacity_root=OWNER, expected=expected)
        finally:
            if (out / 'receipt.json').exists():
                child = read(out / 'receipt.json')
                self.record['commands'].append(dict(path=str(out / 'receipt.json'), sha256=sha(out / 'receipt.json'),
                    command=child['command'], role=role, pid=child.get('pid'), returncode=child.get('returncode')))
                self.save()
        self.owned.disk(OWNER, 9)
        self.check_sources()
        return dict(receipt=child, path=str(out / 'receipt.json'), stdout=(out / 'stdout').read_bytes(), stderr=(out / 'stderr').read_bytes())

    def predecessor(self):
        summary, prior = self.stock.Stage.guard(self.g)
        old = self.stock.Stage.check_plan(self.g)
        manifest = self.stock.Stage.b_guard(self.g, old)
        smoke = read(STOCK_RECEIPT, STOCK_SHA)
        require(smoke['status'] == 'passed' and smoke['source_unchanged'] and smoke['runtime_unchanged']
                and smoke['source_restored'] and len(smoke['commands']) == 28
                and sum(row['role'] == 'smoke-control' for row in smoke['commands']) == 18
                and all(smoke['checks'].values()) and smoke['plan_sha256'] == STOCK_PINS['plan_sha'],
                'exact successful amended stock history required')
        for ref in smoke['commands']:
            child = read(ref['path'], ref['sha256'])
            require(child['status'] == 'finished' and child['command'] == ref['command']
                    and child['supervisor_pid'] == smoke['pid']
                    and smoke['admitted_at'] <= child['started_at'] <= child['finished_at'] <= smoke['finished_at'],
                    'stock child association differs')
            for stream in ['stdout', 'stderr']:
                require(sha(Path(ref['path']).parent / stream) == child[stream + '_sha256'], 'stock raw output changed')
        require(smoke['composition']['manifest_sha256'] == sha(self.stock.ROOT / 'composition/private-sysroot.json')
                and manifest['files'] == {p: r['sha256'] for p, r in old['composition']['files'].items()},
                'original B334 history changed')
        return summary, prior, old

    def metadata(self):
        self.check_sources()
        self.old = read(self.stock.PLAN, STOCK_PINS['plan_sha'])
        _, prior, old = self.predecessor()
        proposal = read(PROPOSAL, self.freeze['files'][str(PROPOSAL)])
        require(proposal['archive_copies'] == [COPY] and proposal['destination'] == str(B2)
                and proposal['capacity'] == dict(entry_gib=16, stop_gib=9, floor_gib=8), 'fixed B2 proposal differs')
        controls = read(self.freeze['controls_summary']['path'], self.freeze['controls_summary']['sha256'])
        require(controls['status'] == 'passed' and controls['controls'] == 10
                and controls['source_commit'] == '95d9501b43848fdbe640fd14c2a88da95da48903', 'qualified compositor source required')
        probes = {}
        for key, root in [('build_compiler', self.stock.D.parent.parent), ('runtime_compiler', self.stock.E)]:
            item = old[key]
            approved = {x['resolved']: x['sha256'] for x in item['closure']['libraries']}
            probes[key] = self.stock.Stage.probe(self.g, Path(item['path']), root, item['sha256'], approved,
                self.stock.REVISION if key == 'runtime_compiler' else None)
            require(probes[key]['version'] == item['version'] and probes[key]['default_sysroot'] == item['default_sysroot'],
                    'actual D/E identity changed')
        for key, argv in [('developer', ['/usr/bin/xcode-select', '-p']),
                         ('sdk', ['/usr/bin/xcrun', '--sdk', 'macosx', '--show-sdk-path']),
                         ('clang', ['/usr/bin/xcrun', '--sdk', 'macosx', '--find', 'clang']),
                         ('linker', ['/usr/bin/xcrun', '--sdk', 'macosx', '--find', 'ld'])]:
            result = self.command(argv)
            require(not result['stderr'] and result['stdout'].decode().strip() == old['sdk']['discovered'][key], 'SDK route changed')
        require(self.command([old['sdk']['clang'], '--version'])['stdout'].decode() == old['sdk']['clang_version'], 'clang version changed')
        snapshots = {}
        (WORK / 'input-snapshots').mkdir()
        for path in self.freeze['snapshot_inputs'] + [str(FROZEN)]:
            data = Path(path).read_bytes()
            expected = self.args.inputs_sha if path == str(FROZEN) else self.freeze['files'][path]
            require(hashlib.sha256(data).hexdigest() == expected, 'metadata snapshot input changed')
            copy = WORK / 'input-snapshots' / expected
            if not copy.exists():
                self.comp.write_new(copy, data, lambda: self.owned.disk(OWNER, 9))
            snapshots[str(copy)] = expected
        original = old['composition']
        proof_files = {row['path']: row['sha256'] for row in original['proofs']}
        proof_files.update(snapshots)
        composition = self.comp.inspect_inputs(archives=[x['file'] for x in original['archives']], stamp=original['stamp'],
            approved_private_files={x['source']: {k: x['file'][k] for k in ['sha256', 'size']} for x in original['private']},
            build_compiler=original['build_compiler'], runtime_source_commit=original['runtime_source_commit'],
            runtime_driver=original['runtime_driver'], proofs=[dict(path=p, sha256=h) for p, h in sorted(proof_files.items())],
            archive_copies=[COPY])
        check_composition(original, composition)
        loader = {}
        for path in [TOOL, COPY['source_destination']]:
            result = self.command(['/usr/bin/otool', '-arch', 'arm64', '-l', str(self.stock.B / path)])
            require(not result['stderr'], 'auxiliary declaration emitted diagnostics')
            loader[path] = dict(receipt=result['path'], **declarations(result['stdout'].decode()))
        tool = loader[TOOL]
        require(any(p in ('@loader_path/../lib', '@executable_path/../lib') for p in tool['rpaths'])
                and ['LC_LOAD_DYLIB', '@rpath/libLLVM.dylib'] in tool['loads'], 'actual auxiliary beta LLVM route differs')
        for path, declaration in loader.items():
            for kind, dependency in declaration['loads']:
                require((path == TOOL and dependency == '@rpath/libLLVM.dylib')
                        or dependency.startswith(('/usr/lib/', '/System/Library/')),
                        'additional auxiliary dependency requires a separate reviewed provider')
                require('..' not in Path(dependency).parts, 'noncanonical auxiliary dependency')
        future = future_commands(old, self.g.amended_build_argv(old), self.stock)
        self.predecessor()
        self.comp.recheck_inputs(composition)
        self.check_sources()
        require(not OUTPUT.exists(), 'metadata created a future runtime output')
        plan = dict(schema_version=1, policy=POLICY, status='planned-unexecuted', owner=str(OWNER),
            inputs_sha256=self.args.inputs_sha, compositor_source_commit='95d9501b43848fdbe640fd14c2a88da95da48903',
            predecessor=dict(stock_smoke_sha256=STOCK_SHA, **STOCK_PINS), input_snapshots=snapshots,
            composition=composition, composition_sha256=self.comp.digest(self.comp.encoded(composition)),
            destination=str(B2), evidence=str(OUTPUT / 'composition'), sdk=old['sdk'], probes=probes,
            guard_files=old['guard_files'], actual_original_auxiliary_declarations=loader, future=future,
            copy_payload_bytes=sum(x['size'] for x in composition['files'].values()),
            proof_copy_bytes=sum(x['size'] for x in composition['proofs']),
            capacity=dict(entry_gib=16, stop_gib=9, floor_gib=8), canonical_lock=str(self.owned.CANONICAL_LOCK),
            wait_seconds=600, assemblies=0, compiler_builds=0, benchmark=False, publication=False)
        self.owned.write(PLAN, plan)
        self.record.update(status='passed', plan_path=str(PLAN), plan_sha256=sha(PLAN), files=335,
            original_B_unchanged=True, source_unchanged=True, runtime_unchanged=True,
            metadata_only=True, finished_at=time.time(), free_bytes_after=self.owned.disk(OWNER))
        self.save()

    def execute(self):
        try:
            with self.owned.workload_lock(self.owned.CANONICAL_LOCK, 600):
                self.record.update(status='running', admitted_at=time.time(), free_bytes_before=self.owned.disk(OWNER, 16))
                self.save()
                self.metadata()
        except BaseException as error:
            self.record.update(status='failed', error=repr(error), finished_at=time.time(),
                               free_bytes_after=shutil.disk_usage(OWNER).free)
            self.save()
            raise


def main():
    require(sys.dont_write_bytecode and not sys.flags.optimize and Path.cwd() == OWNER
            and Path(__file__).resolve() == HERE / 'check.py', 'fixed metadata source/cwd and Python -B required')
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--inputs-sha', required=True)
    args = parser.parse_args()
    require(re.fullmatch('[0-9a-f]{64}', args.inputs_sha), 'exact source freeze required')
    Stage(args).execute()


if __name__ == '__main__':
    main()
