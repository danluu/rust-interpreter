#!/usr/bin/env python3
"""Archive the completed existing-stage1 diagnostic; execute no compiler."""
import gzip, hashlib, io, json, os
from pathlib import Path
import sys, tarfile, time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
OWNER=Path('/Users/danluu/dev/rust-interp-hir-native-controls-evidence-20260913')
RAW=OWNER/'.work/hir-native-direct-capture-probe-01'
PLAN=OWNER/'.work/direct_capture_probe_01.json'
PLAN_SHA='4062b05d9b389cdc9cb0993a34e5e20ecd3faef356db72eb257ffcbc38537f25'
WORK=ROOT/'.work/hir-direct-capture-probe-archive-01'
OUT=ROOT/'results/hir-direct-capture-probe-01'
sys.path.insert(0,str(ROOT/'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write

def digest(data):return hashlib.sha256(data).hexdigest()
def main():
 WORK.mkdir(parents=True,exist_ok=False)
 record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),lock=str(CANONICAL_LOCK),lock_wait_seconds=600,compiler_commands=0)
 write(WORK/'summary.json',record)
 try:
  with workload_lock(CANONICAL_LOCK,600):
   record.update(status='running',admitted_at=time.time(),free_bytes_before=disk(ROOT));write(WORK/'summary.json',record)
   payloads={}
   def retain(path,expected=None):
    path=Path(path);require(path.is_absolute() and path.resolve(strict=True)==path and path.is_file() and not path.is_symlink(),'nonordinary archive input')
    data=path.read_bytes();require(expected is None or digest(data)==expected,'archive input changed: '+str(path))
    require(str(path) not in payloads or payloads[str(path)]==data,'captured input changed');payloads[str(path)]=data;return data
   plan=json.loads(retain(PLAN,PLAN_SHA));receipt=json.loads(retain(RAW/'receipt.json'))
   require(plan['owner']==str(OWNER) and plan['work']==str(RAW) and receipt['owner']==str(OWNER)
      and receipt['status']=='diagnostic-completed' and receipt['expected_plan_sha256']==PLAN_SHA
      and receipt['compiler_returncode']==0 and receipt['diagnostic_only'] is True
      and receipt['executed_native_binary'] is False and receipt['native_qualified'] is False
      and receipt['source_revision']=='3d7ad8282c5695196f4a4dcfd0bdceacac3f79b9'
      and len(receipt['commands'])==11 and receipt['started_at']<=receipt['admitted_at']<=receipt['finished_at'],'wrong completed probe')
   retain(OWNER/'.work/direct_capture_probe_01.py',plan['helper_sha256'])
   reference=plan['failed_archive'];archive=Path(reference['archive'])
   for p,h in plan['inputs'].items():
    if p!=str(archive):retain(p,h)
    else:require(sha(p)==h,'referenced failed archive changed')
   previous=json.loads(retain(reference['summary']));manifest=json.loads(retain(reference['manifest']))
   require(sha(archive)==previous['archive']['sha256']=='a5a6e0e5b2c49603baa0c4d6d2e51b40f57279ab5f4f4f82d75cad0240d3e58b','wrong prior203 archive')
   seen=set()
   with tarfile.open(archive,'r:gz') as tar:
    for member in tar:
     require(member.isfile() and member.name not in seen,'invalid prior member');item=manifest[member.name];data=tar.extractfile(member).read()
     require(member.name==item['source'].lstrip('/') and len(data)==item['bytes'] and digest(data)==item['sha256'],'prior member changed');seen.add(member.name)
   require(seen==set(manifest) and len(seen)==203,'prior archive incomplete')
   children=[];compiler=[]
   for i,ref in enumerate(receipt['commands']):
    path=Path(ref['path']);require(path==RAW/'commands'/f'{i:03d}'/'receipt.json','unexpected probe child location')
    child=json.loads(retain(path,ref['sha256']));require(child['status']=='finished' and child['returncode']==0
       and child['command']==ref['command'] and child['environment']==plan['environment']
       and 'RUSTC_FORCE_RUSTC_VERSION' not in child['environment'],'probe child route changed')
    stdout=retain(path.parent/'stdout',child['stdout_sha256']);stderr=retain(path.parent/'stderr',child['stderr_sha256'])
    children.append(dict(path=str(path),sha256=digest(payloads[str(path)]),command=child['command'],pid=child['pid'],returncode=0))
    if child['command']==plan['compiler_command']:compiler.append((ref,child,stdout,stderr))
    else:require(child['command'][0]=='git','unexpected extra compiler/workload')
   require(len(compiler)==1 and compiler[0][0]==receipt['compiler_command']
      and compiler[0][1]['cwd']==str(RAW/'fixture'),'exact sole compile association changed')
   messages=[s for s in compiler[0][3].decode().splitlines() if s.startswith(('[hir-body-capture]','[hir-body-reuse]'))]
   require(messages==receipt['capture_messages'] and len(messages)==24
      and all(s.startswith('[hir-body-capture] ') and ' rejected-body-tree ' in s and ' cache_hits=0 ' in s for s in messages),'actual diagnostic observation differs')
   before=json.loads(retain(RAW/'compiler-artifacts-before.json'));after=json.loads(retain(RAW/'compiler-artifacts-after.json'))
   require(before==after==json.loads(Path(plan['postfailure_artifacts']).read_bytes()) and len(after['files'])==64,'actual compiler/std identities changed')
   data=retain(RAW/'fixture/input.rs',receipt['source_sha256']);require(digest(data)==plan['inputs'][plan['fixture']],'copied fixture differs')
   binary=RAW/'fixture/body_journal_test';require(sha(binary)==receipt['output_binary_sha256'],'diagnostic output binary changed')
   binary_ref=dict(path=str(binary),sha256=receipt['output_binary_sha256'],bytes=binary.stat().st_size,executed=False,archived=False)
   supervisor=OWNER/'.work/experiments/hir-native-direct-capture-probe-supervisor-01'
   outer=json.loads(retain(supervisor/'status.json'));require(outer['status']=='finished' and outer['returncode']==0 and outer['child_pid']==receipt['pid'],'probe supervisor did not pass')
   retain(supervisor/'plan.json',outer['plan_sha256']);retain(supervisor/'command.log',outer['log_sha256']);retain(supervisor/'supervisor.log')
   for p in [Path(__file__),ROOT/'experiments/stable-cgu/owned_stage.py',ROOT/'scripts/supervise_experiment.py']:retain(p)
   require(all(Path(p).read_bytes()==data for p,data in payloads.items()) and all(sha(p)==h for p,h in plan['inputs'].items()),'frozen inputs changed during archive')
   OUT.mkdir(parents=True,exist_ok=False);target=OUT/'evidence.tar.gz';members={}
   with target.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
     with tarfile.open(fileobj=gz,mode='w') as tar:
      for source,data in sorted(payloads.items()):
       disk(ROOT);name=source.lstrip('/');member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o444;tar.addfile(member,io.BytesIO(data))
       members[name]=dict(source=source,bytes=len(data),sha256=digest(data))
   seen=set()
   with tarfile.open(target,'r:gz') as tar:
    for member in tar:
     require(member.isfile() and member.name not in seen,'bad archive member');data=tar.extractfile(member).read();item=members[member.name]
     require(len(data)==item['bytes'] and digest(data)==item['sha256'],'archive readback differs');seen.add(member.name)
   require(seen==set(members),'archive incomplete');write(OUT/'manifest.json',members)
   summary=dict(schema_version=1,status='completed diagnostic archived; capture/reuse unqualified',owner=str(OWNER),
      source_revision=receipt['source_revision'],plan=dict(path=str(PLAN),sha256=PLAN_SHA),
      receipt=dict(path=str(RAW/'receipt.json'),sha256=sha(RAW/'receipt.json')),commands=children,total_commands=11,
      compiler_commands=1,compiler_returncode=0,environment=plan['environment'],force_version_override_present=False,
      rejection_records=24,capture_messages=messages,verified_cache_hit_records=0,native_qualified=False,
      executed_native_binary=False,output_binary=binary_ref,compiler_and_native_std_unchanged=True,compiler_inventory_files=64,
      source_pre_post_guards='actual retained compiler-source/backtrace guards before and after the sole compiler command',
      prior_failed_archive=dict(paths=reference,sha256=sha(archive),members=203,all_members_verified=True,payload_not_duplicated=True),
      archive=dict(path=target.name,sha256=sha(target),bytes=target.stat().st_size,members=len(members),all_member_hashes_verified=True,gzip_mtime=0),
      manifest_sha256=sha(OUT/'manifest.json'),actual_probe_free_bytes_after=receipt['free_bytes_after'],performance_claim=False,finished_at=time.time())
   write(OUT/'summary.json',summary)
   (OUT/'README.md').write_text('# Direct stage1 capture diagnostic\n\n'
      'The existing compiler3d7ad828 compiled the unchanged native fixture once with capture/info enabled and '
      'RUSTC_FORCE_RUSTC_VERSION absent. Compilation returned0. All24 reports were rejected-body-tree; there '
      'were no verified cache hits. The generated native binary was hashed and never executed.\n\n'
      'All11 commands, exact helper/plan/inputs and supervisor, raw compiler output, copied fixture and '
      'before/after64-file compiler/std inventories are retained. The original diagnostic verified complete '
      'source/backtrace before and after compilation. The prior203-member failed-native archive was reverified '
      'and retained by reference. Every new archive member passed readback. This is diagnostic evidence only; '
      'native reuse correctness, stage2 packaging and performance remain unqualified. Host free space after '
      'the probe was18,894,802,944bytes; no cleanup or capacity credit is assumed.\n')
   record.update(status='passed',finished_at=time.time(),result=str(OUT),archive=summary['archive'],summary_sha256=sha(OUT/'summary.json'),free_bytes_after=disk(ROOT));write(WORK/'summary.json',record)
 except BaseException as error:
  record.update(status='failed',finished_at=time.time(),error=repr(error));write(WORK/'summary.json',record);raise
if __name__=='__main__':main()
