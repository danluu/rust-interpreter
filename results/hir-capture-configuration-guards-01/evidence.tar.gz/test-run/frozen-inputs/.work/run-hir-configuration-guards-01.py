#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/Users/danluu/dev/rust-interp-hir-capture-check-20260913')
EXPECTED_HEAD = '115fbd80bf82ed4a6298691ccf68814b4585bcf0'
PLAN = ROOT / '.work/hir-configuration-guards-plan-01.json'
WORK = ROOT / '.work/hir-configuration-guards-01'
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, identity, require, run, sha, workload_lock, write


def main():
    WORK.mkdir(exist_ok=False)
    plan = json.loads(PLAN.read_text())
    source = plan['source_files']
    def guard():
        require(all(sha(path) == digest for path, digest in source.items()), 'frozen source changed')
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
        require(head == EXPECTED_HEAD, 'source revision changed')
    result = dict(schema_version=1, status='waiting', owner=str(ROOT), source_commit=EXPECTED_HEAD,
                  supervisor_pid=os.getpid(), parent_pid=os.getppid(), identity=identity(os.getpid()),
                  started_at=time.time(), plan_sha256=sha(PLAN), canonical_lock=str(CANONICAL_LOCK),
                  lock_wait_seconds=600, source_files=source,
                  scope='Only two Python source-configuration guard tests; no compiler setup/build/check')
    write(WORK / 'result.json', result)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            result.update(status='running', admitted_at=time.time(), free_bytes_before=shutil.disk_usage(ROOT).free)
            guard()
            snapshots = WORK / 'frozen-inputs'
            for path, digest in source.items():
                relative = Path(path).relative_to(ROOT)
                dest = snapshots / relative
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(Path(path).read_bytes())
                require(sha(dest) == digest, 'snapshot changed')
            shutil.copyfile(PLAN, WORK / 'plan.json')
            env = {key: os.environ[key] for key in ('PATH', 'HOME', 'USER', 'LOGNAME', 'TMPDIR', 'LANG', 'LC_ALL', 'SHELL') if key in os.environ}
            env['PYTHONDONTWRITEBYTECODE'] = '1'
            interpreter = Path(sys.executable).resolve(strict=True)
            result['python'] = dict(executable=sys.executable, resolved=str(interpreter), sha256=sha(interpreter), version=sys.version)
            command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_hir_capture_check.py', '-v']
            write(WORK / 'result.json', result)
            receipt = run(command, cwd=ROOT, env=env, out=WORK / 'command', capacity_root=ROOT)
            stderr = (WORK / 'command/stderr').read_text()
            require('Ran 2 tests in ' in stderr and stderr.rstrip().endswith('OK') and 'skipped=' not in stderr,
                    'expected exactly two passing tests with no skips')
            guard()
            require(sha(interpreter) == result['python']['sha256'], 'Python executable changed')
            result.update(status='passed', tests_passed=2, tests_skipped=0, source_guard='unchanged',
                          command_receipt_sha256=sha(WORK / 'command/receipt.json'),
                          finished_at=time.time(), free_bytes_after=shutil.disk_usage(ROOT).free)
            write(WORK / 'result.json', result)
            print(json.dumps(dict(status='passed', tests=2, pid=receipt['pid'], result=str(WORK / 'result.json'))), flush=True)
    except BaseException as error:
        result.update(status='failed', error=repr(error), finished_at=time.time())
        write(WORK / 'result.json', result)
        raise


if __name__ == '__main__':
    main()
