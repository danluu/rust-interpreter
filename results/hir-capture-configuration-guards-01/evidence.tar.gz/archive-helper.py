#!/usr/bin/env python3
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-hir-config-guard-evidence-20260913')
SOURCE = Path('/Users/danluu/dev/rust-interp-hir-capture-check-20260913')
RUN = SOURCE / '.work/hir-configuration-guards-01'
OUTER = SOURCE / '.work/experiments/hir-configuration-guards-supervisor-01'
DEST = ROOT / 'results/hir-capture-configuration-guards-01'
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, identity, require, sha, workload_lock, write


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    receipt = ROOT / '.work/hir-config-archive-01.json'
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), identity=identity(os.getpid()),
                  started_at=time.time(), canonical_lock=str(CANONICAL_LOCK), lock_wait_seconds=600)
    write(receipt, record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record['admitted_at'] = time.time()
            result = json.loads((RUN / 'result.json').read_text())
            outer = json.loads((OUTER / 'status.json').read_text())
            require(result['status'] == 'passed' and result['tests_passed'] == 2 and result['tests_skipped'] == 0
                    and outer['status'] == 'finished' and outer['returncode'] == 0, 'test run incomplete')
            require(result['source_commit'] == '115fbd80bf82ed4a6298691ccf68814b4585bcf0', 'wrong source')
            for path, expected in result['source_files'].items():
                saved = RUN / 'frozen-inputs' / Path(path).relative_to(SOURCE)
                require(sha(saved) == expected and sha(path) == expected, 'source snapshot mismatch: ' + path)
            command = json.loads((RUN / 'command/receipt.json').read_text())
            for name in ['stdout', 'stderr']:
                require(sha(RUN / 'command' / name) == command[name + '_sha256'], 'raw output mismatch')
            require(sha(OUTER / 'command.log') == outer['log_sha256'], 'outer output mismatch')
            files = {}
            originals = {}
            for base, prefix in [(RUN, 'test-run'), (OUTER, 'test-supervisor')]:
                for path in sorted(base.rglob('*')):
                    require(not path.is_symlink(), 'symlink in evidence')
                    if path.is_file():
                        data = path.read_bytes()
                        files[prefix + '/' + str(path.relative_to(base))] = data
                        originals[str(path)] = digest(data)
            files['archive-helper.py'] = Path(__file__).read_bytes()
            files['archive-owned-stage.py'] = (ROOT / 'experiments/stable-cgu/owned_stage.py').read_bytes()
            files['archive-supervise-experiment.py'] = (ROOT / 'scripts/supervise_experiment.py').read_bytes()
            DEST.mkdir(parents=True, exist_ok=False)
            archive = DEST / 'evidence.tar.gz'
            with tarfile.open(archive, 'w:gz') as tar:
                for name, data in sorted(files.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    tar.addfile(info, io.BytesIO(data))
            with tarfile.open(archive, 'r:gz') as tar:
                members = tar.getmembers()
                require(len(members) == len(files), 'archive count mismatch')
                for member in members:
                    require(member.isfile() and tar.extractfile(member).read() == files[member.name], 'archive bytes mismatch')
            require(all(sha(path) == expected for path, expected in originals.items()), 'evidence changed during archive')
            write(DEST / 'members.json', {name:dict(size=len(data), sha256=digest(data)) for name, data in sorted(files.items())})
            summary = dict(schema_version=1, status='passed', source_commit=result['source_commit'],
                test_count=2, skipped=0, no_compiler_work=True, source_files=result['source_files'],
                test_started_at=command['started_at'], test_finished_at=command['finished_at'],
                test_supervisor_pid=outer['supervisor_pid'], test_helper_pid=result['supervisor_pid'], test_pid=command['pid'],
                source_guard=result['source_guard'], archive=dict(path='evidence.tar.gz', members=len(files),
                size=archive.stat().st_size, sha256=sha(archive), verification='all members read back byte-for-byte'),
                archive_pid=os.getpid(), scope='Two Python configuration guards only; no plan, compiler checkout, build, native execution or benchmark')
            write(DEST / 'summary.json', summary)
            (DEST / 'README.md').write_text('''# HIR capture driver configuration guards\n\nBoth Python tests passed with no skips against source commit `115fbd80bf82ed4a6298691ccf68814b4585bcf0`. They check that newly created Cargo configuration files change the frozen guard and that configuration file/directory symlinks are rejected. The exact driver, four capture-only inputs, README, test, process helpers, and test supervisor were frozen and remained unchanged.\n\nThe archive contains the raw test output, command and environment, Python identity, process receipts, exact source snapshots and supervisor records. Every member was read back and checked. Originals remain in the test worktree. The archive supervisor completion is retained separately in `archive-supervisor.json`.\n\nThis qualifies only these two source-configuration guards. No plan was materialized, compiler checkout created, compiler built or checked, or benchmark run. It makes no HIR reuse or performance claim.\n''')
            record.update(status='passed', finished_at=time.time(), archive_sha256=sha(archive), members=len(files))
            write(receipt, record)
            print(json.dumps(summary['archive']), flush=True)
    except BaseException as error:
        record.update(status='failed', error=repr(error), finished_at=time.time())
        write(receipt, record)
        raise


if __name__ == '__main__':
    main()
