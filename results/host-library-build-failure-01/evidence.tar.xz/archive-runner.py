"""Archive the completed first HOSTLIB failure; never inspect build02 or targets."""
import base64
import fcntl
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import shutil
import sys
import tarfile
import time

OWNER = Path('/Users/danluu/dev/rust-interp-host-library-failure-evidence-20260913')
HOSTLIB = Path('/Users/danluu/dev/rust-interp-host-library-opt-20260913')
RAW = HOSTLIB / '.work/host-library-build-01'
PROV = RAW / 'payload/provenance'
OUTER = HOSTLIB / '.work/experiments/host-library-build-supervisor-01'
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
OUT = OWNER / 'results/host-library-build-failure-01'
GENERATED = OWNER / '.work/host-library-failure-envelopes-01'

def require(ok, message):
    if not ok: raise RuntimeError(message)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for b in iter(lambda: stream.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def load(path): return json.loads(Path(path).read_bytes())
def save(path, value): path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def files(root):
    for directory, dirs, names in os.walk(root, followlinks=False):
        for name in dirs:
            require(not (Path(directory) / name).is_symlink(), 'unexpected directory symlink')
            require(not name.startswith('target') and name not in {'incremental', 'cache', 'cargo-home'}, 'unexpected generated/cache directory')
        for name in names:
            p = Path(directory) / name
            require(p.is_file() and not p.is_symlink(), 'unexpected nonregular evidence')
            yield p

def main():
    OUT.mkdir(parents=True, exist_ok=False)
    result = {'status': 'waiting', 'pid': os.getpid(), 'parent_pid': os.getppid(),
              'cwd': str(Path.cwd()), 'argv': sys.argv, 'started_at': time.time(),
              'lock': str(LOCK), 'lock_wait_seconds': 600, 'runner_sha256': sha(__file__),
              'compiler_commands': 0, 'test_commands': 0, 'benchmark_commands': 0,
              'action': 'archive completed failed build01 only; preserve all originals'}
    result_path = OUT / 'packaging-receipt.json'
    save(result_path, result)
    with LOCK.open('a+b') as lock:
        try:
            deadline = time.monotonic() + 600
            while True:
                try:
                    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    require(time.monotonic() < deadline, 'canonical admission expired')
                    time.sleep(.25)
            result.update(status='archiving', admitted_at=time.time(), free_bytes_before=shutil.disk_usage(OWNER).free)
            save(result_path, result)
            GENERATED.mkdir(exist_ok=False)
            entries, raw_bytecodes = {}, {}
            def add(path, name, expected=None):
                path = Path(path)
                require(path.is_file() and not path.is_symlink(), f'nonregular member {path}')
                require(name not in entries and not name.startswith('/') and '..' not in Path(name).parts, f'member name {name}')
                info = {'source': str(path), 'size': path.stat().st_size, 'sha256': sha(path)}
                require(expected is None or expected == info['sha256'], f'changed retained input {path}')
                entries[name] = info
                return info['sha256']

            plan = load(PROV / 'build-plan.json')
            require(plan['owner'] == str(HOSTLIB) and plan['qualification_policy'] == 'host-library-public-build-v1', 'plan identity')
            require(plan['tool_key'] is None and plan['screen_command'] is None, 'plan predicted publication')
            require(len(plan['commands']) == 9, 'qualification command count')
            require(plan['workload_admission']['lock'] == str(LOCK), 'build lock identity')
            plan_path = HOSTLIB / 'experiments/host-library-opt/planned-build-01.json'
            plan_sha = add(plan_path, 'plans/planned-build-01.json', sha(PROV / 'build-plan.json'))
            for name in ['planned-build-01.process.json', 'source-match-01.json']:
                add(plan_path.parent / name, 'plans/' + name)
            # Bind frozen original bytes from build01's copied provenance. The live
            # HOSTLIB source is deliberately fixed for build02 and is not read here.
            source_count = 0
            for field, directory in [('workspace_sources', 'source'), ('harness', 'harness')]:
                for relative, expected in plan[field].items():
                    require(sha(PROV / directory / relative) == expected, f'frozen {field} differs: {relative}')
                    source_count += 1
            require(load(PROV / 'harness.json')['files'] == plan['harness'], 'harness manifest differs')
            require(set(plan['source_input_paths']) == set(plan['tool_sources']), 'tool input paths differ')
            require(all(plan['workspace_sources'].get(p) == value for p, value in plan['tool_sources'].items()), 'tool/workspace source mismatch')
            require(sha(PROV / 'std-ready.json') == plan['shared_std']['sha256'], 'shared std snapshot differs')
            for p in files(PROV):
                add(p, 'build01/payload/provenance/' + p.relative_to(PROV).as_posix())
            # Include all completed setup metadata and all nine exact command streams.
            for p in files(RAW / 'metadata'):
                add(p, 'build01/metadata/' + p.relative_to(RAW / 'metadata').as_posix())
            for p in RAW.iterdir():
                if p.is_file(): add(p, 'build01/' + p.name)
            supervisor = load(RAW / 'supervisor.json')
            require(supervisor['status'] == 'failed' and supervisor['error'] == 'qualification command failed: real-histories', 'failure outcome differs')
            require(supervisor['cwd'] == str(HOSTLIB), 'supervisor owner')
            commands = []
            for i, command in enumerate(plan['commands']):
                label = command['label']
                receipt = load(command['receipt'])
                require(Path(command['receipt']) == RAW / (label + '-process.json'), 'command receipt path')
                require(receipt['command'] == command['argv'] and receipt['cwd'] == command['cwd'], 'command differs from frozen plan')
                require(receipt['parent_pid'] == supervisor['pid'] and receipt['status'] == 'finished', 'child ownership/status')
                require(receipt['returncode'] == (1 if i == 8 else 0), 'unexpected child returncode')
                for stream in ['stdout', 'stderr']:
                    require(Path(command[stream]) == RAW / (label + '.' + stream), 'command stream path')
                commands.append({'label': label, 'pid': receipt['pid'], 'returncode': receipt['returncode'],
                                 'receipt_sha256': sha(command['receipt']), 'stdout_sha256': sha(command['stdout']),
                                 'stderr_sha256': sha(command['stderr'])})
            outer = load(OUTER / 'status.json')
            require(outer['status'] == 'finished' and outer['returncode'] == 1, 'outer result')
            require(outer['child_pid'] == supervisor['pid'] and outer['supervisor_pid'] == supervisor['parent_pid'], 'outer ownership')
            require(sha(OUTER / 'plan.json') == outer['plan_sha256'] and sha(OUTER / 'command.log') == outer['log_sha256'], 'outer hashes')
            require(set(p.name for p in OUTER.iterdir()) == {'plan.json', 'status.json', 'command.log', 'supervisor.log'}, 'outer files')
            for p in OUTER.iterdir(): add(p, 'outer-supervisor/' + p.name)

            fixture_rows = []
            allowed_dirs = {'package', 'source-states', 'traces', 'final-argv', 'native-argv', 'bytecode'}
            excluded_dirs = {'stock', 'on', 'off', 'target-stock', 'target-off', 'target-on', 'cargo-home'}
            def fixture_file(p, root):
                rel = p.relative_to(RAW / 'fixtures').as_posix()
                if p.suffix == '.rbc':
                    raw = p.read_bytes()
                    h = hashlib.sha256(raw).hexdigest()
                    raw_bytecodes[str(p)] = {'size': len(raw), 'sha256': h}
                    envelope = GENERATED / (rel + '.json')
                    envelope.parent.mkdir(parents=True, exist_ok=True)
                    save(envelope, {'schema_version': 1, 'kind': 'retained-bytecode-archive-envelope',
                                    'created_during_archival': True, 'source': str(p), 'size': len(raw),
                                    'sha256': h, 'encoding': 'base64', 'data': base64.b64encode(raw).decode('ascii')})
                    add(envelope, 'bytecode-envelopes/' + rel + '.json')
                else:
                    require(p.suffix not in {'.rlib', '.rmeta', '.dylib', '.so', '.a', '.o'}, 'unexpected native artifact')
                    add(p, 'fixtures/' + rel)
            fixture_dirs = list((RAW / 'fixtures').iterdir())
            require(len(fixture_dirs) == 3 and all(p.is_dir() for p in fixture_dirs), 'fixture count')
            for root in fixture_dirs:
                excluded = []
                for p in root.iterdir():
                    if p.is_dir():
                        if p.name in excluded_dirs:
                            excluded.append(p.name)
                        else:
                            require(p.name in allowed_dirs, f'unexpected fixture directory {p}')
                            for child in files(p): fixture_file(child, root)
                    else: fixture_file(p, root)
                rows = [json.loads(line) for line in (root / 'commands.jsonl').read_text().splitlines()]
                fixture_rows.append({'name': root.name, 'recorded_commands': len(rows),
                                     'excluded_native_target_cache_directories': sorted(excluded)})
            require(raw_bytecodes, 'missing retained partial bytecode evidence')
            rust = (RAW / 'rust-workspace-tests.stdout').read_text()
            totals = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', rust)
            rust_totals = {name: sum(int(row[i]) for row in totals) for i, name in enumerate(['passed', 'failed', 'ignored'])}
            require(rust_totals == {'passed': 504, 'failed': 0, 'ignored': 2}, 'Rust test totals differ')
            for label in ['launcher-contracts', 'publication-contracts']:
                stderr = (RAW / (label + '.stderr')).read_text()
                require('Ran 5 tests' in stderr and '\nOK\n' in stderr, 'Python contract result differs')
            real = (RAW / 'real-histories.stderr').read_text()
            require('Ran 3 tests' in real and 'FAILED (failures=1)' in real and real.count(' ... ok') == 2, 'real history totals differ')
            require('host library optimization: requires an unambiguous ordinary Cargo host library invocation' in real, 'routing rejection absent')
            require('-Z embed-metadata=no' in real, 'ordinary Cargo flag absent')
            require(not (RAW / 'result.json').exists() and not (RAW / 'payload/rust-interp-vm').exists(), 'unexpected publication result')
            add(Path(__file__), 'archive-runner.py')
            estimate = sum(v['size'] for v in entries.values())
            require(shutil.disk_usage(OWNER).free >= 8 * 1024**3 + 2 * estimate, 'archive disk floor')
            save(OUT / 'members.json', entries)
            archive = OUT / 'evidence.tar.xz'
            with lzma.open(archive, 'wb', filters=[{'id': lzma.FILTER_LZMA2, 'preset': 3, 'dict_size': 64 * 1024 * 1024}]) as compressed:
                with tarfile.open(fileobj=compressed, mode='w|') as tar:
                    for name, info in sorted(entries.items()):
                        ti = tarfile.TarInfo(name); ti.mode = 0o644; ti.mtime = 0; ti.size = info['size']
                        with Path(info['source']).open('rb') as source: tar.addfile(ti, source)
            seen = set()
            with tarfile.open(archive, 'r:xz') as tar:
                for member in tar:
                    require(member.isfile() and member.name in entries and member.name not in seen, 'archive member shape')
                    seen.add(member.name)
                    with tar.extractfile(member) as stream: raw = stream.read()
                    require(len(raw) == entries[member.name]['size'] and hashlib.sha256(raw).hexdigest() == entries[member.name]['sha256'], 'archive member hash')
                    if member.name.startswith('bytecode-envelopes/'):
                        envelope = json.loads(raw)
                        decoded = base64.b64decode(envelope['data'], validate=True)
                        require(len(decoded) == envelope['size'] and hashlib.sha256(decoded).hexdigest() == envelope['sha256'], 'bytecode envelope mismatch')
            require(seen == set(entries), 'missing archive member')
            for info in entries.values(): require(sha(info['source']) == info['sha256'], 'source changed during archival')
            for p, info in raw_bytecodes.items(): require(sha(p) == info['sha256'] and Path(p).stat().st_size == info['size'], 'raw bytecode changed')
            summary = {'status': 'archived completed failure', 'build_status': 'failed',
                       'failed_command': 'real-histories', 'command_count': 9, 'successful_commands': 8,
                       'plan_sha256': plan_sha, 'source_input_key': plan['source_input_key'],
                       'production_source_revision': plan['production_source_revision'],
                       'public_compiler_source_revision': plan['public_compiler_source_revision'],
                       'shared_std_key': plan['shared_std']['key'], 'shared_std_ready_sha256': plan['shared_std']['sha256'],
                       'workspace_source_files': len(plan['workspace_sources']), 'harness_source_files': len(plan['harness']),
                       'frozen_plan_source_files_verified': source_count, 'live_hostlib_source_read': False,
                       'rust_tests': rust_totals, 'python_unit_tests_passed': 10,
                       'real_histories': {'passed': 2, 'failed': 1}, 'commands': commands, 'fixtures': fixture_rows,
                       'failure': 'strict parser rejected ordinary Cargo -Z embed-metadata=no in the shared host-library history',
                       'bytecode_envelopes_created_during_archival': raw_bytecodes,
                       'archive': {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size,
                                   'members': len(entries), 'uncompressed_bytes': estimate},
                       'published_toolset': False, 'screen_executed': False, 'performance_claim': False,
                       'native_tool_binaries_or_targets_archived': False, 'originals_changed': False,
                       'all_members_and_sources_rechecked': True}
            save(OUT / 'summary.json', summary)
            result.update(status='passed', finished_at=time.time(), members=len(entries),
                          archive_sha256=summary['archive']['sha256'], summary_sha256=sha(OUT / 'summary.json'),
                          free_bytes_after=shutil.disk_usage(OWNER).free)
            save(result_path, result)
            print(json.dumps({'status': 'passed', 'pid': os.getpid(), 'archive': summary['archive']}), flush=True)
        except BaseException as error:
            result.update(status='failed', finished_at=time.time(), error=repr(error))
            save(result_path, result)
            raise

if __name__ == '__main__': main()
