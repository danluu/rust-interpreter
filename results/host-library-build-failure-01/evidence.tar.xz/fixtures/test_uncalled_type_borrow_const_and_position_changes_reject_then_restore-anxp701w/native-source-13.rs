#![allow(dead_code)]
pub fn value() -> u32 { 5 }
// position λ
// position λ
const BAD: u32 = panic!("must evaluate");
