#![allow(dead_code)]
pub fn value() -> u32 { 5 }
// position λ
fn uncalled() -> &'static u32 { let x = 1; &x }
