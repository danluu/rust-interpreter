#![allow(dead_code)]
pub fn value() -> u32 { 5 }
// position λ
// position λ
// position λ
#[deny(unconditional_panic)] fn uncalled() -> u32 { [1][1] }
