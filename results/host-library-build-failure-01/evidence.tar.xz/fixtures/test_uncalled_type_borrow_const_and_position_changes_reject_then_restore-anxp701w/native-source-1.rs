#![allow(dead_code)]
pub fn value() -> u32 { 5 }
fn uncalled() -> u32 { false }
