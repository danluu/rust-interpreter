#![allow(dead_code)]
pub fn value() -> u32 { 5 }
