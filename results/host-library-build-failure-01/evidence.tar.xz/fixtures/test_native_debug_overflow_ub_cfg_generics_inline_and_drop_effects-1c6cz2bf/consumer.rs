fn main() {
    assert_eq!(fixture_library::checks(), (false, false));
    assert_eq!(fixture_library::value(), 9);
    let debug = std::panic::catch_unwind(fixture_library::debug);
    assert_eq!(debug.is_err(), false);
    if !false { assert_eq!(debug.unwrap(), 7); }
    let overflow = std::panic::catch_unwind(fixture_library::overflow);
    assert_eq!(overflow.is_err(), true);
    if !true { assert_eq!(overflow.unwrap(), 0); }
}
