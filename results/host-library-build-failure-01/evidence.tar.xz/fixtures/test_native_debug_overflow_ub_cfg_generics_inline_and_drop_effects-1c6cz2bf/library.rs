#![feature(cfg_ub_checks)]
fn generic<T: Copy>(x: T) -> T { x }
#[inline] fn inlined(x: u32) -> u32 { x }
struct Mark<'a>(&'a std::cell::Cell<u32>);
impl Drop for Mark<'_> { fn drop(&mut self) { self.0.set(self.0.get() + 1); } }
pub fn checks() -> (bool, bool) { (cfg!(debug_assertions), cfg!(ub_checks)) }
pub fn value() -> u32 {
    let drops = std::cell::Cell::new(0);
    { let _mark = Mark(&drops); }
    generic(inlined(8)) + drops.get()
}
pub fn debug() -> u32 { debug_assert!(false, "library debug assertion"); 7 }
pub fn overflow() -> u8 { std::hint::black_box(u8::MAX) + 1 }
