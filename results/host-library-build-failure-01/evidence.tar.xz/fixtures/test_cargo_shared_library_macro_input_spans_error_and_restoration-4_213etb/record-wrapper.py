#!/opt/homebrew/opt/python@3.14/bin/python3.14
import json, os, pathlib, sys
directory = pathlib.Path(os.environ['PROC_OPT_TRACE'])
directory.mkdir(parents=True, exist_ok=True)
(directory / (str(os.getpid()) + '.json')).write_text(json.dumps(dict(pid=os.getpid(), argv=sys.argv[1:], cwd=os.getcwd())))
wrapper = os.environ['PROC_OPT_WRAPPER']
os.execv(wrapper, [wrapper, *sys.argv[1:]])
