fn main() {
    let profile = format!("{}:{}", std::env::var("OPT_LEVEL").unwrap(), std::env::var("DEBUG").unwrap());
    let out = std::path::PathBuf::from(std::env::var_os("OUT_DIR").unwrap());
    std::fs::write(out.join("profile.txt"), &profile).unwrap();
    println!("cargo:rustc-env=FIXTURE_BUILD_PROFILE={profile}");
    println!("cargo:rerun-if-changed=build.rs");
    let value = proc_opt_shared::value();
    std::fs::write(out.join("shared-value.txt"), value.to_string()).unwrap();
    println!("cargo:rustc-env=FIXTURE_SHARED_BUILD_VALUE={value}");
}
