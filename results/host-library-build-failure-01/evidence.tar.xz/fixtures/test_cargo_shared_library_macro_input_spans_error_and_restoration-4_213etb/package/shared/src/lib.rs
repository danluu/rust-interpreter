fn generic<T: Copy>(x: T) -> T { x }
#[inline] fn inlined(x: u32) -> u32 { x }
struct Mark<'a>(&'a std::cell::Cell<u32>);
impl Drop for Mark<'_> { fn drop(&mut self) { self.0.set(self.0.get() + 1); } }
pub fn value() -> u32 {
    assert!(cfg!(debug_assertions));
    let drops = std::cell::Cell::new(0);
    { let _mark = Mark(&drops); }
    assert_eq!(drops.get(), 1);
    generic(inlined(5))
}
