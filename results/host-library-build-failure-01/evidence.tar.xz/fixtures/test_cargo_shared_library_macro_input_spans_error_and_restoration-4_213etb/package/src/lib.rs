proc_opt_macros::make!();
#[test] fn selected() {
assert_eq!(SITE, (file!(), 1, 1));
assert_eq!(env!("FIXTURE_SHARED_BUILD_VALUE"), "5"); assert_eq!(env!("FIXTURE_BUILD_PROFILE"), "0:true");
assert_eq!(proc_opt_shared::value(), 5); assert_eq!(GENERATED, 10); }
