extern crate proc_macro;
fn generic<T: Copy>(x: T) -> T { x }
#[inline] fn inlined(x: u32) -> u32 { x }
struct Mark<'a>(&'a std::cell::Cell<u32>);
impl Drop for Mark<'_> { fn drop(&mut self) { self.0.set(self.0.get() + 1); } }
const BODY: u32 = 3;
#[proc_macro]
pub fn make(_: proc_macro::TokenStream) -> proc_macro::TokenStream {
    assert_eq!(env!("FIXTURE_BUILD_PROFILE"), "0:true");
    assert!(cfg!(debug_assertions));
    let drops = std::cell::Cell::new(0);
    { let _mark = Mark(&drops); }
    assert_eq!(drops.get(), 1);
    let input: u32 = std::fs::read_to_string(env!("FIXTURE_MACRO_INPUT")).unwrap().parse().unwrap();
    let value = generic(inlined(BODY)) + input + proc_opt_shared::value();
    let site = proc_macro::Span::call_site();
    format!("pub const GENERATED: u32 = {value}; pub const SITE: (&str, u32, u32) = ({:?}, {}, {});",
        site.file(), site.line(), site.column()).parse().unwrap()
}
