import gzip,hashlib,importlib.util,json,os,tarfile,time
from pathlib import Path
ROOT=Path('/Users/danluu/dev/rust-interp-runtime-workflow-20260918')
OUT=ROOT/'results/runtime-workflow-controls-03'
OWNED=Path('/Users/danluu/dev/rust-interp-runtime-source-qualification-20260913/experiments/stable-cgu/owned_stage.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(OWNED)=='7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e'
s=importlib.util.spec_from_file_location('archive_owned',OWNED);owned=importlib.util.module_from_spec(s);s.loader.exec_module(owned)
with owned.workload_lock(owned.CANONICAL_LOCK,600):
 started=time.time();free=owned.disk(ROOT,9)
 inputs=[Path(__file__).resolve()];records=[]
 for n in (1,2,3):
  tag=f'{n:02d}';w=ROOT/f'.work/runtime-workflow-controls-{tag}'
  r=json.loads((w/'summary.json').read_text());c=json.loads((w/'command/receipt.json').read_text())
  assert r['status']==('failed' if n==1 else 'passed') and c['returncode']==(1 if n==1 else 0)
  assert c['command']==r['command'] and c['environment']==r['environment']
  assert c['cwd']==str(ROOT/'tests') and c['supervisor_pid']==r['pid'] and c['parent_pid']==r['parent_pid']
  assert r['admitted_at']<=c['started_at']<=c['finished_at']<=r['finished_at']
  for channel in ['stdout','stderr']:assert sha(w/'command'/channel)==c[channel+'_sha256']
  for path,copy in r['snapshots'].items():assert sha(w/copy)==r['sources'][path]
  if n==3:
   for path,h in r['sources'].items():assert sha(Path(path))==h
  for directory in [w/'sources',w/'command',ROOT/f'.work/experiments/runtime-workflow-controls-supervisor-{tag}']:
   inputs+=sorted(p for p in directory.rglob('*') if p.is_file())
  inputs += [w/'summary.json', ROOT/f'.work/run_workflow_controls_{tag}.py']
  records.append(dict(attempt=n,status=r['status'],tests=66 if n<3 else 67,
    receipt_sha256=sha(w/'command/receipt.json'),admitted_at=r['admitted_at'],finished_at=r['finished_at'],
    helper_pid=r['pid'],test_pid=c['pid']))
 assert len(inputs)==len(set(inputs)) and sum(p.stat().st_size for p in inputs)<16*2**20
 manifest={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in inputs}
 OUT.mkdir(parents=True,exist_ok=False)
 a=OUT/'evidence.tar.gz'
 with tarfile.open(a,'w:gz') as t:
  for p in inputs:
   owned.disk(ROOT,9);assert not p.is_symlink() and sha(p)==manifest[str(p.relative_to(ROOT))]['sha256']
   t.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
 with tarfile.open(a,'r:gz') as t:
  ms=t.getmembers();assert {x.name for x in ms}==set(manifest)
  for x in ms:
   b=t.extractfile(x).read();assert len(b)==manifest[x.name]['bytes'] and hashlib.sha256(b).hexdigest()==manifest[x.name]['sha256']
 with gzip.open(a,'rb') as f:
  while f.read(1024*1024):pass
 owned.write(OUT/'manifest.json',manifest)
 result=dict(status='passed',actual_controls=67,attempts=records,archive=dict(path=a.name,sha256=sha(a),bytes=a.stat().st_size,members=len(manifest)),
  manifest_sha256=sha(OUT/'manifest.json'),all_member_hashes_verified=True,full_gzip_eof_crc_verified=True,
  native_compiler_commands=0,application_qualified=False,performance_measurement=False,
  archive_pid=os.getpid(),archive_parent_pid=os.getppid(),archive_started_at=started,archive_finished_at=time.time(),
  free_bytes_before=free,free_bytes_after=owned.disk(ROOT))
 owned.write(OUT/'summary.json',result)
 print(json.dumps(result))
