"""Archive completed, explicitly approved retirement; no cleanup or workloads."""
import fcntl, gzip, hashlib, json, lzma, os, shutil, sys, tarfile, time
from pathlib import Path
OWNER = Path('/Users/danluu/dev/rust-interp-host-library-failure-evidence-20260913')
ROOT = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
INSPECTION = OWNER / '.work/host-library-screen-target-inspection-01'
RETIREMENT = OWNER / '.work/host-library-screen-target-retirement-01'
OUTPUT = OWNER / 'results/host-library-screen-target-retirement-01'
WORK = OWNER / '.work/host-library-screen-target-retirement-archive-01'
INSPECTION_SHA = 'cfaccc21b10335b74d91948c15c732cac1c433e1a486b1d94e06d7475add467a'
RUNNER_SHA = '4d87a5f06956f80727279980719c710ef589c8e87f7375b20b7909f64d15e40e'
SCREEN_SHA = 'ee3e4462d95dab04a79531348246fa6d722c444006e27170be299218af646be6'

def require(ok, message):
    if not ok: raise RuntimeError(message)
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()
def read(path): return json.loads(Path(path).read_bytes())
def save(path, value): Path(path).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
def regular_files(directory):
    for root, dirs, names in os.walk(directory, followlinks=False):
        for name in dirs: require(not (Path(root)/name).is_symlink(), 'directory symlink')
        for name in names:
            path = Path(root)/name
            require(path.is_file() and not path.is_symlink(), 'nonregular evidence')
            yield path

def main():
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), argv=sys.argv,
                  cwd=str(Path.cwd()), started_at=time.time(), canonical_lock=str(LOCK), wait_seconds=600,
                  compiler_commands=0, tests=0, benchmarks=0, deletions=0, runner_sha256=sha(__file__))
    save(WORK/'summary.json', record)
    try:
        with LOCK.open('r+') as lock:
            deadline = time.monotonic()+600
            while True:
                try: fcntl.flock(lock.fileno(), fcntl.LOCK_EX|fcntl.LOCK_NB); break
                except BlockingIOError:
                    require(time.monotonic()<deadline, 'canonical admission expired'); time.sleep(.25)
            record.update(status='archiving', lock_acquired_at=time.time(), free_bytes_before=shutil.disk_usage(OWNER).free)
            save(WORK/'summary.json', record)
            inspection, retirement = read(INSPECTION/'summary.json'), read(RETIREMENT/'summary.json')
            require(sha(INSPECTION/'summary.json') == retirement['inspection_sha256'] == INSPECTION_SHA, 'inspection identity')
            require(retirement['script_sha256'] == sha(RETIREMENT/'retirement-script.py') == RUNNER_SHA, 'approved script identity')
            require(inspection['status'] == retirement['status'] == 'passed', 'completion')
            require(len(retirement['deleted']) == 3 and {x['arm'] for x in retirement['deleted']} == {'baseline','candidate','duplicate'}, 'scope')
            require(retirement['inventory_entries_verified'] == 46166 and retirement['retained_files_verified'] == 1150, 'inventory counts')
            require(all(not Path(x['path']).exists() and not Path(x['path']).is_symlink() for x in retirement['deleted']), 'target reappeared')
            require(all(retirement[k] for k in ['retained_proofs_and_copies_preserved','public_inputs_preserved','cache_namespaces_workspaces_and_program_artifacts_preserved','original_screen_and_assessment_preserved','source_restoration_preserved']), 'preservation')
            for name, value in inspection['proof_files'].items(): require(sha(INSPECTION/name)==value, 'inspection proof changed')
            copies = read(INSPECTION/'retained-target-inputs.json')
            require(len(copies)==4812, 'copy bindings')
            for item in copies.values():
                p=Path(item['path'])
                require(p.is_relative_to(INSPECTION/'retained-target-inputs') and not p.is_symlink(), 'copy boundary')
                require(sha(p)==item['sha256'] and p.stat().st_size==item['bytes'], 'copy identity')
            retained = read(INSPECTION/'retained-proof-manifest.json')
            for path, item in retained.items():
                require(sha(path)==item['sha256'] and Path(path).stat().st_size==item['bytes'], 'retained proof changed')
            screen = ROOT/'results/strict-warm-host-library-screen-01'
            screen_summary = read(screen/'summary.json')
            require(screen_summary['status']=='passed' and screen_summary['archive']['all_member_hashes_verified'], 'saved screen status')
            require(sha(screen/screen_summary['archive']['path']) == retirement['archive_sha256'] == screen_summary['archive']['sha256'] == SCREEN_SHA, 'screen archive identity')
            entries = {}
            def add(path, name):
                require(path.is_file() and not path.is_symlink(), 'member file type')
                require(name not in entries and not name.startswith('/') and '..' not in Path(name).parts, 'member name')
                entries[name] = dict(source=str(path), bytes=path.stat().st_size, sha256=sha(path))
            for directory, prefix in [(INSPECTION,'inspection'),(RETIREMENT,'retirement')]:
                for path in regular_files(directory): add(path,prefix+'/'+path.relative_to(directory).as_posix())
            for name in ['inspect-host-library-screen-targets-01.py','retire-host-library-screen-targets-01.py']:
                add(OWNER/'.work'/name,'runners/'+name)
            add(Path(__file__),'runners/archive-host-library-screen-target-retirement-01.py')
            # These preserve the failed assessor preflight as well as successful
            # assessment ownership. The separately verified screen archive is linked,
            # not duplicated; no native targets or compiler binaries are read here.
            for run in ['01','02']:
                for parent, prefix in [(ROOT/'.work'/('host-library-screen-assessment-'+run),'assessment-'+run),
                    (ROOT/'.work/experiments'/('host-library-screen-assessment-supervisor-'+run),'assessment-supervisor-'+run)]:
                    for path in regular_files(parent): add(path,prefix+'/'+path.relative_to(parent).as_posix())
                add(ROOT/'.work'/('run-host-library-screen-assessment-'+run+'.py'),'runners/run-host-library-screen-assessment-'+run+'.py')
            for name in ['summary.json','assessment.md']:
                add(screen/name,'screen-prerequisite/'+name)
            byte_total=sum(row['bytes'] for row in entries.values())
            require(shutil.disk_usage(OWNER).free >= 8*1024**3 + byte_total*2, 'archive disk floor')
            require(not OUTPUT.exists(), 'output already exists'); OUTPUT.mkdir()
            archive=OUTPUT/'evidence.tar.xz'
            with lzma.open(archive,'wb',filters=[{'id':lzma.FILTER_LZMA2,'preset':3,'dict_size':64*1024*1024}]) as compressed:
                with tarfile.open(fileobj=compressed,mode='w|') as tar:
                    for name,item in sorted(entries.items()):
                        ti=tarfile.TarInfo(name); ti.mode=0o444; ti.mtime=0; ti.size=item['bytes']
                        with Path(item['source']).open('rb') as f: tar.addfile(ti,f)
            seen=set()
            with tarfile.open(archive,'r:xz') as tar:
                for member in tar:
                    require(member.isfile() and member.name in entries and member.name not in seen,'archive member type/name')
                    data=tar.extractfile(member).read(); row=entries[member.name]
                    require(len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],'archive member digest')
                    seen.add(member.name)
            require(seen==set(entries),'missing archive members')
            for row in entries.values(): require(sha(row['source'])==row['sha256'],'archive source changed')
            for path,item in retained.items(): require(sha(path)==item['sha256'],'retained source changed')
            with (OUTPUT/'members.json.gz').open('xb') as stream:
                with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:
                    compressed.write((json.dumps(entries,indent=2,sort_keys=True)+'\n').encode())
            require(json.loads(gzip.decompress((OUTPUT/'members.json.gz').read_bytes()))==entries,'manifest serialization')
            summary=dict(schema_version=1,status='passed',kind='completed-host-library-screen-target-retirement',
                inspection_pid=inspection['pid'],retirement_pid=retirement['pid'],archive_pid=os.getpid(),
                inspection_sha256=INSPECTION_SHA,retirement_sha256=sha(RETIREMENT/'summary.json'),approved_retirement_script_sha256=RUNNER_SHA,
                targets=retirement['deleted'],entries_verified=46166,retained_proof_files=1150,retained_target_input_paths=len(copies),
                retained_target_input_content_files=len({x['sha256'] for x in copies.values()}),
                allocated_bytes_before=inspection['allocated_bytes_unique_all_targets'],free_bytes_before=retirement['free_bytes_before'],
                free_bytes_after=retirement['free_bytes_after'],observed_free_byte_change=retirement['free_bytes_after']-retirement['free_bytes_before'],
                allocation_limit='Global free-space change may include unrelated allocations; st_blocks does not expose APFS shared extents.',
                screen_evidence=dict(path=str(screen),archive_sha256=SCREEN_SHA,commands=27,original_tests=14,artifact_snapshots=21),
                failed_assessor_preflight_preserved=True,source_restoration_and_retained_proofs_preserved=True,
                cache_metadata_and_program_artifacts_preserved=True,publication_guard_preserved=True,
                inspection_and_fresh_retirement_quiescence=True,raw_global_process_tables_retained=False,
                process_controls=0,compiler_builds=0,benchmarks=0,performance_claim=False,
                archive=dict(path=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(entries),
                             uncompressed_bytes=byte_total,all_member_hashes_verified=True,all_sources_rechecked=True),
                manifest=dict(path='members.json.gz',sha256=sha(OUTPUT/'members.json.gz')),
                packager_sha256=sha(__file__),finished_at=time.time())
            save(OUTPUT/'summary.json',summary)
            (OUTPUT/'README.md').write_text('''# Completed host-library screen target retirement

Only the three reviewed inner Cargo target directories from the completed host-library screen were retired. Cache namespaces, workspace metadata, program bytecode, source, all 27 command records, 14 test controls, 21 artifact snapshots and the saved screen assessment remain intact.

Fresh checks reconciled 46,166 inventory entries, 1,150 retained proof files and 4,812 original-to-copy bindings for generated source, bytecode and metadata. The targets had no symlinks, special files or external hardlinks. Compiler, tool and standard-library dependencies were disjoint by path and inode; live publication guards passed before and after. Fresh process and handle checks found no target users. Receipts retain process identities, hashes, counts and matching records; global process tables were not saved. No process was controlled.

Unique-inode allocated blocks totaled 8,750,202,880 bytes. Observed free space rose from 20,389,875,712 to 29,155,115,008 bytes (+8,765,239,296). APFS shared extents and concurrent unrelated allocations limit direct attribution.

The archive includes exact inspection and retirement scripts, receipts, inventories, guard proofs and retained target-input copies. It also preserves the initial failed assessment preflight and the successful retry. Every member and source was hash checked after packaging. Native target/compiler binaries are excluded. The separate [screen assessment](../strict-warm-host-library-screen-01/assessment.md) retains the measurement; this retirement makes no performance claim.
''')
            record.update(status='passed',finished_at=time.time(),output=str(OUTPUT),archive=summary['archive'],
                          summary_sha256=sha(OUTPUT/'summary.json'),free_bytes_after=shutil.disk_usage(OWNER).free)
            save(WORK/'summary.json',record); save(OUTPUT/'packaging-receipt.json',record)
            print(json.dumps(record),flush=True)
    except BaseException as error:
        record.update(status='failed',error=repr(error),finished_at=time.time());save(WORK/'summary.json',record);raise
if __name__=='__main__': main()
