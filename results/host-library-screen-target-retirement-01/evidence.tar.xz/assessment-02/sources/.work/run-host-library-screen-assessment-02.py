import hashlib, json, os, subprocess, sys, time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture, write_json

work = root / '.work/host-library-screen-assessment-02'
work.mkdir(exist_ok=False)
raw = root / '.work/strict-warm-host-library-screen-01'
output = root / 'results/strict-warm-host-library-screen-01'
lock_path = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
sha = lambda data: hashlib.sha256(data).hexdigest()
record = dict(owner=str(root), pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
              status='waiting', canonical_lock=str(lock_path), lock_wait_seconds=600,
              raw=str(raw), output=str(output), expected_commands=27, rust_builds=0, benchmarks=0)
write_json(work / 'summary.json', record)
try:
    with lock_path.open('r+') as lock:
        acquire_lock(lock, 600)
        record.update(status='running', lock_acquired_at=time.time(),
                      revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip())
        raw_inputs = {name: (raw / name).read_bytes() for name in ['summary.json', 'plan.json', 'records.json']}
        saved = json.loads(raw_inputs['summary.json'])
        if (saved.get('status') != 'passed' or saved.get('source_restored') is not True or
                saved.get('commands') != 27 or saved.get('candidate_policy') != 'host-library-opt' or
                len(json.loads(raw_inputs['records.json'])) != 27 or
                saved.get('plan_sha256') != sha(raw_inputs['plan.json']) or
                saved.get('records_sha256') != sha(raw_inputs['records.json'])):
            raise RuntimeError('screen is not a complete passed and restored 27-command history')
        if output.exists():raise RuntimeError('assessment destination already exists')
        plan = json.loads(raw_inputs['plan.json'])
        if set(plan['tools'].values()) != {'137ebb5ec945d8ef2c654f04bcdeaf66b1d1f14e87fb5f12ab26005177e14bb3'}:
            raise RuntimeError('host-library screen belongs to another tool publication')
        record['raw_input_hashes'] = {name: sha(data) for name, data in raw_inputs.items()}
        files = sorted(set((root / 'scripts').glob('*.py')) |
                       set((root / 'benchmarks/experiments/strict-warm-build').glob('*.py')) |
                       {Path(__file__)})
        record['source_hashes'] = {}
        for p in files:
            if p.is_symlink():raise RuntimeError('source snapshot contains a symlink: ' + str(p))
            data = p.read_bytes()
            record['source_hashes'][str(p)] = sha(data)
            dest = work / 'sources' / p.relative_to(root)
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        write_json(work / 'summary.json', record)
        command = [sys.executable, '-B', str(root / 'benchmarks/experiments/strict-warm-build/assess_owned_screen.py'),
                   str(raw), '--run-id', 'strict-warm-host-library-screen-01']
        child, out, err = capture(command, cwd=root, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                                  receipt_path=work / 'process.json', receipt=dict(expected_commands=27, raw=str(raw)))
        (work / 'stdout').write_text(out)
        (work / 'stderr').write_text(err)
        unchanged = all(sha(p.read_bytes()) == record['source_hashes'][str(p)] for p in files)
        raw_unchanged = all(sha((raw / name).read_bytes()) == value
                            for name, value in record['raw_input_hashes'].items())
        result = json.loads((output / 'summary.json').read_bytes()) if (output / 'summary.json').exists() else None
        complete = (child.returncode == 0 and result is not None and result.get('status') == 'passed' and
                    result.get('commands') == 27 and result.get('source_restored') is True and
                    result.get('archive', {}).get('all_member_hashes_verified') is True)
        record.update(status='passed' if complete and unchanged and raw_unchanged else 'failed',
                      returncode=child.returncode, child_pid=child.pid, command=command,
                      sources_unchanged=unchanged, raw_inputs_unchanged=raw_unchanged,
                      complete_expected_assessment=complete, archive=result.get('archive') if result else None,
                      finished_at=time.time(), stdout_sha256=sha(out.encode()), stderr_sha256=sha(err.encode()))
        write_json(work / 'summary.json', record)
        print(out, end='')
        print(err, end='', file=sys.stderr)
        sys.exit(0 if complete and unchanged and raw_unchanged else child.returncode or 1)
except BaseException as error:
    if not isinstance(error, SystemExit):
        record.update(status='failed', error=repr(error), finished_at=time.time())
        write_json(work / 'summary.json', record)
    raise
