import fcntl,hashlib,json,os,signal,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture
work=root/'.work/macro-screen-assessment-tests-02'
work.mkdir(exist_ok=False)
paths=sorted(set((root/'scripts').glob('*.py')) | set((root/'tests').glob('*.py')) | set((root/'benchmarks/experiments/strict-warm-build').glob('*.py')))
summary=dict(owner=str(root),supervisor_pid=os.getpid(),started_at=time.time(),performance_measurement=False,lock_wait_seconds=1800,
             source_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
def save(): (work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
save()
try:
 with (root/'.work/benchmark.lock').open('a') as lock:
  def timeout(signum, frame): raise TimeoutError('1800-second lock admission expired; no test child started')
  signal.signal(signal.SIGALRM,timeout)
  signal.alarm(1800)
  try: fcntl.flock(lock,fcntl.LOCK_EX)
  finally: signal.alarm(0)
  summary['lock_acquired_at']=time.time();save()
  command=[sys.executable,'-m','unittest','-v','test_owned_screen_assessment','test_qualified_public_tools']
  child,out,err=capture(command,cwd=root,env=dict(os.environ,PYTHONPATH=str(root/'tests')),receipt_path=work/'process.json',receipt={})
  (work/'stdout').write_text(out);(work/'stderr').write_text(err)
  summary.update(command=command,pid=child.pid,returncode=child.returncode,finished_at=time.time(),
                 status='passed' if child.returncode==0 else 'failed')
  assert all(hashlib.sha256(p.read_bytes()).hexdigest()==summary['source_hashes'][str(p)] for p in paths)
  save();print(json.dumps({k:v for k,v in summary.items() if k!='source_hashes'}));print(err,end='')
  sys.exit(child.returncode)
except BaseException as error:
 if 'status' not in summary:summary.update(status='failed',error=repr(error),finished_at=time.time());save()
 raise
