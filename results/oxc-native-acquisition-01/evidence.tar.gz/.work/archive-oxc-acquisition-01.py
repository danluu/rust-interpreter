import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

OWNER = Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
DEST = OWNER / 'results/oxc-native-acquisition-01'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

paths = set()
for name in ['oxc-acquisition-source-01/inputs.json', 'oxc-acquisition-launch-01.json',
             'oxc-acquisition-launch-record-01.json', 'oxc-acquisition-continuation-source-01/inputs.json',
             'oxc-acquisition-continuation-launch-01.json', 'oxc-acquisition-continuation-launch-record-01.json',
             'oxc-acquisition-continuation-verification-01.json', 'archive-oxc-acquisition-01.py']:
    paths.add(OWNER / '.work' / name)
for name in ['oxc-native-setup-01', 'oxc-acquisition-continuation-01']:
    root = OWNER / '.work' / name
    paths.update(p for p in root.glob('*.json') if p.is_file())
    paths.update(p for p in (root / 'commands').rglob('*') if p.is_file())
    # Retain all frozen source/evidence copies; executor bytes remain in the
    # task-owned setup with their exact hashes in these retained manifests.
    local_inputs = root / 'inputs' / str(OWNER).lstrip('/')
    paths.update(p for p in local_inputs.rglob('*') if p.is_file())
for name in ['oxc-native-acquisition-supervisor-01', 'oxc-acquisition-continuation-supervisor-01']:
    paths.update(p for p in (OWNER / '.work/experiments' / name).rglob('*') if p.is_file())
assert all(p.resolve(strict=True) == p and not p.is_symlink() for p in paths)
assert sum(p.stat().st_size for p in paths) < 96 * 2**20
members = {str(p.relative_to(OWNER)): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(paths)}
manifest = dict(schema_version=1, members=members, input_bytes=sum(r['bytes'] for r in members.values()),
    excluded_payloads='Downloaded source/registry/toolchain payloads and external system/rustup executor bytes remain in owned setup; full source/registry/toolchain inventories and all frozen executor hashes are retained.')
DEST.mkdir(parents=True, exist_ok=False)
with (DEST / 'manifest.json').open('x') as output:
    json.dump(manifest, output, sort_keys=True, indent=2)
    output.write('\n')
archive = DEST / 'evidence.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as output:
    for name, row in members.items():
        payload = (OWNER / name).read_bytes()
        assert hashlib.sha256(payload).hexdigest() == row['sha256']
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(payload), 0o644, 0
        output.addfile(item, io.BytesIO(payload))
assert archive.stat().st_size < 16 * 2**20
with tarfile.open(archive, 'r:gz') as retained:
    assert {m.name for m in retained} == set(members)
    for member in retained.getmembers():
        assert member.isfile() and member.size == members[member.name]['bytes']
        assert hashlib.sha256(retained.extractfile(member).read()).hexdigest() == members[member.name]['sha256']
    while retained.fileobj.read(1024**2):
        pass
print(json.dumps(dict(members=len(members), input_bytes=manifest['input_bytes'], archive_bytes=archive.stat().st_size,
                     archive_sha256=sha(archive), manifest_sha256=sha(DEST/'manifest.json')), indent=2))
