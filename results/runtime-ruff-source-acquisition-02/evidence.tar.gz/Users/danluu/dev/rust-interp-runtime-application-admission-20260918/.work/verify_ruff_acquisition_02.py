import hashlib,json,os,stat,time
from pathlib import Path
ROOT=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
HERE=ROOT/'experiments/runtime-application-admission/ruff-acquisition-02'
WORK=ROOT/'.work/ruff-source-acquisition-02'
def read(path):return json.loads(Path(path).read_bytes())
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def stamp(path):
 s=path.lstat();return {k:getattr(s,'st_'+k) for k in ['dev','ino','mode','nlink','size','mtime_ns','ctime_ns']}
def require(ok,message):
 if not ok:raise RuntimeError(message)
start=time.time();plan=read(HERE/'plan.json');freeze=read(HERE/'inputs.json');launch=read(HERE/'launch.json');terminal=read(WORK/'receipt.json');inventory=read(WORK/'acquired-inventory.json')
require(sha(HERE/'launch.json')=='b2990bcf8ab5a028834fdad93177c747e3a9d0ea4b8d40e07bb352c6475875f6','launch differs')
require(terminal['status']=='passed' and terminal['source_acquired'] and terminal['tracked_files']==11119 and terminal['tracked_bytes']==89102713,'terminal differs')
require(terminal['freeze_sha256']==sha(HERE/'inputs.json')==launch['source_freeze']['sha256'],'freeze differs')
require(sha(WORK/'acquired-inventory.json')==terminal['source_inventory']['sha256'],'inventory differs')
outer=read(ROOT/'.work/experiments/ruff-source-acquisition-supervisor-02/status.json')
execution=read(ROOT/'.work/ruff-source-acquisition-launch-execution-02/record.json')
require(outer['status']=='finished' and outer['returncode']==0 and outer['child_pid']==terminal['pid'] and outer['supervisor_pid']==terminal['parent_pid'],'outer association differs')
require(outer['started_at']<=terminal['started_at']<=terminal['admitted_at']<=terminal['finished_at']<=outer['finished_at'],'outer time bounds differ')
require(execution['returncode']==0 and execution['command']==launch['command'] and execution['environment']==launch['environment'] and execution['cwd']==str(ROOT),'launcher differs')
for base,record,fields in [(ROOT/'.work/ruff-source-acquisition-launch-execution-02',execution,['stdout','stderr'])]:
 for name in fields:require(sha(base/name)==record[name+'_sha256'],'outer raw stream differs')
require(sha(ROOT/'.work/experiments/ruff-source-acquisition-supervisor-02/command.log')==outer['log_sha256'],'outer command log differs')
for name,digest in freeze['files'].items():
 require(sha(name)==digest and sha(WORK/'inputs'/name.lstrip('/'))==digest,'source or retained input differs: '+name)
require(len(terminal['children'])==len(plan['commands'])==17,'child count differs')
pids=[]
for index,(row,expected) in enumerate(zip(terminal['children'],plan['commands'])):
 path=Path(row['path']);child=read(path/'receipt.json');require(child==row['receipt'],'saved child differs')
 require(row['label']==expected['label'] and child['command']==expected['argv'] and child['cwd']==expected['cwd'] and child['environment']==plan['environment'] and child['returncode']==0 and child['status']=='finished','actual child recipe differs')
 require(child['supervisor_pid']==terminal['pid'] and child['parent_pid']==terminal['parent_pid'],'child parent association differs')
 require(terminal['admitted_at']<=child['started_at']<=child['finished_at']<=terminal['finished_at'],'child time bounds differ')
 for name in ['stdout','stderr']:require(sha(path/name)==child[name+'_sha256'],'child raw stream differs')
 pids.append(child['pid'])
require(len(set(pids))==17,'duplicate child PIDs')
source=Path(plan['source']);original=Path(plan['original']);total=0;converted=[]
require(set(inventory)==set(plan['tracked']),'inventory membership differs')
for name,expected in plan['tracked'].items():
 path=source/name;source_before=stamp(path)
 require(stamp(original/name)==expected['stamp'],'original tracked source stamp differs')
 require(source_before==inventory[name]['stamp'],'acquired source stamp differs')
 require((source_before['dev'],source_before['ino'])!=(expected['stamp']['dev'],expected['stamp']['ino']),'source inode was shared')
 require(path.parent.resolve(strict=True)==path.parent,'acquired source parent is indirect')
 if expected['kind']=='symlink':
  require(path.is_symlink() and os.readlink(path)==expected['target'] and path.resolve(strict=True).is_relative_to(source),'source symlink differs')
  payload=os.fsencode(os.readlink(path));original_payload=os.fsencode(os.readlink(original/name))
 else:
  require(stat.S_ISREG(source_before['mode']) and source_before['nlink']==1 and bool(source_before['mode']&0o111)==(expected['mode']=='100755'),'source mode differs')
  payload=path.read_bytes();original_payload=(original/name).read_bytes()
 require(payload==original_payload and hashlib.sha256(payload).hexdigest()==expected['sha256'] and len(payload)==expected['bytes'],'source bytes differ')
 cleaned=payload
 if 'attributes' in expected:
  require(expected['attributes']['eol']=='crlf' and expected['attributes']['text'] in ['set','auto'],'unknown checkout conversion')
  cleaned=payload.replace(b'\r\n',b'\n');require(cleaned.replace(b'\n',b'\r\n')==payload,'mixed checkout newline conversion');converted.append(name)
 require(hashlib.sha1(b'blob '+str(len(cleaned)).encode()+b'\0'+cleaned).hexdigest()==expected['blob'],'Git blob differs')
 require(stamp(path)==source_before and stamp(original/name)==expected['stamp'],'source changed while hashing')
 require({k:v for k,v in inventory[name].items() if k!='stamp'}=={k:v for k,v in expected.items() if k!='stamp'},'retained inventory record differs')
 total+=len(payload)
found=set()
for directory,dirs,files in os.walk(source,followlinks=False):
 if Path(directory)==source:dirs.remove('.git')
 for name in [*dirs,*files]:
  path=Path(directory)/name
  if path.is_symlink() or not path.is_dir():found.add(str(path.relative_to(source)))
require(found==set(inventory)|{'.rust-interp-owned.json'},'unexpected source member')
require(total==89102713 and len(converted)==13,'source total differs')
marker=read(source/'.rust-interp-owned.json');require(marker['owner']==plan['runtime_owner'] and marker['revision']==plan['revision'] and marker['acquired_from']==plan['original'] and sha(source/'.rust-interp-owned.json')==terminal['marker']['sha256'],'source marker differs')
for prefix in ['original-before','acquired','original-after']:
 rows={row['label']:Path(row['path']) for row in terminal['children']}
 require((rows[prefix+'-head']/'stdout').read_text()==plan['revision']+'\n','HEAD differs')
 require(sha(rows[prefix+'-tree']/'stdout')==plan['tree_sha256'],'Git tree differs')
 require((rows[prefix+'-attributes']/'stdout').read_bytes()==plan['attributes_output'].encode(),'Git attributes differ')
 require((rows[prefix+'-status']/'stdout').read_bytes()==(b'?? .rust-interp-owned.json\n' if prefix=='acquired' else b''),'source status differs')
result=dict(status='passed',started_at=start,finished_at=time.time(),receipt_sha256=sha(WORK/'receipt.json'),source_inventory_sha256=sha(WORK/'acquired-inventory.json'),launch_sha256=sha(HERE/'launch.json'),children=17,pids=pids,tracked_files=11119,tracked_bytes=total,crlf_conversions=converted,frozen_inputs=len(freeze['files']),original_unchanged=True,actual_and_original_full_bytes_rehashed=True,exact_source_membership=True,benchmark=False)
p=ROOT/'.work/ruff-acquisition-independent-verification-02.json'
with p.open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(dict(status='passed',path=str(p),sha256=sha(p),receipt=result['receipt_sha256'],tracked_files=11119,tracked_bytes=total,children=17),indent=2))
