import hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
OWNER=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
HERE=OWNER/'experiments/runtime-application-admission/ruff-acquisition-02'
spec=importlib.util.spec_from_file_location('ruff_acquisition',HERE/'acquire_ruff.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
GIT=Path('/Applications/Xcode.app/Contents/Developer/usr/bin/git')
EXEC=Path('/Applications/Xcode.app/Contents/Developer/usr/libexec/git-core')
UPLOAD=Path('/Applications/Xcode.app/Contents/Developer/usr/bin/git-upload-pack')
PYTHON=Path('/opt/homebrew/bin/python3')
SH=Path('/bin/sh')
base=[str(GIT),'-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false','-c','maintenance.auto=false','-c','gc.auto=0']
env=dict(HOME=str(a.WORK/'home'),TMPDIR=str(a.WORK/'tmp')+'/',PATH='/Applications/Xcode.app/Contents/Developer/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin',LANG='C',LC_ALL='C',TZ='UTC',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_SYSTEM='/dev/null',GIT_CONFIG_GLOBAL='/dev/null',GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',GIT_ALLOW_PROTOCOL='file',GIT_EXEC_PATH=str(EXEC),GIT_ATTR_NOSYSTEM='1',GIT_LITERAL_PATHSPECS='1',DEVELOPER_DIR='/Applications/Xcode.app/Contents/Developer',__CF_USER_TEXT_ENCODING='0x1F5:0x0:0x0')
# Source inspection is read-only; the eventual launch creates these private paths.
inspection_env=env|dict(HOME='/var/empty',TMPDIR='/private/tmp/')
raw=subprocess.run([*base,'-C',str(a.ORIGINAL),'ls-tree','-rz','--full-tree',a.REVISION],env=inspection_env,capture_output=True,check=True).stdout
members=a.tree_records(raw)
converted=[]
for name,row in members.items():
 path=a.ORIGINAL/name
 payload=os.fsencode(os.readlink(path)) if row['mode']=='120000' else path.read_bytes()
 digest=hashlib.sha1(b'blob '+str(len(payload)).encode()+b'\0'+payload).hexdigest()
 if digest!=row['blob']:converted.append(name)
a.require(0<len(converted)<=256,'unexpected checkout conversion count')
attributes_output=subprocess.run([*base,'-C',str(a.ORIGINAL),'check-attr','-z','--all','--',*converted],env=inspection_env,capture_output=True,check=True).stdout.decode()
attribute_fields=attributes_output.split('\0')
a.require(attribute_fields.pop()=='' and len(attribute_fields)%3==0,'malformed Git attribute response')
attributes={name:{} for name in converted}
for i in range(0,len(attribute_fields),3):
 name,key,value=attribute_fields[i:i+3]
 a.require(name in attributes and key not in attributes[name],'unexpected Git attribute response')
 attributes[name][key]=value
for name,attrs in attributes.items():
 a.require(attrs.get('eol')=='crlf' and attrs.get('text') in ('set','auto'),'unsupported checkout conversion')
 members[name]['attributes']=attrs
tracked={name:a.inspect_member(a.ORIGINAL,name,row) for name,row in members.items()}
a.require(len(tracked)==11119 and sum(row['bytes'] for row in tracked.values())==89102713,'source inventory differs')
providers=[GIT,UPLOAD,SH,Path('/bin/ps'),Path('/usr/sbin/lsof'),PYTHON,Path('/usr/bin/git')]
providers += [EXEC/name for name in ['git','git-upload-pack','git-index-pack','git-fetch-pack','git-unpack-objects','git-rev-list','git-checkout','git-init','git-fetch','git-status','git-ls-tree','git-rev-parse','git-check-attr']]
executors={str(p):dict(resolved=str(p.resolve(strict=True)),sha256=a.sha(p),stamp=a.stamp(p),link_text=os.readlink(p) if p.is_symlink() else None) for p in providers}
config_paths=[a.ORIGINAL/'.git/config',a.ORIGINAL/'.git/info/attributes',a.ORIGINAL/'.git/info/grafts',a.ORIGINAL/'.git/HEAD',a.ORIGINAL/'.rust-interp-owned.json']
for root in [OWNER,a.R_OWNER,a.ORIGINAL]:
 for ancestor in [root,*root.parents]:
  config_paths += [ancestor/'.cargo/config',ancestor/'.cargo/config.toml']
configuration={}
for path in sorted(set(config_paths)):
 a.require(not path.is_symlink(),'indirect configuration path')
 configuration[str(path)]=dict(exists=path.exists())
 if path.exists():
  a.require(path.is_file(),'non-file configuration')
  configuration[str(path)].update(stamp=a.stamp(path),sha256=a.sha(path))
commands=[]
def row(label,args,cwd=OWNER):commands.append(dict(label=label,argv=[*base,*map(str,args)],cwd=str(cwd)))
def identity(prefix,root):
 row(prefix+'-head',['-C',root,'rev-parse','HEAD'])
 row(prefix+'-tree',['-C',root,'ls-tree','-rz','--full-tree',a.REVISION])
 row(prefix+'-status',['-C',root,'status','--porcelain=v1','--untracked-files=all' if prefix=='acquired' else '--untracked-files=no'])
 row(prefix+'-attributes',['-C',root,'check-attr','-z','--all','--',*converted])
row('git-version-before',['--version'])
identity('original-before',a.ORIGINAL)
row('init',['init','--template='+str(a.WORK/'empty-template'),a.SOURCE])
row('fetch',['-C',a.SOURCE,'fetch','--no-tags','--depth=1','--upload-pack='+str(UPLOAD),a.ORIGINAL,a.REVISION])
row('checkout',['-C',a.SOURCE,'checkout','--detach',a.REVISION])
identity('acquired',a.SOURCE)
identity('original-after',a.ORIGINAL)
row('git-version-after',['--version'])
plan=dict(schema_version=1,status='unexecuted',owner=str(OWNER),runtime_owner=str(a.R_OWNER),source=str(a.SOURCE),original=str(a.ORIGINAL),revision=a.REVISION,work=str(a.WORK),canonical_lock='/Users/danluu/dev/rust-interp/.work/benchmark.lock',wait_seconds=600,environment=env,platform=list(os.uname()),executors=executors,configuration=configuration,attributes_output=attributes_output,tracked=tracked,tracked_bytes=sum(row['bytes'] for row in tracked.values()),tree_sha256=hashlib.sha256(raw).hexdigest(),git_version=subprocess.run([str(GIT),'--version'],env=inspection_env,capture_output=True,check=True,text=True).stdout,commands=commands,bounds=dict(entry_free_gib=16,active_child_stop_gib=9,running_floor_gib=8,allocated_bytes=512*2**20,evidence_bytes=128*2**20,retained_input_bytes=96*2**20,retained_single_input_bytes=32*2**20,command_output_bytes=8*2**20),application_qualified=False,benchmark=False)
def write(path,data):
 with path.open('x') as f:json.dump(data,f,sort_keys=True,indent=2);f.write('\n')
write(a.PLAN,plan)
files=[HERE/'acquire_ruff.py',a.PLAN,OWNER/'experiments/stable-cgu/owned_stage.py',OWNER/'scripts/supervise_experiment.py',Path(__file__).resolve()]
files += [p.resolve(strict=True) for p in providers]
files += [Path(name) for name,row in configuration.items() if row['exists']]
framework=PYTHON.resolve().parents[1]/'Python'
a.require(framework.is_file(),'Python framework provider missing')
files.append(framework)
frozen=dict(schema_version=1,owner=str(OWNER),python=dict(path=str(PYTHON),resolved=str(PYTHON.resolve()),sha256=a.sha(PYTHON)),files={str(p):a.sha(p) for p in sorted(set(files))})
write(a.FROZEN,frozen)
launch=dict(schema_version=1,status='unexecuted',owner=str(OWNER),cwd=str(OWNER),environment=env,command=[str(PYTHON),'-B',str(OWNER/'scripts/supervise_experiment.py'),'--run-id','ruff-source-acquisition-supervisor-02','--',str(PYTHON),'-B',str(HERE/'acquire_ruff.py'),'--frozen-sha',a.sha(a.FROZEN)],helper=dict(path=str(HERE/'acquire_ruff.py'),sha256=a.sha(HERE/'acquire_ruff.py')),plan=dict(path=str(a.PLAN),sha256=a.sha(a.PLAN)),source_freeze=dict(path=str(a.FROZEN),sha256=a.sha(a.FROZEN)),python=frozen['python'],canonical_lock=plan['canonical_lock'],wait_seconds=600,bounds=plan['bounds'],expected_direct_children=17,review_required_before_launch=True)
write(HERE/'launch.json',launch)
print(json.dumps(dict(files=len(files),unique_inputs=len(frozen['files']),input_bytes=sum(Path(p).stat().st_size for p in frozen['files']),tracked_files=len(tracked),tracked_bytes=plan['tracked_bytes'],helper=a.sha(HERE/'acquire_ruff.py'),plan=a.sha(a.PLAN),freeze=a.sha(a.FROZEN),launch=a.sha(HERE/'launch.json')),indent=2))
