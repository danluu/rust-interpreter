import hashlib,json,os
from pathlib import Path
ROOT=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
OLD=Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918/.work/archive_runtime_std_evidence_01.py')
helper=ROOT/'.work/archive_ruff_acquisition_01.py'
s=OLD.read_text().replace('Retain completed std setup proof; never read native or metadata payload files.','Retain completed Ruff acquisition proof; never read live application payload files.')
s=s.replace("Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')",'Path('+repr(str(ROOT))+')')
s=s.replace("'.work/runtime-std-evidence-freeze-01.json'","'.work/ruff-evidence-freeze-01.json'").replace("'.work/runtime-std-evidence-archive-01'","'.work/ruff-evidence-archive-01'").replace("'results/runtime-std-preparation-01'","'results/runtime-ruff-source-acquisition-02'")
s=s.replace("SETUP = ROOT / '.work/runtime-std-preparation-supervision-01'\nRUN = ROOT / '.work/runtime-std-source-paths-01'","SETUP = ROOT / '.work/ruff-source-acquisition-02'")
s=s.replace('489fbd41672ba25c39daee0c31be2ddb36bb08af','8afe1ada316acc721e764e1c7d3cea3dfb1df90e')
s=s.replace('owned.disk(ROOT, 8)','owned.disk(ROOT, 9)').replace('8 * 2**30 + 192 * MIB','9 * 2**30 + 192 * MIB')
start=s.index("            setup = json.loads(payloads[str(SETUP / 'receipt.json')])")
end=s.index('            payloads[str(FREEZE)] = freeze_bytes',start)
s=s[:start]+'''            setup = json.loads(payloads[str(SETUP / 'receipt.json')])
            require(digest(payloads[str(SETUP / 'receipt.json')]) == 'd4493e4564e23aef0d0f3bd89cc7799dd6855b1cdcf9dd0ca32308ba7c63880f'
                    and setup['status'] == 'passed' and len(setup['children']) == 17, 'Ruff acquisition differs')
            verified_path = ROOT / '.work/ruff-acquisition-independent-verification-02.json'
            verified = json.loads(payloads[str(verified_path)])
            require(digest(payloads[str(verified_path)]) == '2eafb3da724027c0949dada074692d9731f91adc27f0fdbf71e3ce4118d373f0'
                    and verified['status'] == 'passed' and verified['children'] == 17
                    and verified['tracked_files'] == 11119 and verified['tracked_bytes'] == 89102713
                    and verified['actual_and_original_full_bytes_rehashed'] and verified['exact_source_membership'],
                    'Ruff independent verification differs')
            for row in setup['children']:
                path = Path(row['path'])
                require(json.loads(payloads[str(path / 'receipt.json')]) == row['receipt'], 'Ruff child record differs')
                for name in ('stdout', 'stderr'):
                    require(digest(payloads[str(path / name)]) == row['receipt'][name + '_sha256'], 'Ruff raw stream differs')
            require(digest(payloads[setup['source_inventory']['path']]) == setup['source_inventory']['sha256'],
                    'Ruff inventory differs')
'''+s[end:]
start=s.index('            summary = dict(schema_version=1')
end=s.index('                archive=dict(',start)
s=s[:start]+'''            summary = dict(schema_version=1, status='passed', source_commit=freeze['source_commit'],
                source_owner=setup['runtime_owner'], source_revision=setup['revision'], source=setup['source'],
                setup_receipt_sha256=digest(payloads[str(SETUP / 'receipt.json')]), direct_children=17,
                source_inventory_sha256=setup['source_inventory']['sha256'],
                tracked_files=verified['tracked_files'], tracked_bytes=verified['tracked_bytes'],
                exact_source_membership=True, original_unchanged=True, crlf_conversions=len(verified['crlf_conversions']),
                retained_input_files=verified['frozen_inputs'], acquisition_only=True,
                actual_commands_rerun=False, live_application_payload_read_by_archive=False,
                application_qualified=False, performance_target_met=False,
'''+s[end:]
helper.write_text(s);compile(s,str(helper),'exec')
paths={helper,ROOT/'.work/prepare_ruff_archive_01.py',ROOT/'.work/verify_ruff_acquisition_02.py',ROOT/'.work/ruff-acquisition-independent-verification-02.json',ROOT/'.work/launch_ruff_acquisition_02.py',ROOT/'.work/prepare_ruff_acquisition_01.py',ROOT/'.work/prepare_ruff_acquisition_02.py',ROOT/'experiments/stable-cgu/owned_stage.py',ROOT/'scripts/supervise_experiment.py'}
directories=[ROOT/'.work/ruff-source-acquisition-02',ROOT/'.work/ruff-source-acquisition-launch-execution-02',ROOT/'.work/experiments/ruff-source-acquisition-supervisor-02']
for directory in directories:paths.update(p for p in directory.rglob('*') if p.is_symlink() or not p.is_dir())
h=ROOT/'experiments/runtime-application-admission'
paths.update(h/name for name in ['acquire_ruff.py','ruff-acquisition-plan-01.json','ruff-acquisition-inputs-01.json','ruff-acquisition-launch-01.json'])
paths.update((h/'ruff-acquisition-02').iterdir())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={str(p):dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(paths)}
freeze=dict(owner=str(ROOT),source_commit='8afe1ada316acc721e764e1c7d3cea3dfb1df90e',python_sha256=sha(Path('/opt/homebrew/bin/python3').resolve()),files=files,input_bytes=sum(v['bytes'] for v in files.values()),directories={str(d):sorted(str(p) for p in d.rglob('*') if p.is_symlink() or not p.is_dir()) for d in directories})
path=ROOT/'.work/ruff-evidence-freeze-01.json'
with path.open('x') as f:json.dump(freeze,f,sort_keys=True,indent=2);f.write('\n')
env=json.loads((h/'ruff-acquisition-02/launch.json').read_bytes())['environment']
launch=dict(owner=str(ROOT),cwd=str(ROOT),environment=env,command=['/opt/homebrew/bin/python3','-B',str(ROOT/'scripts/supervise_experiment.py'),'--run-id','ruff-evidence-supervisor-01','--','/opt/homebrew/bin/python3','-B',str(helper),'--freeze-sha',sha(path)],freeze=dict(path=str(path),sha256=sha(path)),helper=dict(path=str(helper),sha256=sha(helper)))
launchpath=ROOT/'.work/ruff-evidence-launch-01.json'
with launchpath.open('x') as f:json.dump(launch,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(dict(files=len(files),input_bytes=freeze['input_bytes'],helper=sha(helper),freeze=sha(path),launch=sha(launchpath)),indent=2))
