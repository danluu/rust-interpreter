"""Retain completed Ruff acquisition proof; never read live application payload files."""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
FREEZE = ROOT / '.work/ruff-evidence-freeze-01.json'
WORK = ROOT / '.work/ruff-evidence-archive-01'
OUT = ROOT / 'results/runtime-ruff-source-acquisition-02'
OWNED = ROOT / 'experiments/stable-cgu/owned_stage.py'
SETUP = ROOT / '.work/ruff-source-acquisition-02'
MIB = 2 ** 20


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def stamp(path):
    s = path.lstat()
    return (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_nlink)


def capture(path, expected):
    require(path.resolve(strict=True) == path, 'indirect proof path')
    before = stamp(path)
    require(stat.S_ISREG(before[2]) and before[3] <= 32 * MIB, 'unbounded or nonordinary proof')
    data = path.read_bytes()
    require(stamp(path) == before and digest(data) == expected, 'proof bytes or identity changed')
    return data


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--freeze-sha', required=True)
    args = parser.parse_args()
    require(Path.cwd() == ROOT and sys.dont_write_bytecode and not sys.flags.optimize, 'fixed owner/Python -B required')
    freeze_bytes = capture(FREEZE, args.freeze_sha)
    freeze = json.loads(freeze_bytes)
    require(freeze['owner'] == str(ROOT) and freeze['source_commit'] == '8afe1ada316acc721e764e1c7d3cea3dfb1df90e', 'foreign source freeze')
    require(digest(Path(sys.executable).resolve().read_bytes()) == freeze['python_sha256'], 'Python changed')
    require(freeze['files'][str(OWNED)]['sha256'] == '7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e', 'owned helper differs')
    capture(OWNED, freeze['files'][str(OWNED)]['sha256'])
    capture(Path(__file__), freeze['files'][str(Path(__file__))]['sha256'])
    spec = importlib.util.spec_from_file_location('runtime_source_archive_owned', OWNED)
    owned = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = owned
    spec.loader.exec_module(owned)
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(), freeze_sha256=args.freeze_sha)
    owned.write(WORK / 'summary.json', record)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK, 600):
            free = owned.disk(ROOT, 9)
            require(free >= 9 * 2**30 + 192 * MIB, 'archive reservation unavailable')
            record.update(status='running', admitted_at=time.time(), free_bytes_before=free)
            owned.write(WORK / 'summary.json', record)
            payloads = {}
            for name, item in freeze['files'].items():
                owned.disk(ROOT, 9)
                data = capture(Path(name), item['sha256'])
                require(len(data) == item['bytes'], 'frozen proof size differs')
                payloads[name] = data
            require(len(payloads) <= 4096 and sum(map(len, payloads.values())) == freeze['input_bytes'] <= 128 * MIB, 'proof retention bound differs')
            for directory, members in freeze['directories'].items():
                actual = sorted(str(p) for p in Path(directory).rglob('*') if p.is_symlink() or not p.is_dir())
                require(actual == members, 'completed evidence directory membership changed')
            setup = json.loads(payloads[str(SETUP / 'receipt.json')])
            require(digest(payloads[str(SETUP / 'receipt.json')]) == 'd4493e4564e23aef0d0f3bd89cc7799dd6855b1cdcf9dd0ca32308ba7c63880f'
                    and setup['status'] == 'passed' and len(setup['children']) == 17, 'Ruff acquisition differs')
            verified_path = ROOT / '.work/ruff-acquisition-independent-verification-02.json'
            verified = json.loads(payloads[str(verified_path)])
            require(digest(payloads[str(verified_path)]) == '2eafb3da724027c0949dada074692d9731f91adc27f0fdbf71e3ce4118d373f0'
                    and verified['status'] == 'passed' and verified['children'] == 17
                    and verified['tracked_files'] == 11119 and verified['tracked_bytes'] == 89102713
                    and verified['actual_and_original_full_bytes_rehashed'] and verified['exact_source_membership'],
                    'Ruff independent verification differs')
            for row in setup['children']:
                path = Path(row['path'])
                require(json.loads(payloads[str(path / 'receipt.json')]) == row['receipt'], 'Ruff child record differs')
                for name in ('stdout', 'stderr'):
                    require(digest(payloads[str(path / name)]) == row['receipt'][name + '_sha256'], 'Ruff raw stream differs')
            require(digest(payloads[setup['source_inventory']['path']]) == setup['source_inventory']['sha256'],
                    'Ruff inventory differs')
            payloads[str(FREEZE)] = freeze_bytes
            OUT.mkdir(parents=True, exist_ok=False)
            archive = OUT / 'evidence.tar.gz'
            manifest, first = {}, {}
            with archive.open('xb') as stream:
                with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for path, data in sorted(payloads.items()):
                            owned.disk(ROOT, 9)
                            name = path.lstrip('/')
                            member = tarfile.TarInfo(name)
                            member.mode = 0o644
                            key = (digest(data), len(data))
                            if key in first:
                                member.type, member.linkname = tarfile.LNKTYPE, first[key]
                                tar.addfile(member)
                            else:
                                member.size = len(data)
                                tar.addfile(member, io.BytesIO(data))
                                first[key] = name
                            manifest[name] = dict(source=path, sha256=key[0], bytes=key[1])
            require(archive.stat().st_size <= 128 * MIB, 'compressed proof bound exceeded')
            seen = set()
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    owned.disk(ROOT, 9)
                    require(member.name in manifest and member.name not in seen and (member.isfile() or member.islnk()), 'unexpected archive member')
                    if member.islnk():
                        require(member.linkname in seen, 'forward or missing proof link')
                    data = tar.extractfile(member).read()
                    item = manifest[member.name]
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback differs')
                    seen.add(member.name)
            require(seen == set(manifest), 'incomplete archive readback')
            uncompressed = 0
            with gzip.open(archive, 'rb') as compressed:
                while block := compressed.read(MIB):
                    owned.disk(ROOT, 9)
                    uncompressed += len(block)
                    require(uncompressed <= 136 * MIB, 'archive framing exceeds bound')
            # Reading gzip to EOF separately verifies its complete trailer/CRC.

            for path, data in payloads.items():
                owned.disk(ROOT, 9)
                require(capture(Path(path), digest(data)) == data, 'proof changed during archival')
            owned.write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed', source_commit=freeze['source_commit'],
                source_owner=setup['runtime_owner'], source_revision=setup['revision'], source=setup['source'],
                setup_receipt_sha256=digest(payloads[str(SETUP / 'receipt.json')]), direct_children=17,
                source_inventory_sha256=setup['source_inventory']['sha256'],
                tracked_files=verified['tracked_files'], tracked_bytes=verified['tracked_bytes'],
                exact_source_membership=True, original_unchanged=True, crlf_conversions=len(verified['crlf_conversions']),
                retained_input_files=verified['frozen_inputs'], acquisition_only=True,
                actual_commands_rerun=False, live_application_payload_read_by_archive=False,
                application_qualified=False, performance_target_met=False,
                archive=dict(path='evidence.tar.gz', sha256=digest(archive.read_bytes()), bytes=archive.stat().st_size,
                    members=len(manifest), physical_members=len(first), all_member_hashes_verified=True,
                    full_gzip_eof_crc_verified=True, uncompressed_bytes=uncompressed),
                manifest_sha256=digest((OUT / 'manifest.json').read_bytes()),
                archive_pid=os.getpid(), archive_parent_pid=os.getppid(), archive_admitted_at=record['admitted_at'])
            owned.write(OUT / 'summary.json', summary)
            record.update(status='passed', finished_at=time.time(), free_bytes_after=owned.disk(ROOT, 9),
                summary_sha256=digest((OUT / 'summary.json').read_bytes()), archive=summary['archive'])
            owned.write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        owned.write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
