use chrono::Local;
use nu_config::ConfigFileKind;
use nu_engine::command_prelude::*;
use std::io::Write;

#[derive(Clone)]
pub struct ConfigReset;

impl Command for ConfigReset {
    fn name(&self) -> &str {
        "config reset"
    }

    fn signature(&self) -> Signature {
        Signature::build(self.name())
            .switch("nu", "Reset only nu config, config.nu.", Some('n'))
            .switch("env", "Reset only env config, env.nu.", Some('e'))
            .switch("without-backup", "Do not make a backup.", Some('w'))
            .input_output_types(vec![(Type::Nothing, Type::Nothing)])
            .allow_variants_without_examples(true)
            .category(Category::Env)
    }

    fn description(&self) -> &str {
        "Reset nushell environment configurations to default, and saves old config files in the config location as oldconfig.nu and oldenv.nu."
    }

    fn examples(&self) -> Vec<Example<'_>> {
        vec![Example {
            description: "Reset nushell configuration files.",
            example: "config reset",
            result: None,
        }]
    }

    fn run(
        &self,
        engine_state: &EngineState,
        stack: &mut Stack,
        call: &Call,
        _input: PipelineData,
    ) -> Result<PipelineData, ShellError> {
        let only_nu = call.has_flag(engine_state, stack, "nu")?;
        let only_env = call.has_flag(engine_state, stack, "env")?;
        let no_backup = call.has_flag(engine_state, stack, "without-backup")?;
        let span = call.head;
        let config_path = &engine_state.config_dirs.config_home;
        if !only_env {
            let kind = ConfigFileKind::Config;
            let mut nu_config = config_path.clone();
            nu_config.push(kind.path());
            let config_file = kind.scaffold();
            if !no_backup {
                let mut backup_path = config_path.clone();
                backup_path.push(format!(
                    "oldconfig-{}.nu",
                    Local::now().format("%F-%H-%M-%S"),
                ));
                if let Err(err) = std::fs::rename(nu_config.clone(), &backup_path) {
                    return Err(ShellError::Io(IoError::new_with_additional_context(
                        err.not_found_as(NotFound::Directory),
                        span,
                        backup_path,
                        "config.nu could not be backed up",
                    )));
                }
            }
            if let Ok(mut file) = std::fs::File::create(&nu_config)
                && let Err(err) = writeln!(&mut file, "{config_file}")
            {
                return Err(ShellError::Io(IoError::new_with_additional_context(
                    err.not_found_as(NotFound::File),
                    span,
                    nu_config,
                    "config.nu could not be written to",
                )));
            }
        }
        if !only_nu {
            let kind = ConfigFileKind::Env;
            let mut env_config = config_path.clone();
            env_config.push(kind.path());
            let config_file = kind.scaffold();
            if !no_backup {
                let mut backup_path = config_path.clone();
                backup_path.push(format!("oldenv-{}.nu", Local::now().format("%F-%H-%M-%S"),));
                if let Err(err) = std::fs::rename(env_config.clone(), &backup_path) {
                    return Err(ShellError::Io(IoError::new_with_additional_context(
                        err.not_found_as(NotFound::Directory),
                        span,
                        backup_path,
                        "env.nu could not be backed up",
                    )));
                }
            }
            if let Ok(mut file) = std::fs::File::create(&env_config)
                && let Err(err) = writeln!(&mut file, "{config_file}")
            {
                return Err(ShellError::Io(IoError::new_with_additional_context(
                    err.not_found_as(NotFound::File),
                    span,
                    env_config,
                    "env.nu could not be written to",
                )));
            }
        }
        Ok(PipelineData::empty())
    }
}
