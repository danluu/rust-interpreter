use log::info;
use nu_engine::eval_block;
use nu_parser::{find_main_block_id_in_script, parse};
use nu_protocol::{
    PipelineData, ShellError, Spanned, Value,
    debugger::WithoutDebug,
    engine::{EngineState, Stack, StateWorkingSet},
    process::check_exit_status_future,
    report_error::report_compile_error,
    report_parse_error, report_parse_warning,
    shell_error::generic::GenericError,
};

use crate::util::print_pipeline;

#[derive(Default)]
pub struct EvaluateCommandsOpts {
    pub table_mode: Option<Value>,
    pub error_style: Option<Value>,
    pub no_newline: bool,
}

/// Run a command (or commands) given to us by the user
pub fn evaluate_commands(
    commands: &Spanned<String>,
    engine_state: &mut EngineState,
    stack: &mut Stack,
    input: PipelineData,
    args: Vec<String>,
    opts: EvaluateCommandsOpts,
) -> Result<(), ShellError> {
    let EvaluateCommandsOpts {
        table_mode,
        error_style,
        no_newline,
    } = opts;

    // Handle the configured error style early
    if let Some(e_style) = error_style {
        match e_style.coerce_str()?.parse() {
            Ok(e_style) => {
                let mut config = engine_state.get_config().as_ref().clone();
                config.error_style = e_style;
                engine_state.set_config(config);
            }
            Err(err) => {
                return Err(ShellError::Generic(GenericError::new(
                    "Invalid value for `--error-style`",
                    err.to_string(),
                    e_style.span(),
                )));
            }
        }
    }

    // Parse the source code
    let (block, delta) = {
        if let Some(ref t_mode) = table_mode {
            let mut config = engine_state.get_config().as_ref().clone();
            config.table.mode = t_mode.coerce_str()?.parse().unwrap_or_default();
            engine_state.set_config(config);
        }

        let mut working_set = StateWorkingSet::new(engine_state);

        let check_errors = |working_set: &StateWorkingSet| {
            if let Some(warning) = working_set.parse_warnings.first() {
                report_parse_warning(Some(stack), working_set, warning);
            }

            if let Some(err) = working_set.parse_errors.first() {
                report_parse_error(Some(stack), working_set, err);
                std::process::exit(1);
            }

            if let Some(err) = working_set.compile_errors.first() {
                report_compile_error(Some(stack), working_set, err);
                std::process::exit(1);
            }
        };

        let mut output = parse(&mut working_set, None, commands.item.as_bytes(), false);
        check_errors(&working_set);

        if find_main_block_id_in_script(&working_set, &output).is_some() {
            // The CLI parser has already escaped script arguments via `args_to_script`, so we must not
            // escape them again here or we would double-quote values like `"arg 2"`.
            output = parse(
                &mut working_set,
                None,
                format!("main {}", args.join(" ")).as_bytes(),
                false,
            );
            check_errors(&working_set);
        }

        (output, working_set.render())
    };

    // Update permanent state
    engine_state.merge_delta(delta)?;

    // Run the block
    let pipeline = eval_block::<WithoutDebug>(engine_state, stack, &block, input)?;

    let pipeline_data = pipeline.body;
    if let PipelineData::Value(Value::Error { error, .. }, ..) = pipeline_data {
        return Err(*error);
    }

    if let Some(t_mode) = table_mode {
        let mut config = engine_state.get_config().as_ref().clone();
        config.table.mode = t_mode.coerce_str()?.parse().unwrap_or_default();
        engine_state.set_config(config);
    }

    print_pipeline(engine_state, stack, pipeline_data, no_newline)?;
    info!("evaluate {}:{}:{}", file!(), line!(), column!());
    let pipefail = nu_experimental::PIPE_FAIL.get();
    if !pipefail {
        return Ok(());
    }
    // After print pipeline, need to check exit status to implement pipeline feature.
    check_exit_status_future(pipeline.exit)
}
