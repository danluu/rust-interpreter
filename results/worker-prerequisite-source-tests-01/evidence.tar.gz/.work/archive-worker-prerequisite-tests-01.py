import gzip, hashlib, io, json, os, re, sys, tarfile, time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import write_json

sha = lambda b: hashlib.sha256(b).hexdigest()
with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('r+') as lock:
    acquire_lock(lock, 1800)
    attempts, roots = [], []
    for number, expected_status in [('01','failed'),('02','passed')]:
        raw = root / ('.work/worker-prerequisite-tests-' + number)
        supervisor = root / ('.work/experiments/worker-prerequisite-tests-supervisor-' + number)
        result = json.loads((raw / 'summary.json').read_bytes())
        child = json.loads((raw / 'process.json').read_bytes())
        outer = json.loads((supervisor / 'status.json').read_bytes())
        plan = json.loads((supervisor / 'plan.json').read_bytes())
        stderr = (raw / 'stderr').read_text()
        counts = re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$', stderr, re.M)
        expected_code = 0 if expected_status == 'passed' else 1
        assert result['status'] == expected_status and result['reported_counts'] == ['159']
        assert result['sources_unchanged'] and result['returncode'] == expected_code
        assert len(counts) == 1 and counts[0][0] == '159'
        if expected_status == 'passed':
            assert result['complete_expected_suite'] and re.search(r'^OK$', stderr, re.M)
        else:
            assert not result['complete_expected_suite'] and re.search(r'^FAILED \(errors=1\)$', stderr, re.M)
            assert "got an unexpected keyword argument 'qualification_policy'" in stderr
        assert child['status'] == 'finished' and child['returncode'] == expected_code and child['pid'] == result['child_pid']
        assert child['parent_pid'] == result['pid'] and child['command'] == result['command']
        assert child['expected_tests'] == 159 and child['suites'] == result['suites'] and len(result['suites']) == 21
        assert outer['status'] == 'finished' and outer['returncode'] == expected_code
        assert outer['child_pid'] == result['pid'] and outer['supervisor_pid'] == result['parent_pid']
        assert outer['plan_sha256'] == sha((supervisor / 'plan.json').read_bytes())
        assert outer['log_sha256'] == sha((supervisor / 'command.log').read_bytes())
        assert plan['supervisor_sha256'] == result['source_hashes'][str(root / 'scripts/supervise_experiment.py')]
        for name, digest in result['source_hashes'].items():
            snapshot = raw / 'sources' / Path(name).relative_to(root)
            assert not snapshot.is_symlink() and sha(snapshot.read_bytes()) == digest
        attempts.append(dict(attempt=number,status=expected_status,source_revision=result['revision'],
            tests=159,reported_test_seconds=float(counts[0][1]),supervisor_pid=outer['supervisor_pid'],
            helper_pid=result['pid'],child_pid=child['pid'],source_snapshots=len(result['source_hashes']),
            sources_unchanged=True,raw_path=str(raw),supervisor_path=str(supervisor),
            summary_sha256=sha((raw/'summary.json').read_bytes())))
        roots += [raw,supervisor]
    out = root / 'results/worker-prerequisite-source-tests-01'
    out.mkdir(exist_ok=False)
    files = {str(p.relative_to(root)): p for base in roots for p in base.rglob('*') if p.is_file()}
    for path in [Path(__file__)]:
        files[str(path.relative_to(root))] = path
    payloads, manifest = {}, {}
    for name, path in sorted(files.items()):
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        payloads[name] = data
        manifest[name] = dict(bytes=len(data), sha256=sha(data))
    archive = out / 'evidence.tar.gz'
    with archive.open('xb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as writer:
            for name, data in payloads.items():
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = files[name].stat().st_mode & 0o777
                writer.addfile(entry, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as reader:
        assert len(reader.getnames()) == len(manifest) and set(reader.getnames()) == set(manifest)
        for member in reader.getmembers():
            assert member.isfile()
            data = reader.extractfile(member).read()
            assert manifest[member.name] == dict(bytes=len(data), sha256=sha(data))
    write_json(out / 'manifest.json', manifest)
    summary = dict(status='passed',source_revision=result['revision'],tests=159,suites=result['suites'],
        reported_test_seconds=float(counts[0][1]),compiler_or_benchmark_commands=0,attempts=attempts,
        archive=dict(path='evidence.tar.gz',bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(manifest)),
        archive_verification=dict(pid=os.getpid(),parent_pid=os.getppid(),lock=str(Path(lock.name)),
                                  all_member_hashes_verified=True,finished_at=time.time()))
    write_json(out / 'summary.json',summary)
    (out / 'README.md').write_text(f'''# Worker and MonoItem prerequisite source tests

All 159 Python tests passed at source `{result['revision']}`
({counts[0][1]} seconds reported by unittest), with no skips. The first run at source `759498fe9e187ada955eb362e374287390682cb5`
completed all 159 tests with one error: an older publication mock rejected the
new qualification-policy keyword. The second run changes that mock to require
and assert the correct default policy; its publication-failure assertions remain.
Both attempts, including the failed run, are retained. The combined selection
retains all 16 prior compiler, launcher, standard-source, screen and assessor
suites and adds the five worker/publication suites. It includes the corrected
raw/tagged MonoItem evidence check and worker lock, copied-fixture and frozen
proof checks. No Rust build or benchmark ran in this test execution.

The archive contains both attempts' exact tested Python sources, worker fixture inputs,
`owned_stage.py`, shared public build helper, raw test output, child and external
supervisor receipts, and both task scripts. Source snapshot hashes were checked
against the test receipt, and every archive member was rehashed under the
canonical workload lock. Archive headers are normalized; payload bytes are
retained exactly. Public tool build and real 30-command worker qualification
remain separate prerequisites before the 27-command performance screen.
''')
    print(json.dumps(summary))
