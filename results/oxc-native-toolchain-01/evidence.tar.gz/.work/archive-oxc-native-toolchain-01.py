import gzip,hashlib,io,json,tarfile
from pathlib import Path
owner=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
dest=owner/'results/oxc-native-toolchain-01'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
paths={owner/'.work'/name for name in ['archive-oxc-native-toolchain-01.py','oxc-llvm-tools-acquisition-verification-01.json','oxc-native-toolchain-composition-failure-verification-01.json','oxc-native-toolchain-composition-continuation-verification-01.json','oxc-native-rustc-link-source-01.rs','oxc-native-rustc-link-source-01.json','verify-oxc-toolchain-continuation-01.py']}
for name in ['oxc-llvm-tools-acquisition','oxc-native-toolchain-composition','oxc-native-toolchain-composition-continuation']:
 for suffix in ['source-01/inputs.json','launch-01.json','launch-record-01.json']:paths.add(owner/'.work'/(name+'-'+suffix))
 work=owner/'.work'/(name+'-01')
 paths.update(p for p in work.glob('*.json') if p.is_file())
 paths.update(p for p in (work/'commands').rglob('*') if p.is_file())
 paths.update(p for p in (work/'inputs'/str(owner).lstrip('/')).rglob('*') if p.is_file())
 paths.update(p for p in (owner/'.work/experiments'/(name+'-supervisor-01')).rglob('*') if p.is_file())
 for leaf in ['strip.rs','run.rs','debug.o','stripped.o','stripped.rlib','rlib-object.o','stripped-program']:
  if (work/leaf).exists():paths.add(work/leaf)
assert all(p.resolve(strict=True)==p and not p.is_symlink() for p in paths)
assert sum(p.stat().st_size for p in paths)<128*2**20
members={str(p.relative_to(owner)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(paths)}
manifest=dict(schema_version=1,members=members,input_bytes=sum(r['bytes'] for r in members.values()),excluded_payloads='The exact official component archive, original/composed toolchain payload, externally supplied executors and their copied input bytes remain in owned paths. Their complete inventories/SHA identities, official manifest/component proof and every raw controlled child stream are preserved. No application build is represented.')
dest.mkdir(parents=True,exist_ok=False)
with (dest/'manifest.json').open('x') as stream:json.dump(manifest,stream,sort_keys=True,indent=2);stream.write('\n')
archive=dest/'evidence.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as output:
 for name,row in members.items():
  data=(owner/name).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
  entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;output.addfile(entry,io.BytesIO(data))
assert archive.stat().st_size<16*2**20
with tarfile.open(archive,'r:gz') as proof:
 assert {m.name for m in proof}==set(members)
 for m in proof.getmembers():assert m.isfile() and m.size==members[m.name]['bytes'] and hashlib.sha256(proof.extractfile(m).read()).hexdigest()==members[m.name]['sha256']
 while proof.fileobj.read(1024**2):pass
print(json.dumps(dict(members=len(members),input_bytes=manifest['input_bytes'],archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),manifest_sha256=sha(dest/'manifest.json')),indent=2))
