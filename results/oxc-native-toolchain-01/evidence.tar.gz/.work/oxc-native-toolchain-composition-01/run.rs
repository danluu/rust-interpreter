fn main() { println!("{}", std::hint::black_box(42)); }
