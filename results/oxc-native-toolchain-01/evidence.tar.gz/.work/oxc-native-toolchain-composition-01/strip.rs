pub fn strip_control(value: u64) -> u64 { value.wrapping_mul(3).wrapping_add(7) }
