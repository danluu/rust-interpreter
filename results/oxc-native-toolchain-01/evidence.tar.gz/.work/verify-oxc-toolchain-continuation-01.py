import hashlib, importlib.util, json, re
from pathlib import Path
owner=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
work=owner/'.work/oxc-native-toolchain-composition-continuation-01'
composed=owner/'.work/oxc-native-toolchain-composition-01'
outer=owner/'.work/experiments/oxc-native-toolchain-composition-continuation-supervisor-01'
def read(path): return json.loads(Path(path).read_bytes())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
r=read(work/'receipt.json'); o=read(outer/'status.json')
plan=read(owner/'experiments/oxc-plugin-normalization/native-toolchain-composition-continuation-plan-01.json')
frozen=read(owner/'.work/oxc-native-toolchain-composition-continuation-source-01/inputs.json')
assert r['status']=='passed' and o['status']=='finished' and o['returncode']==0
assert r['original_unchanged'] and r['stripping_qualified'] and not r['benchmark']
assert o['child_pid']==r['pid'] and o['supervisor_pid']==r['parent_pid']
assert o['started_at']<=r['started_at']<=r['admitted_at']<=r['finished_at']<=o['finished_at']
assert sha(outer/'command.log')==o['log_sha256']
for path,digest in frozen['files'].items():
 assert sha(path)==digest,path
 assert sha(work/'inputs'/path.lstrip('/'))==digest,path
spec=importlib.util.spec_from_file_location('identity_environment',owner/'scripts/workflow_controls.py')
controls=importlib.util.module_from_spec(spec);spec.loader.exec_module(controls)
expected=['identity-'+str(i) for i in range(1,5)]+['compiler-strip-binary','run-stripped-binary']
expected+=['identity-'+str(i) for i in range(5,9)]+['final-loader-'+str(i) for i in range(1,15)]
assert [c['label'] for c in r['children']]==expected and len(expected)==plan['expected_children']==24
inventory=read(composed/'toolchain-inventory.json'); original=read(plan['original_inventory'])
proof=read(plan['component_proof']); ledger=read(composed/'composition.json')
assert len(original)==65977 and len(inventory)==65992
assert set(inventory)==set(original)|set(proof['declared_files'])
assert len(ledger['component_files'])==15 and not any(p['collision'] for p in ledger['component_files'].values())
for name,row in original.items(): assert inventory[name]==row,name
for name in proof['declared_files']:
 row=proof['members']['llvm-tools-1.98.1-aarch64-apple-darwin/'+proof['component']+'/'+name]
 assert inventory[name]==dict(kind='file',bytes=row['bytes'],mode=row['mode'],sha256=row['sha256']),name
children={}
last=r['admitted_at']
for item in r['children']:
 label=item['label']; path=Path(item['path']); c=read(path/'receipt.json')
 assert c==item['receipt'] and c['status']=='finished' and c['returncode']==0
 assert c['supervisor_pid']==r['pid'] and c['parent_pid']==r['parent_pid']
 assert last<=c['started_at']<=c['finished_at']<=r['finished_at'];last=c['finished_at']
 assert c['cwd']==str(work)
 assert c['environment']==(controls.native_identity_environment(plan['environment']) if label.startswith('identity-') else plan['environment'])
 if '-loader-' in label:
  command=c['command'];assert command[:3]==['/usr/bin/otool','-arch','arm64'] and command[3] in ['-L','-l'] and len(command)==5
  file=Path(command[4]); name=str(file.resolve(strict=True).relative_to(composed/'toolchain')); assert sha(file)==inventory[name]['sha256']
 else: assert c['command']==plan['commands'][label],label
 for channel in ['stdout','stderr']: assert sha(path/channel)==c[channel+'_sha256']
 assert not (path/'stderr').read_bytes(),label
 children[label]=path
assert (children['run-stripped-binary']/'stdout').read_bytes()==b'42\n'
for name,row in r['artifacts'].items(): assert sha(work/name)==row['sha256'] and (work/name).stat().st_size==row['bytes']
identity=read(composed/'native-toolchain-identity.json');old_identity=read(plan['original_identity'])
for role in ['rustc','cargo']:
 assert identity['tools'][role]['sha256']==old_identity['tools'][role]['sha256']==sha(composed/'toolchain/bin'/role)
 assert identity['tools'][role]['version_stdout']==old_identity['tools'][role]['version_stdout']
assert read(composed/'initial-loaders.json')==read(work/'final-loaders.json')
loaders=read(composed/'initial-loaders.json');assert set(loaders)==set(plan['loader_roles'])
provider=composed/'toolchain/lib/rustlib/aarch64-apple-darwin/lib/libLLVM.dylib'
assert sha(provider)==sha(Path(plan['original_prefix'])/'lib/libLLVM.dylib')=='6f65eb3fd2cef5fa962c20b0520ee91a393b15bbe8b19b46d363d791b6bab028'
result=dict(status='passed',children=24,identity_children=8,loader_children=14,retained_failed_children=25,original_members=65977,composed_members=65992,official_component_files=15,compiler_and_cargo_identity_preserved=True,ordinary_stripping_qualified=True,application_compilation=False,benchmark=False,hashes={str(p.relative_to(owner)):sha(p) for p in [work/'receipt.json',outer/'status.json',outer/'command.log',composed/'receipt.json',composed/'composition.json',composed/'native-toolchain-identity.json',composed/'toolchain-inventory.json',composed/'initial-loaders.json',work/'final-loaders.json']})
out=owner/'.work/oxc-native-toolchain-composition-continuation-verification-01.json'
with out.open('x') as f: json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(result,indent=2));print('verification_sha256',sha(out))
