"""Synthetic screen contracts; no Cargo, exporter, guest or benchmark runs."""
import collections
import importlib.util
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

PATH = Path(__file__).resolve().parents[1] / 'benchmarks/experiments/strict-warm-build/screen.py'
SPEC = importlib.util.spec_from_file_location('strict_warm_screen', PATH)
screen = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(screen)


def case():
    return dict(tests=['tests::original'], negative=('wrong', 'v0', 'wrong'),
                edits=[('edit-' + str(n), 'v' + str(n - 1), 'v' + str(n)) for n in range(1, 6)])


ORIGINAL = b'fn production() { v0; }\n#[cfg(test)]\nmod tests { /* original assertion */ }'


class ScreenContracts(unittest.TestCase):
    def test_source_inventory_preserves_symlink_identity_without_following_it(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            directory = root / 'directory'
            directory.mkdir()
            link = root / 'link'
            link.symlink_to('directory', target_is_directory=True)
            directory_link = screen.frozen_input_hash(link)
            link.unlink()
            link.symlink_to('missing')
            dangling_link = screen.frozen_input_hash(link)
            self.assertNotEqual(directory_link, dangling_link)
            link.unlink()
            link.write_bytes(b'missing')
            self.assertNotEqual(dangling_link, screen.frozen_input_hash(link))
            with self.assertRaisesRegex(RuntimeError, 'not a file or symlink'):
                screen.frozen_input_hash(directory)

    def test_fresh_edits_and_compiled_controls_have_balanced_arm_positions(self):
        states = screen.protocol_states(ORIGINAL, case())
        self.assertEqual([s['phase'] for s in states],
            ['cold', 'wrong-edit', 'recovery', *['edit'] * 5, 'restoration'])
        self.assertEqual(len({s['source'] for s in states if s['phase'] == 'edit'}), 5)
        self.assertEqual([states[n]['source'] for n in [0, 2, 8]], [ORIGINAL] * 3)
        for mode in screen.MODES:
            self.assertEqual(collections.Counter(s['modes'].index(mode) for s in states),
                             {0: 3, 1: 3, 2: 3})
        self.assertTrue(all(s['source'].split(b'\n#[cfg(test)]')[1]
                            == ORIGINAL.split(b'\n#[cfg(test)]')[1] for s in states))

    def test_a_return_to_previously_compiled_source_cannot_be_an_edit(self):
        data = case()
        data['edits'][-1] = ('return-original', 'v4', 'v0')
        with self.assertRaisesRegex(RuntimeError, 'already compiled'):
            screen.protocol_states(ORIGINAL, data)

    def test_real_commands_keep_the_profile_and_all_original_tests(self):
        for mode in screen.MODES:
            command = screen.command_for(mode, 'a' * 64, Path('/owned/source'), Path('/owned/run'), {'index': 3})
            value = lambda option: command[command.index(option) + 1]
            self.assertEqual(value('--jobs'), '4')
            self.assertEqual(value('--suite-workers'), '2')
            self.assertEqual(value('--query-cache-retention'), 'demand' if mode == 'candidate' else 'off')
            self.assertEqual(value('--function-cache'), 'auto')
            self.assertEqual(value('--toolchain-lookup'), 'cached')
            self.assertEqual(value('--instruction-limit'), '100000000000')
            self.assertEqual(value('--allocation-limit'), '150000')
            self.assertEqual([command[i + 1] for i, arg in enumerate(command) if arg == '--entry'], screen.CASE['tests'])
            self.assertEqual(len(screen.CASE['tests']), 14)
            self.assertNotIn('--test-filter', command)
            self.assertFalse(any('mir-opt-level' in arg or 'inline-scale' in arg for arg in command))
        with self.assertRaisesRegex(RuntimeError, 'unknown screen arm'):
            screen.command_for('unknown', 'a' * 64, Path('/source'), Path('/run'), {'index': 3})

    def test_ambient_compiler_profile_overrides_cannot_change_one_arm(self):
        with patch.dict(os.environ, dict(PATH='/bin', CARGO_HOME='/cargo', RUSTFLAGS='-Zmir-opt-level=3',
                CARGO_PROFILE_TEST_OPT_LEVEL='3', RUSTC_WRAPPER='/wrong',
                RUST_INTERP_DEMAND_BODIES='1', RUST_TEST_THREADS='8'), clear=True):
            env = screen.environment()
        self.assertEqual(env, dict(PATH='/bin', CARGO_HOME='/cargo', CARGO_TERM_COLOR='never',
                                  RUST_INTERP_LAUNCH_STATS='1'))
        with patch.dict(os.environ, {'DYLD_INSERT_LIBRARIES': '/unknown'}, clear=True):
            with self.assertRaisesRegex(RuntimeError, 'dynamic-loader'):
                screen.environment()

    def test_native_policy_keeps_ordinary_commands_and_shared_launch_checks(self):
        for mode in screen.MODES:
            args = (mode, 'a' * 64, Path('/owned/source'), Path('/owned/run'), {'index': 3})
            demand = screen.command_for(*args)
            native = screen.command_for(*args, candidate_policy='native-host-mir')
            retention_index = demand.index('--query-cache-retention')
            self.assertEqual(native, demand[:retention_index] + demand[retention_index + 2:])
            expected = screen.launch_settings(mode, 'a' * 64)
            expected.pop('query_cache_retention')
            self.assertEqual(screen.launch_settings(mode, 'a' * 64, 'native-host-mir'), expected)
        with self.assertRaisesRegex(RuntimeError, 'unknown candidate policy'):
            screen.command_for(*args, candidate_policy='unknown')

    def test_candidate_capability_is_required_for_the_selected_policy(self):
        tool, key = Path('/owned/tool'), 'a' * 64
        for policy, capability in [('demand-retention', 'query-cache-retention'),
                                   ('native-host-mir', 'native-host-mir-policy'),
                                   ('stable-cgu', 'stable-cgu-partitioning')]:
            with patch.object(screen, 'require_export_option') as check:
                screen.require_candidate_policy(tool, key, policy)
                check.assert_called_once_with(tool, key, capability)
            with patch.object(screen, 'require_export_option', side_effect=RuntimeError('missing capability')):
                with self.assertRaisesRegex(RuntimeError, 'missing capability'):
                    screen.require_candidate_policy(tool, key, policy)

    def test_cgu_comparison_requires_one_compiler_and_tool_build(self):
        a, b, compiler = 'a' * 64, 'b' * 64, 'c' * 64
        screen.validate_comparison('stable-cgu', a, a, compiler, Path('/std/on/ready.json'))
        for policy in ['demand-retention', 'native-host-mir']:
            screen.validate_comparison(policy, a, b, None, None)
            with self.assertRaisesRegex(RuntimeError, 'distinct tool'):
                screen.validate_comparison(policy, a, a, None, None)
            with self.assertRaisesRegex(RuntimeError, 'custom compiler/std'):
                screen.validate_comparison(policy, a, b, compiler, Path('/std/on/ready.json'))
        with self.assertRaisesRegex(RuntimeError, 'identical tool'):
            screen.validate_comparison('stable-cgu', a, b, compiler, Path('/std/on/ready.json'))
        with self.assertRaisesRegex(RuntimeError, 'compiler key'):
            screen.validate_comparison('stable-cgu', a, a, None, Path('/std/on/ready.json'))
        with self.assertRaisesRegex(RuntimeError, 'candidate std'):
            screen.validate_comparison('stable-cgu', a, a, compiler, None)

    def test_cgu_commands_change_only_policy_and_independent_cache_paths(self):
        compiler_key = 'c' * 64
        for mode in screen.MODES:
            args = (mode, 'a' * 64, Path('/owned/source'), Path('/owned/run'), {'index': 3})
            ordinary = screen.command_for(*args, candidate_policy='native-host-mir')
            command = screen.command_for(*args, candidate_policy='stable-cgu', compiler_key=compiler_key)
            index = command.index('--compiler-key')
            self.assertEqual(command[index:index + 4], ['--compiler-key', compiler_key,
                '--stable-cgu-partitioning', 'on' if mode == 'candidate' else 'off'])
            self.assertEqual(command[:index] + command[index + 4:], ordinary)
            self.assertNotIn('--query-cache-retention', command)
        with self.assertRaisesRegex(RuntimeError, 'compiler key'):
            screen.command_for(*args, candidate_policy='stable-cgu')
        with self.assertRaisesRegex(RuntimeError, 'stable-CGU policy'):
            screen.command_for(*args, candidate_policy='native-host-mir', compiler_key=compiler_key)

    def test_cgu_launch_rejects_wrong_compiler_mode_and_discovery_path(self):
        custom = SimpleNamespace(key='c' * 64, rustc=Path('/owned/compiler/bin/rustc'),
            identity=dict(files={'bin/rustc': 'd' * 64}, compiler='custom rustc'))
        launch = screen.launch_settings('candidate', 'a' * 64, 'stable-cgu', custom)
        launch['toolchain_lookup'] = dict(mode='cached', outcome='owned-manifest')
        for key, value in [('key', 'b' * 64), ('rustc_sha256', 'e' * 64),
                           ('stable_cgu_partitioning', 'off')]:
            bad = json.loads(json.dumps(launch))
            bad['custom_compiler'][key] = value
            with self.assertRaisesRegex(RuntimeError, 'settings differ'):
                screen.checked_launch('rust-interp-launch: ' + json.dumps(bad),
                    'candidate', 'a' * 64, True, Path('/absent/suite'), Path('/absent/cache'),
                    candidate_policy='stable-cgu', custom=custom)
        launch['toolchain_lookup']['outcome'] = 'hit'
        with self.assertRaisesRegex(RuntimeError, 'toolchain lookup'):
            screen.checked_launch('rust-interp-launch: ' + json.dumps(launch),
                'candidate', 'a' * 64, True, Path('/absent/suite'), Path('/absent/cache'),
                candidate_policy='stable-cgu', custom=custom)

        launch['toolchain_lookup']['outcome'] = 'owned-manifest'
        expected_std = dict(key='f' * 64, sysroot='/std/on/sysroot', target='aarch64-apple-darwin')
        with self.assertRaisesRegex(RuntimeError, 'prepared std identity'):
            screen.checked_launch('rust-interp-launch: ' + json.dumps(launch),
                'candidate', 'a' * 64, True, Path('/absent/suite'), Path('/absent/cache'),
                candidate_policy='stable-cgu', custom=custom)
        for key, value in [('key', 'e' * 64), ('sysroot', '/std/off/sysroot'), ('target', 'other-target')]:
            launch['std_mir'] = expected_std | {key: value}
            with self.assertRaisesRegex(RuntimeError, 'different standard-library'):
                screen.checked_launch('rust-interp-launch: ' + json.dumps(launch),
                    'candidate', 'a' * 64, True, Path('/absent/suite'), Path('/absent/cache'),
                    candidate_policy='stable-cgu', custom=custom, prepared_std=expected_std)

    def test_prepared_custom_std_requires_matching_compiler_source_and_mode(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            sysroot = root / 'compiler'
            rustc = sysroot / 'bin/rustc'
            rustc.parent.mkdir(parents=True)
            rustc.write_bytes(b'compiler fixture')
            lock = sysroot / 'lib/rustlib/src/rust/library/Cargo.lock'
            lock.parent.mkdir(parents=True)
            lock.write_bytes(b'lock fixture')
            custom = SimpleNamespace(key='c' * 64, sysroot=sysroot, rustc=rustc,
                host='aarch64-apple-darwin', identity=dict(source_sha256='d' * 64))
            identity = dict(policy=screen.STD_POLICY, flags=screen.STD_FLAGS,
                compiler_key=custom.key, compiler='custom compiler identity', target=custom.host,
                source_sha256=custom.identity['source_sha256'], namespace='stable-cgu:off',
                lock_sha256=screen.sha(lock))
            key = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
            work = root / '.work/std-mir' / key
            lib = work / 'sysroot/lib/rustlib' / custom.host / 'lib'
            lib.mkdir(parents=True)
            artifacts = {}
            for crate in ['core', 'alloc', 'std', 'test', 'proc_macro']:
                artifact = lib / ('lib' + crate + '-fixture.rmeta')
                artifact.write_bytes(crate.encode())
                artifacts[str(artifact.relative_to(work))] = dict(stamp=screen.stamp(artifact),
                                                                  sha256=screen.sha(artifact))
            ready = work / 'ready.json'
            ready.write_text(json.dumps(dict(owner=str(root), identity=identity, artifacts=artifacts)))
            with patch.object(screen, 'ROOT', root), \
                 patch.object(screen.subprocess, 'check_output', return_value=identity['compiler']) as probe:
                result = screen.validate_std_ready(ready, {}, custom, 'off')
                self.assertEqual(result['key'], key)
                probe.assert_called_once_with([str(rustc), '-vV'], env={}, text=True)
                probe.reset_mock()
                with self.assertRaisesRegex(RuntimeError, 'identity or mode differs'):
                    screen.validate_std_ready(ready, {}, custom, 'on')
                custom.identity['source_sha256'] = 'e' * 64
                with self.assertRaisesRegex(RuntimeError, 'identity or mode differs'):
                    screen.validate_std_ready(ready, {}, custom, 'off')
                with self.assertRaisesRegex(RuntimeError, 'requires a custom compiler'):
                    screen.validate_std_ready(ready, {})
                probe.assert_not_called()

    def test_whole_command_clock_encloses_capture_without_stage_subtraction(self):
        events = []
        def clock():
            events.append('clock')
            return 10.0 if len(events) == 1 else 12.5
        def capture(*args, **kwargs):
            events.append('capture')
            return 'child', 'stdout', 'stderr'
        with patch.object(screen, 'child_usage', return_value=(1, 2)), \
             patch.object(screen, 'child_cpu_since', return_value=dict(user_seconds=3, system_seconds=1, total_seconds=4)), \
             patch.object(screen.time, 'perf_counter', side_effect=clock), \
             patch.object(screen, 'capture', side_effect=capture):
            result = screen.measure_command(['launcher'])
        self.assertEqual(events, ['clock', 'capture', 'clock'])
        self.assertEqual(result, ('child', 'stdout', 'stderr', 2.5,
                                 dict(user_seconds=3, system_seconds=1, total_seconds=4)))

    def test_receipt_capture_failure_never_becomes_a_successful_timing(self):
        with patch.object(screen, 'capture', side_effect=OSError('receipt failed')):
            with self.assertRaisesRegex(OSError, 'receipt failed'):
                screen.measure_command(['launcher'])

    def test_nonfinite_timing_and_incomplete_controls_are_rejected(self):
        with patch.object(screen, 'capture', return_value=('child', '', '')), \
             patch.object(screen.time, 'perf_counter', side_effect=[1.0, float('nan')]):
            with self.assertRaisesRegex(RuntimeError, 'wall time'):
                screen.measure_command(['launcher'])
        with self.assertRaisesRegex(RuntimeError, 'incomplete'):
            screen.assessment([])
        with self.assertRaisesRegex(RuntimeError, 'incomplete'):
            screen.assessment([dict(validated=False)] * 27)

    def test_missing_launcher_completion_and_wrong_mode_are_rejected(self):
        with self.assertRaisesRegex(RuntimeError, 'completed launcher report'):
            screen.checked_launch('compiler error', 'candidate', 'a' * 64, False,
                                  Path('/absent/suite'), Path('/absent/cache'))
        with self.assertRaisesRegex(RuntimeError, 'settings differ'):
            screen.checked_launch('rust-interp-launch: {"query_cache_retention":"off"}',
                                  'candidate', 'a' * 64, True, Path('/absent/suite'), Path('/absent/cache'))


if __name__ == '__main__':
    unittest.main()
