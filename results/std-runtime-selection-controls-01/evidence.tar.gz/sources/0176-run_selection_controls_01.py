#!/usr/bin/env python3
"""Retain one canonical-lock run of the 23 std preparation/selection controls."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

ROOT = Path('/Users/danluu/dev/rust-interp-runtime-std-selection-20260918')
WORK = ROOT / '.work/std-runtime-selection-controls-01'
OWNED = Path('/Users/danluu/dev/rust-interp-runtime-source-qualification-20260913/experiments/stable-cgu/owned_stage.py')
OWNED_SHA = '7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e'
BASE = '5f016241c7795bef75f90c7e2e3db403f0a5c733'
MODULES = ['test_std_runtime_selection', 'test_std_mir_source_paths']
LIMIT = 32 * 1024 * 1024


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def files():
    return sorted(p for folder in ['scripts', 'tests'] for p in (ROOT / folder).glob('*.py'))


def main():
    require(Path.cwd() == ROOT and sys.dont_write_bytecode and not sys.flags.optimize,
            'fixed cwd, Python -B and ordinary assertions required')
    require(sha(OWNED) == OWNED_SHA, 'owned supervisor changed')
    spec = importlib.util.spec_from_file_location('selection_owned', OWNED)
    owned = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owned)
    paths = files() + [Path(__file__).resolve(), OWNED, Path(sys.executable).resolve(strict=True)]
    require(all(p.is_file() and not p.is_symlink() and p.resolve(strict=True) == p for p in paths),
            'source or Python input is not ordinary')
    sources = {str(p): sha(p) for p in paths}
    total = sum(p.stat().st_size for p in paths)
    require(total <= LIMIT, 'source snapshot exceeds 32 MiB')
    WORK.mkdir(exist_ok=False)
    (WORK / 'tmp').mkdir()
    record = dict(schema_version=1, owner=str(ROOT), status='waiting', pid=os.getpid(),
        parent_pid=os.getppid(), started_at=time.time(), base_commit=BASE, sources=sources,
        source_bytes=total, canonical_lock=str(owned.CANONICAL_LOCK), wait_seconds=600,
        expected_tests=23, benchmark=False, real_compiler_commands=0)
    owned.write(WORK / 'summary.json', record)

    def guard():
        require(files() == paths[:-3], 'local Python module membership changed')
        for path, digest in sources.items():
            require(sha(Path(path)) == digest, 'test source changed: ' + path)

    try:
        with owned.workload_lock(owned.CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=owned.disk(ROOT, 9))
            guard()
            snapshots = {}
            for index, path in enumerate(paths):
                data = path.read_bytes()
                require(hashlib.sha256(data).hexdigest() == sources[str(path)], 'input changed during retention')
                target = WORK / 'sources' / (str(index).zfill(4) + '-' + path.name)
                target.parent.mkdir(exist_ok=True)
                with target.open('xb') as output:
                    output.write(data)
                require(sha(target) == sources[str(path)], 'retained input differs')
                snapshots[str(path)] = str(target.relative_to(WORK))
                owned.disk(ROOT)
            env = dict(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', HOME='/Users/danluu',
                TMPDIR=str(WORK / 'tmp') + '/', LANG='C', LC_ALL='C', TZ='UTC',
                PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')
            command = [sys.executable, '-B', '-m', 'unittest', '-v', *MODULES]
            record.update(snapshots=snapshots, command=command, environment=env)
            owned.write(WORK / 'summary.json', record)
            child = owned.run(command, cwd=ROOT / 'tests', env=env, out=WORK / 'command', capacity_root=ROOT)
            guard()
            for path, snapshot in snapshots.items():
                require(sha(WORK / snapshot) == sources[path], 'retained input changed')
            stderr = (WORK / 'command/stderr').read_text()
            actual = re.findall(r'^test_[^\n]* \(((?:test_std_runtime_selection|test_std_mir_source_paths)\.[^)]+)\) \.\.\. ok$', stderr, re.M)
            require(len(actual) == len(set(actual)) == 23 and
                re.search(r'^Ran 23 tests in [0-9.]+s$', stderr, re.M) and stderr.rstrip().endswith('OK')
                and not (WORK / 'command/stdout').read_bytes(), 'exact 23 passing controls required')
            record.update(status='passed', finished_at=time.time(), actual_tests=actual,
                command_receipt_sha256=sha(WORK / 'command/receipt.json'),
                all_sources_unchanged=True, free_bytes_after=owned.disk(ROOT))
            owned.write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', error=repr(error), finished_at=time.time())
        owned.write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
