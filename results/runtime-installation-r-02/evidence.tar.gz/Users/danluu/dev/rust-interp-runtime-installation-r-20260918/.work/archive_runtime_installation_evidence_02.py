"""Retain completed readmission and R02 proof; never read runtime payload files."""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
FREEZE = ROOT / '.work/runtime-installation-evidence-freeze-02.json'
WORK = ROOT / '.work/runtime-installation-evidence-archive-02'
OUT = ROOT / 'results/runtime-installation-r-02'
OWNED = ROOT / 'experiments/stable-cgu/owned_stage.py'
READMISSION = Path('/Users/danluu/dev/rust-interp-runtime-readmission-20260918/.work/runtime-readmission-01')
INSTALLATION = ROOT / '.work/runtime-installation-r-02'
MIB = 2 ** 20


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def stamp(path):
    s = path.lstat()
    return (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_nlink)


def capture(path, expected):
    require(path.resolve(strict=True) == path, 'indirect proof path')
    before = stamp(path)
    require(stat.S_ISREG(before[2]) and before[3] <= 32 * MIB, 'unbounded or nonordinary proof')
    data = path.read_bytes()
    require(stamp(path) == before and digest(data) == expected, 'proof bytes or identity changed')
    return data


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--freeze-sha', required=True)
    args = parser.parse_args()
    require(Path.cwd() == ROOT and sys.dont_write_bytecode and not sys.flags.optimize, 'fixed owner/Python -B required')
    freeze_bytes = capture(FREEZE, args.freeze_sha)
    freeze = json.loads(freeze_bytes)
    require(freeze['owner'] == str(ROOT) and freeze['source_commit'] == 'c357dc0aec1ccaec5bed8ef76184176b5f25d532', 'foreign source freeze')
    require(digest(Path(sys.executable).resolve().read_bytes()) == freeze['python_sha256'], 'Python changed')
    require(freeze['files'][str(OWNED)]['sha256'] == '7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e', 'owned helper differs')
    capture(OWNED, freeze['files'][str(OWNED)]['sha256'])
    capture(Path(__file__), freeze['files'][str(Path(__file__))]['sha256'])
    spec = importlib.util.spec_from_file_location('runtime_source_archive_owned', OWNED)
    owned = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = owned
    spec.loader.exec_module(owned)
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(), freeze_sha256=args.freeze_sha)
    owned.write(WORK / 'summary.json', record)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK, 600):
            free = owned.disk(ROOT, 8)
            require(free >= 8 * 2**30 + 192 * MIB, 'archive reservation unavailable')
            record.update(status='running', admitted_at=time.time(), free_bytes_before=free)
            owned.write(WORK / 'summary.json', record)
            payloads = {}
            for name, item in freeze['files'].items():
                owned.disk(ROOT, 8)
                data = capture(Path(name), item['sha256'])
                require(len(data) == item['bytes'], 'frozen proof size differs')
                payloads[name] = data
            require(len(payloads) <= 4096 and sum(map(len, payloads.values())) == freeze['input_bytes'] <= 128 * MIB, 'proof retention bound differs')
            for directory, members in freeze['directories'].items():
                actual = sorted(str(p) for p in Path(directory).rglob('*') if p.is_symlink() or not p.is_dir())
                require(actual == members, 'completed evidence directory membership changed')
            admission = json.loads(payloads[str(READMISSION / 'receipt.json')])
            installed = json.loads(payloads[str(INSTALLATION / 'receipt.json')])
            require(digest(payloads[str(READMISSION / 'receipt.json')]) == '5812037c34c633f5ec7bfeec1b6036e63e2cd6c988b3b51b0ba90668e3643129'
                    and admission['status'] == 'passed' and admission['full_current_guard_passed'], 'readmission differs')
            require(digest(payloads[str(INSTALLATION / 'receipt.json')]) == '18ab7ed4861ff08a021ea09922c3e40188ee8a16e88ecad556bb58079c7a5d8c'
                    and installed['status'] == 'passed' and installed['full_current_guard_passed_before_publication'], 'installation differs')
            for result in (admission, installed):
                require(len(result['children']) == 28, 'actual child count differs')
                for ref in result['children']:
                    require(digest(payloads[ref['path']]) == ref['sha256'], 'child association differs')
                    child = json.loads(payloads[ref['path']])
                    for name in ('stdout', 'stderr'):
                        raw = str(Path(ref['path']).parent / name)
                        require(digest(payloads[raw]) == child[name + '_sha256'], 'raw child stream differs')
            ready_ref = installed['ready']
            require(digest(payloads[ready_ref['path']]) == ready_ref['sha256'], 'runtime readiness proof differs')
            ready = json.loads(payloads[ready_ref['path']])
            require(ready['status'] == 'installed' and ready['application_qualified'] is False, 'runtime readiness claim differs')
            verified = json.loads(payloads[str(ROOT / '.work/runtime-installation-r-independent-verification-02.json')])
            require(verified['status'] == 'passed' and verified['ordinary_files_independently_hashed'] == 3709
                    and verified['runtime_bytes_independently_hashed'] == 650879912, 'installed-copy verification differs')
            payloads[str(FREEZE)] = freeze_bytes
            OUT.mkdir(parents=True, exist_ok=False)
            archive = OUT / 'evidence.tar.gz'
            manifest, first = {}, {}
            with archive.open('xb') as stream:
                with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for path, data in sorted(payloads.items()):
                            owned.disk(ROOT, 8)
                            name = path.lstrip('/')
                            member = tarfile.TarInfo(name)
                            member.mode = 0o644
                            key = (digest(data), len(data))
                            if key in first:
                                member.type, member.linkname = tarfile.LNKTYPE, first[key]
                                tar.addfile(member)
                            else:
                                member.size = len(data)
                                tar.addfile(member, io.BytesIO(data))
                                first[key] = name
                            manifest[name] = dict(source=path, sha256=key[0], bytes=key[1])
            require(archive.stat().st_size <= 128 * MIB, 'compressed proof bound exceeded')
            seen = set()
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    owned.disk(ROOT, 8)
                    require(member.name in manifest and member.name not in seen and (member.isfile() or member.islnk()), 'unexpected archive member')
                    if member.islnk():
                        require(member.linkname in seen, 'forward or missing proof link')
                    data = tar.extractfile(member).read()
                    item = manifest[member.name]
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback differs')
                    seen.add(member.name)
            require(seen == set(manifest), 'incomplete archive readback')
            uncompressed = 0
            with gzip.open(archive, 'rb') as compressed:
                while block := compressed.read(MIB):
                    owned.disk(ROOT, 8)
                    uncompressed += len(block)
                    require(uncompressed <= 136 * MIB, 'archive framing exceeds bound')
            # Reading gzip to EOF separately verifies its complete trailer/CRC.

            for path, data in payloads.items():
                owned.disk(ROOT, 8)
                require(capture(Path(path), digest(data)) == data, 'proof changed during archival')
            owned.write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed', source_commit=freeze['source_commit'],
                readmission_children=28, installation_children=28, raw_child_streams=112,
                runtime_key=installed['key'], runtime_ready_sha256=ready_ref['sha256'],
                readmission_receipt_sha256=digest(payloads[str(READMISSION / 'receipt.json')]),
                installation_receipt_sha256=digest(payloads[str(INSTALLATION / 'receipt.json')]),
                source_commit_qualified=admission['source_commit'], full_current_guard_passed=True,
                ordinary_files_independently_hashed=3709, runtime_bytes_independently_hashed=650879912,
                fresh_independent_inodes=True, immutable_modes_checked=True,
                default_source_snippets_verified=True, virtual_source_identity_verified=True,
                actual_commands_rerun=False, live_runtime_payload_read_by_archive=False,
                source_capability_published=True, application_qualified=False, performance_claim=False,
                archive=dict(path='evidence.tar.gz', sha256=digest(archive.read_bytes()), bytes=archive.stat().st_size,
                    members=len(manifest), physical_members=len(first), all_member_hashes_verified=True,
                    full_gzip_eof_crc_verified=True, uncompressed_bytes=uncompressed),
                manifest_sha256=digest((OUT / 'manifest.json').read_bytes()),
                archive_pid=os.getpid(), archive_parent_pid=os.getppid(), archive_admitted_at=record['admitted_at'])
            owned.write(OUT / 'summary.json', summary)
            record.update(status='passed', finished_at=time.time(), free_bytes_after=owned.disk(ROOT, 8),
                summary_sha256=digest((OUT / 'summary.json').read_bytes()), archive=summary['archive'])
            owned.write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        owned.write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
