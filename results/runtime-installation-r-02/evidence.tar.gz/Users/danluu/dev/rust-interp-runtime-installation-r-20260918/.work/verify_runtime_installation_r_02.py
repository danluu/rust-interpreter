"""Independently read the finished R installation and its recorded evidence."""
import hashlib,importlib.util,json,os,stat,sys,time
from pathlib import Path
OWNER=Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
HERE=OWNER/'experiments/runtime-compiler-installation/final-r-02'
WORK=OWNER/'.work/runtime-installation-r-02'
OUT=OWNER/'.work/runtime-installation-r-independent-verification-02.json'
sys.path.insert(0,str(OWNER/'scripts'))
import runtime_compiler as runtime
import std_mir_source_paths as std
from verified_std_diagnostics import source_span_text

def read(p):return json.loads(Path(p).read_bytes())
def sha(p):
 p=Path(p);assert p.resolve(strict=True)==p and p.is_file() and not p.is_symlink()
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def ref(p):return dict(path=str(p),sha256=sha(p))
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def spans(value):
 if isinstance(value,list):
  for v in value:yield from spans(v)
 elif isinstance(value,dict):
  if 'file_name' in value:yield value
  for v in value.values():yield from spans(v)
assert Path.cwd()==OWNER and sys.dont_write_bytecode and not OUT.exists()
owned=load('r02_independent_verification_owned',OWNER/'experiments/stable-cgu/owned_stage.py')
assert sha(OWNER/'experiments/stable-cgu/owned_stage.py')=='7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e'
record=dict(schema_version=1,status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),helper=ref(Path(__file__)))
owned.write(OUT,record)
try:
 with owned.workload_lock(owned.CANONICAL_LOCK,600):
  record.update(status='running',admitted_at=time.time(),free_bytes_before=owned.disk(OWNER,8));owned.write(OUT,record)
  plan=read(HERE/'plan.json');frozen=read(HERE/'inputs.json');launch=read(HERE/'launch.json')
  r=read(WORK/'receipt.json');outer_path=OWNER/'.work/experiments/runtime-installation-r-supervisor-02/status.json';outer=read(outer_path)
  execution_path=OWNER/'.work/runtime-installation-r-launch-execution-02/record.json';execution=read(execution_path)
  assert r['status']=='passed' and r['full_current_guard_passed_before_publication'] and len(r['children'])==28
  assert outer['status']=='finished' and outer['returncode']==0 and outer['child_pid']==r['pid']==70991 and outer['supervisor_pid']==r['parent_pid']==70957
  assert outer['started_at']<=r['started_at']<=r['admitted_at']<=r['finished_at']<=outer['finished_at']
  assert execution['status']=='finished' and execution['returncode']==0 and execution['command']==launch['command'] and execution['cwd']==launch['cwd'] and execution['environment']==launch['environment']
  for name in ('stdout','stderr'):assert sha(execution_path.parent/name)==execution[name+'_sha256']
  assert read(execution_path.parent/'stdout')['supervisor_pid']==outer['supervisor_pid']
  assert sha(outer_path.parent/'command.log')==outer['log_sha256']
  prior=read(plan['evidence']['stage2_plan']['path'])['previous'];children=[]
  for declaration,reference in zip(plan['children'],r['children']):
   p=Path(reference['path']);child=read(p)
   assert sha(p)==reference['sha256'] and p==Path(declaration['out'])/'receipt.json'
   assert child['status']=='finished' and child['returncode'] in declaration['expected']
   assert child['command']==declaration['argv'] and child['cwd']==declaration['cwd']
   env=prior['old_plan']['environment'] if declaration['kind']=='git' else (plan['environment'] if declaration['kind']=='selection' else plan['compiler_environment'])
   assert child['environment']==env and child['supervisor_pid']==r['pid'] and child['parent_pid']==r['parent_pid']
   assert r['admitted_at']<=child['started_at']<=child['finished_at']<=r['finished_at']
   ps=child['identity']['ps'];assert list(map(int,ps.split()[:2]))==[child['pid'],r['pid']]
   cwd=child['identity']['cwd'];assert (child['cwd'] in cwd if child['identity']['cwd_returncode']==0 else child['identity']['cwd_returncode']==1 and not cwd)
   for name in ('stdout','stderr'):assert sha(p.parent/name)==child[name+'_sha256']
   children.append(dict(reference,pid=child['pid'],raw_streams_verified=True,cwd_observation_available=child['identity']['cwd_returncode']==0))
  assert len(set(row['pid'] for row in children))==28
  for i in range(5):
   before=Path(r['children'][i]['path']).parent;after=Path(r['children'][i+22]['path']).parent
   assert (before/'stdout').read_bytes()==(after/'stdout').read_bytes()
  for path,h in frozen['files'].items():
   owned.disk(OWNER,8);assert sha(path)==h
   retained=WORK/'inputs'/path.lstrip('/');assert retained.stat().st_nlink==1 and sha(retained)==h
  spec=read(HERE/'specification.json');identity=runtime.identity_for(spec);key=runtime.digest(identity)
  compiler=runtime.load_runtime_compiler(OWNER,key);root=compiler.sysroot;ready_path=root.parent/'ready.json';ready=read(ready_path)
  assert compiler.identity==identity and key==plan['runtime_key'] and root==Path(plan['sysroot']) and sha(ready_path)==r['ready']['sha256']
  assert ready['application_qualified'] is False and not (root.parent/'failure.json').exists()
  before=runtime.tree_stamps(root);assert before==ready['stamps']
  checked=[];bytes_checked=0
  for component in spec['components']:
   for name,row in component['files'].items():
    owned.disk(OWNER,8);p=root/component['destination']/name;s=p.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not s.st_mode&0o222 and stat.S_IMODE(s.st_mode)==row['mode']&~0o222
    source=Path(component['root'])/name;source_stamp=source.lstat();assert (s.st_dev,s.st_ino)!=(source_stamp.st_dev,source_stamp.st_ino)
    assert s.st_size==row['size'] and sha(p)==row['sha256'];bytes_checked+=s.st_size;checked.append(str(p.relative_to(root)))
  assert len(checked)==3709 and bytes_checked==650879912 and runtime.tree_stamps(root)==before
  proof_path=root.parent/'qualification.json';assert sha(proof_path)==r['source_qualification']['sha256']==ready['prepublication_qualification']['sha256']
  assert proof_path.stat().st_nlink==1 and not proof_path.stat().st_mode&0o222
  proof=read(proof_path);probe=read(WORK/'source-probe/result.json');assert proof==probe and proof['status']=='passed' and proof['key']==key
  commit,source_files=std.compiler_sources(compiler);observed=[]
  for i,reference in enumerate(probe['commands']):
   p=Path(reference['path']).parent;assert sha(p/'receipt.json')==reference['sha256']
   raw=[json.loads(line) for line in (p/'stderr').read_bytes().splitlines() if line.strip()]
   assert any(d.get('level')=='error' and (d.get('code') or {}).get('code')=='E0080' for d in raw) and not (p/'stdout').read_bytes()
   seen=set();base=root/std.SOURCE if i==0 else Path('/rustc')/commit/'library'
   if i==0:std.validate_probe(raw,base,source_files)
   for span in spans(raw):
    if span['file_name']==str(WORK/'source-probe/source.rs'):continue
    name=str(Path(span['file_name']).relative_to(base));assert name in source_files
    source=root/std.SOURCE/name;assert sha(source)==source_files[name]
    retained=probe['retained_sources'][name];assert sha(retained['path'])==retained['sha256']==source_files[name]
    expected=source_span_text(span,source.read_bytes())
    assert span['text']==expected if i==0 else span['text']==[] or span['text']==expected
    if i==0:assert span['text']
    seen.add(name)
   assert {'core/src/panic.rs','std/src/macros.rs'}<=seen;observed.append(sorted(seen))
  assert runtime.load_runtime_compiler(OWNER,key)==compiler
  record.update(status='passed',finished_at=time.time(),free_bytes_after=owned.disk(OWNER,8),
   terminal=ref(WORK/'receipt.json'),outer=ref(outer_path),launch_execution=ref(execution_path),ready=ref(ready_path),
   qualification=ref(proof_path),admission=ref(root.parent/'admission.json'),ordered_children=children,raw_streams=56,
   frozen_sources=len(frozen['files']),retained_source_copies=len(frozen['files']),runtime_key=key,
   ordinary_files_independently_hashed=len(checked),runtime_bytes_independently_hashed=bytes_checked,
   fresh_independent_inodes=True,immutable_modes_checked=True,exact_before_after_stamps=True,source_observations=observed,
   native_reexecution=False,application_qualified=False,performance_claim=False)
  owned.write(OUT,record)
except BaseException as error:
 record.update(status='failed',finished_at=time.time(),error=repr(error));owned.write(OUT,record);raise
print(json.dumps(dict(verification=ref(OUT),terminal=record['terminal'],ready=record['ready'],qualification=record['qualification'])))
