"""Derive source-only readmission proposal; do not run tools or inventory E."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

OWNER=Path('/Users/danluu/dev/rust-interp-runtime-readmission-20260918')
HERE=OWNER/'experiments/runtime-compiler-installation/readmission-01'
R=Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
R_HERE=R/'experiments/runtime-compiler-installation/final-r-01'
WORK=OWNER/'.work/runtime-readmission-01'
sys.path.insert(0,str(OWNER/'scripts'))
import runtime_compiler as runtime

def read(p):return json.loads(Path(p).read_bytes())
def sha(p):
 p=Path(p);assert p.resolve(strict=True)==p and p.is_file() and not p.is_symlink()
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
old=read(R_HERE/'plan.json');candidate=read(old['evidence']['candidate']['path'])
identity=runtime.identity_for(candidate);root=Path(next(c['root'] for c in candidate['components'] if c['role']=='runtime'))
compiler=runtime.RuntimeCompiler(runtime.digest(identity),root,identity)
env=old['environment'];compiler_env=compiler.environment(env)
children=[]
def add(kind,argv,cwd=OWNER,expected=(0,),out=None):
 children.append(dict(kind=kind,argv=argv,cwd=str(cwd),expected=list(expected),
                      out=str(out or WORK/'commands'/f'{len(children):03}')))
for row in old['children'][:5]:add('git',row['argv'],row['cwd'])
add('selection',['/usr/bin/xcrun','--find','otool'])
by_name={str(Path(c['destination'])/n) if c['destination'] else n:Path(c['root'])/n
         for c in candidate['components'] for n in c['files']}
for name in sorted(candidate['loader']):add('loader',['/usr/bin/otool','-l',str(by_name[name])])
for args in [['-vV'],['--print','sysroot'],['-Zhelp']]:add('identity',[str(root/'bin/rustc'),*args])
probe=WORK/'source-probe'; common=[str(root/'bin/rustc'),str(probe/'source.rs'),'--crate-type=lib',
 '--edition=2024','--emit=metadata','--error-format=json','--sysroot',str(root)]
for i,args in enumerate([['-o',str(probe/'local.rmeta')],['-Ztranslate-remapped-path-to-local-path=no','-o',str(probe/'virtual.rmeta')]]):
 add('source',common+args,probe,(1,),probe/'commands'/str(i))
for row in old['children'][:5]:add('git',row['argv'],row['cwd'])
add('selection',['/usr/bin/xcrun','--find','otool']);assert len(children)==28
executors=dict(old['executors']);tool=dict(path=str(root/'bin/rustc'),sha256=identity['files']['bin/rustc'],stamp=runtime.stamp((root/'bin/rustc').lstat()))
# Only this single already-requested E stamp is observed before admission.
assert tool['stamp']==[16777229,1046410388,33216,52408,1789332860998581666,1789333228841623832,2]
executors.update(identity=tool,source=tool)
refs={k:v for k,v in old['evidence'].items() if k!='source_policy'}
refs['unexecuted_r01_plan']=dict(path=str(R_HERE/'plan.json'),sha256=sha(R_HERE/'plan.json'))
plan=dict(schema_version=1,status='prepared-unrun',owner=str(OWNER),work=str(WORK),
 policy='explicit-device-change-runtime-readmission-v1',canonical_lock=old['canonical_lock'],wait_seconds=600,
 environment=env,compiler_environment=compiler_env,executors=executors,selected_otool=old['selected_otool'],
 children=children,evidence=refs,guard_script=old['guard_script'],guard_inputs=old['guard_inputs'],old_plan_sha256=old['old_plan_sha256'],
 observed_device_change=dict(historical_device=16777231,current_device=16777229),
 historical_observation_scope='Only bin/rustc checked before this plan; complete equivalence must be established by this run.',
 retained_input_bound_bytes=64*2**20,output_and_metadata_reservation_bytes=128*2**20,
 entry_free_gib=10,active_child_stop_gib=9,running_floor_gib=8,
 historical_receipts_mutated=False,in_operation_stamp_fields_ignored=[],installation=False,benchmark=False)
write(HERE/'plan.json',plan)
files=read(R_HERE/'inputs.json')['files']
for p,h in files.items():assert sha(p)==h,p
for ref in refs.values():assert sha(ref['path'])==ref['sha256'];files[ref['path']]=ref['sha256']
paths=[*sorted((OWNER/'scripts').glob('*.py')),OWNER/'experiments/stable-cgu/owned_stage.py',
 OWNER/'experiments/runtime-compiler-installation/source_qualification.py',HERE/'requalify.py',HERE/'README.md',HERE/'plan.json',Path(__file__)]
for p in paths:
 files[str(p)]=sha(p)
 if p.suffix=='.py':ast.parse(p.read_bytes(),filename=str(p))
python=read(R_HERE/'inputs.json')['python'];assert str(Path(sys.executable).resolve())==python['resolved'] and sha(python['resolved'])==python['sha256']
size=sum(Path(p).stat().st_size for p in files);assert size<plan['retained_input_bound_bytes']
freeze=dict(schema_version=1,owner=str(OWNER),files=dict(sorted(files.items())),python=python,file_count=len(files),total_bytes=size,source_only=True)
write(HERE/'inputs.json',freeze)
launch=dict(schema_version=1,status='unexecuted',owner=str(OWNER),cwd=str(OWNER),environment=env,
 canonical_lock=plan['canonical_lock'],wait_seconds=600,entry_free_gib=10,active_child_stop_gib=9,running_floor_gib=8,
 expected_children=28,python=python,
 command=[python['path'],'-B',str(OWNER/'scripts/supervise_experiment.py'),'--run-id','runtime-readmission-supervisor-01','--',python['path'],'-B',str(HERE/'requalify.py'),'--frozen-sha',sha(HERE/'inputs.json')],
 source_freeze=dict(path=str(HERE/'inputs.json'),sha256=sha(HERE/'inputs.json')),
 helper=dict(path=str(HERE/'requalify.py'),sha256=sha(HERE/'requalify.py')),
 supervisor=dict(path=str(OWNER/'scripts/supervise_experiment.py'),sha256=sha(OWNER/'scripts/supervise_experiment.py')),
 installation=False,review_required_before_launch=True)
write(HERE/'launch.json',launch)
print(json.dumps(dict(files=len(files),bytes=size,hashes={p.name:sha(p) for p in HERE.iterdir()}),indent=2))
