"""Independent saved-evidence audit; launches no child or installation."""
import hashlib,json,time
from pathlib import Path
OWNER=Path('/Users/danluu/dev/rust-interp-runtime-readmission-20260918')
HERE=OWNER/'experiments/runtime-compiler-installation/readmission-01'
WORK=OWNER/'.work/runtime-readmission-01'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):
 p=Path(p);assert p.resolve(strict=True)==p and p.is_file() and not p.is_symlink()
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def ref(p):return dict(path=str(p),sha256=sha(p))
plan=read(HERE/'plan.json');frozen=read(HERE/'inputs.json');launch=read(HERE/'launch.json')
r=read(WORK/'receipt.json');outer_path=OWNER/'.work/experiments/runtime-readmission-supervisor-01/status.json';outer=read(outer_path)
execution_path=OWNER/'.work/runtime-readmission-launch-execution-01/record.json';execution=read(execution_path)
assert r['status']=='passed' and r['full_current_guard_passed'] and len(r['children'])==28
assert outer['status']=='finished' and outer['returncode']==0 and outer['child_pid']==r['pid']==18530 and outer['supervisor_pid']==r['parent_pid']==18527
assert outer['started_at']<=r['started_at']<=r['admitted_at']<=r['finished_at']<=outer['finished_at']
assert execution['status']=='finished' and execution['returncode']==0 and execution['command']==launch['command'] and execution['cwd']==launch['cwd'] and execution['environment']==launch['environment']
for name in ('stdout','stderr'):assert sha(execution_path.parent/name)==execution[name+'_sha256']
assert read(execution_path.parent/'stdout')['supervisor_pid']==outer['supervisor_pid']
assert sha(outer_path.parent/'command.log')==outer['log_sha256']
prior=read(plan['evidence']['stage2_plan']['path'])['previous'];children=[]
for declaration,reference in zip(plan['children'],r['children']):
 p=Path(reference['path']);child=read(p)
 assert sha(p)==reference['sha256'] and p==Path(declaration['out'])/'receipt.json'
 assert child['status']=='finished' and child['returncode'] in declaration['expected']
 assert child['command']==declaration['argv'] and child['cwd']==declaration['cwd']
 env=prior['old_plan']['environment'] if declaration['kind']=='git' else (plan['environment'] if declaration['kind']=='selection' else plan['compiler_environment'])
 assert child['environment']==env and child['supervisor_pid']==r['pid'] and child['parent_pid']==r['parent_pid']
 assert r['admitted_at']<=child['started_at']<=child['finished_at']<=r['finished_at']
 assert list(map(int,child['identity']['ps'].split()[:2]))==[child['pid'],r['pid']]
 assert (str(Path(child['cwd'])) in child['identity']['cwd'] if child['identity']['cwd_returncode']==0 else child['identity']['cwd_returncode']==1 and child['identity']['cwd']=='')
 for name in ('stdout','stderr'):assert sha(p.parent/name)==child[name+'_sha256']
 children.append(dict(reference,pid=child['pid'],raw_streams_verified=True,cwd_observation_available=child['identity']['cwd_returncode']==0))
assert len(set(row['pid'] for row in children))==28
for i in range(5):
 before=Path(r['children'][i]['path']).parent;after=Path(r['children'][i+22]['path']).parent
 assert (before/'stdout').read_bytes()==(after/'stdout').read_bytes()
for path,h in frozen['files'].items():
 assert sha(path)==h
 retained=WORK/'inputs'/path.lstrip('/');assert retained.stat().st_nlink==1 and sha(retained)==h
assert sha(WORK/'components-initial.json')==sha(WORK/'components-and-stamps.json')==r['fresh_components']['sha256']
new=read(WORK/'components-and-stamps.json');old=read(plan['evidence']['components']['path'])
assert new['components']==old['components'];diff=[]
for i,(before,after) in enumerate(zip(old['snapshots'],new['snapshots'])):
 for kind in ('files','links','directories'):
  assert before[kind].keys()==after[kind].keys()
  for p,b in before[kind].items():
   a=after[kind][p]
   if a!=b:
    assert b[0]==16777231 and a[0]==16777229 and b[1:]==a[1:]
    diff.append(dict(component=i,kind=kind,path=p,historical=b,current=a))
saved_differences=read(WORK/'historical-current-stamp-differences.json')
key=lambda row:(row['component'],row['kind'],row['path'])
assert {key(row):row for row in diff}=={key(row):row for row in saved_differences} and len(diff)==len(saved_differences)==4655
assert sha(WORK/'historical-current-stamp-differences.json')==r['device_readmission']['differences']['sha256']
assert sha(WORK/'candidate-specification.json')==plan['evidence']['candidate']['sha256']
probe=read(WORK/'source-probe/result.json');assert probe['status']=='passed' and probe['exact_source_paths_observed']
assert probe['commands']==r['commands'] and len(probe['commands'])==2
for rel,reference in probe['retained_sources'].items():assert sha(reference['path'])==reference['sha256']
for i,row in enumerate(probe['commands']):
 p=Path(row['path']).parent;raw=[json.loads(line) for line in (p/'stderr').read_bytes().splitlines() if line.strip()]
 assert any(d.get('level')=='error' and (d.get('code') or {}).get('code')=='E0080' for d in raw)
 assert not (p/'stdout').read_bytes()
 assert {'core/src/panic.rs','std/src/macros.rs'}<=set(row['observed']['sources'])
 if i==0:assert all(s['has_text'] for s in row['observed']['spans'])
 else:assert all(s['file_name'].startswith('/rustc/'+r['source_commit']+'/library/') for s in row['observed']['spans'])
metadata=read(WORK/'metadata.json');assert metadata['status']=='inspected-pending-review'
assert sha(WORK/'metadata.json')==r['fresh_metadata']['sha256'] and metadata['components_sha256']==r['fresh_components']['sha256']
result=dict(schema_version=1,status='passed',verified_at=time.time(),controller=ref(HERE/'requalify.py'),
 verification_helper=ref(Path(__file__)),terminal=ref(WORK/'receipt.json'),outer=ref(outer_path),launch_execution=ref(execution_path),
 metadata=ref(WORK/'metadata.json'),components=ref(WORK/'components-and-stamps.json'),
 ordered_children=children,raw_streams=56,frozen_sources=len(frozen['files']),retained_source_copies=len(frozen['files']),
 device_only_differences=len(diff),current_stamps_checked_without_normalization=True,native_reexecution=False,installation=False)
output=OWNER/'.work/runtime-readmission-independent-verification-01.json';assert not output.exists();output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(output=ref(output),terminal=ref(WORK/'receipt.json'),metadata=ref(WORK/'metadata.json'),components=ref(WORK/'components-and-stamps.json')),indent=2))
