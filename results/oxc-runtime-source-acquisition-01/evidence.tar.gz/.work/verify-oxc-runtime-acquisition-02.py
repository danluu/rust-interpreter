import hashlib, importlib.util, json, os, re
from pathlib import Path

owner = Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
work = owner/'.work/oxc-runtime-source-acquisition-02'
outer = owner/'.work/experiments/oxc-runtime-source-acquisition-supervisor-02'
def read(p): return json.loads(Path(p).read_bytes())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name, p):
    spec = importlib.util.spec_from_file_location(name, p)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value
a = module('acquisition_audit', owner/'experiments/oxc-runtime-compatibility/acquire_runtime_source.py')
registry = module('registry_audit', owner/'experiments/oxc-plugin-normalization/registry_cache.py')
plan, freeze, r, o = read(a.PLAN), read(a.FROZEN), read(work/'receipt.json'), read(outer/'status.json')
launch_path = owner/'.work/oxc-runtime-source-acquisition-launch-06.json'
launch = read(launch_path)
assert r['status'] == 'passed' and o['returncode'] == 0 and o['status'] == 'finished'
assert r['source_acquired'] and not r['runtime_compatible'] and not r['benchmark']
assert r['pid'] == o['child_pid'] and r['parent_pid'] == o['supervisor_pid']
assert o['child_started_at'] <= r['started_at'] <= r['admitted_at'] <= r['finished_at'] <= o['finished_at']
assert o['command'] == launch['command'][6:] and o['cwd'] == str(owner)
assert sha(outer/'command.log') == o['log_sha256']
assert sha(a.FROZEN) == r['freeze_sha256']
for name, digest in freeze['files'].items():
    a.frozen_input_file(name, plan['executors'])
    assert sha(name) == sha(work/'inputs'/name.lstrip('/')) == digest, name
assert len(freeze['files']) == 142
children = []
assert len(r['children']) == len(plan['commands']) == 9
for row, wanted in zip(r['children'], plan['commands']):
    path = Path(row['path']); child = read(path/'receipt.json')
    assert row['label'] == wanted['label'] and row['receipt'] == child
    assert child['status'] == 'finished' and child['returncode'] == 0
    assert child['command'] == wanted['argv'] and child['cwd'] == wanted['cwd']
    assert child['environment'] == plan['environment']
    assert child['supervisor_pid'] == r['pid'] and child['parent_pid'] == r['parent_pid']
    assert r['admitted_at'] <= child['started_at'] <= child['finished_at'] <= r['finished_at']
    assert child['identity']['ps'].split()[:2] == [str(child['pid']), str(r['pid'])]
    for channel in ['stdout', 'stderr']: assert sha(path/channel) == child[channel+'_sha256']
    assert (path/'stderr').read_bytes() == b''
    raw = (path/'stdout').read_text()
    if row['label'] == 'controls':
        controls = re.findall(r'^(test_\w+) \([^\n]+\) \.\.\. ok$', raw, re.M)
        assert len(controls) == len(set(controls)) == 17 and 'Ran 17 tests' in raw and raw.endswith('\nOK\n')
    elif row['label'].endswith('-head'): assert raw == a.REVISION+'\n'
    elif row['label'].endswith('-status'): assert raw == '?? .rust-interp-owned.json\n'
    else: assert raw == plan['git_version']
    children.append(dict(label=row['label'], receipt_sha256=sha(path/'receipt.json'), pid=child['pid']))
lock = r['cargo_download_lock']
assert lock['identity'] == plan['cargo_lock_identity']
assert r['children'][5]['receipt']['finished_at'] <= lock['started_at'] <= lock['acquired_at'] <= lock['released_at'] <= r['children'][6]['receipt']['started_at']
assert dict(dev=Path(lock['path']).stat().st_dev, ino=Path(lock['path']).stat().st_ino) == lock['identity']
original, acquired = a.inventory(a.ORIGINAL), read(work/'acquired-source-inventory.json')
assert original == plan['source_inventory'] and a.inventory(a.SOURCE) == acquired
assert sha(work/'acquired-source-inventory.json') == r['source_inventory_sha256']
assert {n:v for n,v in original.items() if n != '.rust-interp-owned.json'} == {n:v for n,v in acquired.items() if n != '.rust-interp-owned.json'}
assert read(a.SOURCE/'.rust-interp-owned.json') == plan['ownership_marker']
for name, row in acquired.items():
    if row['kind'] == 'file':
        p, q = (a.ORIGINAL/name).stat(), (a.SOURCE/name).stat()
        assert (p.st_dev,p.st_ino) != (q.st_dev,q.st_ino)
shared, qualified = read(work/'shared-registry-checksums.json'), read(a.QUALIFIED)['archives']
assert sha(work/'shared-registry-checksums.json') == r['shared_registry_sha256']
assert len(shared) == r['registry_packages'] == 323
for label, proof in plan['packages'].items():
    private = qualified[label]
    assert registry.verify(private['archive'], private['root'], proof['checksum']) == private
    actual = shared[label]
    assert registry.verify(actual['archive'], actual['root'], proof['checksum']) == actual
    if proof['present']: assert actual == proof['existing']
    else:
        assert actual == dict(private, archive=actual['archive'], root=actual['root'])
        for source, target in [(Path(private['archive']), Path(actual['archive'])), *[(Path(private['root'])/n,Path(actual['root'])/n) for n in [*private['members'],'.cargo-ok']]]:
            p,q=source.stat(),target.stat(); assert (p.st_dev,p.st_ino)!=(q.st_dev,q.st_ino)
for relative, proof in plan['indexes'].items():
    assert a.file_record(a.PRIVATE/relative) == proof['private']
    assert a.file_record(a.CARGO_HOME/relative) == (proof['existing'] if proof['present'] else proof['private'])
    for selected in proof['records']:
        assert a.index_record(a.CARGO_HOME/relative, selected['name'],selected['version'],selected['checksum']) == selected['record']
assert sum(not p['present'] for p in plan['packages'].values()) == r['copied_packages'] == 95
assert sum(not p['present'] for p in plan['indexes'].values()) == r['copied_index_files'] == 52
intents = [json.loads(line) for line in (work/'exclusive-create-intents.jsonl').read_text().splitlines()]
assert len(intents) == len({row['path'] for row in intents}) == r['exclusive_create_intents'] == 21825
for row in intents:
    p=Path(row['path']); assert p.exists() or p.is_symlink()
    assert r['admitted_at'] <= row['time'] <= r['finished_at']
assert r['allocation']['total'] <= 640*2**20 and r['allocation']['evidence'] <= 128*2**20
assert r['free_bytes_before'] >= 16*2**30 and r['free_bytes_after'] >= 9*2**30
result = dict(status='passed', children=children, controls=controls, frozen_inputs=142, source_entries=len(acquired),
    registry_packages=323, copied_packages=95, copied_index_files=52, independent_inodes=True,
    original_source_and_private_registry_unchanged=True, preexisting_shared_records_unchanged=True,
    download_lock_released_before_next_child=True, runtime_compatible=False, benchmark=False,
    hashes={str(p.relative_to(owner)):sha(p) for p in [work/'receipt.json',outer/'status.json',outer/'command.log',a.PLAN,a.FROZEN,launch_path,work/'shared-registry-checksums.json',work/'acquired-source-inventory.json',work/'exclusive-create-intents.jsonl']})
out=owner/'.work/oxc-runtime-source-acquisition-verification-02.json'
with out.open('x') as f: json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(dict(path=str(out),sha256=sha(out),status='passed',children=9,controls=17,registry_packages=323),indent=2))
