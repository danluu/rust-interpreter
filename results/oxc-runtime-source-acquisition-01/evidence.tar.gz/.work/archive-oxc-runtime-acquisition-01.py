import gzip, hashlib, io, json, shutil, tarfile
from pathlib import Path

OWNER = Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
DEST = OWNER/'results/oxc-runtime-source-acquisition-01'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
paths = set()
for path in (OWNER/'.work').glob('oxc-runtime-*'):
    if 'compatibility' in path.name or 'publication' in path.name:
        continue
    if path.is_file(): paths.add(path)
    elif path.is_dir(): paths.update(p for p in path.rglob('*') if p.is_file())
for root in (OWNER/'.work/experiments').glob('oxc-runtime-source-acquisition-supervisor-*'):
    paths.update(p for p in root.rglob('*') if p.is_file())
paths.update((OWNER/'experiments/oxc-runtime-compatibility').glob('acquisition-plan-*.json'))
paths.update(OWNER/'.work'/name for name in ['verify-oxc-runtime-acquisition-02.py','archive-oxc-runtime-acquisition-01.py'])
assert all(p.resolve(strict=True) == p and not p.is_symlink() and p.stat().st_nlink == 1 for p in paths)
assert sum(p.stat().st_size for p in paths) < 96*2**20
assert shutil.disk_usage(OWNER).free >= 9*2**30
members = {str(p.relative_to(OWNER)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(paths)}
manifest = dict(schema_version=1,members=members,input_bytes=sum(row['bytes'] for row in members.values()),
    scope='Complete successful source-acquisition receipts and frozen inputs; exact failed04 preflight evidence, all retained unrun snapshots and all acquisition plans. Source/registry payloads remain in their recorded owners and are bound by full byte inventories. Runtime compatibility is not claimed.')
DEST.mkdir(parents=True,exist_ok=False)
with (DEST/'manifest.json').open('x') as f: json.dump(manifest,f,sort_keys=True,indent=2);f.write('\n')
archive=DEST/'evidence.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped, tarfile.open(fileobj=zipped,mode='w') as tar:
    for name,row in members.items():
        assert shutil.disk_usage(OWNER).free >= 9*2**30
        data=(OWNER/name).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
        item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
        tar.addfile(item,io.BytesIO(data))
assert archive.stat().st_size < 32*2**20
with tarfile.open(archive,'r:gz') as tar:
    actual=tar.getmembers();assert len(actual)==len(members) and {m.name for m in actual}==set(members)
    for item in actual:
        assert item.isfile() and item.size==members[item.name]['bytes']
        assert hashlib.sha256(tar.extractfile(item).read()).hexdigest()==members[item.name]['sha256']
    while tar.fileobj.read(1024**2): pass
result=dict(members=len(members),input_bytes=manifest['input_bytes'],archive_bytes=archive.stat().st_size,
    archive_sha256=sha(archive),manifest_sha256=sha(DEST/'manifest.json'),free_bytes_after=shutil.disk_usage(OWNER).free)
print(json.dumps(result,indent=2))
