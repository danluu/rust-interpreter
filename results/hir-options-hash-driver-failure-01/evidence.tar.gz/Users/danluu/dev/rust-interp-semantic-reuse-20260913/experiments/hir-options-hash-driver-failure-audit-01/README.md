# Saved first hash-driver compile failure

This source-only auditor is a distinct successor to the qualified audit02 reader.
Every existing reader function except `main` remains AST-identical, including
strict historical file records, independent file-table reconstruction, all
prerequisites and complete v2 snapshot readback. The original stage02 sources,
prepared packet and success-only reader stay unchanged.

The exact original compiler child exited 1 with E0277: the plain Barrier captured
by `par_join` does not implement rustc's DynSync marker. No binary, linker proof,
serial/parallel driver receipt or result was produced. The ordinary fixture and
three empty artifact directories are retained. The independent failure report
will identify one failed compiler child, zero driver processes and no hash-driver
or application qualification.

The report binds the failed terminal, raw streams, observed PID/parent/cwd/start,
outer terminal and bounded launcher closure; all 109,196 frozen files, provider
and canonical SDK inventories; and all 103 logical snapshot inputs across 99
physical blobs (65 newly stored, 34 reused), with complete gzip EOF/CRC/hash
readback. The complete failed owner can support snapshot reuse only through an
explicit failed-owner policy and separately verified failure audit.

The bounded wrapper is ROOT/.work/execute_hash_driver_failure_audit_01.py. It
requires fresh 16 GiB, canonical600, live9/floor8 and one explicit finite wait.
The child is limited to 900 CPU seconds, 1,200 read seconds, 32 GiB cumulative
ordinary reads and 4 MiB per output file. No compiler, provider, driver, process
probe, signal, retry or snapshot-writing workload is performed. Both source and
wrapper require review before execution. Historical resource samples do not
claim that a future successor packet fits or is admitted.
