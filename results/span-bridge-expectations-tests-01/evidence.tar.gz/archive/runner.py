"""Compact exact completed Python control evidence; no compiler artifacts."""
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import time

ROOT=Path(__file__).resolve().parents[1]
SPAN=Path('/Users/danluu/dev/rust-interp-span-handle-integration-20260913')
sys.path.insert(0,str(ROOT/'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, workload_lock, sha, write


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    work=SPAN/'.work/span-bridge-expectations-tests-01'
    supervisor=SPAN/'.work/experiments/span-bridge-expectations-supervisor-01'
    output=ROOT/'results/span-bridge-expectations-tests-01'
    receipt=ROOT/'.work/span-bridge-expectations-archive-01.json'
    record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),
                lock=str(CANONICAL_LOCK),archive_script_sha256=sha(Path(__file__)))
    write(receipt,record)
    with workload_lock(CANONICAL_LOCK,600):
        record.update(status='admitted',admitted_at=time.time())
        write(receipt,record)
        result=json.loads((work/'summary.json').read_text()); plan=json.loads((work/'plan.json').read_text())
        child=json.loads((work/'command/receipt.json').read_text())
        parent=json.loads((supervisor/'status.json').read_text())
        assert result['status']=='passed' and result['tests_passed']==4 and result['tests_failed']==0
        assert result['source_unchanged'] and result['span_patch_unchanged'] and child['returncode']==0
        assert parent['status']=='finished' and parent['returncode']==0 and parent['child_pid']==result['supervisor_pid']
        assert child['pid']==result['child_pid'] and child['supervisor_pid']==result['supervisor_pid']
        assert sha(work/'plan.json')==result['plan_sha256']
        assert sha(work/'command/stdout')==child['stdout_sha256']
        assert sha(work/'command/stderr')==child['stderr_sha256']
        assert sha(supervisor/'command.log')==parent['log_sha256']
        files={}
        for root,prefix in [(work,'tests'),(supervisor,'supervisor')]:
            for path in sorted(root.rglob('*')):
                if path.is_dir():
                    assert not path.is_symlink();continue
                assert path.is_file() and not path.is_symlink()
                files[prefix+'/'+str(path.relative_to(root))]=path.read_bytes()
        for name,value in plan['inputs'].items():
            data=files['tests/sources/'+name]
            assert len(data)==value['bytes'] and digest(data)==value['sha256']
            assert (SPAN/name).read_bytes()==data
        assert digest(files['tests/sources/experiments/proc-macro-span-handles/span-handles.patch'])==plan['span_patch_sha256']
        files['archive/runner.py']=Path(__file__).read_bytes()
        files['archive/owned_stage.py']=(ROOT/'experiments/stable-cgu/owned_stage.py').read_bytes()
        output.mkdir(parents=True,exist_ok=False)
        archive=output/'evidence.tar.gz'
        with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
            for name,data in sorted(files.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(data))
        with tarfile.open(archive,'r:gz') as tar:
            members=tar.getmembers();assert len(members)==len(files)
            assert all(member.isfile() and member.name in files and tar.extractfile(member).read()==files[member.name] for member in members)
        manifest=dict(archive='evidence.tar.gz',sha256=sha(archive),bytes=archive.stat().st_size,
            member_count=len(files),members={name:dict(bytes=len(data),sha256=digest(data)) for name,data in sorted(files.items())},
            checkpoint=result['checkpoint'],span_patch_sha256=plan['span_patch_sha256'],
            source_unchanged=True,tests_passed=4,tests_failed=0,scope='Pure Python expectation controls only; native bridge and Rust patch unqualified.')
        write(output/'manifest.json',manifest)
        (output/'summary.json').write_bytes((work/'summary.json').read_bytes())
        record.update(status='passed',finished_at=time.time(),archive_sha256=manifest['sha256'],archive_bytes=manifest['bytes'],member_count=len(files))
        write(receipt,record);write(output/'archive-receipt.json',record)
        print(json.dumps({key:record[key] for key in ['status','pid','admitted_at','finished_at','archive_sha256','archive_bytes','member_count']}))


if __name__=='__main__':
    main()
