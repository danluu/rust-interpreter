"""Owned four-test bridge expectation check; no Rust or native subprocess."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, workload_lock, run, write, sha


def main():
    plan_path = ROOT / '.work/span-bridge-expectations-plan-01.json'
    plan = json.loads(plan_path.read_text())
    out = ROOT / '.work/span-bridge-expectations-tests-01'
    out.mkdir(exist_ok=False)
    record = dict(status='waiting', owner=str(ROOT), supervisor_pid=os.getpid(),
        parent_pid=os.getppid(), started_at=time.time(), plan_sha256=sha(plan_path),
        lock=str(CANONICAL_LOCK), workload='four pure Python expectation controls',
        rust_or_native_commands=0, benchmark=False)
    write(out / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='admitted', admitted_at=time.time(),
                lock_identity=dict(device=CANONICAL_LOCK.stat().st_dev, inode=CANONICAL_LOCK.stat().st_ino))
            write(out / 'summary.json', record)
            assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == plan['checkout_revision']
            assert subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT, text=True) == ''
            assert sha(plan_path) == record['plan_sha256']
            for name, expected in plan['inputs'].items():
                source = ROOT / name
                assert source.is_file() and not source.is_symlink() and sha(source) == expected['sha256'], name
                if expected.get('revision'):
                    committed = subprocess.check_output(['git', 'show', expected['revision'] + ':' + name], cwd=ROOT)
                    assert committed == source.read_bytes(), name
                dest = out / 'sources' / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(source.read_bytes())
            (out / 'plan.json').write_bytes(plan_path.read_bytes())
            patch = ROOT / 'experiments/proc-macro-span-handles/span-handles.patch'
            assert sha(patch) == plan['span_patch_sha256']
            record.update(checkpoint=plan['fixture_checkpoint'], checkout_revision=plan['checkout_revision'],
                source_hashes={name: value['sha256'] for name, value in plan['inputs'].items()},
                python=dict(executable=sys.executable, executable_sha256=sha(Path(sys.executable)), version=sys.version))
            env = dict(PATH='/usr/bin:/bin:/usr/sbin:/sbin', HOME=str(Path.home()), LANG='C', LC_ALL='C',
                       PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')
            command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s',
                'experiments/proc-macro-span-handles/integration', '-p', 'test_expectations.py', '-v']
            item = run(command, cwd=ROOT, env=env, out=out / 'command', capacity_root=ROOT)
            stderr = (out / 'command/stderr').read_text()
            assert re.search(r'\nRan 4 tests in [0-9.]+s\n\nOK\n\Z', stderr), stderr
            assert len(re.findall(r'^test_.* \.\.\. ok$', stderr, re.M)) == 4, stderr
            assert (out / 'command/stdout').read_bytes() == b''
            assert all(sha(ROOT / name) == value['sha256'] for name, value in plan['inputs'].items())
            assert sha(plan_path) == record['plan_sha256'] and sha(patch) == plan['span_patch_sha256']
            assert subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT, text=True) == ''
            record.update(status='passed', tests_passed=4, tests_failed=0, child_pid=item['pid'],
                source_unchanged=True, span_patch_unchanged=True, finished_at=time.time())
            write(out / 'summary.json', record)
            print(stderr, end='')
    except BaseException as error:
        record.update(status='failed', error=repr(error), finished_at=time.time())
        write(out / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
