"""Run only the two existing read-only probes against the prepared exact cache."""
import argparse
import json
import os
from pathlib import Path
import sys
import time

import retire as r

WORK = r.OWNER/'.work/ruff-options-hash-strict-cache-quiescence-01'


def main():
    parser=argparse.ArgumentParser(__doc__);parser.add_argument('--inputs-sha256',required=True)
    args=parser.parse_args()
    r.require(Path.cwd()==r.OWNER and sys.dont_write_bytecode and not sys.flags.optimize,'fixed probe owner required')
    r.require(r.sha(r.PACKET/'inputs.json')==args.inputs_sha256,'prepared inputs differ')
    freeze=r.read(r.PACKET/'inputs.json');plan=r.read(r.PACKET/'plan.json')
    r.require(r.sha(r.PACKET/'plan.json')==freeze['plan_sha256'] and dict(os.environ)==plan['environment'],'prepared plan/environment differs')
    checker=object.__new__(r.Retirement);checker.plan=plan;checker.freeze=freeze
    checker.guard();checker.protected();r.require(not WORK.exists() and not WORK.is_symlink(),'fresh probe evidence required')
    # Configure the same unchanged monitor for this separate owned evidence
    # directory. Its namespace, byte/free-space bounds and child logic are exact.
    r.require(r.bounded_probes.EVIDENCE==r.WORK,'unexpected monitor scope')
    r.bounded_probes.EVIDENCE=WORK
    def no_removal(event,args):
        if event in ('os.remove','os.rmdir','os.rename','os.chmod'):
            raise RuntimeError('read-only quiescence cannot remove, rename or chmod')
    sys.addaudithook(no_removal)
    WORK.mkdir();(WORK/'commands').mkdir()
    record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),
        command=[sys.executable,*sys.argv],cwd=str(Path.cwd()),environment=dict(os.environ),
        source_sha256=r.sha(__file__),inputs_sha256=args.inputs_sha256,read_only=True,removed_entries=0,children=[])
    def save():r.owned.write(WORK/'record.json',record)
    save()
    try:
        with r.owned.workload_lock(r.owned.CANONICAL_LOCK,600) as fd:
            record.update(status='running',admitted_at=time.time(),free_bytes_before=r.owned.disk(r.OWNER,9));save()
            checker.guard();checker.protected()
            r.require(r.inventory(r.ROOT)[0]==r.read(r.PACKET/'inventory.json'),'cache differs before probes')
            for spec in plan['commands']:
                out=WORK/'commands'/spec['label']
                try:
                    child=r.bounded_probes.run(spec['argv'],cwd=r.OWNER,environment=plan['environment'],output=out,canonical_fd=fd,expected=tuple(spec['expected']))
                finally:
                    if (out/'receipt.json').exists():
                        record['children'].append(dict(path=str(out/'receipt.json'),sha256=r.sha(out/'receipt.json')));save()
                r.require((out/'stderr').read_bytes()==b'' and (out/'stdout').stat().st_size<=r.MIB,'unexpected probe output')
                raw=(out/'stdout').read_text()
                if spec['label']=='open-handles':r.require(child['returncode']==1 and not raw,'cache has open handles/mappings')
                else:
                    for line in raw.splitlines():
                        parts=line.split();r.require(len(parts)>=9 and parts[0] in plan['closed_history']['owners'],'unexpected owner row')
                        r.require(parts[3:8]!=plan['closed_history']['owners'][parts[0]],'original owner remains live')
            checker.guard();checker.protected();r.require(r.inventory(r.ROOT)[0]==r.read(r.PACKET/'inventory.json'),'cache drift after probes')
            record.update(status='passed',finished_at=time.time(),free_bytes_after=r.owned.disk(r.OWNER,9));save()
        record['released_at']=time.time();save()
    except BaseException as error:
        record.update(status='failed',error=repr(error),finished_at=time.time());save();raise
    print(json.dumps(dict(path=str(WORK/'record.json'),sha256=r.sha(WORK/'record.json'))))


if __name__=='__main__':main()
