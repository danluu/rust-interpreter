# Closed strict01 cache retirement proposal

Select only A/.work/ruff-options-hash-strict-01/cache, including its root directory. The actual strict16 history is normally closed and independently passed; all retained raw,64 artifacts,710 compiler argument files, input snapshots, result and supervision remain outside selection. Runtime, std, tools, source, registry and peer caches are excluded structurally.

The complete final cache contains11,490 files and2,671 directories, with2,195 internal hardlink groups and no external aliases or symlinks. The historical hash/stat inventory remains immutable. Free space after deletion is an observation, not a guaranteed allocation recovery.

Before deletion, a new finite preservation supplement retains all14 generated Rust source files,two generated expressions, Cargo/HIR JSON metadata, timing reports, dependency files and build diagnostics:6,368 members,43,380,475 bytes. Its entire gzip archive was read back to EOF/CRC. The four cached RBC copies match already retained per-state artifacts. Other compiled objects, metadata, libraries and incremental binary caches are rebuildable.

This reuses the original strict-cache retirement code. fd_remove.py is byte-identical to the independently audited12-fixture implementation. The two-probe monitor changes only its owned cache/evidence routes. Retirement changes closed-history and archive adapters to this actual history, retaining descriptor-based traversal, alias validation, durable intent/completion/validation ledger and protected noncache checks. The existing12 proof covers the unchanged remover, not a new executed qualification of these adapter changes.

prepare.py performs read-only discovery and emits the concrete unrun packet. retire.py later acquires the canonical lock, rehashes the exact cache/proofs/protected evidence, executes the same two read-only lsof/ps probes and immediately rechecks before calling the unchanged remover. It retains9GiB live free space,256MiB evidence,192MiB ledger and600-second lock wait. An audit hook rejects explicit os.kill/os.killpg calls. No peer process can be controlled. Probe observations do not establish an operating-system barrier against a subsequent opener.

The separate probe_only.py is an unrun draft and is not needed by the selected execution: the actual retirement performs fresh inline probes exactly once. No duplicate preliminary probes have run. The direct ordinary supervisor launch uses the prepared exact environment/cwd and must be normally waited by its caller.

Preparing a packet does not authorize its removal command. The exact source and packet await root review before one retirement launch. No screen or compiler execution is performed here.
