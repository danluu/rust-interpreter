"""Read only the owned closed cache/evidence; produce an unrun removal packet."""
import ast
import json
import os
from pathlib import Path
import sys

import retire as r

O = Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
PRIOR = r.OWNER/'experiments/ruff-strict-cache-retirement-01'
CONTROL_AUDIT = O/'.work/ruff-strict-cache-retirement-controls-independent-verification-01.json'
CONTROL_RECEIPT = r.OWNER/'.work/ruff-strict-cache-retirement-controls-01/receipt.json'
OUTER = r.OWNER/'.work/experiments/ruff-options-hash-strict-cache-retirement-supervisor-01'


def main():
    r.require(Path.cwd() == r.OWNER and sys.dont_write_bytecode and not sys.flags.optimize, 'fixed owner/Python required')
    r.require(not any(p.exists() for p in [r.PACKET,r.WORK,r.ASSESSMENT,OUTER]), 'fresh retirement proposal required')
    r.capacity()
    r.require(r.sha(r.FINAL) == '582e2a338fabf33b4f228c3cda0131b1539df05097ac1dc2380abd5585016f7f', 'closed inventory differs')
    r.require(r.sha(r.HERE/'fd_remove.py') == r.sha(PRIOR/'fd_remove.py') == '0b154792e3b393bdc018a6ee4337347535be466db64aa3fa40cd6a3899be6041', 'actual12-qualified remover differs')
    r.require(r.sha(CONTROL_AUDIT) == 'b5509ae9544c4fd3e348c5c869fce82671c802270e9e5b920110b5a3e56b9230', 'actual12 independent audit differs')
    audit = r.read(CONTROL_AUDIT)
    r.require(audit['status'] == 'verified' and audit['controls'] == 12 and audit['receipt_sha256'] == r.sha(CONTROL_RECEIPT), 'actual fixture qualification differs')
    archive_pins = {
        str(r.ARCHIVE): dict(manifest_sha256='663a2e0cb781af8999126edb339de54766ce75a1da92d6530e6050c279673e8f', archive_sha256='e2217254f827beae2afbe18f44eada42c57771af83905f1976443d9622c0f043'),
        str(r.SUPPLEMENT): dict(manifest_sha256='dd3252e0d33b533f76e2a8fff1d37082cf5047a22b12fa9f2a59314e88d9958a', archive_sha256='5b2812d1e0b7244dfcd76be75a3f9eb887b336e856b1593dd7275799e713cf70')}
    def ref(path):
        return dict(path=str(path), sha256=r.sha(path))
    closed = dict(terminal=ref(r.ROOT.parent/'supervision.json'), result=ref(r.ROOT.parent/'result.json'),
        outer=ref(r.OWNER/'.work/experiments/ruff-options-hash-strict-supervisor-01/status.json'),
        parent=ref(r.Q/'.work/ruff-options-hash-strict-execution-01/record.json'))
    r.require(closed['result']['sha256'] == 'fc2ae5d0870f777410dd32c95e12be6d3c3b0900e96f8a412225aa55508eb54c'
              and r.sha(r.AUDIT) == '2f4bd3da61ecf59e392939b278060b832c08c8864af0d74aee94ac87c954357f', 'current strict proof differs')
    assessment = dict(status='source-and-closed-evidence-assessment', root=str(r.ROOT), cache_root_identity=r.identity(r.ROOT),
        closed_history=closed, archives=archive_pins,
        no_consumers=dict(scope='Declared current/future task consumers plus fresh read-only handle/owner probes; not an OS exclusion barrier.',
            completed_owner='Strict01 is terminal and normally waited; all16 child receipts are final.',
            future_screen='Fresh screen02 requires this entire strict cache absent and derives four separate custom namespaces plus two native roots.',
            saved_consumers='Preparation and saved strict/HIR readbacks consume retained raw/artifacts/argv/results, not mutable cache payloads.',
            external_providers='Installed runtime, std, tools, source, registries and all peer caches are outside this exact selected tree.'),
        deletion_authorized_by_preparation=False)
    r.owned.write(r.ASSESSMENT,assessment)
    rows,allocated=r.inventory(r.ROOT)
    r.require(rows == r.historical_rows(), 'complete current cache differs from saved final state')
    counts=r.cache_summary(rows)
    r.require(counts['entries']==14161 and counts['files']==11490 and counts['directories']==2671
              and counts['internal_hardlink_groups']==2195, 'unexpected exact cache structure')
    history=r.closed_history(); archives=r.verify_archive()
    # Retain all selected per-state artifacts outside the selected root. Final
    # cache RBC copies are independently matched by the preservation supplement.
    members={v['path']:v for v in r.read(r.ARCHIVE/'manifest.json')['members']}
    artifacts={}
    for record in r.read(r.ROOT.parent/'result.json')['records']:
        for key in ['bytecode','catalog','dep_info','cargo_timing']:
            item=record['proof'][key];path=Path(item['path'])
            r.require(not path.is_relative_to(r.ROOT) and members[str(path)]['sha256']==item['sha256']
                      and r.sha(path)==item['sha256'], 'selected artifact not preserved outside cache')
            artifacts[str(path)]=item
    supplement=r.read(r.SUPPLEMENT/'manifest.json')
    r.require(supplement['member_count']==6368 and len(supplement['rbc_already_retained'])==4, 'source/diagnostic supplement incomplete')
    for row in supplement['rbc_already_retained']:
        r.require(Path(row['path']).is_relative_to(r.ROOT) and r.sha(row['path'])==row['sha256']
                  and row['retained_matches'] and all(artifacts[v['path']]['sha256']==row['sha256'] for v in row['retained_matches']), 'cached RBC lacks retained selected copy')
    protected={str(r.ROOT.parent):r.inventory(r.ROOT.parent,exclude_cache=True)[0]}
    files,routes={},{}
    def add(path,expected=None):
        path=Path(path);target=path.resolve(strict=True)
        r.require(not target.is_relative_to(r.ROOT) and target.stat().st_size<=512*r.MIB, 'invalid immutable input')
        row=r.file(target)
        if expected is not None:r.require(row['sha256']==expected,'input differs')
        r.require(str(target) not in files or files[str(target)]==row,'input conflict')
        files[str(target)]=row;routes[str(path)]=dict(resolved=str(target),identity=r.identity(path))
        r.require(len(files)<=4096 and sum(v['identity']['size'] for v in files.values())<=2*r.GIB,'finite closure exceeded')
        if target.suffix=='.py':ast.parse(target.read_bytes(),filename=str(target))
    for p in r.HERE.iterdir():
        if p.is_file():add(p)
    for p in [r.ASSESSMENT,r.FINAL,r.AUDIT,CONTROL_AUDIT,CONTROL_RECEIPT,
              PRIOR/'fd_remove.py',PRIOR/'test_fd_remove.py',PRIOR/'controls-01/inputs.json',
              r.OWNER/'experiments/stable-cgu/owned_stage.py',r.OWNER/'scripts/supervise_experiment.py',
              r.OWNER/'experiments/runtime-application-admission/runtime_platform.py',
              r.OWNER/'.work/ruff-options-hash-strict-mechanism-eligibility-01.json']:
        add(p)
    old_controls=r.read(PRIOR/'controls-01/inputs.json')
    r.require(old_controls['files'][str(PRIOR/'fd_remove.py')]['sha256']==r.sha(r.HERE/'fd_remove.py'),'current remover was not fixture-qualified')
    for directory in [r.ARCHIVE,r.SUPPLEMENT,r.Q/'.work/ruff-options-hash-strict-execution-01',r.OWNER/'.work/experiments/ruff-options-hash-strict-supervisor-01']:
        for p in directory.iterdir():
            if p.is_file():add(p)
    for name,items in protected.items():
        for relative,row in items.items():
            if row['kind']=='file':add(Path(name)/relative,row['sha256'])
    original=r.read(r.OWNER/'experiments/runtime-application-admission/ruff-options-hash-strict-01/plan/plan.json')
    add(original['editable_source']['path'],original['editable_source']['original_sha256'])
    for name in ['plan.json','inputs.json','launch.json','metadata-preflight.json']:
        add(r.OWNER/'experiments/runtime-application-admission/ruff-options-hash-strict-01/plan'/name)
    python=Path(sys.executable).resolve(strict=True)
    for p in [python,'/opt/homebrew/bin/python3','/bin/ps','/usr/sbin/lsof']:add(p)
    environment=dict(HOME='/Users/danluu',USER='danluu',LOGNAME='danluu',LANG='C',LC_ALL='C',TZ='UTC',
        PATH='/usr/bin:/bin:/usr/sbin:/sbin',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',__CF_USER_TEXT_ENCODING='0x1F5:0x0:0x0')
    commands=[dict(label='open-handles',argv=['/usr/sbin/lsof','+D',str(r.ROOT)],expected=[0,1]),
              dict(label='closed-owners',argv=['/bin/ps','-p',','.join(sorted(history['owners'],key=int)),'-o','pid=,ppid=,pgid=,lstart=,tty=,command='],expected=[0,1])]
    transition=dict(action='retire-completed-derived-cache',root=str(r.ROOT),original_final_catalog=ref(r.FINAL),
        historical_actual_audit=ref(r.AUDIT),complete_calls=16,counts=counts,archives=archive_pins,selected_artifacts=artifacts,
        catalog_meaning='Immutable historical cache inventory; successful retirement does not imply current cache existence.',
        future_work='All later histories require fresh caches; no selected provider or retained evidence is removed.')
    plan=dict(status='prepared-unrun',owner=str(r.OWNER),root=str(r.ROOT),work=str(r.WORK),python=str(python),
        counts=counts,observed_allocated_bytes=allocated,environment=environment,routes=dict(routes),commands=commands,
        platform_identity=r.runtime_platform.identity(list(os.uname())),platform_context=r.runtime_platform.observation(list(os.uname())),
        controls=dict(receipt=str(CONTROL_RECEIPT),audit=str(CONTROL_AUDIT)),closed_history=history,protected_evidence=protected,
        outer_identity=r.identity(r.ROOT.parent),outer_children=sorted(os.listdir(r.ROOT.parent)),transition=transition,archive_readback=archives,
        bounds=dict(entry_free_bytes=9*r.GIB+256*r.MIB,live_free_gib=9,floor_gib=8,evidence_bytes=256*r.MIB,ledger_bytes=192*r.MIB,
            canonical_wait_seconds=600,discovery_inputs=4096,discovery_input_bytes=2*r.GIB,single_input_bytes=512*r.MIB,
            inventory_entries=20000,inventory_logical_bytes=3*r.GIB),
        exclusions=['Only the whole strict01 cache tree is selected.','No signals, chmod, compiler, provider, benchmark or peer process control.',
            'Protected noncache evidence is rehashed; no new whole-provider inventory claim.'])
    r.PACKET.mkdir();r.owned.write(r.PACKET/'inventory.json',rows);r.owned.write(r.PACKET/'plan.json',plan)
    for p in [r.PACKET/'inventory.json',r.PACKET/'plan.json']:add(p)
    freeze=dict(status='prepared-unrun',owner=str(r.OWNER),files=files,plan_sha256=r.sha(r.PACKET/'plan.json'))
    r.owned.write(r.PACKET/'inputs.json',freeze)
    command=[str(python),'-B',str(r.HERE/'retire.py'),'--inputs-sha256',r.sha(r.PACKET/'inputs.json')]
    OUTER.mkdir();r.owned.write(OUTER/'plan.json',dict(owner=str(r.OWNER),supervisor_sha256=r.sha(r.OWNER/'scripts/supervise_experiment.py'),command=command))
    launch=dict(status='prepared-unrun-awaiting-exact-review',command=[str(python),'-B',str(r.OWNER/'scripts/supervise_experiment.py'),'--supervise',str(OUTER/'plan.json')],
        cwd=str(r.OWNER),environment=environment,inputs_sha256=r.sha(r.PACKET/'inputs.json'),helper_sha256=r.sha(r.HERE/'retire.py'),
        outer_plan_sha256=r.sha(OUTER/'plan.json'),actual_readonly_probes=2,removed_entries=14161,bounds=plan['bounds'])
    r.owned.write(r.PACKET/'launch.json',launch)
    checker=object.__new__(r.Retirement);checker.plan=plan;checker.freeze=freeze
    checker.guard();checker.protected();r.require(r.inventory(r.ROOT)[0]==rows,'cache changed during preparation')
    print(json.dumps(dict(status='prepared-unrun',files=len(files),bytes=sum(v['identity']['size'] for v in files.values()),
        launch_sha256=r.sha(r.PACKET/'launch.json'),inputs_sha256=r.sha(r.PACKET/'inputs.json'),plan_sha256=r.sha(r.PACKET/'plan.json'),counts=counts),sort_keys=True))


if __name__ == '__main__':
    main()
