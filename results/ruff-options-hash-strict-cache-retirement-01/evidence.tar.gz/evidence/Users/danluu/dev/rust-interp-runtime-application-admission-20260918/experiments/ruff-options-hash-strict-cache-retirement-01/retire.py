"""Retire the single completed strict Ruff cache, preserving its closed evidence."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent
OWNER = HERE.parents[1]
ROOT = OWNER / '.work/ruff-options-hash-strict-01/cache'
WORK = OWNER / '.work/ruff-options-hash-strict-cache-retirement-01'
PACKET = HERE / 'plan-01'
Q = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
ARCHIVE = Q / 'results/ruff-options-hash-strict-01'
SUPPLEMENT = Q / 'results/ruff-options-hash-strict-cache-preservation-01'
ASSESSMENT = OWNER / '.work/ruff-options-hash-strict-cache-retirement-assessment-01.json'
FINAL = OWNER / '.work/ruff-options-hash-strict-cache-inventory-01.json'
AUDIT = OWNER / '.work/ruff-options-hash-strict-independent-readback-01.json'
GIB, MIB = 2**30, 2**20
def no_explicit_signals(event, args):
    if event in ('os.kill', 'os.killpg'):
        raise RuntimeError('retirement forbids explicit process signals')

sys.addaudithook(no_explicit_signals)
sys.path.insert(0, str(OWNER / 'experiments/runtime-application-admission'))
import runtime_platform
import bounded_probes
import fd_remove
owned = bounded_probes.owned


def require(value, message):
    if not value:
        raise RuntimeError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def identity(path):
    return fd_remove.identity(Path(path).lstat())


def capacity():
    free = owned.disk(OWNER, 9)
    if WORK.exists():
        require(bounded_probes.allocated(WORK)['bytes'] <= 256*MIB, 'retirement evidence exceeds 256 MiB')
    return free


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8*MIB), b''):
            owned.disk(OWNER, 9)
            h.update(block)
    return h.hexdigest()


def file(path):
    path = Path(path); before = identity(path)
    require(path.resolve(strict=True) == path and stat.S_ISREG(before['mode']), 'ordinary canonical file required: '+str(path))
    digest = sha(path)
    require(identity(path) == before, 'file changed while hashing: '+str(path))
    return dict(identity=before, sha256=digest)


def inventory(root, *, exclude_cache=False):
    root = Path(root)
    require(root.resolve(strict=True) == root and stat.S_ISDIR(root.lstat().st_mode), 'ordinary root required')
    rows = {'.': dict(kind='directory', identity=identity(root))}
    seen = set(); allocated = 0; logical_bytes = 0
    for parent, dirs, files in os.walk(root, followlinks=False):
        if exclude_cache and Path(parent) == ROOT.parent:
            dirs[:] = [name for name in dirs if name != ROOT.name]
        for name in sorted(dirs + files):
            path = Path(parent) / name; before = identity(path)
            require(path.resolve(strict=True) == path, 'indirect inventory path: '+str(path))
            if stat.S_ISDIR(before['mode']):
                row = dict(kind='directory', identity=before)
            else:
                require(stat.S_ISREG(before['mode']), 'nonordinary inventory entry: '+str(path))
                logical_bytes += before['size']
                require(logical_bytes <= 3*GIB and before['size'] <= 512*MIB, 'inventory byte bound')
                row = dict(kind='file', **file(path))
            rows[str(path.relative_to(root))] = row
            require(len(rows) <= 20000, 'inventory entry bound')
    for name, row in rows.items():
        inode = (row['identity']['dev'], row['identity']['ino'])
        if inode not in seen:
            allocated += (root if name == '.' else root/name).lstat().st_blocks*512
            seen.add(inode)
    return rows, allocated


def historical_rows():
    frozen = read(FINAL)
    require(frozen['status'] == 'inventoried-only' and frozen['retired'] is False, 'historical inventory scope differs')
    result = {'.': dict(kind='directory', identity=read(ASSESSMENT)['cache_root_identity'])}
    for root, tree in frozen['roots'].items():
        path = Path(root)
        require(path.parent == ROOT and path.name in ['baseline', 'candidate'] and not tree['links'], 'selected cache root differs')
        convert = lambda values: dict(zip(fd_remove.FIELDS, values, strict=True))
        result[path.name] = dict(kind='directory', identity=convert(tree['stamp']))
        for name, values in tree['directories'].items():
            result[path.name+'/'+name] = dict(kind='directory', identity=convert(values))
        for name, row in tree['files'].items():
            result[path.name+'/'+name] = dict(kind='file', identity=convert(row['stamp']), sha256=row['sha256'])
    return result


def cache_summary(rows):
    groups = {}; directories = 0
    for name, row in rows.items():
        ident = row['identity']
        if row['kind'] == 'directory':
            require(stat.S_ISDIR(ident['mode']) and ident['mode'] & stat.S_IWUSR, 'nonwritable directory')
            directories += 1
        else:
            require(row['kind'] == 'file' and stat.S_ISREG(ident['mode']), 'nonordinary cache entry')
            groups.setdefault((ident['dev'], ident['ino']), []).append(row)
    for aliases in groups.values():
        require(all(row == aliases[0] for row in aliases) and aliases[0]['identity']['nlink'] == len(aliases), 'external hardlink or inconsistent aliases')
    return dict(entries=len(rows), directories=directories, files=len(rows)-directories,
        file_inode_groups=len(groups), internal_hardlink_groups=sum(len(v)>1 for v in groups.values()),
        logical_file_bytes=sum(row['identity']['size'] for row in rows.values() if row['kind']=='file'))


def closed_history():
    assessment = read(ASSESSMENT)
    proof = assessment['closed_history']; terminal = read(proof['terminal']['path']); outer = read(proof['outer']['path'])
    parent = read(proof['parent']['path']); result = read(proof['result']['path'])
    for ref in proof.values():
        require(sha(ref['path']) == ref['sha256'], 'closed evidence digest differs')
    require(terminal['status'] == result['status'] == 'passed' and outer['status'] == parent['status'] == 'finished'
            and outer['returncode'] == parent['returncode'] == parent['controller_returncode'] == 0
            and parent['supervisor_may_be_live'] is parent['controller_may_be_live'] is False, 'closed history outcome differs')
    require(terminal['pid'] == outer['child_pid'] and terminal['parent_pid'] == outer['supervisor_pid'] == parent['pid']
            and outer['supervisor_parent_pid'] == parent['parent_pid'], 'closed parent association differs')
    require(parent['started_at'] <= outer['started_at'] <= terminal['started_at'] <= terminal['admitted_at']
            <= terminal['finished_at'] <= outer['finished_at'] <= parent['finished_at'], 'closed chronology differs')
    require(parent['outer_status_sha256'] == proof['outer']['sha256'] and terminal['result'] == proof['result'], 'closed proof association differs')
    plan_path = OWNER/'experiments/runtime-application-admission/ruff-options-hash-strict-01/plan/plan.json'
    plan = read(plan_path); require(sha(plan_path) == terminal['plan_sha256'], 'closed plan differs')
    require(len(terminal['children']) == len(plan['commands']) == len(result['records']) == 16, 'complete history count differs')
    previous = terminal['admitted_at']; owners = {}; children = []
    for ref, expected in zip(terminal['children'], plan['commands'], strict=True):
        raw = Path(ref['path']); child = read(raw/'receipt.json')
        require(child == ref['receipt'] and ref['label'] == expected['label'], 'closed embedded child differs')
        require(child['command'] == expected['command'] and child['cwd'] == expected['cwd'] and child['environment'] == plan['child_environment'], 'actual recipe differs')
        require(child['status'] == 'finished' and child['returncode'] == expected['expected_returncode']
                and child['supervisor_pid'] == terminal['pid'] and child['parent_pid'] == terminal['parent_pid'], 'child closure differs')
        require(previous <= child['started_at'] <= child['finished_at'] <= terminal['finished_at'], 'child chronology differs')
        previous = child['finished_at']
        for stream in ['stdout','stderr']: require(sha(raw/stream) == child[stream+'_sha256'], 'closed raw differs')
        ps = child['identity']['ps'].split()
        require(child['identity']['ps_returncode'] == 0 and int(ps[0]) == child['pid'] and int(ps[1]) == terminal['pid'], 'closed PS association differs')
        owners[str(child['pid'])] = ps[3:8]
        children.append(dict(path=str(raw/'receipt.json'), sha256=sha(raw/'receipt.json'), pid=child['pid']))
    for key, pid in [('supervisor_identity',outer['supervisor_pid']),('child_identity',outer['child_pid'])]:
        parts=outer[key].splitlines()[-1].split(); require(int(parts[0]) == pid, 'closed outer identity differs'); owners[str(pid)] = parts[2:7]
    audit = read(AUDIT)
    require(audit['status'] == 'passed' and audit['commands'] == 16 and audit['application_strict_compatibility'] is True
            and audit['mechanism_eligible'] is True and result['strict_compatibility'] is True, 'independent actual strict qualification required')
    audited = {row['path']: row['sha256'] for row in audit['refs']}
    require(all(audited.get(row['path']) == row['sha256'] for row in proof.values())
            and len(audit['bytecode_pairs']) == 8 and result['source_restoration'] == audit['source_restoration'],
            'independent readback belongs to a different closed history')
    return dict(history=proof, owners=owners, children=children, audit_sha256=sha(AUDIT))


def verify_archive():
    assessment = read(ASSESSMENT); reports=[]
    for directory, expected_count, bound in [(ARCHIVE,840,128*MIB),(SUPPLEMENT,6368,80*MIB)]:
        binding = assessment['archives'][str(directory)]
        require(sha(directory/'manifest.json') == binding['manifest_sha256']
                and sha(directory/'evidence.tar.gz') == binding['archive_sha256'], 'preservation archive differs')
        manifest = read(directory/'manifest.json'); rows = {r['member']:r for r in manifest['members']}
        require(len(rows) == len(manifest['members']) == expected_count, 'archive member declaration differs')
        seen=set(); payload_bytes=0
        with tarfile.open(directory/'evidence.tar.gz','r|gz') as archive:
            for member in archive:
                capacity(); require(member.isfile() and member.name in rows and member.name not in seen and member.size <= 64*MIB, 'unexpected archive payload')
                h=hashlib.sha256(); size=0
                with archive.extractfile(member) as stream:
                    for block in iter(lambda:stream.read(MIB),b''):
                        capacity();size+=len(block);h.update(block)
                row=rows[member.name]
                require(size == row['bytes'] and h.hexdigest() == row['sha256'], 'preserved archive member differs')
                seen.add(member.name);payload_bytes+=size
        require(seen == set(rows), 'incomplete archive')
        expanded=0
        with gzip.open(directory/'evidence.tar.gz','rb') as stream:
            for block in iter(lambda:stream.read(MIB),b''):
                capacity();expanded+=len(block);require(expanded <= bound, 'expanded archive bound')
        reports.append(dict(path=str(directory),members=len(seen),payload_bytes=payload_bytes,expanded_bytes=expanded,all_hashes=True,full_gzip_eof_crc=True))
    return reports


class Retirement:
    def __init__(self, digest):
        require(Path.cwd() == OWNER and sys.dont_write_bytecode and not sys.flags.optimize, 'fixed Python owner required')
        require(sha(PACKET/'inputs.json') == digest, 'freeze differs')
        self.freeze = read(PACKET/'inputs.json'); self.plan = read(PACKET/'plan.json')
        require(sha(PACKET/'plan.json') == self.freeze['plan_sha256'], 'plan differs')
        require(self.plan['root'] == str(ROOT) and self.plan['counts']['entries'] == 14161, 'scope differs')
        require(str(Path(sys.executable).resolve(strict=True)) == self.plan['python'], 'Python differs')
        require(dict(os.environ) == self.plan['environment'], 'environment differs')
        self.guard(); require(not WORK.exists() and not WORK.is_symlink(), 'fresh evidence required'); WORK.mkdir()
        self.record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(), children=[],
            inputs_sha256=digest, plan_sha256=sha(PACKET/'plan.json'), benchmark=False, compiler_calls=0)
        self.save()

    def save(self):
        owned.write(WORK/'receipt.json', self.record)

    def guard(self):
        runtime_platform.validate(list(os.uname()), self.plan['platform_identity'])
        for name, row in self.freeze['files'].items():
            require(file(name) == row, 'frozen file differs: '+name)
        for name, row in self.plan['routes'].items():
            path = Path(name)
            require(str(path.resolve(strict=True)) == row['resolved'] and identity(path) == row['identity'], 'executor/provider route differs')
        controls = read(self.plan['controls']['receipt']); audit = read(self.plan['controls']['audit'])
        require(controls['status'] == 'passed' and controls['controls_passed'] == 12 and audit['status'] == 'verified'
            and audit['receipt_sha256'] == sha(self.plan['controls']['receipt']), 'fixture proof differs')
        require(closed_history() == self.plan['closed_history'], 'historical ownership differs')

    def protected(self, retired=False):
        for name, expected in self.plan['protected_evidence'].items():
            expected = json.loads(json.dumps(expected))
            current = inventory(Path(name), exclude_cache=True)[0]
            if Path(name) == ROOT.parent:
                # Only this directory's bookkeeping changes when its cache child is removed.
                for rows in [current, expected]:
                    rows['.']['identity'] = {k: rows['.']['identity'][k] for k in ['dev','ino','mode']}
            require(current == expected, 'noncache evidence changed: '+name)
        expected = set(self.plan['outer_children']) - ({ROOT.name} if retired else set())
        require(set(os.listdir(ROOT.parent)) == expected, 'cache parent membership differs')
        require(all(identity(ROOT.parent)[k] == self.plan['outer_identity'][k] for k in ['dev','ino','mode']), 'cache parent route differs')

    def probe(self, spec, fd):
        output = WORK/'commands'/spec['label']
        try:
            result = bounded_probes.run(spec['argv'], cwd=OWNER, environment=self.plan['environment'], output=output,
                canonical_fd=fd, expected=tuple(spec['expected']))
        finally:
            if (output/'receipt.json').exists():
                child = read(output/'receipt.json')
                self.record['children'].append(dict(label=spec['label'], path=str(output/'receipt.json'), sha256=sha(output/'receipt.json'), pid=child.get('pid')))
                self.save()
        require((output/'stderr').read_bytes() == b'' and (output/'stdout').stat().st_size <= MIB, 'unexpected probe output')
        return result, (output/'stdout').read_text()

    def run(self):
        try:
            with owned.workload_lock(owned.CANONICAL_LOCK, 600) as fd:
                free = capacity(); require(free >= 9*GIB+256*MIB, 'entry reservation unavailable')
                self.record.update(status='running', admitted_at=time.time(), free_bytes_before=free); self.save()
                self.guard(); self.protected()
                rows, allocated = inventory(ROOT)
                require(rows == historical_rows() == read(PACKET/'inventory.json') and cache_summary(rows) == self.plan['counts'], 'cache membership/content changed')
                require(identity(ROOT.parent) == self.plan['outer_identity'], 'cache parent changed before admission')
                self.record['archive_readback'] = verify_archive(); self.save()
                owned.write(WORK/'transition.json', self.plan['transition'])
                owned.write(WORK/'admitted-inventory.json', dict(entries=rows, observed_allocated_bytes=allocated))
                (WORK/'commands').mkdir()
                child, raw = self.probe(self.plan['commands'][0], fd)
                require(child['returncode'] == 1 and not raw, 'cache has open handles or mappings')
                child, raw = self.probe(self.plan['commands'][1], fd)
                for line in raw.splitlines():
                    parts = line.split(); require(len(parts) >= 9 and parts[0] in self.plan['closed_history']['owners'], 'unexpected exact-PID observation')
                    require(parts[3:8] != self.plan['closed_history']['owners'][parts[0]], 'closed workload owner remains alive')
                self.guard(); self.protected()
                require(inventory(ROOT)[0] == rows and identity(ROOT.parent) == self.plan['outer_identity'], 'cache drift after quiescence')
                with (WORK/'deleted.jsonl').open('xb'): pass
                try:
                    removed = fd_remove.remove_tree(ROOT, rows, self.plan['outer_identity'], WORK/'deleted.jsonl', capacity)
                finally:
                    self.record['ledger'] = fd_remove.ledger_summary(WORK/'deleted.jsonl')
                    self.save()
                require(not ROOT.exists() and not ROOT.is_symlink(), 'cache root remains')
                self.protected(retired=True); self.guard()
                ledger = self.record['ledger']
                require(all(set(ledger[k]) == set(rows) and len(ledger[k]) == len(rows) for k in ['intent','unlinked','validated'])
                    and not ledger['uncertain'] and ledger['readback_error'] is None, 'incomplete removal ledger')
                require(removed == dict(removed_entries=14161, files=11490, directories=2671, root_absent=True), 'removal count differs')
                self.record.update(status='passed', removed=removed, ledger_sha256=sha(WORK/'deleted.jsonl'),
                    transition_sha256=sha(WORK/'transition.json'), free_bytes_after=capacity(), protected_noncache_evidence_unchanged=True,
                    historical_cache_inventory_retired=True, actual_readonly_probes=2)
        except BaseException as error:
            self.record.update(status='failed', error=repr(error)); raise
        finally:
            self.record['finished_at'] = time.time(); self.save()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--inputs-sha256', required=True)
    Retirement(parser.parse_args().inputs_sha256).run()
