#!/usr/bin/env python3
"""Publish the finite closed strict-cache retirement evidence once."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile
import time

A = Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
Q = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
O = Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
DEST = Q / 'results/ruff-options-hash-strict-cache-retirement-01'
LIST = A / '.work/ruff-options-hash-strict-retirement-publication-paths-01.json'
LIST_SHA = 'cd4dcfc33b4e829f1bfe12a9a6f1aa3b01f532bc5b94d7793070bc9ad88ceb0b'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stamp(path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def ref(path):
    s = stamp(path)
    assert stat.S_ISREG(s[2]) and path.resolve(strict=True) == path
    data = path.read_bytes()
    assert stamp(path) == s
    return dict(path=str(path), bytes=len(data), sha256=sha(data), stamp=s)


def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, sort_keys=True, indent=2)
        f.write('\n')


def main():
    assert not DEST.exists()
    assert sha(LIST.read_bytes()) == LIST_SHA
    selected = [Path(p) for p in json.loads(LIST.read_bytes())]
    assert len(selected) == len(set(selected)) == 45
    assert sum(p.stat().st_size for p in selected) == 73756142
    paths = selected + [LIST, Path(__file__).absolute()]
    members = []
    for p in paths:
        assert any(p.is_relative_to(r) for r in (A, Q, O))
        row = ref(p)
        row['member'] = 'evidence/' + str(p).removeprefix('/')
        members.append(row)
    assert sum(r['bytes'] for r in members) <= 128 * 2**20
    prior = Q / 'results/ruff-options-hash-strict-01'
    supplement = Q / 'results/ruff-options-hash-strict-cache-preservation-01'
    external = [ref(prior/n) for n in ('manifest.json', 'evidence.tar.gz')]
    external += [ref(supplement/n) for n in ('manifest.json', 'evidence.tar.gz', 'readback.json')]
    assert external[1]['sha256'] == 'e2217254f827beae2afbe18f44eada42c57771af83905f1976443d9622c0f043'
    assert external[3]['sha256'] == '5b2812d1e0b7244dfcd76be75a3f9eb887b336e856b1593dd7275799e713cf70'
    assert not (A/'.work/ruff-options-hash-strict-01/cache').exists()
    DEST.mkdir()
    archive = DEST / 'evidence.tar.gz'
    with archive.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                for row in members:
                    p = Path(row['path'])
                    data = p.read_bytes()
                    assert sha(data) == row['sha256'] and stamp(p) == row['stamp']
                    info = tarfile.TarInfo(row['member'])
                    info.size = len(data)
                    info.mode = 0o644
                    tar.addfile(info, io.BytesIO(data))
    assert archive.stat().st_size <= 24 * 2**20
    write(DEST/'preserved-evidence.json', dict(
        references=external,
        strict_actual_members=840,
        cache_supplement_members=6368,
        scope='Existing strict actual archive plus separately published source/diagnostic supplement. Their bytes are referenced, not duplicated. Supplement readback describes its pre-deletion observation; the new retirement receipt records the later deletion.',
    ))
    (DEST/'STATUS.md').write_text('''The explicitly selected strict01 cache tree was retired successfully after the correctness history and all owners closed. The normal parent waited for the supervisor and controller; both scoped read-only probes closed normally. The cache parent is absent. No other cache or provider was selected.

The durable ledger accounts for 14,161 entries: 11,490 files and 2,671 directories, with 42,483 intent/unlinked/validated events and no uncertain removals. Independent saved readback checked the complete ledger, internal hardlink transitions, final absence, all 1,030 frozen inputs and protected noncache membership and hashes. The observed free-byte increase is not claimed to be exclusively attributable to this retirement.

Before removal, 6,368 generated-source, diagnostic, catalog and dependency files (43,380,475 payload bytes) were preserved in the separately referenced cache-preservation capsule. The original strict capsule retains 840 evidence members, including all raw results, 64 artifacts, 710 compiler-argv files and the historical complete cache inventory. Ordinary compiled cache payloads are rebuildable and are not duplicated here.

Preparation attempt01 failed because the already committed strict archive was absent from the sparse working tree. Its exact failure and partial assessment remain retained. The archive was restored byte-exact from commit b4d73ec3, and unchanged preparation02 then passed. The retirement ran once after explicit parent review. The standalone probe_only.py draft was not executed; the two actual probes ran inline immediately before removal. No signals, compiler calls or benchmark runs were performed by retirement.

The descriptor-based remover is byte-identical to the previously qualified implementation; its actual 12-case controls are referenced as historical qualification, not relabeled as new wrapper tests. The complete new source/diffs, prepared packet, actual closed records and raw ledger are archived here. Independent readback is saved-data verification, not new provider qualification. Screen02 preparation is separately verified; this capsule makes no timing or speedup claim.
''')
    top = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p.read_bytes())) for p in sorted(DEST.iterdir()) if p.is_file()}
    write(DEST/'manifest.json', dict(
        status='published', created_at=time.time(), members=members,
        member_count=len(members), uncompressed_payload_bytes=sum(r['bytes'] for r in members),
        files=top, retirement_passed=True, cache_absent=True,
        compiler_calls=0, benchmark_runs=0, performance_qualified=False,
        source_scope='Finite closed source, preparation, probe, owner, ledger and readback evidence; no provider or compiled-cache payloads.',
    ))
    print(json.dumps(dict(path=str(DEST), members=len(members), bytes=sum(r['bytes'] for r in members), archive_bytes=archive.stat().st_size, manifest_sha256=sha((DEST/'manifest.json').read_bytes()))))


if __name__ == '__main__':
    main()
