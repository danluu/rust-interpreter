"""Normally wait for the reviewed exact completed-cache retirement."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

A = Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
Q = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
H = A/'experiments/ruff-options-hash-strict-cache-retirement-01'
OUT = Q/'.work/ruff-options-hash-strict-retirement-execution-01'
OUTER = A/'.work/experiments/ruff-options-hash-strict-cache-retirement-supervisor-01'
WORK = A/'.work/ruff-options-hash-strict-cache-retirement-01'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def ref(p):
    return dict(path=str(p), sha256=sha(p))


def read(p):
    return json.loads(Path(p).read_bytes())


def save(value):
    with (OUT/'record.json').open('w') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')


assert Path.cwd() == A and sys.dont_write_bytecode and not sys.flags.optimize
assert sha(H/'plan-01/launch.json') == '129af7bb0657a3949a816a2161b5869a35b32b85638952265f7f0aa90fab4929'
assert sha(H/'plan-01/inputs.json') == '4e301256bd19907e8c5bacf298a0c1ead3b9af7fd08429a44e3270301ebb978f'
assert sha(H/'plan-01/plan.json') == 'a06cc880cbc6b562c11e63edf56a2b2f826ab5d107675dfeb53f1c56428f5f8d'
launch = read(H/'plan-01/launch.json')
assert sha(H/'retire.py') == launch['helper_sha256'] == '9c040f5c132c35f09975e2a7fa0238190f47cf695d6b827c14eb68a4090956cf'
assert sha(OUTER/'plan.json') == launch['outer_plan_sha256']
outer_plan = read(OUTER/'plan.json')
assert set(outer_plan) == {'owner', 'supervisor_sha256', 'command'}
assert outer_plan['owner'] == str(A)
assert sha(A/'scripts/supervise_experiment.py') == outer_plan['supervisor_sha256']
assert launch['command'] == [str(Path(sys.executable).resolve()), '-B', str(A/'scripts/supervise_experiment.py'), '--supervise', str(OUTER/'plan.json')]
assert not any(os.path.lexists(p) for p in [OUT, WORK, OUTER/'status.json'])
OUT.mkdir()
record = dict(status='starting', parent_pid=os.getpid(), parent_parent_pid=os.getppid(),
    started_at=time.time(), source=ref(__file__), launch=ref(H/'plan-01/launch.json'),
    command=launch['command'], environment=launch['environment'], cwd=str(A),
    supervisor_may_be_live=True, controller_may_be_live=True, signals=0, retries=0,
    scope='Only closed strict01 cache; retained evidence and installed providers excluded.',
    canonical_policy='Retirement child owns canonical lock; parent holds none.')
save(record)
with (OUT/'stdout').open('xb') as stdout, (OUT/'stderr').open('xb') as stderr:
    child = subprocess.Popen(launch['command'], cwd=A, env=launch['environment'],
        stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
    try:
        record.update(pid=child.pid, child_started_at=time.time())
        save(record)
    finally:
        code = child.wait()
record.update(status='finished', returncode=code, finished_at=time.time(),
    supervisor_may_be_live=False, stdout=ref(OUT/'stdout'), stderr=ref(OUT/'stderr'))
save(record)
outer = read(OUTER/'status.json')
assert outer['status'] == 'finished' and outer['supervisor_pid'] == child.pid
assert outer['supervisor_parent_pid'] == os.getpid() and outer['command'] == outer_plan['command']
assert outer['plan_sha256'] == sha(OUTER/'plan.json') and outer['log_sha256'] == sha(OUTER/'command.log')
record.update(controller_may_be_live=False, controller_returncode=outer['returncode'], outer=ref(OUTER/'status.json'))
save(record)
assert code == outer['returncode'] == 0
receipt = read(WORK/'receipt.json')
assert receipt['status'] == 'passed' and receipt['pid'] == outer['child_pid'] and receipt['parent_pid'] == child.pid
assert record['started_at'] <= receipt['started_at'] <= receipt['finished_at'] <= outer['finished_at'] <= record['finished_at']
assert receipt['removed'] == dict(removed_entries=14161, files=11490, directories=2671, root_absent=True)
assert receipt['protected_noncache_evidence_unchanged'] is True and receipt['actual_readonly_probes'] == 2
assert not os.path.lexists(A/'.work/ruff-options-hash-strict-01/cache')
record.update(retirement_verified=True, receipt=ref(WORK/'receipt.json'))
save(record)
print(json.dumps(ref(OUT/'record.json')))
