#!/usr/bin/env python3
"""Package one completed upgrade control run; never execute its test commands."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
UPGRADE = Path('/Users/danluu/dev/rust-interp-hir-upgrade-20260913')
HIRC = Path('/Users/danluu/dev/rust-interp-hir-capture-check-20260913')
PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
RAW = UPGRADE / '.work/hir-upgrade-controls-01'
SUPERVISOR = UPGRADE / '.work/experiments/hir-upgrade-controls-supervisor-01'
HISTORY = PRIMARY / 'results/hir-capture-check-failed-01'
OUT = ROOT / 'results/hir-upgrade-controls-01'
WORK = ROOT / '.work/hir-upgrade-controls-archive-01'
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    WORK.mkdir(parents=True, exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
                  started_at=time.time(), lock=str(CANONICAL_LOCK), lock_wait_seconds=600)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            payloads = {}

            def capture(path, expected=None):
                path = Path(path)
                require(path.is_absolute() and path.resolve(strict=True) == path
                        and path.is_file() and not path.is_symlink(), 'nonordinary evidence path')
                data = path.read_bytes()
                require(expected is None or digest(data) == expected, 'evidence source changed: ' + str(path))
                if str(path) in payloads:
                    require(payloads[str(path)] == data, 'evidence changed during capture')
                payloads[str(path)] = data
                return data

            test = json.loads(capture(RAW / 'summary.json'))
            require(test['status'] == 'passed', 'controls did not pass')
            for path, expected in test['inputs'].items():
                capture(path, expected)
            child = json.loads(capture(RAW / 'command/receipt.json', test['command_receipt_sha256']))
            require(child['status'] == 'finished' and child['returncode'] == 0
                    and child['cwd'] == str(UPGRADE)
                    and child['command'][1:] == ['-m', 'unittest', 'discover', '-s', 'tests',
                                                '-p', 'test_hir_capture_upgrade.py', '-v'],
                    'unexpected completed test command')
            stderr = capture(RAW / 'command/stderr', child['stderr_sha256']).decode()
            capture(RAW / 'command/stdout', child['stdout_sha256'])
            successes = re.findall(r'^test_[^\n]+ \.\.\. ok$', stderr, re.M)
            require(len(successes) == 6 and re.search(r'^Ran 6 tests in [0-9.]+s$', stderr, re.M)
                    and stderr.rstrip().endswith('OK'), 'six passing controls without skips required')
            supervisor = json.loads(capture(SUPERVISOR / 'status.json'))
            require(supervisor['status'] == 'finished' and supervisor['returncode'] == 0
                    and supervisor['child_pid'] == test['pid'], 'test supervisor association changed')
            capture(SUPERVISOR / 'plan.json', supervisor['plan_sha256'])
            capture(SUPERVISOR / 'command.log', supervisor['log_sha256'])
            capture(SUPERVISOR / 'supervisor.log')

            # These imported historical inputs were not in the ten-file test
            # runner map. Bind their current snapshot to the earlier archive;
            # do not relabel them as guarded during the six-test execution.
            previous = json.loads(capture(HISTORY / 'summary.json',
                'b84494be573ff080843b80ef5aacf424fe1f1648e7d0ad996283f3860f254f0a'))
            previous_manifest = json.loads(capture(HISTORY / 'manifest.json',
                '6f038a40708f21d9e493ff13a327d67493195bcdc3beba453e04fa5a3bc2820e'))
            old_plan_path = HIRC / 'experiments/hir-capture-check/planned-check-01.json'
            old_plan = json.loads(capture(old_plan_path,
                previous_manifest[str(old_plan_path).lstrip('/')]['sha256']))
            for path, expected in old_plan['inputs'].items():
                require(previous_manifest[path.lstrip('/')]['sha256'] == expected,
                        'historical input is not bound by the archived proof')
                capture(path, expected)
            for path in [Path(__file__), ROOT / 'experiments/stable-cgu/owned_stage.py',
                         ROOT / 'scripts/supervise_experiment.py']:
                capture(path)

            OUT.mkdir(parents=True, exist_ok=False)
            archive = OUT / 'evidence.tar.gz'
            manifest = {}
            with archive.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for source, data in sorted(payloads.items()):
                            disk(ROOT)
                            name = source.lstrip('/')
                            member = tarfile.TarInfo(name)
                            member.size = len(data)
                            member.mode = 0o644
                            tar.addfile(member, io.BytesIO(data))
                            manifest[name] = dict(source=source, bytes=len(data), sha256=digest(data))
            seen = set()
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    require(member.isfile() and member.name not in seen, 'invalid archive member')
                    seen.add(member.name)
                    item = manifest[member.name]
                    data = tar.extractfile(member).read()
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'],
                            'archive readback differs')
            require(seen == set(manifest), 'archive readback incomplete')
            require(all(Path(path).read_bytes() == data for path, data in payloads.items()),
                    'retained source changed during archive')
            write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed',
                source_commit='4489362f4327b102379319f807c1abfe12e80436',
                raw=str(RAW), supervisor=str(SUPERVISOR), controls=6, skipped=0,
                test_pid=child['pid'], helper_pid=test['pid'], supervisor_pid=supervisor['supervisor_pid'],
                test_command=child['command'], test_seconds=child['finished_at'] - child['started_at'],
                actual_test_summary_sha256=digest(payloads[str(RAW / 'summary.json')]),
                test_run_frozen_inputs=test['inputs'],
                historical_imported_inputs=dict(inputs=old_plan['inputs'],
                    association='additional archive-time snapshots matching the previous failed-history proof; not added to the original test-run guard map',
                    previous_archive_sha256=previous['archive']['sha256']),
                archive=dict(path=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
                             members=len(manifest), all_member_hashes_verified=True, gzip_mtime=0),
                manifest_sha256=sha(OUT / 'manifest.json'),
                scope='six Python controls only; no compiler, unit, capture execution or cache-performance qualification')
            write(OUT / 'summary.json', summary)
            (OUT / 'README.md').write_text(
                '# HIR upgrade source controls\n\n'
                'All six Python controls passed with no skips at source `4489362f`. '
                'They check historical failure admission, reviewed plan and fixed-command binding, '
                'capacity and owner rejection, archived source association, all required test names, '
                'and text delta creation/deletion/change. No compiler workload ran.\n\n'
                'The archive preserves the exact test command, stdout/stderr, receipts, supervisor, '
                'and all ten inputs guarded by that test run. The imported old HIRC inputs are '
                'additional archive-time snapshots matched to the already verified failed-history '
                'archive; they were not added retrospectively to the test runner’s guard map. '
                'All archive members were read back and checked against the manifest. '
                'Compiler sources, targets and old receipts were unchanged.\n')
            record.update(status='passed', finished_at=time.time(), free_bytes_after=disk(ROOT),
                          result=str(OUT), archive=summary['archive'],
                          summary_sha256=sha(OUT / 'summary.json'))
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
