import hashlib,json,re
from pathlib import Path
owner=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918');work=owner/'.work/oxc-native-compatibility-01';outer=owner/'.work/experiments/oxc-native-compatibility-supervisor-01'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(work/'receipt.json');o=read(outer/'status.json');plan=read(owner/'experiments/oxc-plugin-normalization/native-compatibility-plan-01.json');freeze=read(owner/'.work/oxc-native-compatibility-source-01/inputs.json');case=read(owner/'experiments/oxc-plugin-normalization/case.json')['case'];source=owner/'.work/sources/oxc';assert r['status']=='passed' and o['returncode']==0 and r['source_restored'] and len(r['children'])==56
for p,d in freeze['files'].items():assert sha(p)==d,p
assert sha(outer/'command.log')==o['log_sha256']
children={};warnings=[];dyld=set()
for row in r['children']:
 path=Path(row['path']);child=read(path/'receipt.json');assert child==row['receipt'] and child['status']=='finished';assert child['supervisor_pid']==r['pid'] and child['parent_pid']==r['parent_pid'];assert r['admitted_at']<=child['started_at']<=child['finished_at']<=r['finished_at'];assert child['returncode']==(101 if row['label']=='state--1' else 0)
 for channel in ['stdout','stderr']:assert sha(path/channel)==child[channel+'_sha256']
 raw=(path/'stderr').read_text(); messages=re.findall(r'^warning: (.+)$',raw,re.M)
 if messages:warnings.append(dict(label=row['label'],path=str(path/'stderr'),sha256=sha(path/'stderr'),warnings=messages))
 dyld.update(re.findall(r'dyld\[(\d+)\]',raw));children[row['label']]=child
assert [s['label'] for s in r['states']]==plan['state_labels'];assert len(r['states'])==6
states=[]
for row in r['states']:
 label=row['label'];wanted='FAILED' if label=='state--1' else 'ok';assert sorted(row['tests'])==sorted([[n,wanted] for n in case['tests']]);child=children[label];raw=(Path(row['child_path'])/'stdout').read_text();events=[]
 for line in raw.splitlines():
  if line.startswith('{'):
   event=json.loads(line);events.append(event)
   if event.get('reason')=='build-finished':assert event['success'];break
 artifacts=[e for e in events if e.get('reason')=='compiler-artifact' and e.get('executable') and e['profile'].get('test') and 'lib' in e['target']['kind']];assert len(artifacts)==1 and artifacts[0]==row['executable']['artifact'];assert artifacts[0]['package_id']==plan['package_id']
 if label!='state-0':assert not artifacts[0]['fresh']
 assert child['command']==plan['commands'][label]['command'] and child['cwd']==plan['commands'][label]['cwd']
 if label=='state--1':
  for name in case['tests']:
   match=re.search(r'^---- '+re.escape(name)+r' stdout ----\n(.*?)(?=^---- |^failures:|\Z)',raw,re.M|re.S);assert match and 'panicked at' in match[1] and 'assertion' in match[1]
 states.append(dict(label=label,source_sha256=row['source_sha256'],artifact_sha256=row['executable']['sha256'],artifact_fresh=artifacts[0]['fresh'],tests=row['tests'],whole_child_seconds=child['finished_at']-child['started_at']))
assert states[0]['source_sha256']==states[-1]['source_sha256']==sha(source/case['file']);assert [s['source_sha256'] for s in states[:-1]]==plan['source_states'];assert sha(r['states'][-1]['executable']['path'])==states[-1]['artifact_sha256'];assert read(work/'initial-sdk.json')==read(work/'final-sdk.json');assert read(work/'initial-loaders.json')==read(work/'final-loaders.json')
result=dict(schema_version=1,status='six-state native tests passed with unresolved stripping-tool warning',clean_native_performance_qualified=False,benchmark=False,children=56,states=states,source_restored=True,warnings=warnings,unique_reported_dyld_pids=sorted(dyld,key=int),limitation='Installed upstream rust-objcopy cannot find @rpath/libLLVM.dylib in its auxiliary host lib directory. Cargo continues with warnings; proc-macro diagnostics are replayed on warm builds. Do not infer clean native baseline or optimization speedups.',hashes={str(p.relative_to(owner)):sha(p) for p in [work/'receipt.json',outer/'status.json',outer/'command.log',work/'initial-sdk.json',work/'final-sdk.json',work/'initial-loaders.json',work/'final-loaders.json',owner/'.work/oxc-native-compatibility-source-01/inputs.json']})
output=owner/'.work/oxc-native-compatibility-verification-01.json'
with output.open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['warnings','states']},indent=2));print('states',[(s['label'],round(s['whole_child_seconds'],3),s['artifact_fresh']) for s in states]);print('warning_children',len(warnings));print('verification_sha256',sha(output))
