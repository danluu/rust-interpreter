import gzip,hashlib,io,json,tarfile
from pathlib import Path
owner=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918');work=owner/'.work/oxc-native-compatibility-01';dest=owner/'results/oxc-native-compatibility-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths={owner/'.work'/n for n in ['oxc-native-compatibility-source-01/inputs.json','oxc-native-compatibility-launch-01.json','oxc-native-compatibility-launch-record-01.json','oxc-native-compatibility-verification-01.json','verify-oxc-native-01.py','oxc-native-objcopy-path-review-01.json','oxc-native-llvm-tools-component-review-01.json','archive-oxc-native-01.py']}
paths.update(p for p in work.glob('*.json') if p.is_file());paths.update(p for p in (work/'commands').rglob('*') if p.is_file());paths.update(p for p in (work/'inputs'/str(owner).lstrip('/')).rglob('*') if p.is_file());paths.update(p for p in (owner/'.work/experiments/oxc-native-compatibility-supervisor-01').rglob('*') if p.is_file())
root=owner/'.work/oxc-native-setup-01/rustup/toolchains/1.98.1-aarch64-apple-darwin/lib/rustlib';paths.update(root/n for n in ['manifest-rustc-aarch64-apple-darwin','multirust-channel-manifest.toml','components'])
assert all(p.resolve(strict=True)==p and not p.is_symlink() for p in paths);assert sum(p.stat().st_size for p in paths)<96*2**20
members={str(p.relative_to(owner)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(paths)};manifest=dict(schema_version=1,members=members,input_bytes=sum(v['bytes'] for v in members.values()),excluded_payloads='Native target and acquired source/toolchain/registry bytes remain in owned paths. Frozen inputs, inventories, compiler/artifact hashes and every raw command stream are retained.')
dest.mkdir(parents=True,exist_ok=False)
with (dest/'manifest.json').open('x') as f:json.dump(manifest,f,sort_keys=True,indent=2);f.write('\n')
archive=dest/'evidence.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as output:
 for name,row in members.items():
  data=(owner/name).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;output.addfile(entry,io.BytesIO(data))
assert archive.stat().st_size<16*2**20
with tarfile.open(archive,'r:gz') as proof:
 assert {m.name for m in proof}==set(members)
 for m in proof.getmembers():assert m.isfile() and m.size==members[m.name]['bytes'] and hashlib.sha256(proof.extractfile(m).read()).hexdigest()==members[m.name]['sha256']
 while proof.fileobj.read(1024**2):pass
receipt=json.loads((work/'receipt.json').read_text());discovery=next(r['receipt'] for r in receipt['children'] if r['label']=='discover-build');print(json.dumps(dict(members=len(members),input_bytes=manifest['input_bytes'],archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),manifest_sha256=sha(dest/'manifest.json'),cold_discovery_seconds=discovery['finished_at']-discovery['started_at'],final_executable_bytes=receipt['states'][-1]['executable']['bytes']),indent=2))
