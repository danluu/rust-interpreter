#!/usr/bin/env python3
"""Archive only completed production setup/stage1 receipts and frozen source."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tarfile
import time

PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
DRIVER = Path('/Users/danluu/dev/rust-interp-stable-mono-compiler-build-20260913')
SOURCE = Path('/Users/danluu/dev/rustc-stable-mono-production-20260913')
WORK = DRIVER / '.work/mono-production-build-02'
RUN = Path(__file__).resolve().parent
OUT = PRIMARY / 'results/mono-production-bootstrap-through-stage1-01'
COMMIT = '58e1e1f5311f4424ea81def4763081f6da62d9b3'
sys.path.insert(0, str(DRIVER / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write

STAGES = {
    'prepare-02': ('prepare', 'd901977bb4b1b9ad5985f164c2366646c6226ed7a6e714dabf266a4d1420b1fd', 'passed', 'mono-production-prepare-supervisor-03'),
    'freeze-source-01': ('freeze-source', '472720e6d6e5616e529d25a48267dbe9b269d43c1c8deab11c9472396f4ba06c', 'failed', 'mono-production-freeze-supervisor-01'),
    'freeze-source-continuation-01': ('freeze-source', '6a2bf9a0f4273fd6e88785c397936a6c92cfc1ee3de332b0b34e694fa61b7d2c', 'passed', 'mono-production-freeze-continuation-supervisor-01'),
    'stage1-01': ('stage1', '6d73d326dd2ea49d37ff78b96b7977954c07fda1a9e97b74d6a835d0ffc3f383', 'passed', 'mono-production-stage1-supervisor-01'),
    'stage1-controls-01': ('stage1-controls', 'cbe1ebe6c946bb960207407cb7081b39efc7798b428a631cd210e402c91bfc59', 'passed', 'mono-production-stage1-controls-supervisor-01'),
}


def read(path):
    return json.loads(Path(path).read_bytes())


def main():
    receipt = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
        lock=str(CANONICAL_LOCK), lock_wait_seconds=1800, action='saved completed-stage evidence archive only',
        runner_sha256=sha(__file__), compiler_commands=0, benchmark_commands=0)
    require(not (RUN / 'receipt.json').exists(), 'archive attempt already exists')
    write(RUN / 'receipt.json', receipt)
    try:
        with workload_lock(CANONICAL_LOCK, 1800):
            receipt.update(status='admitted', admitted_at=time.time(), free_bytes_before=disk(PRIMARY))
            write(RUN / 'receipt.json', receipt)
            require(not OUT.exists(), 'result output already exists')
            paths, members = {}, {}

            def add(name, path, expected=None):
                path = Path(path)
                require(name not in paths and path.is_file() and not path.is_symlink(), 'invalid archive member')
                actual = sha(path)
                require(expected is None or actual == expected, 'saved evidence changed: ' + str(path))
                paths[name] = path
                members[name] = dict(source=str(path), bytes=path.stat().st_size, sha256=actual)

            plan_path = DRIVER / 'experiments/stable-cgu/planned-mono-production-build-02.json'
            add('plans/original-plan02.json', plan_path, '7459043abb2959cd2192bebb7f635a67d7a53de0b6412ba2c3ac96f6efdba453')
            plan = read(plan_path)
            continuation_path = DRIVER / 'experiments/stable-cgu/planned-freeze-source-continuation-01.json'
            add('plans/freeze-continuation01.json', continuation_path,
                '962f76ab72c2afa0d678f1a38b2ca3bb3e30611a039130011326e3466cd2ea6a')
            continuation = read(continuation_path)
            require(continuation['original_plan']['sha256'] == sha(plan_path), 'continuation names another original plan')
            for name, expected in plan['inputs'].items():
                path = Path(name)
                require(path.is_relative_to(DRIVER), 'original source input escapes driver')
                add('inputs/' + str(path.relative_to(DRIVER)), path, expected)
            add('inputs/experiments/stable-cgu/freeze-source-continuation.py',
                DRIVER / 'experiments/stable-cgu/freeze-source-continuation.py', continuation['runner_sha256'])
            add('inputs/experiments/stable-cgu/FREEZE-SOURCE-CONTINUATION.md',
                DRIVER / 'experiments/stable-cgu/FREEZE-SOURCE-CONTINUATION.md')
            for name, expected in continuation['pinned_recipe_sources'].items():
                add('compiler-source/' + name, SOURCE / name, expected)

            add('source/source.json', WORK / 'source.json')
            frozen = read(WORK / 'source.json')
            require(frozen['source_commit'] == COMMIT and frozen['base_commit'] == plan['base_commit']
                    and frozen['upstream_commit'] == plan['upstream_commit'], 'frozen compiler revision differs')
            for name, expected in [('combined-upstream.patch', frozen['combined_patch_sha256']),
                                   ('mono-formatted.patch', frozen['formatted_mono_patch_sha256'])]:
                add('source/' + name, WORK / name, expected)
            add('source/bootstrap.toml', SOURCE / 'bootstrap.toml', frozen['config_sha256'])
            for name in continuation['files']:
                add('compiler-source/' + name, SOURCE / name, frozen['inventory']['files'][name])

            completed = read(WORK / 'completed.json')
            add('source/completed-at-archive.json', WORK / 'completed.json')
            selected, summaries = {}, {}
            for attempt, (stage, expected, status, supervisor_name) in STAGES.items():
                base = WORK / 'stages' / attempt
                stage_path = base / 'receipt.json'
                require(sha(stage_path) == expected, 'completed stage receipt changed')
                record = read(stage_path)
                require(record['stage'] == stage and record['status'] == status
                        and record['plan_sha256'] == sha(plan_path), 'stage status or plan differs')
                if status == 'passed':
                    proof = dict(path=str(stage_path), sha256=expected)
                    require(completed[stage] == proof, 'driver no longer names this successful completion')
                    selected[stage] = proof
                for reference in record['commands']:
                    child_path = Path(reference['receipt'])
                    require(child_path.is_relative_to(base / 'commands') and sha(child_path) == reference['sha256'],
                            'child receipt escapes its stage or differs')
                    child = read(child_path)
                    require(child['status'] == 'finished' and child['command'] == reference['command']
                            and child['returncode'] == reference['returncode'], 'child did not finish as recorded')
                    for name in ['stdout', 'stderr']:
                        require(sha(child_path.parent / name) == child[name + '_sha256'], 'raw child log changed')
                # Recursion is confined to these five explicitly completed
                # receipt directories. No bootstrap build/output tree is read.
                for path in sorted(base.rglob('*')):
                    require(not path.is_symlink(), 'linked stage evidence')
                    if path.is_file():
                        require(path.name in ['stdout', 'stderr'] or path.suffix in ['.json', '.patch'],
                                'unexpected non-evidence stage file')
                        add('stages/' + attempt + '/' + str(path.relative_to(base)), path)
                supervisor_root = DRIVER / '.work/experiments' / supervisor_name
                supervisor = read(supervisor_root / 'status.json')
                require(supervisor['supervisor_pid'] == record['parent_pid']
                        and supervisor['child_pid'] == record['supervisor_pid']
                        and supervisor['status'] == 'finished'
                        and supervisor['returncode'] == (0 if status == 'passed' else 1), 'supervisor identity or outcome differs')
                require(sha(supervisor_root / 'command.log') == supervisor['log_sha256'], 'supervisor output changed')
                require(sha(supervisor_root / 'plan.json') == supervisor['plan_sha256'], 'supervisor plan changed')
                for name in ['plan.json', 'status.json', 'command.log', 'supervisor.log']:
                    add('supervisors/' + supervisor_name + '/' + name, supervisor_root / name)
                summaries[attempt] = dict(stage=stage, status=status, supervisor_pid=record['parent_pid'],
                    helper_pid=record['supervisor_pid'], commands=len(record['commands']),
                    admitted_at=record['admitted_at'], finished_at=record['finished_at'], receipt_sha256=expected)
            write(RUN / 'completed-through-stage1.json', dict(source=str(WORK / 'completed.json'),
                source_sha256=sha(WORK / 'completed.json'), selected=selected,
                scope='only successful prepare/freeze/stage1/stage1-controls; later stages are not qualified here'))
            add('source/completed-through-stage1.json', RUN / 'completed-through-stage1.json')
            add('packaging/archive_bootstrap_stage1.py', __file__)

            OUT.mkdir()
            archive_path = OUT / 'evidence.tar.xz'
            with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
                for name, path in sorted(paths.items()):
                    info = archive.gettarinfo(str(path), arcname=name)
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    with path.open('rb') as stream:
                        archive.addfile(info, stream)
            with tarfile.open(archive_path, 'r:xz') as archive:
                require(archive.getnames() == sorted(paths), 'archive member list changed')
                for entry in archive:
                    stream, checksum = archive.extractfile(entry), hashlib.sha256()
                    for block in iter(lambda: stream.read(1024 * 1024), b''):
                        checksum.update(block)
                    require(checksum.hexdigest() == members[entry.name]['sha256'], 'archive member changed')
            require(all(sha(paths[name]) == item['sha256'] for name, item in members.items()),
                    'source evidence changed during archival')
            write(OUT / 'members.json', members)
            summary = dict(status='passed', kind='production compiler bootstrap through stage1 controls',
                source_commit=COMMIT, original_plan_sha256=sha(plan_path), continuation_plan_sha256=sha(continuation_path),
                source_inventory_sha256=members['source/source.json']['sha256'], bootstrap_sha256=frozen['config_sha256'],
                stages=summaries, later_stages_qualified=False, interpreter_integration_qualified=False,
                benchmark_commands=0, performance_claim=False, compiler_binaries_or_caches_archived=False,
                original_failure_preserved=True, source_or_driver_modified_by_archival=False,
                archive=dict(path='evidence.tar.xz', sha256=sha(archive_path), bytes=archive_path.stat().st_size,
                             members=len(members), uncompressed_bytes=sum(v['bytes'] for v in members.values())))
            write(OUT / 'summary.json', summary)
            receipt.update(status='passed', finished_at=time.time(), archive_sha256=summary['archive']['sha256'],
                           members=len(members), summary_sha256=sha(OUT / 'summary.json'), free_bytes_after=disk(PRIMARY))
            write(RUN / 'receipt.json', receipt)
            write(OUT / 'packaging-receipt.json', receipt)
            print(json.dumps(receipt))
    except BaseException as error:
        receipt.update(status='failed', finished_at=time.time(), error=repr(error))
        write(RUN / 'receipt.json', receipt)
        raise


if __name__ == '__main__':
    main()
