#!/usr/bin/env python3
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-hir-config-guard-evidence-20260913')
SOURCE = Path('/Users/danluu/dev/rust-interp-hir-capture-check-20260913')
RUN = SOURCE / '.work/hir-configuration-guards-02'
OUTER = SOURCE / '.work/experiments/hir-configuration-guards-supervisor-02'
DEST = ROOT / 'results/hir-capture-offline-seed-guards-01'
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, identity, require, sha, workload_lock, write


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    receipt = ROOT / '.work/hir-config-archive-02.json'
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), identity=identity(os.getpid()),
                  started_at=time.time(), canonical_lock=str(CANONICAL_LOCK), lock_wait_seconds=600)
    write(receipt, record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record['admitted_at'] = time.time()
            result = json.loads((RUN / 'result.json').read_text())
            outer = json.loads((OUTER / 'status.json').read_text())
            require(result['status'] == 'passed' and result['tests_passed'] == 6 and result['tests_skipped'] == 0
                    and outer['status'] == 'finished' and outer['returncode'] == 0, 'test run incomplete')
            require(result['source_commit'] == 'af9c37f427fb1447c1219c0e828dc71ceedbd8dd', 'wrong source')
            for path, expected in result['source_files'].items():
                saved = RUN / 'frozen-inputs' / Path(path).relative_to(SOURCE)
                require(sha(saved) == expected and sha(path) == expected, 'source snapshot mismatch: ' + path)
            command = json.loads((RUN / 'command/receipt.json').read_text())
            for name in ['stdout', 'stderr']:
                require(sha(RUN / 'command' / name) == command[name + '_sha256'], 'raw output mismatch')
            require(sha(OUTER / 'command.log') == outer['log_sha256'], 'outer output mismatch')
            files = {}
            originals = {}
            for base, prefix in [(RUN, 'test-run'), (OUTER, 'test-supervisor')]:
                for path in sorted(base.rglob('*')):
                    require(not path.is_symlink(), 'symlink in evidence')
                    if path.is_file():
                        data = path.read_bytes()
                        files[prefix + '/' + str(path.relative_to(base))] = data
                        originals[str(path)] = digest(data)
            files['archive-helper.py'] = Path(__file__).read_bytes()
            files['archive-owned-stage.py'] = (ROOT / 'experiments/stable-cgu/owned_stage.py').read_bytes()
            files['archive-supervise-experiment.py'] = (ROOT / 'scripts/supervise_experiment.py').read_bytes()
            DEST.mkdir(parents=True, exist_ok=False)
            archive = DEST / 'evidence.tar.gz'
            with tarfile.open(archive, 'w:gz') as tar:
                for name, data in sorted(files.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    tar.addfile(info, io.BytesIO(data))
            with tarfile.open(archive, 'r:gz') as tar:
                members = tar.getmembers()
                require(len(members) == len(files), 'archive count mismatch')
                for member in members:
                    require(member.isfile() and tar.extractfile(member).read() == files[member.name], 'archive bytes mismatch')
            require(all(sha(path) == expected for path, expected in originals.items()), 'evidence changed during archive')
            write(DEST / 'members.json', {name:dict(size=len(data), sha256=digest(data)) for name, data in sorted(files.items())})
            summary = dict(schema_version=1, status='passed', source_commit=result['source_commit'],
                test_count=6, skipped=0, no_compiler_work=True, source_files=result['source_files'],
                test_started_at=command['started_at'], test_finished_at=command['finished_at'],
                test_supervisor_pid=outer['supervisor_pid'], test_helper_pid=result['supervisor_pid'], test_pid=command['pid'],
                source_guard=result['source_guard'], archive=dict(path='evidence.tar.gz', members=len(files),
                size=archive.stat().st_size, sha256=sha(archive), verification='all members read back byte-for-byte'),
                archive_pid=os.getpid(), scope='Six Python configuration/archive guards only; no plan, compiler checkout, build, native execution or benchmark')
            write(DEST / 'summary.json', summary)
            (DEST / 'README.md').write_text('# HIR copied bootstrap seed guards\n\nAll six Python tests passed with no skips against source commit `af9c37f427fb1447c1219c0e828dc71ceedbd8dd`. The two existing configuration guards remain, plus four tests covering exact cache destinations/distribution environment, missing or corrupt copies with restoration, file/ancestor symlinks, and non-file archive paths. All ten frozen inputs remained unchanged.\n\nThe archive retains raw output, command/environment, Python identity, exact source and unchanged bootstrap inputs, process receipts and completed test supervisors. All members were read back byte-for-byte. Archive supervisor completion is retained separately. Originals and the historical two-test result (`../hir-capture-configuration-guards-01`) remain intact.\n\nThe source checks copied archive hashes before each `./x`; these tests do not invoke bootstrap or any downloader. Source inspection establishes that `RUSTUP_DIST_SERVER=file:///dev/null` constrains distribution fallback only. CI LLVM uses a separate server; this is not a complete network sandbox or a guarantee against mutation after preflight.\n\nNo plan, compiler checkout, compiler check/build, benchmark, or HIR cache-hit qualification was performed.\n')
            record.update(status='passed', finished_at=time.time(), archive_sha256=sha(archive), members=len(files))
            write(receipt, record)
            print(json.dumps(summary['archive']), flush=True)
    except BaseException as error:
        record.update(status='failed', error=repr(error), finished_at=time.time())
        write(receipt, record)
        raise


if __name__ == '__main__':
    main()
