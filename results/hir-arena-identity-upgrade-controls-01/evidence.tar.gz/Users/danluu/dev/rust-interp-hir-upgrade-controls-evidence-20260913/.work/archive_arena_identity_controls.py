#!/usr/bin/env python3
import gzip,hashlib,io,json,os,re,sys,tarfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
UP=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
RAW=UP/'.work/hir-arena-identity-upgrade-controls-01'
SUP=UP/'.work/experiments/hir-arena-identity-upgrade-controls-supervisor-01'
OUT=ROOT/'results/hir-arena-identity-upgrade-controls-01'
WORK=ROOT/'.work/hir-arena-identity-controls-archive-01'
sys.path.insert(0,str(ROOT/'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK,disk,require,sha,workload_lock,write

def digest(data):return hashlib.sha256(data).hexdigest()
def main():
 WORK.mkdir(parents=True,exist_ok=False)
 r=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),canonical_lock=str(CANONICAL_LOCK),lock_wait_seconds=600)
 write(WORK/'summary.json',r)
 try:
  with workload_lock(CANONICAL_LOCK,600):
   r.update(status='running',admitted_at=time.time(),free_bytes_before=disk(ROOT));write(WORK/'summary.json',r)
   payloads={}
   def capture(path,expected=None):
    p=Path(path);require(p.is_absolute() and p.resolve(strict=True)==p and p.is_file() and not p.is_symlink(),'nonordinary evidence')
    data=p.read_bytes();require(expected is None or digest(data)==expected,'source changed: '+str(p))
    require(str(p) not in payloads or payloads[str(p)]==data,'changed during capture');payloads[str(p)]=data;return data
   test=json.loads(capture(RAW/'summary.json','fcaa278867a9ff4d894e7b3e57de403dea319135484f186b57676b721a1c1f80'))
   require(test['status']=='passed' and test['expected_controls']==4 and test['all_inputs_unchanged'] and len(test['inputs'])==52
           and test['source_revision']=='73a5b122cbac49d2e7dedf6d488b0091fc598982','wrong control history')
   require(set(test['snapshots'])==set(test['inputs']) and test['actual_tests']==test['required_tests']
           and len(test['actual_tests'])==4 and test['command_receipt_sha256']=='277360d558c083d980f303675f6684c2569f004ec6d4a74da09ca9338ea3f538', 'exact test/receipt binding changed')
   references=[]
   for path,expected in test['inputs'].items():
    snap=test['snapshots'][path]
    if snap.get('archive_reference'):
     require(sha(path)==expected==snap['sha256'],'historical archive changed')
     base=Path(path).parent;manifest=json.loads(capture(base/'manifest.json',test['inputs'][str(base/'manifest.json')]))
     summary=json.loads(capture(base/'summary.json',test['inputs'][str(base/'summary.json')]))
     require(summary['archive']['sha256']==expected,'reference summary association changed')
     seen=set()
     with tarfile.open(path,'r:gz') as tar:
      for member in tar:
       require(member.isfile() and member.name not in seen and member.name in manifest,'invalid reference member')
       seen.add(member.name);data=tar.extractfile(member).read();m=manifest[member.name]
       require(member.name==m['source'].lstrip('/') and len(data)==m['bytes'] and digest(data)==m['sha256'],'reference member changed')
     require(seen==set(manifest),'reference incomplete')
     references.append(dict(path=path,sha256=expected,members=len(seen),all_members_verified=True))
    else:
     data=capture(path,expected);require(capture(snap['path'],expected)==data and len(data)==snap['bytes'],'snapshot changed')
   child=json.loads(capture(RAW/'command/receipt.json',test['command_receipt_sha256']))
   require(child['returncode']==0 and child['status']=='finished' and child['cwd']==str(UP)
           and child['command'][1:]==['-B','-m','unittest','discover','-s','tests','-p','test_hir_arena_identity_upgrade.py','-v'],'wrong test child')
   stderr=capture(RAW/'command/stderr',child['stderr_sha256']).decode();capture(RAW/'command/stdout',child['stdout_sha256'])
   require(len(re.findall(r'^test_[^\n]+ \.\.\. ok$',stderr,re.M))==4 and re.search(r'^Ran 4 tests in [0-9.]+s$',stderr,re.M)
           and stderr.rstrip().endswith('OK'),'four successes required')
   require(sorted(re.findall(r'^test_[^\n]* \(([^)]+)\) \.\.\. ok$',stderr,re.M))==test['required_tests'], 'actual test identities changed')
   require(len(references)==5, 'five reference archives required')
   supervisor=json.loads(capture(SUP/'status.json'))
   require(supervisor['status']=='finished' and supervisor['returncode']==0 and supervisor['child_pid']==test['pid'],'supervisor mismatch')
   capture(SUP/'plan.json',supervisor['plan_sha256']);capture(SUP/'command.log',supervisor['log_sha256']);capture(SUP/'supervisor.log')
   for path in [Path(__file__),ROOT/'experiments/stable-cgu/owned_stage.py',ROOT/'scripts/supervise_experiment.py']:capture(path)
   OUT.mkdir(parents=True,exist_ok=False);archive=OUT/'evidence.tar.gz';manifest={}
   with archive.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
     with tarfile.open(fileobj=gz,mode='w') as tar:
      for source,data in sorted(payloads.items()):
       disk(ROOT);name=source.lstrip('/');m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
       manifest[name]=dict(source=source,bytes=len(data),sha256=digest(data))
   seen=set()
   with tarfile.open(archive,'r:gz') as tar:
    for m in tar:
     require(m.isfile() and m.name not in seen and m.name in manifest,'invalid archive member');seen.add(m.name)
     data=tar.extractfile(m).read();item=manifest[m.name];require(len(data)==item['bytes'] and digest(data)==item['sha256'],'archive readback differs')
   require(seen==set(manifest) and all(Path(p).read_bytes()==b for p,b in payloads.items()),'archive or input changed')
   require(all(sha(ref['path'])==ref['sha256'] for ref in references),'reference changed after readback')
   write(OUT/'manifest.json',manifest)
   summary=dict(status='passed',schema_version=1,source_revision=test['source_revision'],controls=4,skipped=0,
    test_pid=child['pid'],helper_pid=test['pid'],supervisor_pid=supervisor['supervisor_pid'],raw=str(RAW),supervisor=str(SUP),
    inputs=test['inputs'],all_52_inputs_unchanged=True,historical_archive_references=references,
    scope='four Python controls only; no compiler/source mutation/native hit or performance qualification',
    archive=dict(path=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(manifest),all_member_hashes_verified=True),manifest_sha256=sha(OUT/'manifest.json'))
   write(OUT/'summary.json',summary)
   (OUT/'README.md').write_text('# Arena identity upgrade source controls\n\n'
    'All four Python controls passed at `73a5b122` in0.246seconds, without skips. '
    'They preserve all27 required Rust control names, exact arena-identity source delta, '
    'the diagnostic-only predecessor status, five separate historical archives and fixed plan rules. '
    'No compiler, source mutation, native cache-hit qualification or performance measurement occurred in these controls.\n\n'
    'The archive retains complete raw child/supervisor receipts and47 exact source snapshots. '
    'All52 input bindings remain unchanged; five historical tar payloads were verified in full and remain references. '
    'Every new member passed byte-size and SHA256 readback.\n')
   r.update(status='passed',finished_at=time.time(),result=str(OUT),archive=summary['archive'],summary_sha256=sha(OUT/'summary.json'),free_bytes_after=disk(ROOT));write(WORK/'summary.json',r)
 except BaseException as e:
  r.update(status='failed',finished_at=time.time(),error=repr(e));write(WORK/'summary.json',r);raise
if __name__=='__main__':main()
