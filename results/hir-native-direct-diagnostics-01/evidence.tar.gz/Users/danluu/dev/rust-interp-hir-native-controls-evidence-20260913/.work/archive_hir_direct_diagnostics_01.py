#!/usr/bin/env python3
"""Archive two completed diagnostics; never rerun compiler or native commands."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results/hir-native-direct-diagnostics-01'
WORK = ROOT / '.work/hir-native-direct-diagnostics-archive-01'
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write

HISTORIES = [
    ('capture', '5946b8abf2fe095b9e7c6c0ccb9159825b5f14d90ff26c41bc51f9c5d0b60cb3',
     '4062b05d9b389cdc9cb0993a34e5e20ecd3faef356db72eb257ffcbc38537f25'),
    ('hir-tree', 'ddc031629e3dd0b27cca0603577c900565a1ff2ee423618993816cd61fa1e7b3',
     'd1c66cc03684cbd76ef8d9f45f4e39f1ebcb50958df2069d34f2715b1a68e986'),
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    WORK.mkdir(parents=True, exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
                  lock=str(CANONICAL_LOCK), lock_wait_seconds=600)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            payloads, excluded, references, histories = {}, {}, {}, []

            def capture(path, expected=None):
                path = Path(path)
                require(path.is_absolute() and path.is_file() and not path.is_symlink()
                        and path.resolve(strict=True) == path, 'nonordinary evidence input: ' + str(path))
                data = path.read_bytes()
                require(expected is None or digest(data) == expected, 'evidence changed: ' + str(path))
                require(str(path) not in payloads or payloads[str(path)] == data, 'evidence changed while reading')
                payloads[str(path)] = data
                return data

            def verify_reference(paths, hashes, required):
                archive = Path(paths['archive'])
                require(archive.is_absolute() and archive.resolve(strict=True) == archive
                        and archive.is_file() and not archive.is_symlink()
                        and sha(archive) == hashes[str(archive)], 'predecessor archive changed')
                excluded[str(archive)] = hashes[str(archive)]
                if str(archive) in references:
                    return
                manifest = json.loads(capture(paths['manifest'], hashes[paths['manifest']]))
                summary = json.loads(capture(paths['summary'], hashes[paths['summary']]))
                require(summary['archive']['sha256'] == hashes[str(archive)]
                        and summary['archive']['all_member_hashes_verified'], 'predecessor summary mismatch')
                pending, seen = dict(required), set()
                with tarfile.open(archive, 'r:gz') as tar:
                    for member in tar:
                        disk(ROOT)
                        require(member.isfile() and member.name not in seen and member.name in manifest,
                                'invalid predecessor member')
                        seen.add(member.name)
                        item = manifest[member.name]
                        data = tar.extractfile(member).read()
                        source = item['source']
                        require(member.name == source.lstrip('/') and Path(source).is_absolute()
                                and '..' not in Path(member.name).parts
                                and len(data) == item['bytes'] and digest(data) == item['sha256'],
                                'predecessor member content/origin mismatch')
                        if source in pending:
                            require(pending.pop(source) == item['sha256'], 'required predecessor input differs')
                require(not pending and seen == set(manifest), 'incomplete predecessor archive')
                references[str(archive)] = dict(paths=paths, hashes=hashes, required=required,
                    members=len(seen), all_members_verified=True, payload_not_duplicated=True)

            for label, receipt_sha, plan_sha in HISTORIES:
                raw = ROOT / '.work' / ('hir-native-direct-' + label + '-probe-01')
                stem = 'direct_' + label.replace('-', '_') + '_probe_01'
                plan_path = ROOT / '.work' / (stem + '.json')
                plan = json.loads(capture(plan_path, plan_sha))
                run = json.loads(capture(raw / 'receipt.json', receipt_sha))
                capture(ROOT / '.work' / (stem + '.py'), plan['helper_sha256'])
                require(run['status'] == 'diagnostic-completed' and run['compiler_returncode'] == 0
                        and run['source_revision'] == '3d7ad8282c5695196f4a4dcfd0bdceacac3f79b9'
                        and run['expected_plan_sha256'] == plan_sha and run['diagnostic_only']
                        and not run['native_qualified'] and not run['executed_native_binary']
                        and run['original_native_result'] == 'failed' and len(run['commands']) == 11,
                        'diagnostic result or scope changed')
                require('RUSTC_FORCE_RUSTC_VERSION' not in plan['environment'], 'diagnostic unexpectedly used override')
                archive = plan['failed_archive']
                hashes = {path: plan['inputs'][path] for path in archive.values()}
                required = {p: h for p, h in plan['inputs'].items() if p in
                    {plan['failed_command'], plan['postfailure_artifacts'], plan['fixture'], plan['rmake_source']}}
                verify_reference(archive, hashes, required)
                failed_summary = json.loads(payloads[archive['summary']])
                for ref in failed_summary['historical_archives']:
                    verify_reference(ref['paths'], ref['hashes'], ref['required'])
                for path, expected in plan['inputs'].items():
                    if path in excluded:
                        require(excluded[path] == expected, 'excluded archive binding changed')
                    else:
                        capture(path, expected)
                compiler = None
                for ref in run['commands']:
                    path = Path(ref['path'])
                    require(path.is_relative_to(raw / 'commands'), 'foreign diagnostic child')
                    child = json.loads(capture(path, ref['sha256']))
                    require(child['status'] == 'finished' and child['returncode'] == 0
                            and child['command'] == ref['command'] and child['environment'] == plan['environment'],
                            'diagnostic child or actual environment changed')
                    stdout = capture(path.parent / 'stdout', child['stdout_sha256'])
                    stderr = capture(path.parent / 'stderr', child['stderr_sha256'])
                    if child['command'] == plan['compiler_command']:
                        require(compiler is None and child['cwd'] == str(raw / 'fixture')
                                and ref == run['compiler_command'], 'actual compiler association changed')
                        messages = [line for line in stderr.decode().splitlines()
                                    if line.startswith(('[hir-body-capture]', '[hir-body-reuse]'))]
                        require(messages == run['capture_messages'] and len(messages) == 24
                                and all(' rejected-body-tree ' in line for line in messages),
                                'actual rejection observation changed')
                        compiler = child
                    else:
                        require(child['command'][0] == 'git', 'unexpected additional workload command')
                require(compiler is not None, 'missing diagnostic compiler')
                before = capture(raw / 'compiler-artifacts-before.json')
                after = capture(raw / 'compiler-artifacts-after.json')
                expected = capture(plan['postfailure_artifacts'], plan['inputs'][plan['postfailure_artifacts']])
                require(json.loads(before) == json.loads(after) == json.loads(expected),
                        'diagnostic compiler/std inventory association changed')
                capture(raw / 'fixture/input.rs', run['source_sha256'])
                if label == 'hir-tree':
                    tree = capture(raw / 'fixture/hir-tree.txt', run['hir_tree_sha256'])
                    require(len(tree) == run['hir_tree_bytes'] == 2851254, 'raw HIR size changed')
                outer_root = ROOT / '.work/experiments' / ('hir-native-direct-' + label + '-probe-supervisor-01')
                outer = json.loads(capture(outer_root / 'status.json'))
                launch = json.loads(capture(outer_root / 'plan.json', outer['plan_sha256']))
                require(outer['status'] == 'finished' and outer['returncode'] == 0
                        and outer['child_pid'] == run['pid'] and outer['supervisor_pid'] == run['parent_pid']
                        and launch['command'] == outer['command']
                        and launch['command'][-2:] == ['--plan-sha256', plan_sha], 'diagnostic supervisor changed')
                capture(outer_root / 'command.log', outer['log_sha256'])
                capture(outer_root / 'supervisor.log')
                histories.append(dict(label=label, raw=str(raw), receipt_sha256=receipt_sha,
                    plan=str(plan_path), plan_sha256=plan_sha, supervisor=str(outer_root),
                    supervisor_pid=outer['supervisor_pid'], helper_pid=run['pid'], compiler_pid=compiler['pid'],
                    compiler_returncode=0, rejected_body_tree_records=24, successful_capture_records=0,
                    native_qualified=False, compiled_binary_sha256=run.get('output_binary_sha256'),
                    hir_tree_sha256=run.get('hir_tree_sha256'), hir_tree_bytes=run.get('hir_tree_bytes')))

            for path in [Path(__file__), ROOT / 'experiments/stable-cgu/owned_stage.py',
                         ROOT / 'scripts/supervise_experiment.py']:
                capture(path)
            OUT.mkdir(parents=True, exist_ok=False)
            target = OUT / 'evidence.tar.gz'
            manifest = {}
            with target.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for source, data in sorted(payloads.items()):
                            disk(ROOT)
                            name = source.lstrip('/')
                            member = tarfile.TarInfo(name); member.size = len(data); member.mode = 0o644
                            tar.addfile(member, io.BytesIO(data))
                            manifest[name] = dict(source=source, bytes=len(data), sha256=digest(data))
            seen = set()
            with tarfile.open(target, 'r:gz') as tar:
                for member in tar:
                    require(member.isfile() and member.name not in seen and member.name in manifest,
                            'invalid result archive member')
                    seen.add(member.name); data = tar.extractfile(member).read(); item = manifest[member.name]
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback changed')
            require(seen == set(manifest) and all(Path(p).read_bytes() == b for p, b in payloads.items())
                    and all(sha(p) == h for p, h in excluded.items()), 'archive/source postguard failed')
            write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='archived', source_revision='3d7ad8282c5695196f4a4dcfd0bdceacac3f79b9',
                histories=histories, historical_archives=list(references.values()), compiler_invocations=2,
                original_native_qualification='failed', native_qualified=False, performance_claim=False,
                exclusions=['compiler/native binaries', 'incremental cache', 'referenced predecessor archive payloads'],
                archive=dict(path=target.name, sha256=sha(target), bytes=target.stat().st_size,
                    members=len(manifest), all_member_hashes_verified=True, gzip_mtime=0),
                manifest_sha256=sha(OUT / 'manifest.json'))
            write(OUT / 'summary.json', summary)
            (OUT / 'README.md').write_text(
                '# Direct HIR capture diagnostics\n\n'
                'Two bounded diagnostics used the existing stage1 compiler at source `3d7ad828`, '
                'the byte-identical frozen fixture and the original HIRC environment with no '
                '`RUSTC_FORCE_RUSTC_VERSION`. Both compiler commands returned zero. Each emitted '
                '24 `rejected-body-tree` records; neither produced a successful capture or cache hit. '
                'The first produced a native binary which was not executed. The second added '
                '`-Zunpretty=hir-tree` and retained its full 2,851,254-byte textual output.\n\n'
                'The smallest child function has block/literal/root IDs 1/2/3, matching the reported '
                'S=1/E=4 interval. Its visible spans lie within the owner; the HIR dump does not expose '
                'Span parent metadata. This did not establish the failing subcheck or a fix. The '
                'original compiletest native qualification remains failed. No performance result is claimed.\n\n'
                'All 22 child receipts and raw outputs, both exact plans/helpers/supervisors, frozen '
                'fixture and imported source bytes, and compiler/std inventory equality proofs are retained. '
                'All archive members were read back and verified. Four predecessor archives were verified '
                'and referenced through exact manifests, summaries and hashes without duplicating their payloads.\n')
            record.update(status='passed', finished_at=time.time(), free_bytes_after=disk(ROOT),
                result=str(OUT), archive=summary['archive'], summary_sha256=sha(OUT / 'summary.json'))
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', error=repr(error), finished_at=time.time())
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
