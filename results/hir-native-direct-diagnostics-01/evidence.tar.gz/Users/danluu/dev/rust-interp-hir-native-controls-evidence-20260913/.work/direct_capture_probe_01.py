#!/usr/bin/env python3
"""One existing-compiler diagnostic; this does not qualify native cache reuse."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
NATIVE = Path('/Users/danluu/dev/rust-interp-hir-native-correctness-20260913')
WORK = ROOT / '.work/hir-native-direct-capture-probe-01'
PLAN = ROOT / '.work/direct_capture_probe_01.json'
NATIVE_PLAN = NATIVE / 'experiments/hir-native-correctness/planned-native-01.json'
NATIVE_PLAN_SHA = '27977dafa0f59c7f9ee891b2e27ad3e75acfb8606411dd4ef2f0104e2e6cab81'
SOURCE_REVISION = '3d7ad8282c5695196f4a4dcfd0bdceacac3f79b9'


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ordinary(path):
    p = Path(path)
    require(p.is_absolute() and p.resolve(strict=True) == p and p.is_file()
            and not p.is_symlink(), 'nonordinary frozen input: ' + str(p))
    return p


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--plan-sha256', required=True)
    args = parser.parse_args()
    require(re.fullmatch('[0-9a-f]{64}', args.plan_sha256)
            and sha(ordinary(PLAN)) == args.plan_sha256, 'reviewed probe plan changed')
    plan = json.loads(PLAN.read_bytes())
    require(plan['owner'] == str(ROOT) and plan['work'] == str(WORK)
            and plan['helper_sha256'] == sha(Path(__file__)), 'probe owner/helper changed')
    for path, expected in plan['inputs'].items():
        require(sha(ordinary(path)) == expected, 'frozen probe dependency changed: ' + path)
    spec = importlib.util.spec_from_file_location('frozen_native_probe',
        NATIVE / 'experiments/hir-native-correctness/check.py')
    native = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = native
    spec.loader.exec_module(native)
    engine = native.engine
    WORK.mkdir(parents=True, exist_ok=False)
    receipt = dict(schema_version=1, status='waiting', owner=str(ROOT), pid=os.getpid(),
        parent_pid=os.getppid(), started_at=time.time(), expected_plan_sha256=args.plan_sha256,
        diagnostic_only=True, native_qualified=False, commands=[])
    engine.write(WORK / 'receipt.json', receipt)
    try:
        with engine.workload_lock(engine.CANONICAL_LOCK, 600):
            receipt.update(status='running', admitted_at=time.time(), free_bytes_before=engine.disk(ROOT, 9))
            engine.write(WORK / 'receipt.json', receipt)
            native_plan = json.loads(NATIVE_PLAN.read_bytes())
            require(sha(NATIVE_PLAN) == NATIVE_PLAN_SHA, 'native history plan changed')
            prior = native_plan['previous']
            state = prior['source']
            env = dict(prior['old_plan']['environment'])
            require(state['revision'] == SOURCE_REVISION and 'RUSTC_FORCE_RUSTC_VERSION' not in env
                    and env == plan['environment'], 'source or original HIRC environment changed')
            archive = plan['failed_archive']
            summary = json.loads(Path(archive['summary']).read_bytes())
            require(summary['source_revision'] == SOURCE_REVISION
                    and summary['bootstrap_build_passed'] and summary['identity_probes_passed'] == 3
                    and summary['capture_report_lines'] == summary['verified_cache_hit_lines'] == 0
                    and not summary['native_hit_qualified'], 'wrong failed native history')
            required = {p: h for p, h in plan['inputs'].items()
                        if p in {str(NATIVE_PLAN), plan['failed_command'], plan['postfailure_artifacts'],
                                 plan['fixture'], plan['rmake_source']}}
            engine.verify_archive(archive['archive'], archive['manifest'], archive['summary'], required)
            expected_artifacts = json.loads(Path(plan['postfailure_artifacts']).read_bytes())
            require(native.artifacts() == expected_artifacts, 'stage1 compiler or native std changed')
            engine.write(WORK / 'compiler-artifacts-before.json', expected_artifacts)
            failed = json.loads(Path(plan['failed_command']).read_bytes())
            require(failed['command'] == native.COMMANDS['native'] and failed['returncode'] != 0
                    and failed['environment'] == env, 'failed command association changed')
            require(native.inputs() == native_plan['inputs']
                    and native.extra_configurations() == native_plan['configurations']
                    and native.old.frozen_plan() == prior['old_plan'], 'native source recipe changed')

            def guard():
                require(sha(PLAN) == args.plan_sha256 and sha(Path(__file__)) == plan['helper_sha256'],
                        'probe helper/plan changed')
                require(all(sha(ordinary(p)) == h for p, h in plan['inputs'].items()),
                        'frozen probe input changed')
                engine.disk(ROOT, 9)

            def command(argv, cwd=native.SOURCE):
                guard()
                directory = WORK / 'commands' / f'{len(receipt["commands"]):03d}'
                ref = dict(path=str(directory / 'receipt.json'), command=list(map(str, argv)))
                receipt['commands'].append(ref)
                engine.write(WORK / 'receipt.json', receipt)
                try:
                    result = engine.run(argv, cwd=cwd, env=env, out=directory, capacity_root=ROOT)
                finally:
                    if (directory / 'receipt.json').exists():
                        ref['sha256'] = sha(directory / 'receipt.json')
                        engine.write(WORK / 'receipt.json', receipt)
                guard()
                return dict(result, stdout=(directory / 'stdout').read_text(),
                            stderr=(directory / 'stderr').read_text())

            engine.source_guard(state, command, sha(prior['old_plan_path']))
            app = WORK / 'fixture'
            app.mkdir(exist_ok=False)
            payload = Path(plan['fixture']).read_bytes()
            (app / 'input.rs').write_bytes(payload)
            require(sha(app / 'input.rs') == plan['inputs'][plan['fixture']], 'fixture copy changed')
            argv = [str(native.RUSTC), '-L', str(app), 'input.rs', '--crate-name', 'body_journal_test',
                '-o', 'body_journal_test', '-Cmetadata=body_journal_test', '-Cincremental=cache-on',
                '-Zhir-body-cache-capture=true', '-Cdebuginfo=2', '--edition=2024',
                '-Zincremental-info', '--target=' + native.old.HOST]
            require(argv == plan['compiler_command'], 'fixed direct compiler command changed')
            try:
                result = command(argv, app)
            finally:
                engine.source_guard(state, command, sha(prior['old_plan_path']))
                require(native.artifacts() == expected_artifacts, 'compiler/std changed during probe')
                require(sha(app / 'input.rs') == plan['inputs'][plan['fixture']], 'probe source changed')
                engine.write(WORK / 'compiler-artifacts-after.json', expected_artifacts)
            # Source postguards append their own git command receipts.
            compiler_ref = next(dict(ref) for ref in receipt['commands'] if ref['command'] == argv)
            messages = [line for line in result['stderr'].splitlines()
                        if line.startswith(('[hir-body-capture]', '[hir-body-reuse]'))]
            guard()
            receipt.update(status='diagnostic-completed', finished_at=time.time(),
                free_bytes_after=engine.disk(ROOT), compiler_command=compiler_ref,
                compiler_returncode=result['returncode'], source_revision=SOURCE_REVISION,
                source_sha256=sha(app / 'input.rs'), output_binary_sha256=sha(app / 'body_journal_test'),
                capture_messages=messages, observation='capture messages recorded' if messages else 'no capture messages',
                native_qualified=False, executed_native_binary=False, original_native_result='failed')
            engine.write(WORK / 'receipt.json', receipt)
    except BaseException as error:
        receipt.update(status='failed', error=repr(error), finished_at=time.time())
        engine.write(WORK / 'receipt.json', receipt)
        raise


if __name__ == '__main__':
    main()
