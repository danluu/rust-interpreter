extern crate proc_macro;
#[proc_macro] pub fn observe(input: proc_macro::TokenStream) -> proc_macro::TokenStream {
 let span = input.into_iter().next().expect("marker token").span();
 let local = span.local_file().expect("actual source path");
 format!("({:?}, {:?}, {}u32, {}u32)", span.file(), local.to_str().unwrap(), span.line(), span.column()).parse().unwrap()
}
