pub fn observe() -> crate::Observed { let span = path_probe::observe!(marker); (file!(), span.0, span.1, span.2, span.3) }
