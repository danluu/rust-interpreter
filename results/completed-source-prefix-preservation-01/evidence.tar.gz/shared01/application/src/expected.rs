// Original unused native expectation; restored after every exported history.
pub const EXPECTED: [(&[u8], &[u8], &[u8], u32, u32); 2] = [(b"", b"", b"", 0, 0); 2];
