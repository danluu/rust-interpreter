// phase:000000000000000
#[path="core/src/panic.rs"] mod std_looking;
mod expected;
pub type Observed = (&'static str, &'static str, &'static str, u32, u32);
pub fn observe_main() -> Observed { let span = path_probe::observe!(marker); (file!(), span.0, span.1, span.2, span.3) }
fn equal_bytes(value: &str, expected: &[u8]) -> bool {
 let actual = value.as_bytes(); if actual.len() != expected.len() { return false; }
 let mut i = 0; while i < actual.len() { if actual[i] != expected[i] { return false; } i += 1; } true
}
fn compare(value: Observed, expected: (&[u8], &[u8], &[u8], u32, u32)) -> u32 {
 (equal_bytes(value.0, expected.0) as u32) | ((equal_bytes(value.1, expected.1) as u32) << 1) |
 ((equal_bytes(value.2, expected.2) as u32) << 2) | (((value.3 == expected.3) as u32) << 3) |
 (((value.4 == expected.4) as u32) << 4)
}
pub fn entry() -> u32 { compare(observe_main(), expected::EXPECTED[0]) | (compare(std_looking::observe(), expected::EXPECTED[1]) << 5) }
fn show(label: &str, value: Observed) { println!("{}|{}|{}|{}|{}|{}", label, value.0, value.1, value.2, value.3, value.4); }
fn main() { show("main", observe_main()); show("std-looking", std_looking::observe()); }
