import fcntl, hashlib, json, os, re, struct, time
from pathlib import Path

RUN=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913/.work/strict-warm-stable-cgu-screen-01')
OUT=Path(__file__).parent
MASK=(1<<64)-1
DIGITS='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'

def rotate(x,n):return ((x<<n)|(x>>(64-n)))&MASK
def sip_round(v):
    a,b,c,d=v
    a=(a+b)&MASK;c=(c+d)&MASK;b=rotate(b,13)^a;d=rotate(d,16)^c;a=rotate(a,32)
    c=(c+b)&MASK;a=(a+d)&MASK;b=rotate(b,17)^c;d=rotate(d,21)^a;c=rotate(c,32)
    return [a,b,c,d]
def cgu_hash(text):
    data=text.encode()+b'\xff'
    v=[0x736f6d6570736575,0x646f72616e646f6d^0xee,0x6c7967656e657261,0x7465646279746573]
    stop=len(data)//8*8
    for offset in range(0,stop,8):
        value=int.from_bytes(data[offset:offset+8],'little')
        v[3]^=value;v=sip_round(v);v[0]^=value
    value=((len(data)&255)<<56)|int.from_bytes(data[stop:],'little')
    v[3]^=value;v=sip_round(v);v[0]^=value;v[2]^=0xee
    for _ in range(3):v=sip_round(v)
    low=v[0]^v[1]^v[2]^v[3];v[1]^=0xdd
    for _ in range(3):v=sip_round(v)
    value=low|((v[0]^v[1]^v[2]^v[3])<<64)
    result=''
    while value:value,rem=divmod(value,36);result=DIGITS[rem]+result
    return result.rjust(25,'0')

def stamp(path):
    s=path.stat();return dict(device=s.st_dev,inode=s.st_ino,bytes=s.st_size,mtime_ns=s.st_mtime_ns)
def sha(data):return hashlib.sha256(data).hexdigest()

def symbols(path):
    before=stamp(path)
    with path.open('rb') as stream:
        header=stream.read(32)
        magic,cpu,subtype,filetype,ncmds,sizeofcmds,flags,reserved=struct.unpack('<8I',header)
        if magic!=0xfeedfacf or filetype!=1:raise RuntimeError('not a little-endian Mach-O64 object')
        commands=stream.read(sizeofcmds);cursor=0;sections={};section_index=0;sym=None
        for _ in range(ncmds):
            cmd,size=struct.unpack_from('<II',commands,cursor)
            if cmd==2:sym=struct.unpack_from('<4I',commands,cursor+8)
            if cmd==0x19:
                nsects=struct.unpack_from('<I',commands,cursor+64)[0]
                for index in range(nsects):
                    item=struct.unpack_from('<16s16sQQ8I',commands,cursor+72+80*index)
                    section_index+=1
                    sections[section_index]=dict(name=item[0].rstrip(b'\0').decode(),segment=item[1].rstrip(b'\0').decode(),address=item[2],bytes=item[3])
            cursor+=size
        if sym is None:raise RuntimeError('object has no symbol table')
        offset,count,string_offset,string_size=sym
        stream.seek(offset);table=stream.read(16*count)
        stream.seek(string_offset);strings=stream.read(string_size)
    functions={}
    for index in range(count):
        name_index,kind,section,desc,address=struct.unpack_from('<IBBHQ',table,index*16)
        if kind&0xe0 or kind&0x0e!=0x0e or sections[section]['name']!='__text':continue
        end=strings.find(b'\0',name_index)
        name=strings[name_index:end].decode('ascii')
        functions.setdefault(address,[]).append(dict(name=name,external=bool(kind&1)))
    if stamp(path)!=before:raise RuntimeError('object changed during analysis')
    text=next((s for s in sections.values() if s['name']=='__text'),dict(address=0,bytes=0))
    addresses=sorted(functions)
    extents=[(addresses[i+1] if i+1<len(addresses) else text['address']+text['bytes'])-address for i,address in enumerate(addresses)]
    rows=[row for aliases in functions.values() for row in aliases]
    return dict(path=str(path),stamp=before,read_bytes=len(header)+len(commands)+len(table)+len(strings),
        header_commands_sha256=sha(header+commands),symbols_sha256=sha(table),strings_sha256=sha(strings),
        text_bytes=text['bytes'],distinct_function_addresses=len(functions),
        external_function_addresses=sum(any(r['external'] for r in group) for group in functions.values()),
        external_drop_function_addresses=sum(any(r['external'] and 'drop_in_place' in r['name'] for r in group) for group in functions.values()),
        largest_extent=max(extents,default=0),top10_extents=sum(sorted(extents,reverse=True)[:10]),
        symbol_sample=[r['name'] for r in rows if 'drop_in_place' in r['name']][:3]),rows

started=time.time()
with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('a') as lock:
    admission=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),cwd=str(Path.cwd()),argv=[str(Path(__file__).resolve())],started_at=started,wait_limit_seconds=600,lock='/Users/danluu/dev/rust-interp/.work/benchmark.lock')
    (OUT/'attempt02-admission.json').write_text(json.dumps(admission,indent=2)+'\n')
    deadline=time.monotonic()+600
    while True:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if time.monotonic()>=deadline:
                admission.update(status='timed-out',finished_at=time.time())
                (OUT/'attempt02-admission.json').write_text(json.dumps(admission,indent=2)+'\n')
                raise
            time.sleep(.1)
    admission.update(status='admitted',admitted_at=time.time())
    (OUT/'attempt02-admission.json').write_text(json.dumps(admission,indent=2)+'\n')
    summary_bytes=(RUN/'summary.json').read_bytes()
    summary=json.loads(summary_bytes)
    report=dict(schema_version=1,pid=os.getpid(),parent_pid=os.getppid(),started_at=started,
        source='retained completed screen artifacts only; no compiler, test, or benchmark run',
        summary_sha256=sha(summary_bytes),script_sha256=sha(Path(__file__).read_bytes()),arms={})
    newest={}
    for arm,workspace in summary['cache_workspaces'].items():
        sessions=[p for p in (Path(workspace)/'target/debug/incremental').glob('nu_protocol-*/s-*') if p.is_dir()]
        newest[arm]=max(sessions,key=lambda p:p.stat().st_mtime_ns)
        reports=[]
        for session in sorted(sessions):
            products=session/'work-products.bin';data=products.read_bytes()
            names={v.decode() for v in re.findall(rb'[0-9a-z]{25}(?=\.o)',data)}
            objects={p.stem:stamp(p) for p in session.glob('*.o')}
            if names!=set(objects):raise RuntimeError('work products do not exactly name saved objects')
            reports.append(dict(path=str(session),work_products_sha256=sha(data),work_products_stamp=stamp(products),
                names=sorted(names),object_bytes=sum(x['bytes'] for x in objects.values()),
                tiny808=sum(x['bytes']==808 for x in objects.values()),objects=objects))
        report['arms'][arm]=reports
    small=min(newest['baseline'].glob('*.o'),key=lambda p:p.stat().st_size)
    small_report,rows=symbols(small)
    encodings={m for row in rows for m in re.findall(r'Cs([0-9a-zA-Z]*)_11nu_protocol',row['name'])}
    if len(encodings)!=1:raise RuntimeError('ambiguous stable crate ID')
    encoded=encodings.pop();number=0
    for char in encoded:number=number*62+DIGITS.index(char)
    number+=2 if encoded else 1
    expected={cgu_hash(f'nu_protocol.{number:08x}-stable-cgu-v1.256-{index}'):index for index in range(256)}
    report.update(stable_crate_id_encoding=encoded,stable_crate_id_hex=f'{number:016x}',id_source=small_report,
        expected_bucket_names={name:index for name,index in sorted(expected.items())})
    for arm,items in report['arms'].items():
        for item in items:item['fixed_bucket_matches']=len(set(item['names'])&set(expected))
    heavy=sorted(newest['candidate'].glob('*.o'),key=lambda p:p.stat().st_size,reverse=True)[:2]
    report['largest_candidate_objects']=[symbols(path)[0] for path in heavy]
    report['finished_at']=time.time()
    (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(stable_id=report['stable_crate_id_hex'],arms={arm:[dict(fixed_matches=i['fixed_bucket_matches'],objects=len(i['names']),bytes=i['object_bytes'],empty808=i['tiny808']) for i in items] for arm,items in report['arms'].items()},heavy=report['largest_candidate_objects']),indent=2))

admission.update(status='finished',finished_at=time.time(),returncode=0)
(OUT/'attempt02-admission.json').write_text(json.dumps(admission,indent=2)+'\n')
