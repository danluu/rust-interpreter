import gzip,hashlib,io,json,os,sys,tarfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import write_json
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
INSPECTION=ROOT/'.work/worker-screen-target-inspection-01'
RETIREMENT=ROOT/'.work/worker-screen-target-retirement-01'
OUTPUT=ROOT/'results/worker-screen-target-retirement-01'
WORK=ROOT/'.work/worker-screen-target-retirement-archive-01'
WORK.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_bytes())
record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,builds=0,benchmarks=0,deletions=0)
write_json(WORK/'summary.json',record)
try:
 with LOCK.open('r+') as lock:
  acquire_lock(lock,600);record.update(status='archiving',lock_acquired_at=time.time());write_json(WORK/'summary.json',record)
  inspection=read(INSPECTION/'summary.json');retirement=read(RETIREMENT/'summary.json')
  assert sha((INSPECTION/'summary.json').read_bytes())==retirement['inspection_sha256']=='557581c2b185a938640a66cad97ca41afe5c6f249c488ebcfca5bdd84f61780d'
  assert inspection['status']==retirement['status']=='passed' and len(retirement['deleted'])==3
  assert retirement['retained_proofs_and_copies_preserved'] and retirement['public_inputs_preserved']
  assert all(not Path(x['path']).exists() and not Path(x['path']).is_symlink() for x in retirement['deleted'])
  for name,h in inspection['proof_files'].items():assert sha((INSPECTION/name).read_bytes())==h
  copies=read(INSPECTION/'retained-target-inputs.json')
  for item in copies.values():
   p=Path(item['path']);assert p.is_relative_to(INSPECTION/'retained-target-inputs') and not p.is_symlink()
   b=p.read_bytes();assert sha(b)==item['sha256'] and len(b)==item['bytes']
  screen=ROOT/'results/strict-warm-frontend-worker-screen-01';screen_summary=read(screen/'summary.json')
  assert sha((screen/screen_summary['archive']['path']).read_bytes())==retirement['archive_sha256']==screen_summary['archive']['sha256']
  paths={Path(__file__),ROOT/'.work/inspect-worker-screen-targets-01.py',ROOT/'.work/retire-worker-screen-targets-01.py'}
  directories=[INSPECTION,RETIREMENT,*[ROOT/'.work/experiments'/name for name in ['worker-screen-target-inspection-supervisor-01','worker-screen-target-retirement-supervisor-01']]]
  for directory in directories:
   for p in directory.rglob('*'):
    assert not p.is_symlink()
    if p.is_file():paths.add(p)
  for name in ['worker-screen-target-inspection-supervisor-01','worker-screen-target-retirement-supervisor-01']:
   s=read(ROOT/'.work/experiments'/name/'status.json');assert s['status']=='finished' and s['returncode']==0
  files={str(p.relative_to(ROOT)):p.read_bytes() for p in sorted(paths)}
  manifest={name:dict(bytes=len(data),sha256=sha(data)) for name,data in files.items()}
  assert not OUTPUT.exists();OUTPUT.mkdir()
  with (OUTPUT/'evidence.tar.gz').open('xb') as stream:
   with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as archive:
     for name,data in files.items():
      info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o444;info.mtime=0
      archive.addfile(info,io.BytesIO(data))
  verified=set()
  with tarfile.open(OUTPUT/'evidence.tar.gz','r:gz') as archive:
   for member in archive:
    assert member.isfile() and member.name not in verified and member.name in manifest
    data=archive.extractfile(member).read();assert len(data)==manifest[member.name]['bytes'] and sha(data)==manifest[member.name]['sha256']
    verified.add(member.name)
  assert verified==set(manifest)
  summary=dict(schema_version=1,status='passed',kind='completed-worker-screen-target-retirement',
   inspection_pid=inspection['pid'],retirement_pid=retirement['pid'],archive_pid=os.getpid(),
   inspection_sha256=retirement['inspection_sha256'],retirement_sha256=sha((RETIREMENT/'summary.json').read_bytes()),
   targets=retirement['deleted'],entries_verified=retirement['inventory_entries_verified'],
   retained_proof_files=retirement['retained_files_verified'],retained_target_input_paths=len(copies),
   retained_target_input_content_files=len({x['sha256'] for x in copies.values()}),
   allocated_bytes_before=inspection['allocated_bytes_unique_all_targets'],
   free_bytes_before=retirement['free_bytes_before'],free_bytes_after=retirement['free_bytes_after'],
   observed_free_byte_change=retirement['free_bytes_after']-retirement['free_bytes_before'],
   allocation_limit='Observed global filesystem difference can include concurrent unrelated allocation; st_blocks does not expose APFS shared extents.',
   inspection_and_fresh_retirement_quiescence=True,raw_global_process_tables_retained=False,
   screen_evidence=dict(path=str(screen),archive_sha256=retirement['archive_sha256'],commands=27,original_tests=14),
   source_restoration_and_all_retained_proofs_preserved=True,cache_metadata_and_program_artifacts_preserved=True,
   publication_guard_preserved=True,process_controls=0,compiler_builds=0,benchmarks=0,performance_claim=False,
   archive=dict(path='evidence.tar.gz',sha256=sha((OUTPUT/'evidence.tar.gz').read_bytes()),bytes=(OUTPUT/'evidence.tar.gz').stat().st_size,members=len(manifest),all_member_hashes_verified=True,gzip_mtime=0),
   packager_sha256=sha(Path(__file__).read_bytes()),finished_at=time.time())
  write_json(OUTPUT/'manifest.json',manifest);write_json(OUTPUT/'summary.json',summary)
  (OUTPUT/'README.md').write_text('# Completed worker-screen target retirement\n\n'
   'Only the three reviewed inner Cargo target directories from the completed frontend-worker screen were retired. '
   'Cache namespaces, workspace metadata, program bytecode/catalogs/calls, source, all 27 command records, '
   'all 14 test controls, 21 artifact snapshots and the saved screen assessment remain intact.\n\n'
   f"Fresh retirement checks reconciled {summary['entries_verified']:,} inventory entries, {summary['retained_proof_files']} retained proof files and "
   f"{summary['retained_target_input_paths']:,} original-to-copy bindings for bytecode, generated sources and metadata. "
   'Public compiler/tool/std dependencies were disjoint by path and inode; live publication guards passed before and after. '
   'Fresh process and lsof checks found no matching path, inode, cwd or handle users. Global tables were kept only in memory; '
   'the receipts retain hashes, counts and matching records. No process was controlled.\n\n'
   f"Allocated blocks by unique inode totaled {summary['allocated_bytes_before']/1024**3:.3f} GiB. "
   f"Observed free space rose from {summary['free_bytes_before']:,} to {summary['free_bytes_after']:,} bytes "
   f"({summary['observed_free_byte_change']/1024**3:.3f} GiB). APFS shared extents and unrelated allocations limit direct attribution.\n\n"
   'The archive contains exact inspection/retirement sources, receipts, inventories, guard proofs and retained target-input copies. '
   'Every archive member was read back and hash checked. Compiler binaries and retired native cache artifacts are excluded. '
   'The separate [worker screen assessment](../strict-warm-frontend-worker-screen-01/assessment.md) retains the performance result; '
   'this cleanup makes no performance claim.\n')
  record.update(status='passed',finished_at=time.time(),output=str(OUTPUT),archive=summary['archive']);write_json(WORK/'summary.json',record)
  print(json.dumps(record))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());write_json(WORK/'summary.json',record);raise
