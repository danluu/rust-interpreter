import collections,gzip,hashlib,json,os,shutil,stat,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json
from qualified_public_tools import WORKER_BUILD_POLICY,validate_public_tool,validate_input_guard,validate_live_inputs
WORK=ROOT/'.work/worker-screen-target-inspection-01'
RAW=ROOT/'.work/strict-warm-frontend-worker-screen-01'
RESULT=ROOT/'results/strict-warm-frontend-worker-screen-01'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
WORK.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
def digest(path):return sha(Path(path).read_bytes())
def write(name,value):write_json(WORK/name,value)
def ordinary(path):
 assert path.resolve(strict=True)==path and not path.is_symlink(),str(path)
def walk(base,exclude=()):
 for directory,dirs,names in os.walk(base,followlinks=False):
  dirs[:]=sorted(n for n in dirs if Path(directory)/n not in exclude)
  for name in sorted(names):yield Path(directory)/name
retained={}
def retain(path):
 path=Path(path);ordinary(path);assert path.is_file(),str(path)
 data=path.read_bytes();retained[str(path)]=dict(sha256=sha(data),bytes=len(data));return data
record=dict(schema_version=1,status='waiting',owner=str(ROOT),pid=os.getpid(),parent_pid=os.getppid(),
 started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,deleted=[],workloads_executed=0,
 scope='inspection only: three completed worker-screen inner Cargo targets')
write('summary.json',record)
try:
 with LOCK.open('r+') as lock:
  acquire_lock(lock,600)
  record.update(status='inspecting',lock_acquired_at=time.time(),free_bytes_before=shutil.disk_usage(ROOT).free)
  record['revision']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
  write('summary.json',record)
  source_paths={Path(__file__),ROOT/'scripts/supervise_experiment.py'}|{Path(m.__file__) for m in tuple(sys.modules.values()) if getattr(m,'__file__',None) and str(m.__file__).startswith(str(ROOT/'scripts')+'/')}
  for path in source_paths:
   data=retain(path);dest=WORK/'sources'/path.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  completed=json.loads(retain(RAW/'summary.json'));plan=json.loads(retain(RAW/'plan.json'));rows=json.loads(retain(RAW/'records.json'))
  assessed=json.loads(retain(RESULT/'summary.json'))
  assert completed['status']==assessed['status']=='passed' and completed['source_restored'] and assessed['source_restoration_rechecked']
  assert len(rows)==completed['commands']==assessed['commands']==27
  assert completed['plan_sha256']==assessed['plan_sha256']==digest(RAW/'plan.json')
  assert completed['records_sha256']==assessed['records_sha256']==digest(RAW/'records.json')
  archive=RESULT/assessed['archive']['path'];assert sha(retain(archive))==assessed['archive']['sha256']
  assert assessed['archive']['all_member_hashes_verified'] is True
  supervisors=[ROOT/'.work/experiments/strict-warm-frontend-worker-screen-supervisor-01',ROOT/'.work/experiments/worker-screen-assessment-supervisor-01']
  completion={}
  for directory in supervisors:
   value=json.loads(retain(directory/'status.json'));assert value['status']=='finished' and value['returncode']==0
   completion[str(directory)]=value
   for path in walk(directory):retain(path)
  for path in walk(ROOT/'.work/worker-screen-assessment-01'):retain(path)
  for row in rows:
   receipt=json.loads(retain(RAW/'receipts'/f"{row['index']}-{row['mode']}.json"))
   assert receipt['status']=='finished' and receipt['pid']==row['pid'] and receipt['returncode']==row['returncode']
  source=Path(plan['source'])/plan['case']['file'];assert sha(retain(source))==plan['original_source_sha256']
  retain(Path(plan['source'])/'.rust-interp-owned.json')
  cache=RAW/'caches';ordinary(cache)
  assert {p.name for p in cache.iterdir()}=={'baseline','candidate','duplicate'}
  namespace='rust-interp-'+sha(str(ROOT).encode())[:24]
  candidates={}
  for arm,workspace in completed['cache_workspaces'].items():
   assert arm in ('baseline','candidate','duplicate')
   parent=cache/arm;ordinary(parent);assert {p.name for p in parent.iterdir()}=={namespace}
   marker=parent/namespace/'.rust-interp-cache.json'
   assert json.loads(retain(marker))==dict(schema_version=1,kind='rust-interp-cache',owner=str(ROOT))
   workspace=Path(workspace);ordinary(workspace)
   assert workspace.is_relative_to(parent/namespace/'workspaces')
   target=workspace/'target';ordinary(target);assert target.is_dir()
   candidates[arm]=target
  selected=list(candidates.values())
  assert len(selected)==3 and len(set(selected))==3
  for path in walk(RAW,exclude=(cache,)):retain(path)
  for path in walk(RESULT):retain(path)
  for path in walk(cache,exclude=tuple(selected)):retain(path)
  artifact_count=0
  for item in assessed['artifact_inventory']:
   path=ROOT/item['path'];assert path.is_relative_to(RAW/'artifacts')
   data=retain(path);assert sha(data)==item['sha256'] and len(data)==item['bytes'];artifact_count+=1
  key=plan['tools']['baseline'];assert set(plan['tools'].values())=={key}
  tool=ROOT/'.work/interpreter-tools'/key
  public=validate_public_tool(tool,key,lambda path:retain(path),qualification_policy=WORKER_BUILD_POLICY)
  validate_input_guard(public,plan['public_input_guard'])
  guard=validate_live_inputs(public,rehash=False);write('public-input-guard.json',guard)
  for name in ('publication.json','publication-guard.json','ready.json','capabilities.json','source.json'):retain(tool/name)
  dependencies={str(path) for path in public['payload_paths']}|set(public['input_records'])|set(public['searches'])
  for dependency in dependencies|set(retained):
   path=Path(dependency)
   assert not any(path==target or path.is_relative_to(target) for target in selected),('retained dependency enters target',dependency)
   if path.exists():assert not any(path.resolve().is_relative_to(target) for target in selected),('retained dependency alias enters target',dependency)
  inventory=[];inodes=set();inode_rows=collections.defaultdict(list);copies={};allocations={}
  for arm,target in candidates.items():
   entries=[target]
   for directory,dirs,names in os.walk(target,followlinks=False):
    for name in sorted(dirs+names):entries.append(Path(directory)/name)
   for path in entries:
    s=path.lstat();kind='directory' if stat.S_ISDIR(s.st_mode) else 'file' if stat.S_ISREG(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'special'
    assert kind!='special',str(path)
    row=dict(root=str(target),path=str(path.relative_to(target)),arm=arm,kind=kind,device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,blocks=s.st_blocks,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink,link=os.readlink(path) if kind=='symlink' else None)
    inventory.append(row);inodes.add((s.st_dev,s.st_ino));inode_rows[(s.st_dev,s.st_ino)].append(row)
    if kind=='file' and (path.suffix in ('.rbc','.json','.jsonl','.rs','.toml','.lock','.txt','.d') or 'history' in path.name or path.name in ('CACHEDIR.TAG','.cargo-lock')):
     data=path.read_bytes();h=sha(data);destination=WORK/'retained-target-inputs'/h
     destination.parent.mkdir(exist_ok=True)
     if not destination.exists():destination.write_bytes(data)
     assert digest(destination)==h
     copies[str(path)]=dict(path=str(destination),sha256=h,bytes=len(data),role='bytecode' if '.rbc' in path.name else 'generated source, history or target metadata')
   armrows=[r for r in inventory if r['arm']==arm]
   unique={(r['device'],r['inode']):r for r in armrows}
   allocations[arm]=dict(path=str(target),entries=len(armrows),regular_files=sum(r['kind']=='file' for r in armrows),symlinks=sum(r['kind']=='symlink' for r in armrows),logical_bytes=sum(r['bytes'] for r in armrows if r['kind']=='file'),allocated_bytes_unique_inodes=sum(r['blocks']*512 for r in unique.values()),root_identity=armrows[0])
  dependency_inode_matches=[]
  for dependency in dependencies|set(retained):
   path=Path(dependency)
   if path.exists():
    s=path.stat()
    if (s.st_dev,s.st_ino) in inodes:dependency_inode_matches.append(dependency)
  assert not dependency_inode_matches,'retained input shares a target inode'
  for original,item in copies.items():
   assert digest(Path(original))==digest(Path(item['path']))==item['sha256']
  inventory_bytes=''.join(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n' for row in inventory).encode()
  packed=gzip.compress(inventory_bytes,mtime=0);(WORK/'inventory.jsonl.gz').write_bytes(packed)
  write('retained-target-inputs.json',copies)
  write('publication-dependencies.json',dict(tool_key=key,files=public['input_records'],searches=public['searches'],payload_paths=list(map(str,public['payload_paths'])),live_guard=str(WORK/'public-input-guard.json')))
  quiescence={}
  for label,argv in [('processes',['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,tty=,command=']),('handles',['/usr/sbin/lsof','-nP','-FpcftDin'])]:
   child,out,err=capture(argv,cwd=ROOT,env=dict(os.environ),receipt_path=WORK/(label+'-process.json'),receipt={})
   found=[]
   if label=='processes':
    found=[line for line in out.splitlines() if any(str(path) in line for path in selected)]
   else:
    process={};entry={}
    def finish():
     name=entry.get('n','')
     try:inode=(int(entry.get('D',''),16),int(entry.get('i','')))
     except ValueError:inode=None
     path_match=any(name==str(path) or name.startswith(str(path)+'/') for path in selected)
     if inode in inodes or path_match:found.append(dict(process=process.copy(),file=entry.copy(),inode_match=inode in inodes,path_match=path_match))
    for line in out.splitlines():
     if not line:continue
     k,v=line[0],line[1:]
     if k=='p':finish();process={'pid':v};entry={}
     elif k=='c':process['command']=v
     elif k=='f':finish();entry={'fd':v}
     else:entry[k]=v
    finish()
   quiescence[label]=dict(pid=child.pid,returncode=child.returncode,stdout_sha256=sha(out.encode()),stderr_sha256=sha(err.encode()),stdout_lines=len(out.splitlines()),stderr_lines=len(err.splitlines()),matches=found,raw_output_retained=False)
   write('quiescence.json',quiescence)
   assert child.returncode==0 and not err.strip(),label+' inspection incomplete'
   assert not found,label+' has candidate users'
  # Re-stat every inventoried entry after handle inspection; no candidate was modified.
  for row in inventory:
   path=Path(row['root'])/row['path'];s=path.lstat()
   assert (s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_blocks,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink)==tuple(row[k] for k in ['device','inode','mode','bytes','blocks','mtime_ns','ctime_ns','nlink']),str(path)
  for path,proof in retained.items():assert digest(Path(path))==proof['sha256'],path
  validate_live_inputs(public,rehash=False)
  write('retained-proof-manifest.json',retained)
  unique={key:values[0] for key,values in inode_rows.items()}
  external_links=[dict(device=dev,inode=ino,observed_paths=len(values),nlink=values[0]['nlink']) for (dev,ino),values in inode_rows.items() if values[0]['kind']=='file' and values[0]['nlink']>len(values)]
  write('external-hardlinks.json',external_links)
  record.update(status='passed',finished_at=time.time(),candidates=allocations,inventory_entries=len(inventory),
   inventory_sha256=sha(packed),inventory_bytes=len(packed),retained_proof_manifest_sha256=digest(WORK/'retained-proof-manifest.json'),
   retained_files=len(retained),retained_target_inputs=len(copies),retained_target_input_bytes=sum(x['bytes'] for x in copies.values()),
   publication_dependencies=len(dependencies),dependency_inode_matches=dependency_inode_matches,quiescence=quiescence,
   no_users_proved=True,all_target_entries_unchanged=True,retained_inputs_unchanged=True,completion=completion,
   artifacts_preserved=artifact_count,allocated_bytes_unique_all_targets=sum(row['blocks']*512 for row in unique.values()),
   external_hardlink_inodes=len(external_links),allocation_limit='st_blocks by unique inode; APFS shared extents can make actual reclaimed space smaller',
   archive_sha256=assessed['archive']['sha256'],free_bytes_after=shutil.disk_usage(ROOT).free,
   retirement_requires='fresh canonical admission, exact inventory/retained-proof revalidation and fresh path/inode/handle/cwd checks; no deletion authorized by this inspection')
  record['proof_files']={name:digest(WORK/name) for name in ['inventory.jsonl.gz','retained-proof-manifest.json','retained-target-inputs.json','publication-dependencies.json','public-input-guard.json','quiescence.json','external-hardlinks.json']}
  write('summary.json',record)
  print(json.dumps({k:record[k] for k in ['status','pid','inventory_entries','retained_files','retained_target_inputs','allocated_bytes_unique_all_targets','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());write('summary.json',record);raise
