"""Retire only three reviewed completed-screen targets after fresh checks.

This file is prepared for root review. It must not be launched before the
explicit retirement admission; it performs no process controls.
"""
import gzip,hashlib,json,os,shutil,stat,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,write_json
from qualified_public_tools import WORKER_BUILD_POLICY,validate_public_tool,validate_input_guard,validate_live_inputs
PROOF=ROOT/'.work/worker-screen-target-inspection-01'
WORK=ROOT/'.work/worker-screen-target-retirement-01'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
KEY='b8a99895aeff8b6b7f927d45f9865109040a589d4fad3de2c67852717f4178a9'
NAMESPACE='rust-interp-061a1db840c03ee05d177a5e'
RAW=ROOT/'.work/strict-warm-frontend-worker-screen-01'
SUFFIXES={'baseline':'bd5061af201414df97c37bb4','candidate':'baa3a845ce9ec787e0c8d581','duplicate':'c5ad85ab6321c5670fa3b011'}
TARGETS={arm:RAW/'caches'/arm/NAMESPACE/'workspaces'/KEY/suffix/'target' for arm,suffix in SUFFIXES.items()}
INSPECTION_SHA='557581c2b185a938640a66cad97ca41afe5c6f249c488ebcfca5bdd84f61780d'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def ordinary(path):assert path.resolve(strict=True)==path and not path.is_symlink(),str(path)
def save():write_json(WORK/'summary.json',record)
def entries(target):
 result=[target]
 for directory,dirs,names in os.walk(target,followlinks=False):
  result.extend(Path(directory)/name for name in sorted(dirs+names))
 return result
def entry_stat(path):
 s=path.lstat()
 return dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,blocks=s.st_blocks,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink,link=os.readlink(path) if stat.S_ISLNK(s.st_mode) else None)
WORK.mkdir(exist_ok=False)
record=dict(schema_version=1,status='waiting',owner=str(ROOT),pid=os.getpid(),parent_pid=os.getppid(),
 started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,deleted=[],builds=0,benchmarks=0,
 scope='only the three exact reviewed inner Cargo targets',script_sha256=sha(Path(__file__)))
save()
try:
 with LOCK.open('r+') as lock:
  acquire_lock(lock,600)
  record.update(status='revalidating',lock_acquired_at=time.time(),free_bytes_before=shutil.disk_usage(ROOT).free);save()
  assert sha(PROOF/'summary.json')==INSPECTION_SHA
  inspection=json.loads((PROOF/'summary.json').read_bytes())
  assert inspection['status']=='passed' and inspection['no_users_proved'] and inspection['deleted']==[]
  assert inspection['inventory_entries']==46584 and inspection['external_hardlink_inodes']==0
  assert {arm:row['path'] for arm,row in inspection['candidates'].items()}=={arm:str(path) for arm,path in TARGETS.items()}
  for name,digest in inspection['proof_files'].items():assert sha(PROOF/name)==digest,name
  retained=json.loads((PROOF/'retained-proof-manifest.json').read_bytes())
  copies=json.loads((PROOF/'retained-target-inputs.json').read_bytes())
  assert len(retained)==704 and len(copies)==4812
  def retained_check():
   for name,item in retained.items():
    path=Path(name);ordinary(path)
    assert not any(path==target or path.is_relative_to(target) for target in TARGETS.values())
    assert sha(path)==item['sha256'] and path.stat().st_size==item['bytes'],name
   for item in copies.values():
    path=Path(item['path']);ordinary(path)
    assert path.is_relative_to(PROOF/'retained-target-inputs')
    assert sha(path)==item['sha256'] and path.stat().st_size==item['bytes'],str(path)
   for name,digest in inspection['proof_files'].items():assert sha(PROOF/name)==digest,name
   assert sha(PROOF/'summary.json')==INSPECTION_SHA
  retained_check()
  snapshots={target:{} for target in TARGETS.values()};inodes=set()
  with gzip.open(PROOF/'inventory.jsonl.gz','rt') as stream:
   for line in stream:
    row=json.loads(line);target=Path(row['root']);assert target in snapshots
    assert row['path'] not in snapshots[target]
    snapshots[target][row['path']]=row
    inodes.add((row['device'],row['inode']))
  def target_check(target):
   ordinary(target);assert target.is_dir()
   actual=entries(target);expected=snapshots[target]
   assert {str(path.relative_to(target)) for path in actual}==set(expected),'candidate entry set changed'
   for path in actual:
    row=expected[str(path.relative_to(target))]
    assert all(row[name]==value for name,value in entry_stat(path).items()),str(path)
  for arm,target in TARGETS.items():
   target_check(target)
   marker=RAW/'caches'/arm/NAMESPACE/'.rust-interp-cache.json'
   assert json.loads(marker.read_bytes())==dict(schema_version=1,kind='rust-interp-cache',owner=str(ROOT))
  for original,item in copies.items():
   path=Path(original);assert any(path.is_relative_to(target) for target in TARGETS.values())
   assert sha(path)==item['sha256'] and path.stat().st_size==item['bytes'],original
  tool=ROOT/'.work/interpreter-tools'/KEY
  public=validate_public_tool(tool,KEY,lambda path:path.read_bytes(),qualification_policy=WORKER_BUILD_POLICY)
  validate_input_guard(public,json.loads((PROOF/'public-input-guard.json').read_bytes()))
  guard=validate_live_inputs(public,rehash=False);write_json(WORK/'public-before.json',guard)
  dependencies={str(path) for path in public['payload_paths']}|set(public['input_records'])|set(public['searches'])|set(retained)|{item['path'] for item in copies.values()}
  for name in dependencies:
   path=Path(name)
   assert not any(path==target or path.is_relative_to(target) for target in TARGETS.values()),name
   if path.exists():
    assert not any(path.resolve().is_relative_to(target) for target in TARGETS.values()),name
    s=path.stat();assert (s.st_dev,s.st_ino) not in inodes,('retained inode alias',name)
  checks={}
  for label,argv in [('processes',['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,tty=,command=']),('handles',['/usr/sbin/lsof','-nP','-FpcftDin'])]:
   child,out,err=capture(argv,cwd=ROOT,env=dict(os.environ),receipt_path=WORK/(label+'-process.json'),receipt={})
   found=[]
   if label=='processes':found=[line for line in out.splitlines() if any(str(path) in line for path in TARGETS.values())]
   else:
    process={};entry={}
    def finish():
     name=entry.get('n','')
     try:inode=(int(entry.get('D',''),16),int(entry.get('i','')))
     except ValueError:inode=None
     path_match=any(name==str(path) or name.startswith(str(path)+'/') for path in TARGETS.values())
     if inode in inodes or path_match:found.append(dict(process=process.copy(),file=entry.copy(),inode_match=inode in inodes,path_match=path_match))
    for line in out.splitlines():
     if not line:continue
     k,v=line[0],line[1:]
     if k=='p':finish();process={'pid':v};entry={}
     elif k=='c':process['command']=v
     elif k=='f':finish();entry={'fd':v}
     else:entry[k]=v
    finish()
   checks[label]=dict(pid=child.pid,returncode=child.returncode,stdout_sha256=hashlib.sha256(out.encode()).hexdigest(),stderr_sha256=hashlib.sha256(err.encode()).hexdigest(),stdout_lines=len(out.splitlines()),stderr_lines=len(err.splitlines()),matches=found,raw_output_retained=False)
   write_json(WORK/'quiescence.json',checks)
   assert child.returncode==0 and not err.strip(),label+' inspection incomplete'
   assert not found,label+' has candidate users'
  # Preserve this exact script and its inspection/proof identities before mutation.
  (WORK/'retirement-script.py').write_bytes(Path(__file__).read_bytes())
  assert sha(WORK/'retirement-script.py')==record['script_sha256']
  record.update(status='retiring',quiescence=checks,quiescent_at=time.time(),
   inspection_sha256=INSPECTION_SHA,proof_files=inspection['proof_files'],target_paths={arm:str(path) for arm,path in TARGETS.items()},
   inventory_entries_verified=46584,retained_files_verified=len(retained),retained_target_inputs_verified=len(copies),
   archive_sha256=inspection['archive_sha256'],estimated_allocated_bytes=inspection['allocated_bytes_unique_all_targets'])
  save()
  for arm,target in TARGETS.items():
   # The inventory/ordinary-directory check is repeated immediately before each exact rmtree.
   target_check(target)
   assert target==RAW/'caches'/arm/NAMESPACE/'workspaces'/KEY/SUFFIXES[arm]/'target'
   shutil.rmtree(target)
   assert not target.exists() and not target.is_symlink()
   record['deleted'].append(dict(arm=arm,path=str(target),finished_at=time.time(),free_bytes=shutil.disk_usage(ROOT).free));save()
  retained_check()
  after=validate_live_inputs(public,rehash=False);assert after==guard
  write_json(WORK/'public-after.json',after)
  record.update(status='passed',finished_at=time.time(),free_bytes_after=shutil.disk_usage(ROOT).free,
   retained_proofs_and_copies_preserved=True,public_inputs_preserved=True,
   cache_namespaces_workspaces_and_program_artifacts_preserved=True,
   original_screen_and_assessment_preserved=True,source_restoration_preserved=True)
  save()
  print(json.dumps({k:record[k] for k in ['status','pid','deleted','free_bytes_before','free_bytes_after','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());save();raise
