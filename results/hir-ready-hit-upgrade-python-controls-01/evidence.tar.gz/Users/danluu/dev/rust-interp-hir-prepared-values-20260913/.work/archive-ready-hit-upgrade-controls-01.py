"""Retain exact completed continuation controls and zero-test launch failure."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time

ROOT=Path(__file__).resolve().parents[1]
READY=Path('/Users/danluu/dev/rust-interp-hir-ready-hit-upgrade-20260913')
sys.path.insert(0,str(ROOT/'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, workload_lock, sha, write


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    output=ROOT/'results/hir-ready-hit-upgrade-python-controls-01'
    receipt=ROOT/'.work/hir-ready-hit-upgrade-controls-archive-01.json'
    record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),
        lock=str(CANONICAL_LOCK),archive_script_sha256=sha(Path(__file__)),compiler_or_test_commands=0)
    write(receipt,record)
    with workload_lock(CANONICAL_LOCK,600):
        record.update(status='admitted',admitted_at=time.time());write(receipt,record)
        work=READY/'.work/hir-ready-hit-upgrade-controls-02'
        summary=json.loads((work/'summary.json').read_text())
        child=json.loads((work/'command/receipt.json').read_text())
        assert summary['status']=='passed' and child['status']=='finished' and child['returncode']==0
        assert sha(work/'command/receipt.json')==summary['command_receipt_sha256']
        assert child['supervisor_pid']==summary['pid']
        assert sha(work/'command/stdout')==child['stdout_sha256']
        assert sha(work/'command/stderr')==child['stderr_sha256']
        stderr=(work/'command/stderr').read_text()
        assert re.search(r'\nRan 14 tests in [0-9.]+s\n\nOK\n\Z',stderr),stderr
        assert len(re.findall(r'^test_.* \.\.\. ok$',stderr,re.M))==14
        sources={Path(path) for path in summary['inputs']}
        sources.update(work/name for name in ['runner.py','summary.json','command/receipt.json','command/stdout','command/stderr'])
        supervisors={}
        for number,exitcode in [(1,2),(2,0)]:
            sup=READY/'.work/experiments'/f'hir-ready-hit-upgrade-controls-supervisor-{number:02d}'
            row=json.loads((sup/'status.json').read_text());supervisors[str(number)]=row
            assert row['status']=='finished' and row['returncode']==exitcode
            assert sha(sup/'plan.json')==row['plan_sha256']
            assert sha(sup/'command.log')==row['log_sha256']
            sources.update(sup/name for name in ['status.json','plan.json','command.log','supervisor.log'])
            if number==1:
                log=(sup/'command.log').read_text()
                assert "can't open file" in log and 'No such file or directory' in log
                assert row['command']==['python3','.work/hir-ready-hit-upgrade-controls-01/runner.py']
                assert not (READY/'.work/hir-ready-hit-upgrade-controls-01').exists()
            else:
                assert row['child_pid']==summary['pid'] and row['supervisor_pid']==child['parent_pid']
        sources.update([Path(__file__),ROOT/'experiments/stable-cgu/owned_stage.py',ROOT/'scripts/supervise_experiment.py'])
        files={}
        for source in sorted(sources):
            assert source.is_file() and not source.is_symlink()
            data=source.read_bytes()
            if str(source) in summary['inputs']:assert digest(data)==summary['inputs'][str(source)]
            files[str(source).lstrip('/')]=dict(source=str(source),data=data)
        output.mkdir(parents=True,exist_ok=False)
        archive=output/'evidence.tar.gz'
        with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
            for name,item in sorted(files.items()):
                data=item['data'];info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(data))
        with tarfile.open(archive,'r:gz') as tar:
            members=tar.getmembers();assert len(members)==len(files)
            assert all(m.isfile() and m.name in files and tar.extractfile(m).read()==files[m.name]['data'] for m in members)
        for path,expected in summary['inputs'].items():assert sha(path)==expected
        manifest={name:dict(source=item['source'],bytes=len(item['data']),sha256=digest(item['data'])) for name,item in sorted(files.items())}
        write(output/'manifest.json',manifest)
        result=dict(status='Python controls passed; failed zero-test launcher retained',checkpoint='a5df182dbcda19511b1cc99665796291d2b07046',
            ready_hit_checkpoint='5cd6acd3f50912cec5fb29375b130afa70506703',tests_passed=14,tests_failed=0,
            test_summary=summary,failed_launcher=dict(supervisor=supervisors['1']['supervisor_pid'],child=supervisors['1']['child_pid'],returncode=2,tests_run=0,
                cause='Runner file did not exist after setup omitted parent-directory creation; no helper or tests started.'),
            successful_supervisor=supervisors['2']['supervisor_pid'],successful_child=child['pid'],
            archive=dict(path='evidence.tar.gz',sha256=sha(archive),bytes=archive.stat().st_size,members=len(files),all_member_hashes_verified=True),
            exact_input_count=len(summary['inputs']),inputs_unchanged=True,Rust_or_native_commands=0,performance_claim=False)
        write(output/'summary.json',result)
        record.update(status='passed',finished_at=time.time(),archive=result['archive'],source_inputs=len(summary['inputs']))
        write(receipt,record);write(output/'archive-receipt.json',record)
        print(json.dumps({key:record[key] for key in ['status','pid','admitted_at','finished_at','archive','source_inputs']}))


if __name__=='__main__':
    main()
