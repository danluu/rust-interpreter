from pathlib import Path
import importlib.util, os, sys, time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, workload_lock, run, sha, write, require
spec=importlib.util.spec_from_file_location('ready_hit_upgrade',ROOT/'experiments/hir-ready-hit-upgrade/upgrade.py')
u=importlib.util.module_from_spec(spec);sys.modules[spec.name]=u;spec.loader.exec_module(u)
WORK=Path(__file__).resolve().parent
frozen=u.inputs() | u.engine.old.frozen_plan()['inputs'] | {str(Path(__file__).resolve()):sha(Path(__file__))}
env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','LC_CTYPE','SYSTEMROOT']}
r=dict(status='waiting',started_at=time.time(),pid=os.getpid(),inputs=frozen)
write(WORK/'summary.json',r)
try:
    with workload_lock(CANONICAL_LOCK,600):
        r.update(status='running',admitted_at=time.time());write(WORK/'summary.json',r)
        require(all(sha(p)==h for p,h in frozen.items()),'test source changed before execution')
        run([sys.executable,'-m','unittest','discover','-s','tests','-p','test_hir_*upgrade.py','-v'],cwd=ROOT,env=env,out=WORK/'command',capacity_root=ROOT)
        require(all(sha(p)==h for p,h in frozen.items()),'test source changed')
        output=(WORK/'command/stderr').read_text()
        require('Ran 14 tests' in output and output.rstrip().endswith('OK'),'fourteen actual tests required')
        r.update(status='passed',finished_at=time.time(),command_receipt_sha256=sha(WORK/'command/receipt.json'))
        write(WORK/'summary.json',r)
except BaseException as e:
    r.update(status='failed',finished_at=time.time(),error=repr(e));write(WORK/'summary.json',r);raise
