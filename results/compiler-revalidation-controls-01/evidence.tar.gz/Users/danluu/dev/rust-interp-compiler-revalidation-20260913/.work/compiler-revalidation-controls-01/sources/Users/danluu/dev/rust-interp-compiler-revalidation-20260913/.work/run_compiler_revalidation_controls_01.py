#!/usr/bin/env python3
"""Run the 45 focused synthetic compiler-policy controls; no real compiler inputs."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

ROOT=Path('/Users/danluu/dev/rust-interp-compiler-revalidation-20260913')
HERE=ROOT/'tests'
PLAN=ROOT/'.work/compiler-revalidation-focused-tests-01.json'
WORK=ROOT/'.work/compiler-revalidation-controls-01'
FREEZE=ROOT/'.work/compiler-revalidation-controls-source-01/inputs.json'
FREEZE_SHA='e74ef036d931cf20f2a401eb491e9545a1f51b6a731953d421099aec8bc1f2d5'
OWNED=Path('/Users/danluu/dev/rust-interp-compiler-revalidation-20260913/experiments/stable-cgu/owned_stage.py')
OWNED_SHA='7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e'
ADMISSION=ROOT/'.work/compiler-revalidation-controls-admission-01.json'
PYTHON=Path('/opt/homebrew/bin/python3')
NAMES=['test_custom_compiler.CustomCompilerTests.test_changed_bytes_with_restored_size_mtime_and_permissions_are_rejected', 'test_custom_compiler.CustomCompilerTests.test_custom_selection_rejects_compiler_and_loader_overrides', 'test_custom_compiler.CustomCompilerTests.test_extra_files_writable_installations_and_symlinks_are_rejected', 'test_custom_compiler.CustomCompilerTests.test_imported_mono_help_is_bound_into_identity_and_cannot_be_relabelled', 'test_custom_compiler.CustomCompilerTests.test_macos_audit_accepts_dylib_self_identity_without_treating_it_as_a_load', 'test_custom_compiler.CustomCompilerTests.test_macos_audit_checks_support_tool_load_edges_and_executable_paths', 'test_custom_compiler.CustomCompilerTests.test_macos_audit_preserves_internal_library_and_rpath_checks', 'test_custom_compiler.CustomCompilerTests.test_macos_audit_rejects_live_paths_for_every_actual_load_kind', 'test_custom_compiler.CustomCompilerTests.test_owned_installation_hits_need_no_compiler_process_or_content_rehash', 'test_custom_compiler.CustomCompilerTests.test_partial_components_stage1_and_wrong_ownership_are_rejected', 'test_custom_compiler.CustomCompilerTests.test_recorded_help_proves_only_actual_options_and_legacy_keys_still_load', 'test_custom_compiler.CustomCompilerTests.test_revalidation_rejects_changed_selected_identity', 'test_custom_compiler.CustomCompilerTests.test_tool_association_rejects_missing_compiler_mismatched_compiler_and_binary_manifest', 'test_runtime_compiler.RuntimeCompilerTests.test_actual_loader_mismatch_preserves_incomplete_attempt', 'test_runtime_compiler.RuntimeCompilerTests.test_auxiliary_tool_has_its_own_executable_rpath_context', 'test_runtime_compiler.RuntimeCompilerTests.test_capacity_failure_during_copy_retains_bytes_and_starts_no_probe', 'test_runtime_compiler.RuntimeCompilerTests.test_changed_runtime_bytes_even_with_restored_size_mtime_are_rejected', 'test_runtime_compiler.RuntimeCompilerTests.test_component_collision_native_ambiguity_and_stage_claim_rejected', 'test_runtime_compiler.RuntimeCompilerTests.test_destination_corrupted_before_first_stamp_is_rejected_before_probes', 'test_runtime_compiler.RuntimeCompilerTests.test_executable_source_script_is_preserved_and_never_probed_as_native', 'test_runtime_compiler.RuntimeCompilerTests.test_final_root_sources_no_private_metadata_and_no_lookup_workload', 'test_runtime_compiler.RuntimeCompilerTests.test_forged_probe_options_wrong_owner_and_live_overrides_rejected', 'test_runtime_compiler.RuntimeCompilerTests.test_loader_rejects_external_missing_ambiguous_and_unknown_edges', 'test_runtime_compiler.RuntimeCompilerTests.test_output_mutation_during_probe_cannot_publish', 'test_runtime_compiler.RuntimeCompilerTests.test_probe_wrong_final_root_cannot_publish', 'test_runtime_compiler.RuntimeCompilerTests.test_source_extra_files_and_bad_hash_fail_before_installation', 'test_runtime_compiler.RuntimeCompilerTests.test_source_links_wrong_target_unlisted_link_and_omission_contents_rejected', 'test_std_mir_source_paths.StdSourcePathsTests.test_changed_runtime_at_final_revalidation_keeps_failure_without_readiness', 'test_std_mir_source_paths.StdSourcePathsTests.test_changed_source_same_size_mtime_and_restored_permissions_is_rejected', 'test_std_mir_source_paths.StdSourcePathsTests.test_configured_child_loader_and_identity_overrides_are_rejected', 'test_std_mir_source_paths.StdSourcePathsTests.test_conflicting_environment_is_rejected_instead_of_silently_cleared', 'test_std_mir_source_paths.StdSourcePathsTests.test_empty_duplicate_missing_and_escaping_inventories_fail', 'test_std_mir_source_paths.StdSourcePathsTests.test_empty_override_presence_cannot_suppress_required_mir_flags', 'test_std_mir_source_paths.StdSourcePathsTests.test_failed_native_preflight_and_build_keep_receipts_but_never_publish_ready', 'test_std_mir_source_paths.StdSourcePathsTests.test_final_runtime_revalidation_uses_runtime_policy', 'test_std_mir_source_paths.StdSourcePathsTests.test_included_cargo_configuration_is_rejected_before_any_child', 'test_std_mir_source_paths.StdSourcePathsTests.test_inherited_trim_or_rustflags_configuration_is_rejected', 'test_std_mir_source_paths.StdSourcePathsTests.test_missing_published_source_or_extra_sysroot_file_is_rejected', 'test_std_mir_source_paths.StdSourcePathsTests.test_old_unmapped_compiler_and_unreviewed_cargo_are_rejected', 'test_std_mir_source_paths.StdSourcePathsTests.test_preparation_publishes_complete_readonly_sources_and_retains_actual_receipts', 'test_std_mir_source_paths.StdSourcePathsTests.test_runtime_requires_exact_source_capability_before_children', 'test_std_mir_source_paths.StdSourcePathsTests.test_shared_preparation_is_new_immutable_identity_and_modes_load_same_bytes', 'test_std_mir_source_paths.StdSourcePathsTests.test_source_snippets_are_verified_without_rewriting_raw_diagnostics', 'test_std_mir_source_paths.StdSourcePathsTests.test_typed_prekey_recipe_preserves_flags_root_profile_features_and_two_jobs', 'test_std_mir_source_paths.StdSourcePathsTests.test_v1_default_dispatch_is_unchanged_and_v2_requires_explicit_selection']


def require(ok,message):
    if not ok:raise RuntimeError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ordinary(path):
    path=Path(path)
    require(path.is_absolute() and path.is_file() and not path.is_symlink() and path.resolve(strict=True)==path,
        'expected ordinary control input: '+str(path))
    return path


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--helper-sha',required=True)
    parser.add_argument('--admission-sha',required=True)
    args=parser.parse_args()
    require(sys.dont_write_bytecode and not sys.flags.optimize and Path.cwd()==ROOT,'fixed cwd and Python -B required')
    require(Path(__file__).resolve()==ROOT/'.work/run_compiler_revalidation_controls_01.py','fixed helper path required')
    require(sha(ordinary(__file__))==args.helper_sha and sha(ordinary(ADMISSION))==args.admission_sha,'reviewed helper/admission changed')
    require(sha(ordinary(FREEZE))==FREEZE_SHA and sha(ordinary(OWNED))==OWNED_SHA,'source freeze or owned supervisor changed')
    freeze=json.loads(FREEZE.read_bytes())
    require(freeze['controls']==45 and len(freeze['files'])==29 and freeze['base_commit']=='0e57b2b5b79f29c22e3a47d68959dcdc42dbc176' and set(freeze['files'])==set(freeze['snapshots']),
        'exact independent source closure required')
    require(str(Path(sys.executable).resolve(strict=True))==freeze['python']['resolved']
        and sha(sys.executable)==freeze['python']['sha256'] and PYTHON.resolve(strict=True)==Path(freeze['python']['resolved']),
        'exact retained Python identity required')
    sources=dict(freeze['files'])|{str(FREEZE):FREEZE_SHA,str(Path(__file__).resolve()):args.helper_sha,str(ADMISSION):args.admission_sha}
    for path,snapshot in freeze['snapshots'].items():sources[snapshot]=freeze['files'][path]
    def guard():
        for path,expected in sources.items():require(sha(ordinary(path))==expected,'frozen control input changed: '+path)
        require(sha(sys.executable)==freeze['python']['sha256'],'Python changed')
        require(sorted(str(p.relative_to(ROOT)) for directory in [ROOT/'scripts',ROOT/'tests']
            for p in directory.glob('*.py'))==freeze['local_module_membership'],'local Python module membership changed')
    guard()
    spec=importlib.util.spec_from_file_location('compiler_revalidation_controls_owned',OWNED)
    owned=importlib.util.module_from_spec(spec);sys.modules[spec.name]=owned;spec.loader.exec_module(owned)
    WORK.mkdir(exist_ok=False);(WORK/'tmp').mkdir()
    record=dict(schema_version=1,status='waiting',owner=str(ROOT),pid=os.getpid(),parent_pid=os.getppid(),
        started_at=time.time(),helper_sha256=args.helper_sha,admission_sha256=args.admission_sha,source_freeze_sha256=FREEZE_SHA,
        canonical_lock=str(owned.CANONICAL_LOCK),wait_seconds=600,python=freeze['python'],
        compiler_commands=0,exporter_execution=False,benchmark=False,real_archive_reads=0,real_compiler_input_reads=0,
        base_commit=freeze['base_commit'],source_patch_sha256=freeze['source_patch_sha256'])
    owned.write(WORK/'summary.json',record)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK,600):
            record.update(status='running',admitted_at=time.time(),free_bytes_before=owned.disk(ROOT));owned.write(WORK/'summary.json',record)
            guard()
            plan=json.loads(PLAN.read_bytes())
            require(sha(PLAN)==freeze['test_plan_sha256'] and plan['required_tests']==NAMES
                and plan['expected_tests']==45 and plan['expected_skips']==0
                and plan['cwd']==str(HERE) and plan['floor_gib']==8 and plan['wait_seconds']==600,
                'reviewed focused test plan changed')
            names=[]
            for module in ['test_custom_compiler','test_runtime_compiler','test_std_mir_source_paths']:
                tree=ast.parse((HERE/(module+'.py')).read_bytes())
                names.extend(module+'.'+cls.name+'.'+node.name for cls in tree.body if isinstance(cls,ast.ClassDef)
                    for node in cls.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_'))
            require(sorted(names)==NAMES,'reviewed 45 test definitions differ')
            snapshots={}
            for path,expected in sorted(sources.items()):
                owned.disk(ROOT)
                raw=Path(path).read_bytes();require(hashlib.sha256(raw).hexdigest()==expected,'input changed while copying')
                dest=WORK/'sources'/path.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True)
                with dest.open('xb') as output:output.write(raw)
                snapshots[path]=dict(path=str(dest),sha256=expected,bytes=len(raw))
            env=dict(PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',HOME='/Users/danluu',
                TMPDIR=str(WORK/'tmp')+'/',LANG='C',LC_ALL='C',TZ='UTC',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
            command=[str(PYTHON),'-B','-m','unittest','-v','test_custom_compiler','test_runtime_compiler','test_std_mir_source_paths']
            require(command==plan['command'] and env==plan['environment'],'exact command/environment differs')
            record.update(sources=sources,snapshots=snapshots,required_tests=NAMES,environment=env,command=command,command_cwd=str(HERE))
            owned.write(WORK/'summary.json',record)
            try:
                child=owned.run(command,cwd=HERE,env=env,out=WORK/'command',capacity_root=ROOT)
            finally:
                if (WORK/'command/receipt.json').exists():record['command_receipt_sha256']=sha(WORK/'command/receipt.json')
                guard()
                for row in snapshots.values():require(sha(ordinary(row['path']))==row['sha256'],'retained control source changed')
                record['all_inputs_unchanged']=True;owned.write(WORK/'summary.json',record)
            require(not (WORK/'command/stdout').read_bytes(),'unexpected synthetic-control stdout')
            text=(WORK/'command/stderr').read_text()
            actual=re.findall(r'^test_[^\n]* \((test_(?:custom_compiler|runtime_compiler|std_mir_source_paths)\.[^)]+)\) \.\.\. ok$',text,re.M)
            require(sorted(actual)==NAMES and len(actual)==45 and re.search(r'^Ran 45 tests in [0-9.]+s$',text,re.M)
                and text.rstrip().endswith('OK') and 'skipped' not in text,'exact 45 passing unfiltered controls required')
            record.update(status='passed',finished_at=time.time(),free_bytes_after=owned.disk(ROOT),actual_tests=actual,
                source_files=29,retained_inputs=len(sources),production_policy_modules_imported_by_tests=True,
                synthetic_installations_exercised=True,real_compiler_or_sysroot_inspected=False)
            owned.write(WORK/'summary.json',record)
    except BaseException as error:
        record.update(status='failed',error=repr(error),finished_at=time.time());owned.write(WORK/'summary.json',record);raise


if __name__=='__main__':main()
