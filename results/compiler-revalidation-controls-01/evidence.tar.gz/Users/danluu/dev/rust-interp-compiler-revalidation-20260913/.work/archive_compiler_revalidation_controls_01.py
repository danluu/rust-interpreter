#!/usr/bin/env python3
"""Retain completed compiler-policy controls using the existing tar route."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-compiler-revalidation-20260913')
RAW = ROOT / '.work/compiler-revalidation-controls-01'
SUPERVISOR = ROOT / '.work/experiments/compiler-revalidation-controls-supervisor-01'
LAUNCH = ROOT / '.work/compiler-revalidation-controls-launch-01.json'
OUT = ROOT / 'results/compiler-revalidation-controls-01'
WORK = ROOT / '.work/compiler-revalidation-controls-archive-01'
OWNED = ROOT / 'experiments/stable-cgu/owned_stage.py'
EXPECTED_SUMMARY = 'd879e043f493d8df5661708447a1934ce9793e8cb04b8fa2b2aae18e2b64802e'
EXPECTED_CHILD = '7fea109904d99b7bdad46a3166f890881af01d78b6753c3677a63edb31446d1a'
REVISION = '0e57b2b5b79f29c22e3a47d68959dcdc42dbc176'


def digest(data):
    return hashlib.sha256(data).hexdigest()


assert digest(OWNED.read_bytes()) == '7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e'
sys.path.insert(0, str(OWNED.parent))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--helper-sha', required=True)
    args = parser.parse_args()
    require(sys.dont_write_bytecode and not sys.flags.optimize and Path.cwd() == ROOT,
            'fixed cwd and Python -B required')
    require(Path(__file__).resolve() == ROOT / '.work/archive_compiler_revalidation_controls_01.py'
            and sha(__file__) == args.helper_sha, 'reviewed archive source changed')
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
                  started_at=time.time(), helper_sha256=args.helper_sha,
                  lock=str(CANONICAL_LOCK), lock_wait_seconds=600)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            payloads = {}

            def capture(path, expected=None):
                path = Path(path)
                require(path.is_absolute() and path.resolve(strict=True) == path
                        and path.is_file() and not path.is_symlink(), 'nonordinary evidence path')
                data = path.read_bytes()
                require(expected is None or digest(data) == expected, 'evidence source changed: ' + str(path))
                if str(path) in payloads:
                    require(payloads[str(path)] == data, 'evidence changed during capture')
                payloads[str(path)] = data
                return data

            test = json.loads(capture(RAW / 'summary.json', EXPECTED_SUMMARY))
            require(test['status'] == 'passed' and test['base_commit'] == REVISION
                    and test['source_patch_sha256'] == '28956052e73ea36209072b10056b6920a4c21ebfcbdc2b12e5739c4315897f3d'
                    and test['source_files'] == 29 and len(test['sources']) == 61
                    and test['all_inputs_unchanged'] and test['command_receipt_sha256'] == EXPECTED_CHILD
                    and test['real_archive_reads'] == test['real_compiler_input_reads'] == 0
                    and test['compiler_commands'] == 0 and not test['real_compiler_or_sysroot_inspected']
                    and test['production_policy_modules_imported_by_tests']
                    and test['synthetic_installations_exercised'],
                    'exact passing synthetic compiler-policy history required')
            for path, expected in test['sources'].items():
                capture(path, expected)
            for path, row in test['snapshots'].items():
                require(row['sha256'] == test['sources'][path], 'test snapshot association differs')
                require(len(capture(row['path'], row['sha256'])) == row['bytes'], 'snapshot size differs')
            require(set(test['snapshots']) == set(test['sources']), 'test source snapshots incomplete')
            child = json.loads(capture(RAW / 'command/receipt.json', EXPECTED_CHILD))
            require(child['status'] == 'finished' and child['returncode'] == 0
                    and child['cwd'] == test['command_cwd'] == str(ROOT / 'tests') and child['command'] == test['command']
                    and child['environment'] == test['environment'] and child['supervisor_pid'] == test['pid']
                    and child['parent_pid'] == test['parent_pid']
                    and test['admitted_at'] <= child['started_at'] <= child['finished_at'] <= test['finished_at'],
                    'completed test command/environment/process association differs')
            require(not capture(RAW / 'command/stdout', child['stdout_sha256']), 'unexpected test stdout')
            stderr = capture(RAW / 'command/stderr', child['stderr_sha256']).decode()
            actual = re.findall(r'^test_[^\n]* \((test_(?:custom_compiler|runtime_compiler|std_mir_source_paths)\.[^)]+)\) \.\.\. ok$', stderr, re.M)
            require(len(actual) == 45 and actual == test['actual_tests'] == test['required_tests']
                    and re.search(r'^Ran 45 tests in [0-9.]+s$', stderr, re.M)
                    and stderr.rstrip().endswith('OK') and 'skipped' not in stderr,
                    '45 actual unfiltered passing names required')
            outer = json.loads(capture(SUPERVISOR / 'status.json', '086c634cb9381ca50d0be5700765575dd246c38a4d42c98c110e155ecd52e901'))
            plan = json.loads(capture(SUPERVISOR / 'plan.json', outer['plan_sha256']))
            require(outer['status'] == 'finished' and outer['returncode'] == 0
                    and outer['child_pid'] == test['pid'] and outer['supervisor_pid'] == test['parent_pid']
                    and outer['started_at'] <= test['started_at'] <= test['finished_at'] <= outer['finished_at']
                    and outer['command'] == plan['command'] and outer['cwd'] == plan['owner'] == str(ROOT),
                    'outer supervisor association differs')
            capture(SUPERVISOR / 'command.log', outer['log_sha256'])
            capture(SUPERVISOR / 'supervisor.log')
            launch = json.loads(capture(LAUNCH, '24a6ca35a7afa38487533a1a0f6827e4c2f16b10105852e1da1b627c8191e3f3'))
            admission = json.loads(capture(launch['admission'], launch['admission_sha256']))
            require(plan['command'] == launch['command'][launch['command'].index('--') + 1:]
                    and admission['helper_sha256'] == test['helper_sha256']
                    and launch['admission_sha256'] == test['admission_sha256']
                    and admission['source_freeze_sha256'] == test['source_freeze_sha256'],
                    'saved launch/admission/helper association differs')
            for suffix in ('.stdout', '.stderr'):
                capture(LAUNCH.with_suffix(suffix))
            readme = capture(ROOT / '.work/compiler-revalidation-controls-archive-README-01.md',
                '722b0d9aae18b24ee44c1dc3232d90c445d0930fdbadca75440bc6bbcc121eec')
            for path in [Path(__file__), ROOT / '.work/compiler-revalidation-controls-archive-launch-01.json']:
                capture(path)
            OUT.mkdir(parents=True, exist_ok=False)
            archive = OUT / 'evidence.tar.gz'
            manifest = {}
            with archive.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for source, data in sorted(payloads.items()):
                            disk(ROOT)
                            name = source.lstrip('/')
                            member = tarfile.TarInfo(name)
                            member.size, member.mode = len(data), 0o644
                            tar.addfile(member, io.BytesIO(data))
                            manifest[name] = dict(source=source, bytes=len(data), sha256=digest(data))
            seen = set()
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    disk(ROOT)
                    require(member.isfile() and member.name not in seen, 'invalid archive member')
                    seen.add(member.name)
                    item = manifest[member.name]
                    with tar.extractfile(member) as stream:
                        data = stream.read()
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback differs')
            require(seen == set(manifest), 'archive readback incomplete')
            require(all(capture(path) == data for path, data in list(payloads.items())), 'retained input changed')
            write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed', base_commit=REVISION, source_patch_sha256=test['source_patch_sha256'], raw=str(RAW),
                supervisor=str(SUPERVISOR), controls=45, skipped=0, actual_tests=actual,
                test_pid=child['pid'], helper_pid=test['pid'], supervisor_pid=outer['supervisor_pid'],
                test_command=child['command'], test_seconds=child['finished_at'] - child['started_at'],
                actual_test_summary_sha256=EXPECTED_SUMMARY, actual_test_receipt_sha256=EXPECTED_CHILD,
                tested_sources=test['sources'], all_sources_unchanged=True,
                archive=dict(path=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
                             members=len(manifest), all_member_hashes_verified=True, gzip_mtime=0),
                manifest_sha256=sha(OUT / 'manifest.json'), archive_helper_sha256=args.helper_sha,
                archive_pid=os.getpid(), archive_parent_pid=os.getppid(), archive_admitted_at=record['admitted_at'],
                real_archive_reads=0, real_compiler_input_reads=0, assembly_performed=False,
                compiler_commands=0, runtime_qualification=False, performance_claim=False,
                scope='45 synthetic compiler-policy controls; no real compiler, Cargo or loader execution')
            write(OUT / 'summary.json', summary)
            (OUT / 'README.md').write_bytes(readme)
            record.update(status='passed', finished_at=time.time(), free_bytes_after=disk(ROOT),
                          result=str(OUT), archive=summary['archive'], summary_sha256=sha(OUT / 'summary.json'))
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
