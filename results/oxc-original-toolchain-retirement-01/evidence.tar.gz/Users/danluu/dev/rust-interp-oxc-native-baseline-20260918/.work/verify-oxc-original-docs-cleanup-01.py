import hashlib,json,os,stat
from pathlib import Path
O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918');W=O/'.work/oxc-original-docs-cleanup-01';H=O/'experiments/oxc-original-docs-cleanup'
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def identity(p,keys):
 s=p.lstat();return {k:getattr(s,'st_'+k) for k in keys}
r=read(W/'receipt.json');a=read(O/'.work/oxc-original-docs-capacity-assessment-01.json');plan=read(H/'plan.json');op=O/'.work/experiments/oxc-original-docs-cleanup-supervisor-01';outer=read(op/'status.json')
assert r['status']=='passed' and r['deleted_entries']==67312 and r['retained_documentation_unchanged'] and r['compiler_providers_unchanged'] and not r['original_toolchain_complete']
assert outer['status']=='finished' and outer['returncode']==0 and r['pid']==outer['child_pid'] and r['parent_pid']==outer['supervisor_pid']
assert outer['started_at']<=r['started_at']<=r['admitted_at']<=r['finished_at']<=outer['finished_at']
assert sha(op/'plan.json')==outer['plan_sha256'] and sha(op/'command.log')==outer['log_sha256']
root=Path(a['target']);assert not root.exists() and not root.is_symlink()
expected={str(root/name) if name!='.' else str(root) for name in a['entries']}
ledger=[json.loads(line) for line in (W/'deleted.jsonl').read_text().splitlines()]
assert len(r['deleted'])==len(set(r['deleted']))==len(ledger)==len(expected)==67312
assert set(r['deleted'])==expected and [row['path'] for row in ledger]==r['deleted']
assert all(r['admitted_at']<=row['time']<=r['finished_at'] for row in ledger)
assert read(W/'admitted-assessment.json')==dict(path=str(O/'.work/oxc-original-docs-capacity-assessment-01.json'),sha256=sha(O/'.work/oxc-original-docs-capacity-assessment-01.json'),exact_entries=67312,retained_files=65826)
permission_file=W/'directory-permissions.jsonl';permissions=[json.loads(line) for line in permission_file.read_text().splitlines()] if permission_file.exists() else []
assert permissions==r['directory_permissions']
readonly={str(root/name) if name!='.' else str(root):row for name,row in a['entries'].items() if stat.S_ISDIR(row['mode']) and not row['mode']&stat.S_IWUSR}
assert len(permissions)==len(readonly) and {x['path'] for x in permissions}==set(readonly)
for row in permissions:
 before,after=row['before'],row['after'];assert before==readonly[row['path']]
 assert all(before[k]==after[k] for k in ['dev','ino','nlink','size','mtime_ns']) and after['mode']==before['mode']|stat.S_IWUSR
 assert r['admitted_at']<=row['time']<=r['finished_at']
assert len(r['children'])==len(plan['commands'])==2
previous=r['admitted_at'];missing=[]
for item,spec in zip(r['children'],plan['commands'],strict=True):
 p=Path(item['path']);c=read(p);assert item['label']==spec['label'] and sha(p)==item['sha256']
 assert c['command']==spec['argv'] and c['cwd']==str(O) and c['environment']==plan['environment']
 assert c['status']=='finished' and c['returncode']==1 and c['supervisor_pid']==r['pid'] and c['parent_pid']==r['parent_pid']
 assert previous<=c['started_at']<=c['finished_at']<=ledger[0]['time'];previous=c['finished_at']
 for stream in ['stdout','stderr']:assert sha(p.parent/stream)==c[stream+'_sha256'] and (p.parent/stream).read_bytes()==b''
 actual=c['identity'];fields=actual['ps'].split(None,9)
 assert actual['ps_returncode']==0 and list(map(int,fields[:3]))==[c['pid'],r['pid'],c['pid']] and fields[8]=='??' and fields[9]==' '.join(c['command'])
 if actual['cwd_returncode']==0:assert actual['cwd'].splitlines()==[f'p{c["pid"]}','fcwd','n'+str(O)]
 else:assert actual['cwd_returncode']==1 and actual['cwd']=='';missing.append(spec['label'])
retained=Path(a['retained']);names={'.'}
for directory,dirs,files in os.walk(retained,followlinks=False):
 for name in dirs+files:names.add(str((Path(directory)/name).relative_to(retained)))
assert names==set(a['retained_entries'])
for name,row in a['retained_entries'].items():
 p=retained if name=='.' else retained/name;assert p.resolve(strict=True)==p and identity(p,row)==row
for name,digest in a['files'].items():assert sha(retained/name)==digest and identity(retained/name,a['retained_entries'][name])==a['retained_entries'][name]
freeze=read(H/'inputs.json')
for name,row in freeze['files'].items():
 p=Path(name);assert identity(p,row['identity'])==row['identity'] and sha(p)==row['sha256']
for name,row in plan['protected_routes'].items():
 p=Path(name);assert p.resolve(strict=True)==p and identity(p,row['identity'])==row['identity'] and sha(p)==row['sha256']
for name,row in plan['protected_aliases'].items():
 p=Path(name);assert p.is_symlink() and identity(p,row['identity'])==row['identity'] and os.readlink(p)==row['target'] and str(p.resolve(strict=True))==row['resolved']
result=dict(status='verified',receipt_sha256=sha(W/'receipt.json'),supervisor_sha256=sha(op/'status.json'),exact_deleted_entries=67312,readonly_children=2,directory_permissions=len(permissions),frozen_inputs=len(freeze['files']),retained_documentation_files=65826,retained_documentation_entries=67312,full_retained_bytes_and_membership_unchanged=True,protected_provider_routes=len(plan['protected_routes']),original_toolchain_complete=False,fast_child_cwd_probe_unavailable=missing,finished_at=r['finished_at'],free_bytes_after=r['free_bytes_after'])
out=O/'.work/oxc-original-docs-cleanup-actual-verification-01.json'
with out.open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(dict(path=str(out),sha256=sha(out),**result),indent=2))
