import hashlib,json,tarfile
from pathlib import Path
O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918');W=O/'.work/oxc-original-llvm-retirement-01';H=O/'experiments/oxc-original-llvm-retirement'
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def ident(p,keys):
 s=p.lstat();return {k:getattr(s,'st_'+k) for k in keys}
r=read(W/'receipt.json');p=read(H/'plan.json');a=read(O/'.work/oxc-original-llvm-provider-capacity-assessment-01.json');d=read(W/'deleted.json');outerdir=O/'.work/experiments/oxc-original-llvm-retirement-supervisor-01';outer=read(outerdir/'status.json')
assert r['status']=='passed' and not r['original_toolchain_complete'] and r['original_toolchain_retired'] and r['deleted']==[d]
assert outer['status']=='finished' and outer['returncode']==0 and outer['child_pid']==r['pid'] and outer['supervisor_pid']==r['parent_pid']
assert outer['started_at']<=r['started_at']<=r['admitted_at']<=d['time']<=r['finished_at']<=outer['finished_at']
assert sha(outerdir/'plan.json')==outer['plan_sha256'] and sha(outerdir/'command.log')==outer['log_sha256']
assert d['path']==p['target']==a['target'] and d['before']==a['identity']
assert d['unlinked_open_fd']['nlink']==0 and all(d['before'][k]==d['unlinked_open_fd'][k] for k in ['dev','ino','mode','size','mtime_ns'])
target=Path(p['target']);assert not target.exists() and not target.is_symlink()
assert ident(target.parent,d['parent_after'])==d['parent_after']
assert len(r['children'])==len(p['commands'])==2
previous=r['admitted_at'];missing=[]
for ref,spec in zip(r['children'],p['commands'],strict=True):
 path=Path(ref['path']);c=read(path);assert ref['label']==spec['label'] and sha(path)==ref['sha256']
 assert c['status']=='finished' and c['returncode']==1 and c['command']==spec['argv'] and c['environment']==p['environment'] and c['cwd']==str(O)
 assert c['supervisor_pid']==r['pid'] and c['parent_pid']==r['parent_pid'] and previous<=c['started_at']<=c['finished_at']<=d['time'];previous=c['finished_at']
 for name in ['stdout','stderr']:assert (path.parent/name).read_bytes()==b'' and sha(path.parent/name)==c[name+'_sha256']
 fields=c['identity']['ps'].split(None,9);assert c['identity']['ps_returncode']==0 and list(map(int,fields[:3]))==[c['pid'],r['pid'],c['pid']] and fields[8]=='??' and fields[9]==' '.join(c['command'])
 if c['identity']['cwd_returncode']==0:assert c['identity']['cwd'].splitlines()==[f'p{c["pid"]}','fcwd','n'+str(O)]
 else:assert c['identity']['cwd_returncode']==1 and not c['identity']['cwd'];missing.append(spec['label'])
for name,row in read(H/'inputs.json')['files'].items():
 path=Path(name);assert ident(path,row['identity'])==row['identity'] and sha(path)==row['sha256']
for name,row in p['protected_routes'].items():
 path=Path(name);assert path.resolve(strict=True)==path and ident(path,row['identity'])==row['identity'] and sha(path)==row['sha256']
for name,row in p['protected_aliases'].items():
 import os
 path=Path(name);assert path.is_symlink() and ident(path,row['identity'])==row['identity'] and os.readlink(path)==row['target'] and str(path.resolve(strict=True))==row['resolved']
assert sha(Path(a['archive']))==a['archive_sha256']
with tarfile.open(a['archive'],'r:xz') as t:
 m=t.getmember(a['archive_member']);assert m.isfile() and m.size==a['identity']['size'] and hashlib.file_digest(t.extractfile(m),'sha256').hexdigest()==a['sha256']
 while t.fileobj.read(2**20):pass
result=dict(status='verified',receipt_sha256=sha(W/'receipt.json'),supervisor_sha256=sha(outerdir/'status.json'),deleted_sha256=sha(W/'deleted.json'),exact_deleted_files=1,original_toolchain_complete=False,protected_routes=len(p['protected_routes']),protected_aliases=len(p['protected_aliases']),official_archive_and_member_full_xz_eof_verified=True,independent_qualified_copies_unchanged=True,frozen_inputs=len(read(H/'inputs.json')['files']),readonly_children=2,unavailable_cwd_probes=missing,finished_at=r['finished_at'],free_bytes_after=r['free_bytes_after'])
out=O/'.work/oxc-original-llvm-retirement-actual-verification-01.json'
with out.open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(dict(path=str(out),sha256=sha(out),**result),indent=2))
