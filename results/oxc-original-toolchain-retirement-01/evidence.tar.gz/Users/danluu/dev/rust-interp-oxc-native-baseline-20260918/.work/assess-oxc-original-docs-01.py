import hashlib,json,os,stat,time
from pathlib import Path
O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
old=O/'.work/oxc-native-setup-01/rustup/toolchains/1.98.1-aarch64-apple-darwin'
kept=O/'.work/oxc-native-toolchain-composition-01/toolchain'
REL=Path('share/doc/rust');target=old/REL;retained=kept/REL
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def ident(p):
 s=p.lstat();return {k:getattr(s,'st_'+k) for k in ['dev','ino','mode','nlink','size','mtime_ns','ctime_ns']}
def inventory(root):
 assert root.resolve(strict=True)==root
 rows={'.':ident(root)};allocated=root.lstat().st_blocks*512
 for directory,dirs,files in os.walk(root,followlinks=False):
  for name in sorted(dirs+files):
   p=Path(directory)/name;s=p.lstat();assert stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode)
   assert p.resolve(strict=True)==p
   if stat.S_ISREG(s.st_mode):assert s.st_nlink==1
   rows[str(p.relative_to(root))]=ident(p);allocated+=s.st_blocks*512
 return rows,allocated
started=time.time();a,allocated=inventory(target);b,kept_allocation=inventory(retained);assert set(a)==set(b)
ip=O/'.work/oxc-acquisition-continuation-01/toolchain-inventory.json';cp=O/'.work/oxc-native-toolchain-composition-01/toolchain-inventory.json'
original=json.loads(ip.read_bytes());composed=json.loads(cp.read_bytes());files={};total=0
for name,row in a.items():
 other=b[name];assert (row['dev'],row['ino'])!=(other['dev'],other['ino'])
 assert stat.S_IFMT(row['mode'])==stat.S_IFMT(other['mode'])
 if not stat.S_ISREG(row['mode']):continue
 p=target/name;q=retained/name;key=str(REL/name);proof=original[key]
 assert composed[key]==proof and proof['kind']=='file'
 assert proof['bytes']==row['size']==other['size'] and stat.S_IMODE(row['mode'])==stat.S_IMODE(other['mode'])==proof['mode']
 digest=sha(p);assert digest==proof['sha256']==sha(q) and ident(p)==row and ident(q)==other
 files[name]=digest;total+=row['size']
expected={str(Path(key).relative_to(REL)) for key in original if Path(key).is_relative_to(REL)}
assert expected==set(files)
assert inventory(target)[0]==a and inventory(retained)[0]==b
history={}
for name in ['oxc-native-compatibility-01','oxc-native-compatibility-02','oxc-native-toolchain-composition-continuation-01','oxc-runtime-strict-compatibility-01']:
 p=O/'.work'/name/'receipt.json';d=json.loads(p.read_bytes());assert d['status']=='passed';history[str(p)]=dict(sha256=sha(p),status=d['status'],finished_at=d['finished_at'])
result=dict(status='assessed-read-only',target=str(target),retained=str(retained),entries=a,retained_entries=b,files=files,
 logical_bytes=total,allocated_bytes=allocated,retained_allocated_bytes=kept_allocation,historical_receipts=history,
 inventory_proofs={str(p):sha(p) for p in [ip,cp]},started_at=started,finished_at=time.time(),
 scope='Only redundant installed documentation in the original completed native01 toolchain; qualified composed documentation and all compiler/provider routes remain protected.',
 limitations=['No quiescence probe or deletion performed.','Complete original-toolchain inventory remains historical; any changed original installation requires restoration/requalification before replaying old guards.','No unique documentation byte is discarded: every original file is exact in the independently allocated qualified composed tree.'])
out=O/'.work/oxc-original-docs-capacity-assessment-01.json'
with out.open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(dict(path=str(out),report_sha256=sha(out),entries=len(a),files=len(files),logical_bytes=total,allocated_bytes=allocated),indent=2))
