import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-runtime-lookup-paths-20260918')
PRIOR = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
OUT = ROOT / 'results/runtime-lookup-paths-01'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('archive_owned', ROOT / 'experiments/stable-cgu/owned_stage.py')
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)
paths = [Path(__file__), ROOT / 'scripts/supervise_experiment.py', ROOT / 'experiments/stable-cgu/owned_stage.py',
    PRIOR / '.work/profile_runtime_lookup_01.py', PRIOR / '.work/runtime-lookup-profile-inputs-01.json',
    PRIOR / '.work/runtime-lookup-profile-launch-01.json']
for base in [ROOT / 'experiments/runtime-lookup', ROOT / '.work/runtime-lookup-comparison-01',
        ROOT / '.work/runtime-lookup-comparison-outer-01', ROOT / '.work/experiments/runtime-lookup-comparison-supervisor-01',
        PRIOR / '.work/runtime-lookup-profile-01', PRIOR / '.work/runtime-lookup-profile-outer-01',
        PRIOR / '.work/experiments/runtime-lookup-profile-supervisor-01']:
    paths.extend(p for p in base.rglob('*') if p.is_file())
paths = sorted(set(paths))
manifest = {}
for p in paths:
    if p.resolve(strict=True) != p or p.is_symlink():
        raise RuntimeError('nonordinary archive source')
    manifest[str(p).lstrip('/')] = dict(source=str(p), sha256=sha(p), bytes=p.stat().st_size)
if sum(r['bytes'] for r in manifest.values()) > 64 * 2**20:
    raise RuntimeError('archive input bound exceeded')
with owned.workload_lock('/Users/danluu/dev/rust-interp/.work/benchmark.lock', 600):
    owned.disk(ROOT, 9)
    started = time.time()
    OUT.mkdir(exist_ok=False)
    archive = OUT / 'evidence.tar.gz'
    seen = {}
    with tarfile.open(archive, 'w:gz') as output:
        for name, row in manifest.items():
            owned.disk(ROOT, 9)
            payload = Path(row['source']).read_bytes()
            if len(payload) != row['bytes'] or hashlib.sha256(payload).hexdigest() != row['sha256']:
                raise RuntimeError('archive input changed')
            member = tarfile.TarInfo(name)
            member.mode = 0o644
            if row['sha256'] in seen:
                member.type = tarfile.LNKTYPE
                member.linkname = seen[row['sha256']]
                output.addfile(member)
            else:
                member.size = len(payload)
                output.addfile(member, io.BytesIO(payload))
                seen[row['sha256']] = name
    with tarfile.open(archive, 'r:gz') as source:
        names = set()
        for member in source:
            row = manifest[member.name]
            payload = source.extractfile(member).read()
            if len(payload) != row['bytes'] or hashlib.sha256(payload).hexdigest() != row['sha256']:
                raise RuntimeError('archive readback failed')
            names.add(member.name)
        if names != set(manifest):
            raise RuntimeError('archive membership differs')
    with gzip.open(archive, 'rb') as source:
        while source.read(1024**2):
            pass
    owned.write(OUT / 'manifest.json', manifest)
    comparison = json.loads((ROOT / '.work/runtime-lookup-comparison-01/receipt.json').read_text())
    summary = dict(status='passed', qualification='lookup component only; no application timing or 0.5s claim',
        controls=22, measured_pairs=12, warmups=2, median_lookup_seconds=comparison['median_lookup_seconds'],
        pairs=comparison['pairs'], observations=comparison['observations'],
        comparison_receipt_sha256=sha(ROOT / '.work/runtime-lookup-comparison-01/receipt.json'),
        archive_sha256=sha(archive), archive_bytes=archive.stat().st_size,
        logical_members=len(manifest), physical_members=len(seen), manifest_sha256=sha(OUT / 'manifest.json'),
        archive_pid=os.getpid(), archive_parent_pid=os.getppid(), archive_admitted_at=started,
        archive_finished_at=time.time(), free_bytes_after=owned.disk(ROOT, 9))
    owned.write(OUT / 'summary.json', summary)
    print(json.dumps({k:summary[k] for k in ['archive_sha256','archive_bytes','logical_members','physical_members','manifest_sha256']}))
