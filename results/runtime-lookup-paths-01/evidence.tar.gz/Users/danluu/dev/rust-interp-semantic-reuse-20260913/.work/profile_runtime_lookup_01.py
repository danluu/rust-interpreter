"""Read-only installed runtime/std lookup diagnosis; no compiler child or speedup claim."""
import cProfile
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import pstats
import resource
import sys
import time

ROOT = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
OWNER = Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
WORK = ROOT / '.work/runtime-lookup-profile-01'
FROZEN = ROOT / '.work/runtime-lookup-profile-inputs-01.json'
RKEY = 'eca3d1317ba4c852d64de435aa0f0e5d87ae63bd4eb96cfafacc7b0a85841d03'
SKEY = 'e4d1cd29bf4dbac5f9cbf6a92c77a562b89f7079c4474653f180346a00f24b63'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def main():
    require(len(sys.argv) == 2 and sha(FROZEN) == sys.argv[1], 'exact frozen input required')
    frozen = json.loads(FROZEN.read_text())
    require(Path.cwd() == ROOT and sys.dont_write_bytecode and not sys.flags.optimize, 'fixed invocation required')
    def guard():
        require(sha(FROZEN) == sys.argv[1], 'freeze changed')
        for path, expected in frozen['files'].items():
            require(sha(path) == expected, 'input changed: ' + path)
        require(str(Path(sys.executable).resolve()) == frozen['python']['path']
                and sha(sys.executable) == frozen['python']['sha256'], 'Python changed')
    guard()
    spec = importlib.util.spec_from_file_location('lookup_owned', ROOT / 'experiments/stable-cgu/owned_stage.py')
    owned = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(owned)
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
        started_at=time.time(), inputs_sha256=sys.argv[1], environment=dict(os.environ),
        compiler_commands=0, application_benchmark=False, speedup_claim=False, trials=[])
    def save():
        owned.write(WORK / 'receipt.json', record)
    save()
    try:
        with owned.workload_lock(ROOT.parent / 'rust-interp/.work/benchmark.lock', 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=owned.disk(ROOT, 16))
            save()
            guard()
            retained = WORK / 'inputs'
            retained.mkdir()
            for path, checksum in frozen['files'].items():
                owned.disk(ROOT, 9)
                copy = retained / checksum
                if not copy.exists():
                    with copy.open('xb') as stream:
                        stream.write(Path(path).read_bytes())
                require(sha(copy) == checksum, 'input retention differs')
            sys.path.insert(0, str(ROOT / 'scripts'))
            start = time.perf_counter()
            import runtime_compiler
            import std_mir_source_paths as std
            record['module_import_seconds'] = time.perf_counter() - start
            def lookup():
                cpu = time.process_time()
                start = time.perf_counter()
                compiler = runtime_compiler.load_runtime_compiler(OWNER, RKEY)
                middle = time.perf_counter()
                prepared = std.load(OWNER, SKEY, compiler, 'immutable-source-paths-v2:shared')
                end = time.perf_counter()
                return dict(runtime_seconds=middle-start, std_seconds=end-middle,
                    total_seconds=end-start, cpu_seconds=time.process_time()-cpu,
                    runtime_key=compiler.key, std_key=prepared[2])
            for _ in range(3):
                guard()
                owned.disk(ROOT, 9)
                record['trials'].append(lookup())
                save()
            guard()
            profiler = cProfile.Profile()
            record['instrumented_trial'] = profiler.runcall(lookup)
            profiler.dump_stats(WORK / 'lookup.prof')
            stream = io.StringIO()
            pstats.Stats(profiler, stream=stream).strip_dirs().sort_stats('cumulative').print_stats(60)
            (WORK / 'profile.txt').write_text(stream.getvalue())
            guard()
            for checksum in frozen['files'].values():
                require(sha(retained / checksum) == checksum, 'retained input changed')
            record.update(status='passed', finished_at=time.time(), free_bytes_after=owned.disk(ROOT, 9),
                profile_sha256=sha(WORK / 'lookup.prof'), text_sha256=sha(WORK / 'profile.txt'),
                maximum_rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
            save()
            print(json.dumps({k:record[k] for k in ['status','trials','instrumented_trial','module_import_seconds']}))
    except BaseException as error:
        record.update(status='failed', error=repr(error), finished_at=time.time())
        save()
        raise


if __name__ == '__main__':
    main()
