import fcntl, hashlib, json, os, pathlib, shutil, subprocess, sys, time
root=pathlib.Path.cwd();out=root/'.work/demand-retention-release-01';target=root/'.work/demand-retention-release-target'
compiler=pathlib.Path('/Users/danluu/.rustup/toolchains/nightly-2026-09-08-aarch64-apple-darwin/bin/rustc')
vm=pathlib.Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913/.work/interpreter-tools/923ad6d94c365365f15322ee65d32dca6ba9ccc4fd07a8147111329ea1955c86/rust-interp-vm')
lockpath=pathlib.Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode()
def snapshot():
 names=subprocess.check_output(['git','ls-files','crates','scripts','tests','Cargo.toml','Cargo.lock','rust-toolchain.toml'],text=True).splitlines()
 return {name:digest(root/name) for name in sorted(set(names)) if (root/name).is_file()}
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert commit=='355f12ad83f1140625482f526e2541ac7ce92f4e'
before=snapshot();source_vm=json.loads(vm.with_name('source.json').read_text())
vm_inputs={name:sha for name,sha in before.items() if name.startswith('crates/bytecode/') or name in ('Cargo.toml','Cargo.lock')}
for name,sha in vm_inputs.items():assert source_vm['files'][name]==sha,(name,'retained VM source mismatch')
assert digest(vm)=='83ca5b7882debeae37af8099c99c5cfb1a3829ed969444ee350eee12aa72b4df'
inputs=[root/'Cargo.toml',root/'Cargo.lock']
for crate in ('bytecode','mir-export'):inputs.extend(sorted((root/'crates'/crate).rglob('*.rs')));inputs.append(root/'crates'/crate/'Cargo.toml')
legacy=hashlib.sha256()
for p in inputs:legacy.update(str(p.relative_to(root)).encode()+b'\0'+p.read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith(('RUST_INTERP_','CARGO_PROFILE_')) and k not in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_TARGET_DIR','RUSTC','RUSTDOC','RUSTUP_TOOLCHAIN')}
env['CARGO_INCREMENTAL']='0'
relevant=('CARGO_HOME','RUSTUP_HOME','CARGO_INCREMENTAL','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTC','RUSTDOC','CC','CXX','AR','CFLAGS','CXXFLAGS','LDFLAGS','SDKROOT','MACOSX_DEPLOYMENT_TARGET','DYLD_LIBRARY_PATH','PATH')
receipt={'schema_version':1,'supervisor_pid':os.getpid(),'cwd':str(root),'shared_lock':str(lockpath),'started_at':time.time(),'source_commit':commit,'source_before':before,'legacy_source_tool_key':legacy.hexdigest(),'build_environment':{k:env.get(k) for k in relevant},'cargo_profile':'ordinary release defaults; no CARGO_PROFILE_* overrides','vm':str(vm),'vm_sha256':digest(vm),'vm_source_files_verified':vm_inputs,'compiler_version':subprocess.check_output([compiler,'-vV'],text=True),'compiler_binary_sha256':digest(compiler),'cargo_version':subprocess.check_output([compiler.with_name('cargo'),'-vV'],text=True),'commands':[]}
def save(): (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save();print('task-owned release supervisor PID',os.getpid(),flush=True)
commands=[['cargo','+nightly-2026-09-08','build','--release','--locked','--offline','--jobs','2','--package','rust-interp-mir-export','--bin','rust-interp-mir-export','--bin','rust-interp-rustc-wrapper','--target-dir',str(target)]]
commands += [['python3','-m','unittest','discover','-s','tests','-p',pattern,'-v'] for pattern in ['test_demand_retention.py','test_demand_retention_cargo.py']]
status=0
with lockpath.open('a+') as lock:
 deadline=time.monotonic()+300
 while True:
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
  except BlockingIOError:
   if time.monotonic()>deadline:raise SystemExit('shared lock unavailable after bounded wait')
   print('waiting for shared lock',flush=True);time.sleep(15)
 receipt['lock_acquired_at']=time.time();save()
 for stage,command in enumerate(commands):
  childenv=env if stage==0 else dict(env,RUST_INTERP_TEST_EXPORTER=str(target/'release/rust-interp-mir-export'),RUST_INTERP_TEST_ARTIFACT_DIR=str(out/'fixtures'),RUST_INTERP_TEST_VM=str(vm))
  row={'command':command,'started_at':time.time(),'log':str(out/f'{stage}.log')};receipt['commands'].append(row)
  with pathlib.Path(row['log']).open('w') as log:
   child=subprocess.Popen(command,cwd=root,env=childenv,stdout=log,stderr=subprocess.STDOUT);row['pid']=child.pid;save();print('task-owned release PID',child.pid,'stage',stage,flush=True)
   while child.poll() is None:
    try:child.wait(timeout=30)
    except subprocess.TimeoutExpired:print('release stage still running',stage,'PID',child.pid,flush=True)
  row['returncode']=child.returncode;row['finished_at']=time.time();save();print(pathlib.Path(row['log']).read_text()[-5000:],flush=True)
  if child.returncode:status=child.returncode;break
receipt['source_after']=snapshot();receipt['source_unchanged']=before==receipt['source_after'];assert receipt['source_unchanged'],'build source changed'
assert digest(vm)==receipt['vm_sha256'],'retained VM changed'
if status:receipt['finished_at']=time.time();save();raise SystemExit(status)
binaries={name:digest(target/'release'/name) for name in ('rust-interp-mir-export','rust-interp-rustc-wrapper')};binaries['rust-interp-vm']=digest(vm)
composition={'kind':'demand-retention-release-candidate-v1','schema_version':1,'source_commit':commit,'legacy_source_tool_key':receipt['legacy_source_tool_key'],'source_manifest_sha256':hashlib.sha256(canonical(before)).hexdigest(),'compiler_version':receipt['compiler_version'],'compiler_binary_sha256':receipt['compiler_binary_sha256'],'cargo_version':receipt['cargo_version'],'build_environment':receipt['build_environment'],'cargo_profile':receipt['cargo_profile'],'cargo_command':commands[0],'retained_vm_tool_key':vm.parent.name,'binaries':binaries}
key=hashlib.sha256(canonical(composition)).hexdigest();directory=root/'.work/interpreter-tools'/key
assert not directory.exists();directory.mkdir(parents=True)
for name in binaries:shutil.copy2(vm if name=='rust-interp-vm' else target/'release'/name,directory/name)
probe=subprocess.run([str(directory/'rust-interp-mir-export'),'--rust-interp-capabilities'],capture_output=True,text=True,check=True,timeout=10)
caps=json.loads(probe.stdout);assert caps['schema_version']==1 and 'query-cache-retention' in caps['export_options'];caps.update(tool_key=key,exporter_sha256=binaries['rust-interp-mir-export'])
(directory/'capabilities.json').write_text(json.dumps(caps,indent=2)+'\n')
(directory/'source.json').write_text(json.dumps({'tool_key':key,'key_algorithm':'SHA256 of canonical composition JSON','composition':composition,'files':before,'source_commit':commit,'source':str(root),'retained_vm_provenance':str(vm.with_name('source.json'))},indent=2)+'\n')
(directory/'ready.json').write_text(json.dumps(binaries,indent=2)+'\n')
sys.path.insert(0,str(root/'scripts'));import interpreter
interpreter.installed_tools(key);interpreter.require_export_option(directory,key,'query-cache-retention')
receipt.update(finished_at=time.time(),binaries=binaries,composition=composition,tool_key=key,tool_directory=str(directory),capabilities=caps);save();print('immutable release tool',directory,flush=True)
