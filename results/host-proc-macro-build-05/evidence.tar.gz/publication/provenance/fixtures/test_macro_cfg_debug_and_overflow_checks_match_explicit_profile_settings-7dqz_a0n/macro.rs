extern crate proc_macro;
#[proc_macro]
pub fn value(input: proc_macro::TokenStream) -> proc_macro::TokenStream {
    match input.to_string().as_str() {
        "debug" => { debug_assert!(false, "macro debug assertion"); "7".parse().unwrap() },
        "overflow" => (std::hint::black_box(u8::MAX) + 1).to_string().parse().unwrap(),
        _ => if cfg!(debug_assertions) { "1" } else { "0" }.parse().unwrap(),
    }
}
