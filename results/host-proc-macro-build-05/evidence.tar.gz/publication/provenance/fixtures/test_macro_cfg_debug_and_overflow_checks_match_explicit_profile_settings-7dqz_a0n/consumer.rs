fn main() { assert_eq!(fixture_macro::value!(overflow), 0); }
