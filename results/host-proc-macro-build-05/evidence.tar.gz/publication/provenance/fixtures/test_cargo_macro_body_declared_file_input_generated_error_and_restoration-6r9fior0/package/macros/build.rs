fn main() {
    let profile = format!("{}:{}", std::env::var("OPT_LEVEL").unwrap(), std::env::var("DEBUG").unwrap());
    let out = std::path::PathBuf::from(std::env::var_os("OUT_DIR").unwrap());
    std::fs::write(out.join("profile.txt"), &profile).unwrap();
    println!("cargo:rustc-env=FIXTURE_BUILD_PROFILE={profile}");
    println!("cargo:rerun-if-changed=build.rs");
    
    let input = std::path::PathBuf::from(std::env::var_os("CARGO_MANIFEST_DIR").unwrap()).join("input.txt");
    println!("cargo:rustc-env=FIXTURE_MACRO_INPUT={}", input.display());
    println!("cargo:rerun-if-changed=input.txt");
}
