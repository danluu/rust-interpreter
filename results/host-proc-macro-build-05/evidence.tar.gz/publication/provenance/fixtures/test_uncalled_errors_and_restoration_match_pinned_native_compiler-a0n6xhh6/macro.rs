#![allow(dead_code)]
extern crate proc_macro;
#[proc_macro] pub fn value(_: proc_macro::TokenStream) -> proc_macro::TokenStream { "3".parse().unwrap() }
