#!/usr/bin/env python3
"""Archive the completed ordinary native fixture check, without compiler work."""
import fcntl
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import tarfile
import time

OWNER = Path('/Users/danluu/dev/rust-interp-external-trait-fixture-evidence-20260913')
SOURCE = Path('/Users/danluu/dev/rust-interp-external-trait-index-20260913')
RAW = SOURCE / '.work/external-trait-index-fixtures-01'
SUPERVISOR = SOURCE / '.work/experiments/external-trait-index-fixtures-supervisor-01'
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
OUT = OWNER / 'results/external-trait-index-ordinary-fixtures-01'
RUN = OWNER / '.work/external-fixtures-archive-01'
COMPILER = 'f9fb3e5f59b8567fffd32c936a9864d0baee77038574236710fbcec75a57d33f'
COMMIT = '58e1e1f5311f4424ea81def4763081f6da62d9b3'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def require(value, message):
    if not value:
        raise ValueError(message)

def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def main():
    RUN.mkdir(exist_ok=False)
    receipt = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
        argv=sys.argv, cwd=os.getcwd(), lock=str(LOCK), lock_wait_seconds=600,
        workload='completed ordinary fixture archive only', benchmark=False)
    save(RUN / 'result.json', receipt)
    try:
        require(LOCK.resolve(strict=True) == LOCK, 'canonical lock changed')
        with LOCK.open('r+') as lock:
            deadline = time.monotonic() + 600
            while True:
                try:
                    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        raise TimeoutError('archive admission expired before input reads')
                    time.sleep(.2)
            require(shutil.disk_usage(OWNER).free >= 8 * 1024**3, 'less than 8 GiB free')
            receipt.update(status='admitted', admitted_at=time.time())
            save(RUN / 'result.json', receipt)
            OUT.mkdir(parents=True, exist_ok=False)
            inputs, members, excluded = {}, {}, {}

            def read(path):
                path = Path(path)
                before = path.lstat()
                require(stat.S_ISREG(before.st_mode), 'nonregular/indirect input: ' + str(path))
                data = path.read_bytes()
                after = path.lstat()
                require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)
                    == (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),
                    'input changed while reading')
                inputs[str(path)] = dict(size=len(data), sha256=sha(data))
                return data

            def obj(path):
                return json.loads(read(path))

            def add(path, name):
                require(name not in members, 'duplicate archive member')
                members[name] = read(path)

            result = obj(RAW / 'result.json')
            require(result['status'] == 'passed' and result['commands'] == 33 and result['states'] == 18
                and result['source_restored'] is True and result['compiler_unchanged'] is True
                and result['fixture_validation_only'] is True and result['benchmark'] is False
                and result['index_enabled'] is False and result['patched_compiler_qualified'] is False,
                'ordinary fixture scope/outcome differs')
            supervisor = obj(SUPERVISOR / 'status.json')
            require(supervisor['status'] == 'finished' and supervisor['returncode'] == 0,
                'fixture supervisor did not pass')
            require(sha(read(SUPERVISOR / 'command.log')) == supervisor['log_sha256'], 'outer log changed')
            compiler = obj(RAW / 'compiler-ready.json')
            require(compiler['key'] == COMPILER and compiler['identity']['provenance']['source_commit'] == COMMIT,
                'wrong actual ordinary compiler')
            # The live PRIMARY scripts changed after this completed run. Bind
            # the original snapshots to the recorded hashes, never substitute
            # current helper bytes for historical compilation inputs.
            frozen = result['source_files']
            names = {Path(path).name: (path, digest) for path, digest in frozen.items()}
            require(len(names) == len(frozen), 'ambiguous frozen input basename')
            seen = set()
            for path in sorted((RAW / 'frozen-inputs').iterdir()):
                match = re.fullmatch(r'\d{3}-(.+)', path.name)
                require(match and match[1] in names and match[1] not in seen, 'unknown frozen input')
                seen.add(match[1])
                require(sha(read(path)) == names[match[1]][1], 'frozen source snapshot changed')
            require(seen == set(names), 'missing frozen source snapshot')
            require(sha(read(RAW / 'main.rs')) == names['main.rs'][1]
                and sha(read(RAW / 'external.rs')) == names['external.rs'][1], 'source restoration differs')
            require(sha(read(RAW / 'libexternal.rlib')) == result['external_sha256'], 'native dependency changed')
            excluded[str(RAW / 'libexternal.rlib')] = inputs[str(RAW / 'libexternal.rlib')]
            commands = obj(RAW / 'commands.json')
            states = obj(RAW / 'states.json')
            require(len(commands) == 33 and len(states) == 18, 'history count differs')
            by_label = {row['label']: row for row in commands}
            indices = {row['label']: index for index, row in enumerate(commands)}
            require(len(by_label) == 33, 'duplicate command label')
            for index, row in enumerate(commands):
                stem = RAW / 'logs' / f'{index:03d}-{row["label"]}'
                process = obj(Path(str(stem) + '.process.json'))
                require(process['pid'] == row['pid'] and process['returncode'] == row['returncode']
                    and process['status'] == 'finished' and process['command'] == row['command'],
                    'command/process association differs')
                for suffix in ['stdout', 'stderr']:
                    require(sha(read(Path(str(stem) + '.' + suffix))) == row[suffix + '_sha256'],
                        'raw command output changed')
                require(not any('index-external-trait' in arg for arg in row['command']), 'index unexpectedly enabled')
                if row['command'][0].endswith('/bin/rustc') and row['label'] != 'compiler-version':
                    require('-Zstable-cgu-partitioning=no' in row['command']
                        and '-Zstable-mono-cgu-partitioning=no' in row['command'], 'ordinary policy changed')
            errors = {}
            for state in states:
                require(sha(read(RAW / 'state-sources' / (state['label'] + '.rs'))) == state['source_sha256'],
                    'state source snapshot differs')
                compile_row = by_label[state['label']]
                stem = RAW / 'logs' / f'{indices[state["label"]]:03d}-{state["label"]}'
                diagnostics = [json.loads(line) for line in read(Path(str(stem) + '.stderr')).splitlines()]
                if state['expected_code']:
                    errors[state['label']] = state['expected_code']
                    require(compile_row['returncode'] == 1, 'expected diagnostic compile succeeded')
                    require(any(d.get('code') and d['code']['code'] == state['expected_code'] for d in diagnostics),
                        'raw required diagnostic missing')
                else:
                    execute = by_label[state['label'] + '-execute']
                    require(compile_row['returncode'] == 0 and execute['returncode'] == 0, 'native state failed')
                    execute_stem = RAW / 'logs' / f'{indices[execute["label"]]:03d}-{execute["label"]}'
                    require(read(Path(str(execute_stem) + '.stdout')).decode() == state['expected_stdout']
                        and not read(Path(str(execute_stem) + '.stderr')), 'raw native output differs')
                    if state['expected_warning']:
                        require(any(d.get('level') == 'warning' and d.get('code')
                            and d['code']['code'] == state['expected_warning'] for d in diagnostics),
                            'raw required warning missing')
                    path = RAW / 'binaries' / state['label']
                    require(sha(read(path)) == state['binary_sha256'], 'saved native executable changed')
                    excluded[str(path)] = inputs[str(path)]
            require(errors == {'missing_method':'E0599','ambiguous':'E0034','type_error':'E0308',
                'borrow_error':'E0382','const_error':'E0080'}, 'uncalled diagnostic matrix differs')
            native = read(RAW / 'native')
            require(sha(native) == states[-1]['binary_sha256'], 'final native executable differs from restored state')
            excluded[str(RAW / 'native')] = dict(size=len(native), sha256=sha(native))
            for directory, prefix in [(RAW / 'logs','logs'), (RAW / 'state-sources','state-sources'),
                (RAW / 'frozen-inputs','frozen-inputs'), (SUPERVISOR,'fixture-supervisor')]:
                for path in sorted(directory.iterdir()):
                    add(path, prefix + '/' + path.name)
            for name in ['result.json','commands.json','states.json','compiler-ready.json','main.rs','external.rs']:
                add(RAW / name, 'run/' + name)
            add(Path(__file__), 'archive-helper.py')
            index = {name: dict(size=len(data),sha256=sha(data)) for name,data in sorted(members.items())}
            archive = OUT / 'evidence.tar.gz'
            with archive.open('xb') as output:
                with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for name,data in sorted(members.items()):
                            member = tarfile.TarInfo(name); member.size = len(data); member.mode = 0o444
                            tar.addfile(member, io.BytesIO(data))
            with tarfile.open(archive,'r:gz') as tar:
                require(tar.getnames() == sorted(index), 'archive member set differs')
                for member in tar:
                    data = tar.extractfile(member).read()
                    require(dict(size=len(data),sha256=sha(data)) == index[member.name], 'archive member differs')
            for path,expected in inputs.items():
                data = Path(path).read_bytes()
                require(dict(size=len(data),sha256=sha(data)) == expected, 'retained input changed')
            save(OUT / 'members.json', index)
            save(OUT / 'inputs.json', inputs)
            save(OUT / 'native-binary-hashes.json', excluded)
            receipt.update(status='passed', finished_at=time.time(), members=len(index),
                archive_size=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                fixture_validation_only=True, patched_compiler_qualified=False, index_enabled=False,
                commands=33, states=18, successful_native_states=13, error_codes=errors,
                source_restored=True, retained_inputs_unchanged=True, compiler_key=COMPILER,
                compiler_source_commit=COMMIT, performance_claim=False)
            save(RUN / 'result.json', receipt); save(OUT / 'summary.json', receipt)
            print(json.dumps(receipt))
    except BaseException as error:
        receipt.update(status='failed', finished_at=time.time(), error=repr(error))
        save(RUN / 'result.json', receipt)
        raise

if __name__ == '__main__':
    main()
