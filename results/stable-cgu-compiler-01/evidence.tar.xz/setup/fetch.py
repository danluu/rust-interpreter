import json,os,pathlib,shutil,subprocess,time
root=pathlib.Path.cwd();out=root/'.work/stable-cgu-compiler-setup-01';source=pathlib.Path('/Users/danluu/dev/rustc-stable-cgu-20260913');revision='cea272fa356e94bd2ee2cadf376630aa0683867a'
assert not source.exists()
r={'schema_version':1,'purpose':'owned exact pinned rustc source setup, no compiler or LLVM build','supervisor_pid':os.getpid(),'cwd':str(root),'source':str(source),'revision':revision,'started_at':time.time(),'free_bytes_before':shutil.disk_usage(root).free,'commands':[]}
def save():(out/'fetch-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
save();print('task-owned source supervisor',os.getpid(),flush=True)
commands=[(['git','init',str(source)],root),(['git','remote','add','origin','https://github.com/rust-lang/rust.git'],source),(['git','fetch','--depth','1','origin',revision],source),(['git','checkout','-b','stable-cgu-prototype','FETCH_HEAD'],source),(['git','branch','pinned-base',revision],source)]
for index,(cmd,cwd) in enumerate(commands):
 row={'command':cmd,'cwd':str(cwd),'started_at':time.time(),'log':str(out/f'fetch-{index}.log')};r['commands'].append(row)
 with open(row['log'],'w') as log:
  child=subprocess.Popen(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT);row['pid']=child.pid;save();print('task-owned source PID',child.pid,'stage',index,flush=True)
  while child.poll() is None:
   try:child.wait(timeout=30)
   except subprocess.TimeoutExpired:print('source stage still running',index,'PID',child.pid,flush=True)
 row['returncode']=child.returncode;row['finished_at']=time.time();save();print(pathlib.Path(row['log']).read_text()[-2000:],flush=True)
 if child.returncode:raise SystemExit(child.returncode)
r['actual_revision']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert r['actual_revision']==revision
r['free_bytes_after']=shutil.disk_usage(root).free;r['finished_at']=time.time();save()
