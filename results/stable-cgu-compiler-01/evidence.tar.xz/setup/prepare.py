import hashlib,json,os,pathlib,shutil,subprocess,tarfile,time,urllib.request
root=pathlib.Path.cwd();out=root/'.work/stable-cgu-compiler-setup-01';source=pathlib.Path('/Users/danluu/dev/rustc-stable-cgu-20260913');revision='cea272fa356e94bd2ee2cadf376630aa0683867a'
r={'schema_version':1,'purpose':'prebuilt matching LLVM and required source preparation; no build','supervisor_pid':os.getpid(),'started_at':time.time(),'free_bytes_before':shutil.disk_usage(root).free,'commands':[]}
def save():(out/'prepare-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
save();print('task-owned prepare supervisor',os.getpid(),flush=True)
archive=out/'rust-dev-nightly-aarch64-apple-darwin.tar.xz';url='https://ci-artifacts.rust-lang.org/rustc-builds/'+revision+'/'+archive.name
r['download']={'url':url,'started_at':time.time()};save()
with urllib.request.urlopen(url,timeout=60) as response,archive.open('wb') as f:shutil.copyfileobj(response,f)
r['download'].update({'finished_at':time.time(),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()});save()
llvm=source/'.ci-llvm';llvm.mkdir()
with tarfile.open(archive) as tar:
 members=tar.getmembers();r['download']['unpacked_bytes']=sum(m.size for m in members)
 for member in members:
  parts=pathlib.PurePosixPath(member.name).parts
  if len(parts)<3 or parts[1]!='rust-dev':continue
  name=pathlib.PurePosixPath(*parts[2:]);assert not name.is_absolute() and '..' not in name.parts
  member.name=str(name);tar.extract(member,llvm)
r['llvm_root']=str(llvm);save()
for index,cmd in enumerate([['git','submodule','update','--init','--depth','1','--','library/backtrace'],[str(llvm/'bin/llvm-config'),'--version','--libdir','--link-shared','--libs']]):
 row={'command':cmd,'cwd':str(source),'started_at':time.time(),'log':str(out/f'prepare-{index}.log')};r['commands'].append(row)
 with open(row['log'],'w') as log:
  child=subprocess.Popen(cmd,cwd=source,stdout=log,stderr=subprocess.STDOUT);row['pid']=child.pid;save();print('task-owned prepare PID',child.pid,'stage',index,flush=True)
  while child.poll() is None:
   try:child.wait(timeout=30)
   except subprocess.TimeoutExpired:print('prepare still running',index,child.pid,flush=True)
 row['returncode']=child.returncode;row['finished_at']=time.time();save();print(pathlib.Path(row['log']).read_text()[-2000:],flush=True)
 if child.returncode:raise SystemExit(child.returncode)
r['free_bytes_after']=shutil.disk_usage(root).free;r['finished_at']=time.time();save()
