"""Read completed preparation metadata/sources; no target imports or workloads."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat

ROOT = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
R = Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
A = Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
SOURCE = ROOT/'experiments/runtime-installation-after-preflight05-02'
PACKET = SOURCE/'installation-plan-01'
E = R/'.work/hir-options-hash-runtime-installation-preparation-execution-06'
FIELDS = ('dev', 'ino', 'mode', 'nlink', 'size', 'mtime_ns', 'ctime_ns')
CHECKED = {}


def raw(path):
    path = Path(path)
    before = path.lstat()
    assert path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
    identity = {key: getattr(before, 'st_'+key) for key in FIELDS}
    assert before.st_size <= 64*2**20
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        assert {key: getattr(os.fstat(stream.fileno()), 'st_'+key) for key in FIELDS} == identity
        data = stream.read(64*2**20+1)
        assert {key: getattr(os.fstat(stream.fileno()), 'st_'+key) for key in FIELDS} == identity
    assert {key: getattr(path.lstat(), 'st_'+key) for key in FIELDS} == identity
    assert len(data) == before.st_size
    row = dict(size=len(data), sha256=hashlib.sha256(data).hexdigest(), identity=identity)
    assert str(path) not in CHECKED or CHECKED[str(path)] == row
    CHECKED[str(path)] = row
    return data, row


def doc(path):
    return json.loads(raw(path)[0])


def ref(path):
    return dict(path=str(path), sha256=raw(path)[1]['sha256'])


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)+'\n').encode()


record = doc(E/'record.json')
assert ref(E/'record.json')['sha256'] == '2979f64660c2154d6fda90da711f3c967e15442cdb93191ff854ced5385c90f8'
assert record['status'] == 'finished' and record['returncode'] == 0 and record['preparation_passed'] is True
assert record['pid'] == 12064 and record['parent_pid'] == 11348 and not record['observation_errors']
assert not record['signals'] and record['compiler_calls'] == record['provider_probes'] == 0
assert record['started_at'] <= record['child_started_at'] <= record['finished_at'] <= record['readback_finished_at']
assert record['capacity'] == dict(entry_gib=16, live_gib=9, floor_gib=8)
assert record['entry_free_bytes'] >= 16*2**30 and all(s['free_bytes'] >= 9*2**30 for s in record['samples'])
assert {p.name for p in E.iterdir()} == {'record.json', 'launcher.py', 'invocation.json', 'source-rows.json', 'stdout', 'stderr', 'child-observation.json'}
for stream in ['stdout', 'stderr']:
    assert ref(E/stream)['sha256'] == record[stream+'_sha256']
assert raw(E/'stderr')[0] == b''
assert ref(E/'launcher.py')['sha256'] == ref(SOURCE/'prepare_once.py')['sha256'] == record['source_sha256']
assert ref(E/'child-observation.json')['sha256'] == record['child_observation_sha256']
observation = doc(E/'child-observation.json')
assert observation['status'] == 'returned' and observation['pid'] == record['pid'] and observation['parent_pid'] == record['parent_pid']
assert observation['blocked_events'] == [] and observation['command'] == record['producer_command']
assert record['child_started_at'] <= observation['started_at'] <= observation['finished_at'] <= record['finished_at']
invocation = doc(E/'invocation.json')
assert ref(record['invocation']['path'])['sha256'] == record['invocation']['sha256']
assert doc(record['invocation']['path']) == invocation and raw(E/'invocation.json')[0] == canonical(invocation)
source_rows = doc(E/'source-rows.json')
assert len(source_rows) == 502 and sum(r['size'] for r in source_rows.values()) == 5472654
for name, row in source_rows.items():
    assert raw(name)[1] == row

names = {'plan.json', 'inputs.json', 'snapshot-plan.json', 'launch.json', 'metadata-preflight.json', 'source-policy-proof.json', 'specification.json'}
assert set(record['outputs']) == {p.name for p in PACKET.iterdir()} == names
for name in names:
    assert raw(PACKET/name)[1] == record['outputs'][name]
plan, wire, snap, launch, metadata, spec = [doc(PACKET/n) for n in ['plan.json', 'inputs.json', 'snapshot-plan.json', 'launch.json', 'metadata-preflight.json', 'specification.json']]
routes = doc(SOURCE/'routes.json')
assert plan['attempt'] == ref(SOURCE/'routes.json')
assert plan['phase'] == metadata['phase'] == 'installation' and plan['status'] == 'prepared-unrun'
assert plan['owner'] == str(R) and plan['work'] == routes['work'] and plan['supervisor_work'] == routes['supervisor']
assert plan['capacity'] == launch['capacity'] == routes['capacity']
assert metadata['status'] == 'passed-read-only-discovery' and metadata['children'] == 0 and metadata['work_created'] is False
assert observation['started_at'] <= metadata['started_at'] <= metadata['finished_at'] <= observation['finished_at']
assert launch['status'] == 'prepared-unrun-awaiting-exact-review' and launch['cwd'] == str(R)
assert launch['inputs_sha256'] == snap['inputs_sha256'] == metadata['inputs_sha256'] == ref(PACKET/'inputs.json')['sha256']
assert launch['plan_sha256'] == wire['plan_sha256'] == ref(PACKET/'plan.json')['sha256']
assert launch['snapshot_plan_sha256'] == ref(PACKET/'snapshot-plan.json')['sha256']
assert launch['helper_sha256'] == ref(SOURCE/'entry.py')['sha256']
assert launch['command'] == [wire['python'], '-B', str(R/'scripts/supervise_experiment.py'), '--run-id', Path(routes['supervisor']).name, '--', wire['python'], '-B', str(SOURCE/'entry.py'), '--packet', str(PACKET), '--inputs-sha256', launch['inputs_sha256'], '--snapshot-plan-sha256', launch['snapshot_plan_sha256']]
assert plan['specification'] == ref(PACKET/'specification.json') and plan['source_policy'] == ref(PACKET/'source-policy-proof.json')

base_ref = wire['file_table_base']
assert ref(base_ref['path']) == base_ref
base = doc(base_ref['path'])
assert not set(base['files']) & set(wire['files'])
files = dict(base['files'], **wire['files'])
assert wire['file_table_integrity'] == dict(count=len(files), total_bytes=sum(r['size'] for r in files.values()), sha256=hashlib.sha256(canonical(files)).hexdigest())
assert len(files) == metadata['files'] == 113465 and sum(r['size'] for r in files.values()) == metadata['bytes'] == 6877209265
# The conservative preimport allowlist includes historical scripts not selected
# as current phase inputs. The producer explicitly retains the supplemental
# manifest and its complete rows, not every optional historical allowlist row.
manifest_path = invocation['adapter']['source_manifest']['path']
manifest_rows = doc(manifest_path)['files']
for name, row in dict(manifest_rows, **{manifest_path: raw(manifest_path)[1]}).items():
    assert files[name] == row
assert files[invocation['preflight']['path']] == raw(invocation['preflight']['path'])[1]
assert plan['source_preflight_readback']['audit'] == invocation['preflight']
assert plan['source_preflight_readback']['reference'] == plan['source_preflight'] == ref(Path(routes['preflight']['work'])/'source-probe/result.json')
for key, count in [('installation_qualification', 25), ('retry_qualification', 33)]:
    proof = plan[key]
    assert proof['controls'] == count and ref(proof['audit']['path']) == proof['audit']
    audit = doc(proof['audit']['path'])
    assert audit['status'] == 'verified' and audit['controls'] == count
    for name in ['receipt', 'result']:
        assert proof[name+'_sha256'] == audit[name+'_sha256'] == ref(Path(proof['evidence'])/(name+'.json'))['sha256']

startup = plan['startup_environment']
assert startup == metadata['startup_environment'] and startup['preparation_record'] == str(E/'record.json')
assert startup['preparer'] == ref(SOURCE/'prepare.py') and startup['source_manifest'] == invocation['adapter']['source_manifest']
derivation = startup['derivation']
assert derivation['passed'] == record['environment'] == observation['environments']['passed']
observed = dict(record['environment'], __CF_USER_TEXT_ENCODING='0x1F5:0x0:0x52')
assert all(observation['environments'][k] == observed for k in ['before_validation', 'before_producer_imports', 'at_return_or_failure'])
assert all(v == observed for v in derivation['observations'].values())
assert metadata['environment_at_completion'] == observed
assert '__CF_USER_TEXT_ENCODING' not in plan['environment']
assert launch['environment'] == plan['launch_environment'] == wire['launch_environment'] == derivation['launch_environment'] == dict(plan['environment'], __CF_USER_TEXT_ENCODING=observed['__CF_USER_TEXT_ENCODING'])

resources = plan['installation_resources']
destinations, directories = {}, {'.'}
for component in spec['components']:
    for name, row in component['files'].items():
        dest = PurePosixPath(component['destination'])/name
        assert not dest.is_absolute() and '..' not in dest.parts and str(dest) not in destinations
        destinations[str(dest)] = row
        directories.update(map(str, dest.parents))
rounded = lambda size: (size+4095)//4096*4096
assert len(destinations) == resources['copied_files'] == 3708
assert sum(v['size'] for v in destinations.values()) == resources['logical_bytes'] == 636631680
assert sum(rounded(v['size']) for v in destinations.values()) == resources['rounded_payload_bytes'] == 645951488
assert len(directories) == resources['sysroot_directories'] == 942
assert resources['policy'] == routes['installation_resources']
assert resources['directory_reservation_bytes'] == (len(directories)+1)*4096
assert resources['metadata_reservation_bytes'] == rounded(resources['admission_json_bytes'])+rounded(resources['ready_json_upper_bytes'])+resources['policy']['qualification_maximum_bytes']
assert resources['atomic_temporary_reservation_bytes'] == max(rounded(resources['admission_json_bytes']), rounded(resources['ready_json_upper_bytes']), resources['policy']['metadata_slack_bytes'])
assert resources['total_reserved_bytes'] == sum(resources[k] for k in ['rounded_payload_bytes', 'directory_reservation_bytes', 'metadata_reservation_bytes', 'atomic_temporary_reservation_bytes'])+resources['policy']['metadata_slack_bytes'] == 822697984
assert resources['total_reserved_bytes'] <= resources['policy']['prefix_limit_bytes'] == 2**30
assert resources['loader_children'] == len(spec['loader']) == 10
assert launch['children'] == resources['total_children'] == len(plan['children']) == 15
sysroot, work = Path(plan['sysroot']), Path(plan['work'])
rustc = str(sysroot/'bin/rustc')
child_env = dict(plan['environment'], PATH=str(sysroot/'bin')+':'+plan['environment']['PATH'], RUSTC=rustc)
expected = [[['/usr/bin/otool', '-l', str(sysroot/name)], str(R), [0], str(work/'commands'/f'{n:03d}')] for n, name in enumerate(sorted(spec['loader']))]
expected += [[[rustc, *flags], str(R), [0], str(work/'commands'/f'{n:03d}')] for n, flags in enumerate([['-vV'], ['--print', 'sysroot'], ['-Zhelp']], 10)]
probe = work/'source-probe'
common = [rustc, str(probe/'source.rs'), '--crate-type=lib', '--edition=2024', '--emit=metadata', '--error-format=json', '--sysroot', str(sysroot)]
expected += [[common+extra+['-o', str(probe/(name+'.rmeta'))], str(probe), [1], str(probe/'commands'/str(n))] for n, (name, extra) in enumerate([('local', []), ('virtual', ['-Ztranslate-remapped-path-to-local-path=no'])])]
assert plan['children'] == [dict(argv=argv, cwd=cwd, expected=rc, output=out, environment=child_env) for argv, cwd, rc, out in expected]

projection = snap['projection']
assert set(projection['files']) == set(wire['snapshot_inputs']) | {str(PACKET/'inputs.json')}
assert len(projection['files']) == 274 and len(projection['blobs']) == 248 and len(projection['reuse']) == 219
for name, row in projection['files'].items():
    assert row == dict(path=name, **raw(name)[1])
    if name != str(PACKET/'inputs.json'):
        assert files[name] == {k:v for k,v in row.items() if k != 'path'}
assert projection['logical_bytes'] == sum(r['size'] for r in projection['files'].values()) == 97120944
assert set(projection['blobs']) == {r['sha256'] for r in projection['files'].values()}
for digest, reference in projection['reuse'].items():
    data, row = raw(reference['path'])
    assert row['identity'] == reference['identity'] and row['sha256'] == reference['blob']['sha256']
    assert reference['blob'] == projection['blobs'][digest] and len(data) == reference['blob']['compressed_bytes']
    h, count = hashlib.sha256(), 0
    with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
        while chunk := stream.read(2**20):
            count += len(chunk)
            assert count <= 64*2**20
            h.update(chunk)
    assert count == reference['blob']['logical_bytes'] and h.hexdigest() == digest
assert snap['measured_existing_evidence_bytes']+snap['projected_reservation_bytes'] == 249704448 <= snap['evidence_cap_bytes'] == 256*2**20
assert projection['new_compressed_allocated_bytes']+projection['manifest_reservation_bytes']+snap['remaining_evidence_reservation_bytes'] == snap['projected_reservation_bytes']
absent = [Path(routes[k]) for k in ['work', 'supervisor', 'launcher_execution']] + [sysroot.parent]
assert all(not os.path.lexists(p) for p in absent)
assert raw(E/'record.json')[1]['sha256'] == '2979f64660c2154d6fda90da711f3c967e15442cdb93191ff854ced5385c90f8'
report = dict(status='completed-installation06-preparation-packet-readback-passed',
    scope='All seven packet bytes and metadata, closed preparation/raw/source rows, all selected logical snapshot bytes and reused gzip EOF. Full provider/SDK payload inventory is not independently reread here; preparation performed its frozen full guards.',
    preparation=ref(E/'record.json'), reader=ref(Path(__file__).resolve()), outputs=record['outputs'],
    parent_pid=record['parent_pid'], child_pid=record['pid'], returncode=0,
    source_rows=len(source_rows), source_bytes=sum(r['size'] for r in source_rows.values()),
    reconstructed_files=len(files), reconstructed_bytes=metadata['bytes'], file_table_base=base_ref,
    selected_logical_files=len(projection['files']), selected_logical_bytes=projection['logical_bytes'],
    unique_projected_blobs=len(projection['blobs']), reused_blobs_full_gzip_eof=len(projection['reuse']), new_projected_blobs=len(projection['blobs'])-len(projection['reuse']),
    children=15, recipe_exactly_reconstructed=True, installation_resources=resources,
    evidence_existing_bytes=snap['measured_existing_evidence_bytes'], evidence_reserved_bytes=snap['projected_reservation_bytes'],
    evidence_cap_bytes=snap['evidence_cap_bytes'], workload_environment=plan['environment'], launch_environment=plan['launch_environment'],
    startup_observations_preserved=True, preflight=invocation['preflight'], installation_controls=invocation['adapter']['installation_controls'],
    fresh_output_paths=[str(p) for p in absent], provider_calls=0, compiler_calls=0, production_source_imports=0, installation_launched=False,
    checked_files=CHECKED)
output = A/'.work/runtime-installation06-prepared-packet-independent-readback-01.json'
data = (json.dumps(report, sort_keys=True, indent=2)+'\n').encode()
with output.open('xb') as stream:
    stream.write(data)
print(json.dumps(dict(path=str(output), sha256=hashlib.sha256(data).hexdigest(), checked_files=len(CHECKED))))
