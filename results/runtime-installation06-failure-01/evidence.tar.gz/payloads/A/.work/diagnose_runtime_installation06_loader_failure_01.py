"""Read only closed owner/raw loader evidence and the exact partial prefix metadata."""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time

ROOT = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
R = Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918')
A = Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
SOURCE = ROOT/'experiments/runtime-installation-after-preflight05-02'
PACKET = SOURCE/'installation-plan-01'
WORK = R/'.work/hir-options-hash-runtime-installation-06'
OUTER = R/'.work/experiments/hir-options-hash-runtime-installation-supervisor-06'
LAUNCHER = R/'.work/hir-options-hash-runtime-installation-launch-execution-06'
FIELDS = ('dev', 'ino', 'mode', 'size', 'mtime_ns', 'ctime_ns', 'nlink')
checked = {}
started = time.time()


def identity(path):
    s = Path(path).lstat()
    return {k:getattr(s, 'st_'+k) for k in FIELDS}


def raw(path):
    path = Path(path); before = identity(path)
    assert path.resolve(strict=True) == path and stat.S_ISREG(before['mode']) and before['size'] <= 16*2**20
    data = path.read_bytes()
    assert identity(path) == before and len(data) == before['size']
    row = dict(identity=before, size=len(data), sha256=hashlib.sha256(data).hexdigest())
    assert str(path) not in checked or checked[str(path)] == row
    checked[str(path)] = row
    return data


def doc(path):
    return json.loads(raw(path))


def ref(path):
    raw(path)
    return dict(path=str(path), sha256=checked[str(path)]['sha256'])


def parse_loads(text):
    """Independent saved-text parser; preserve order and every repeated command."""
    result = dict(rpaths=[], loads=[])
    blocks = re.split(r'(?m)^Load command \d+\s*$', text)[1:]
    assert blocks
    for block in blocks:
        match = re.search(r'(?m)^\s*cmd (LC_\w+)\s*$', block)
        assert match
        kind = match[1]
        assert kind != 'LC_DYLD_ENVIRONMENT'
        if kind == 'LC_RPATH':
            result['rpaths'].append(re.search(r'(?m)^\s*path (.+) \(offset \d+\)\s*$', block)[1])
        elif kind in {'LC_LOAD_DYLIB','LC_LOAD_WEAK_DYLIB','LC_REEXPORT_DYLIB','LC_LOAD_UPWARD_DYLIB','LC_LAZY_LOAD_DYLIB','LC_LOAD_DYLINKER'}:
            result['loads'].append([kind, re.search(r'(?m)^\s*name (.+) \(offset \d+\)\s*$', block)[1]])
        else:
            assert not kind.endswith('_DYLIB') or kind == 'LC_ID_DYLIB'
    return result


plan = doc(PACKET/'plan.json'); spec = doc(PACKET/'specification.json')
terminal = doc(WORK/'receipt.json'); outer = doc(OUTER/'status.json'); launcher = doc(LAUNCHER/'record.json')
assert terminal['status'] == 'failed' and terminal['error'] == "RuntimeError('actual runtime loader declaration differs')"
assert len(terminal['children']) == 10
assert outer['status'] == 'finished' and outer['returncode'] == 1
assert launcher['status'] == 'terminal-observed' and launcher['returncode'] == 1 and launcher['launcher_returncode'] == 0
assert terminal['pid'] == outer['child_pid'] == launcher['controller_pid'] == 87781
assert terminal['parent_pid'] == outer['supervisor_pid'] == launcher['supervisor_pid'] == 87735
assert terminal['finished_at'] <= outer['finished_at'] <= launcher['terminal_observed_at'] <= launcher['finished_at']
assert ref(OUTER/'status.json')['sha256'] == launcher['outer_sha256']
assert ref(OUTER/'plan.json')['sha256'] == outer['plan_sha256']
assert ref(OUTER/'command.log')['sha256'] == outer['log_sha256']
for name in ['stdout', 'stderr']:
    assert ref(LAUNCHER/name)['sha256'] == launcher[name+'_sha256']
assert ref(LAUNCHER/'launcher.py')['sha256'] == launcher['launcher_source_sha256'] == ref(SOURCE/'launch.py')['sha256']
assert ref(PACKET/'launch.json')['sha256'] == launcher['launch_sha256']
raw(R/'scripts/runtime_compiler.py')
raw(SOURCE/'controller.py')
assert len(spec['loader']) == 10 and len(plan['children']) == 15
observations, unavailable_cwd = [], []
for index, name in enumerate(sorted(spec['loader'])):
    declaration = plan['children'][index]
    command = WORK/'commands'/f'{index:03d}'
    receipt_path = command/'receipt.json'; child = doc(receipt_path)
    assert terminal['children'][index] == dict(path=str(receipt_path), pid=child['pid'], returncode=0, sha256=ref(receipt_path)['sha256'])
    assert child['status'] == 'finished' and child['returncode'] == 0
    assert child['supervisor_pid'] == terminal['pid'] and child['parent_pid'] == terminal['parent_pid']
    assert child['command'] == declaration['argv'] and child['cwd'] == declaration['cwd']
    assert child['environment'] == declaration['environment'] and child['expected'] == declaration['expected'] == [0]
    assert terminal['admitted_at'] <= child['started_at'] <= child['finished_at'] <= terminal['finished_at']
    for stream in ['stdout', 'stderr']:
        assert ref(command/stream)['sha256'] == child[stream+'_sha256']
    assert not raw(command/'stderr')
    text = raw(command/'stdout').decode('utf-8', 'strict')
    actual = parse_loads(text)
    markers = list(re.finditer(r'(?m)^'+re.escape(str(Path(plan['sysroot'])/name))+r' \(architecture ([^)]+)\):\s*$', text))
    slices = []
    for number, match in enumerate(markers):
        end = markers[number+1].start() if number+1 < len(markers) else len(text)
        value = parse_loads(text[match.end():end])
        slices.append(dict(architecture=match[1], declaration=value, equals_declared=value == spec['loader'][name]))
    if child['identity']['cwd_returncode'] != 0:
        unavailable_cwd.append(dict(pid=child['pid'], output=str(command), observation=child['identity']))
    observations.append(dict(path=name, receipt=ref(receipt_path), stdout=ref(command/'stdout'),
        declared=spec['loader'][name], parsed_all_sections=actual, matches=actual == spec['loader'][name],
        architecture_sections=slices, actual_pid=child['pid'], returncode=child['returncode']))
different = [row for row in observations if not row['matches']]
assert [row['path'] for row in different] == [f'lib/librustc-beta_rt.{name}.dylib' for name in ['asan','lsan','rtsan','tsan']]
for row in different:
    assert [s['architecture'] for s in row['architecture_sections']] == ['x86_64','x86_64h','arm64']
    assert all(s['equals_declared'] for s in row['architecture_sections'])
    assert row['parsed_all_sections'] == dict(rpaths=row['declared']['rpaths']*3, loads=row['declared']['loads']*3)

prefix = Path(plan['sysroot']).parent
assert prefix == R/'.work/runtime-compilers'/plan['runtime_key']
assert {p.name for p in prefix.iterdir()} == {'sysroot','admission.json','failure.json'}
admission = doc(prefix/'admission.json'); failure = doc(prefix/'failure.json')
assert admission['identity']['admission'] == spec
assert failure == dict(error='actual runtime loader declaration differs', key=plan['runtime_key'])
assert not os.path.lexists(prefix/'ready.json') and not os.path.lexists(prefix/'qualification.json')
assert not os.path.lexists(WORK/'source-probe')


def census():
    found = {}
    stack = [prefix]
    while stack:
        path = stack.pop(); stamp = identity(path)
        name = '.' if path == prefix else str(path.relative_to(prefix))
        assert stat.S_ISREG(stamp['mode']) or stat.S_ISDIR(stamp['mode'])
        found[name] = stamp
        assert len(found) <= 10000
        if stat.S_ISDIR(stamp['mode']):
            stack.extend(sorted(path.iterdir(), reverse=True))
    return found


partial = census()
assert census() == partial
assert {name.removeprefix('sysroot/') for name, stamp in partial.items() if name.startswith('sysroot/') and stat.S_ISREG(stamp['mode'])} == set(admission['identity']['files'])
metadata_bytes = sum(stamp['size'] for stamp in partial.values() if stat.S_ISREG(stamp['mode']))
report = dict(status='closed-installation06-failure-after-ten-successful-loader-processes',
    pid=os.getpid(), parent_pid=os.getppid(), started_at=started, finished_at=time.time(),
    preparation=ref(R/'.work/hir-options-hash-runtime-installation-preparation-execution-06/record.json'),
    receipt=ref(WORK/'receipt.json'), outer=ref(OUTER/'status.json'), launcher=ref(LAUNCHER/'record.json'),
    actual_supervisor_pid=87735, actual_controller_pid=87781, actual_loader_children=10,
    planned_children=15, actual_compiler_cli_children=0, actual_source_probe_children=0,
    all_ten_children_closed_zero=True, observed_children=observations,
    unavailable_contemporaneous_cwd=unavailable_cwd,
    diagnosis='Four universal sanitizer images emit three architecture sections under unqualified otool -l. The runtime text parser concatenates all sections; each saved section individually equals the declared loader record. Other six images match. No deduplication or command reinterpretation is used to relabel this failed attempt.',
    failed_comparisons=4, matched_comparisons=6, partial_prefix=str(prefix),
    partial_prefix_metadata=partial, partial_regular_file_bytes=metadata_bytes,
    payload_bytes_independently_rehashed=False, prefix_metadata_stable_two_walks=True,
    ready_absent=True, qualification_absent=True, source_probe_absent=True,
    runtime_qualified=False, source_or_prefix_mutations=False, new_provider_or_compiler_calls=0,
    evidence=checked, reader=ref(Path(__file__).resolve()))
output = A/'.work/runtime-installation06-loader-failure-readback-01.json'
data = (json.dumps(report, sort_keys=True, indent=2)+'\n').encode()
with output.open('xb') as stream:
    stream.write(data)
print(json.dumps(dict(path=str(output), sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
    actual_children=10, mismatches=4, metadata_entries=len(partial))))
