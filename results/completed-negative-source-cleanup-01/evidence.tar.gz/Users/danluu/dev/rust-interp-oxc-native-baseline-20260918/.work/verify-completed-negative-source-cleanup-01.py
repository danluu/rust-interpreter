import gzip,hashlib,json,stat
import tarfile
from pathlib import Path
O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
R=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
W=O/'.work/completed-negative-source-cleanup-01'
P=O/'experiments/completed-negative-source-cleanup/plan-01'
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def identity(p,keys):
 s=p.lstat();return {k:getattr(s,'st_'+k) for k in keys}
r=read(W/'receipt.json');a=read(O/'.work/completed-negative-source-assessment-01.json');plan=read(P/'plan.json')
op=O/'.work/experiments/completed-negative-source-cleanup-supervisor-01'
outer=read(op/'status.json')
assert r['status']=='passed' and r['deleted_entries']==27657 and r['retained_originals_unchanged'] and r['all_six_negative_copies_absent']
assert outer['status']=='finished' and outer['returncode']==0 and r['pid']==outer['child_pid'] and r['parent_pid']==outer['supervisor_pid']
assert outer['started_at']<=r['started_at']<=r['admitted_at']<=r['finished_at']<=outer['finished_at']
assert sha(op/'plan.json')==outer['plan_sha256'] and sha(op/'command.log')==outer['log_sha256']
expected={str(Path(row['root'])/name) if name!='.' else row['root'] for row in a['roots'].values() for name in row['entries']}
assert all(not Path(row['root']).exists() and not Path(row['root']).is_symlink() for row in a['roots'].values())
ledger=[json.loads(line) for line in (W/'deleted.jsonl').read_text().splitlines()]
assert len(r['deleted'])==len(set(r['deleted']))==len(ledger)==len(expected)==27657
assert set(r['deleted'])==expected and [row['path'] for row in ledger]==r['deleted']
assert all(r['admitted_at']<=row['time']<=r['finished_at'] for row in ledger)
assert read(W/'admitted-inventory.json')=={name:row['entries'] for name,row in a['roots'].items()}
permissions=[json.loads(line) for line in (W/'directory-permissions.jsonl').read_text().splitlines()]
assert permissions==r['directory_permissions']
readonly={str(Path(row['root'])/name) if name!='.' else row['root']:v for row in a['roots'].values() for name,v in row['entries'].items() if stat.S_ISDIR(v['mode']) and not v['mode']&stat.S_IWUSR}
assert len(permissions)==len(readonly) and {x['path'] for x in permissions}==set(readonly)
for row in permissions:
 before,after=row['before'],row['after'];assert before==readonly[row['path']]
 assert all(before[k]==after[k] for k in ['dev','ino','nlink','size','mtime_ns']) and after['mode']==before['mode']|stat.S_IWUSR
 assert r['admitted_at']<=row['time']<=r['finished_at']
assert len(r['children'])==len(plan['commands'])==7
previous=r['admitted_at'];missing_cwd=[]
for item,spec in zip(r['children'],plan['commands'],strict=True):
 p=Path(item['path']);c=read(p);assert item['label']==spec['label'] and sha(p)==item['sha256']
 assert c['command']==spec['argv'] and c['cwd']==str(O) and c['environment']==plan['environment']
 assert c['status']=='finished' and c['returncode'] in spec['expected'] and c['supervisor_pid']==r['pid'] and c['parent_pid']==r['parent_pid']
 assert previous<=c['started_at']<=c['finished_at']<=r['finished_at'];previous=c['finished_at']
 for stream in ['stdout','stderr']:assert sha(p.parent/stream)==c[stream+'_sha256'] and (p.parent/stream).read_bytes()==b''
 actual=c['identity'];fields=actual['ps'].split(None,9)
 assert actual['ps_returncode']==0 and list(map(int,fields[:3]))==[c['pid'],r['pid'],c['pid']] and fields[8]=='??' and fields[9]==' '.join(c['command'])
 if actual['cwd_returncode']==0:assert actual['cwd'].splitlines()==[f'p{c["pid"]}','fcwd','n'+str(O)]
 else:assert actual['cwd_returncode']==1 and actual['cwd']=='' and item['label']=='owned-pids';missing_cwd.append(item['label'])
archives=[]
for directory,count in [(O/'results/completed-negative-source-preservation-01',4),(O/'results/completed-source-prefix-preservation-01',304),(R/'results/mono-production-source-observables-02',641)]:
 m=read(directory/'manifest.json');expanded=0
 with tarfile.open(directory/'evidence.tar.gz','r:gz') as t:
  members=t.getmembers();assert len(members)==count and {x.name for x in members}==set(m)
  for x in members:
   assert x.isfile() or x.islnk();value=t.extractfile(x).read();assert len(value)==m[x.name]['bytes'] and hashlib.sha256(value).hexdigest()==m[x.name]['sha256']
   if count==4:
    if x.name=='absence-and-origin.json':assert json.loads(value)==plan['deltas']
    else:assert value==b'X'*6751
  while t.fileobj.read(2**20):pass
 with gzip.open(directory/'evidence.tar.gz','rb') as f:
  while block:=f.read(2**20):expanded+=len(block)
 archives.append(dict(path=str(directory),members=count,expanded_bytes=expanded,archive_sha256=sha(directory/'evidence.tar.gz'),manifest_sha256=sha(directory/'manifest.json')))
assert archives[0]['archive_sha256']==r['retention']['archive_sha256'] and archives[0]['manifest_sha256']==r['retention']['manifest_sha256']
for name,row in a['retained_original_files'].items():
 p=Path(name);assert identity(p,row['identity'])==row['identity'] and sha(p)==row['sha256'] and identity(p,row['identity'])==row['identity']
for root,rows in a['retained_original_directories'].items():
 for name,row in rows.items():
  p=Path(root) if name=='.' else Path(root)/name;assert identity(p,row)==row
freeze=read(P/'inputs.json')
for name,row in freeze['files'].items():
 p=Path(name);assert identity(p,row['identity'])==row['identity'] and sha(p)==row['sha256']
result=dict(status='verified',receipt_sha256=sha(W/'receipt.json'),supervisor_sha256=sha(op/'status.json'),exact_deleted_entries=27657,readonly_children=7,directory_permissions=len(permissions),frozen_inputs=len(freeze['files']),retained_original_files=len(a['retained_original_files']),original_files_and_directories_unchanged=True,archives=archives,archive_full_gzip_eof=True,all_six_roots_absent=True,fast_child_cwd_probe_unavailable=missing_cwd,recorded_cwd_exact_for_all=True,finished_at=r['finished_at'],free_bytes_after=r['free_bytes_after'])
out=O/'.work/completed-negative-source-cleanup-actual-verification-01.json'
with out.open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(dict(path=str(out),sha256=sha(out),**result),indent=2))
