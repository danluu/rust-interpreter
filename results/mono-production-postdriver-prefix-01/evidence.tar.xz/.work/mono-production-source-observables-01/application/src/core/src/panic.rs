pub fn run() { crate::show("std-looking", file!(), path_probe::observe!(marker)); }
