// phase:000000000000000
#[path="core/src/panic.rs"] mod std_looking;
pub fn show(label: &str, file: &str, value: (&str, &str, u32, u32)) {
 println!("{}|{}|{}|{}|{}|{}", label, file, value.0, value.1, value.2, value.3);
}
pub fn entry() { show("main", file!(), path_probe::observe!(marker)); std_looking::run(); }
fn main() { entry(); }
