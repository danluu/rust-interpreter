import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture,require_space,write_json
from custom_compiler import load_compiler
DRIVER=Path('/Users/danluu/dev/rust-interp-stable-mono-compiler-build-20260913')
RAW=DRIVER/'.work/mono-production-build-02'
WORK=ROOT/'.work/mono-production-import-02';WORK.mkdir(exist_ok=False)
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
SOURCE='58e1e1f5311f4424ea81def4763081f6da62d9b3'
STAGES=['prepare','freeze-source','stage1','stage1-controls','stage2','option-hash','stage2-controls','dist','package','native-controls','strip-controls','complete']
record=dict(status='waiting-preflight',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),lock=str(LOCK),preflight_wait=600,importer_wait=45,stages=STAGES)
def save():write_json(WORK/'result.json',record)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
proof={}
def retain(path):
 path=Path(path);data=path.read_bytes();proof[str(path)]=hashlib.sha256(data).hexdigest()
 target=WORK/'driver-proof'/path.relative_to(DRIVER);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 return json.loads(data)
record['prior_attempt']=dict(path=str(ROOT/'.work/mono-production-import-01/result.json'),sha256=sha(ROOT/'.work/mono-production-import-01/result.json'),reason='checker incorrectly used queue-start timestamps instead of canonical admission order; importer was not started')
save()
try:
 assert os.path.samefile(ROOT/'.work/benchmark.lock',LOCK)
 with LOCK.open('r+') as lock:
  acquire_lock(lock,600);record.update(status='preflight',admitted_at=time.time(),revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip());save()
  completed=retain(RAW/'completed.json');assert set(completed)==set(STAGES)
  prior=0;receipts={}
  for stage in STAGES:
   ref=completed[stage];assert sha(ref['path'])==ref['sha256'];r=retain(Path(ref['path']))
   assert r['stage']==stage and r['status']=='passed' and r['returncode']==0
   assert r['started_at']<=r['admitted_at']<=r['finished_at'] and r['admitted_at']>=prior
   prior=r['finished_at'];receipts[stage]=r
   for command in r['commands']:
    path=Path(command['receipt']);assert sha(path)==command['sha256']
    actual=json.loads(path.read_bytes());assert actual['status']=='finished' and actual['returncode']==command['returncode'] and actual['command']==command['command']
    proof[str(path)]=command['sha256']
  complete=receipts['complete'];assert complete['source_revision']==SOURCE
  package=Path(complete['package']);provenance_path=Path(complete['provenance'])
  assert package==RAW/'packaged-stage2-01' and provenance_path==RAW/'package-01/provenance.json'
  source=retain(RAW/'source.json');assert source['source_commit']==SOURCE and sha(RAW/'source.json')==complete['source_receipt_sha256']
  provenance=retain(provenance_path);package_record=retain(RAW/'package-01/receipt.json')
  assert provenance['stage']==2 and provenance['source_commit']==package_record['source_revision']==SOURCE
  assert provenance['package_mode']==package_record['package_mode']=='first-production'
  assert provenance['package_receipt_sha256']==sha(RAW/'package-01/receipt.json')==receipts['package']['package_receipt']['sha256']
  assert provenance['build_receipt_sha256']==completed['stage2-controls']['sha256'] and provenance['original_build_receipt_sha256']==completed['stage2']['sha256']
  assert provenance['dist_receipt_sha256']==completed['dist']['sha256']
  assert provenance['patch_sha256']==source['combined_patch_sha256']==sha(RAW/'combined-upstream.patch')
  assert provenance['bootstrap_sha256']==source['config_sha256']==complete['config_sha256']
  assert provenance['std_source_paths']==package_record['std_source_paths']
  cap=retain(RAW/'source-capability.json');assert cap==provenance['std_source_paths'] and sha(RAW/'source-capability.json')==provenance['source_capability_sha256']
  assert cap['virtual_rust_source_base_dir']=='/rustc/'+SOURCE and cap['virtual_rustc_dev_source_base_dir']=='/rustc-dev/'+SOURCE
  assert package_record['native_source_probe']['diagnostics_rewritten'] is False and package_record['native_source_probe']['strict_integration_required'] is True
  for stage in ['native-controls','strip-controls']:
   ref=receipts[stage]['control_result'];assert sha(ref['path'])==ref['sha256'];assert retain(Path(ref['path']))['status']=='passed'
  ordinary_files={}
  for path in package.rglob('*'):
   assert not path.is_symlink(),str(path)
   if path.is_file():ordinary_files[str(path.relative_to(package))]=sha(path)
   else:assert path.is_dir()
  assert ordinary_files==package_record['files'] and len(ordinary_files)==6902
  package_bytes=sum((package/name).stat().st_size for name in ordinary_files)
  assert shutil.disk_usage(ROOT).free>=package_bytes+8*1024**3
  require_space(ROOT,8)
  paths=set((ROOT/'scripts').glob('*.py'))|set((ROOT/'tests').glob('*.py'))|{ROOT/name for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']}|{p for p in (ROOT/'crates').rglob('*') if p.is_file()}|set((ROOT/'experiments/stable-cgu').glob('*.py'))|set((ROOT/'experiments/stable-cgu').glob('*.md'))|{Path(__file__)}
  frozen={}
  for path in sorted(paths):
   assert path.resolve(strict=True)==path and not path.is_symlink()
   data=path.read_bytes();frozen[str(path.relative_to(ROOT))]=hashlib.sha256(data).hexdigest()
   target=WORK/'source'/path.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  write_json(WORK/'source-manifest.json',frozen);write_json(WORK/'driver-proof-manifest.json',proof)
  write_json(WORK/'package-files.json',ordinary_files)
  record.update(status='preflight-passed',source_commit=SOURCE,package=str(package),provenance=str(provenance_path),package_files=len(ordinary_files),package_bytes=package_bytes,source_files=len(frozen),driver_receipts_verified=len(completed),free_bytes_before_import=shutil.disk_usage(ROOT).free,preflight_finished_at=time.time());save()
 # The existing importer acquires the same canonical alias itself: no nested flock.
 command=[sys.executable,'-B',str(ROOT/'scripts/custom_compiler.py'),'--install-from',str(package),'--provenance',str(provenance_path)]
 child,out,err=capture(command,cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),receipt_path=WORK/'import-process.json',receipt=dict(source_commit=SOURCE))
 (WORK/'stdout').write_text(out);(WORK/'stderr').write_text(err)
 record.update(importer_pid=child.pid,importer_returncode=child.returncode);save()
 assert child.returncode==0,'compiler importer failed; preserve this attempt'
 actual=json.loads(out);compiler=load_compiler(ROOT,actual['compiler_key'])
 assert compiler.identity['files']==ordinary_files and compiler.identity['provenance']==provenance
 assert compiler.identity['provenance']['source_commit']==SOURCE
 assert {'stable-cgu-partitioning','stable-mono-cgu-partitioning'}<=set(compiler.identity['unstable_options']['supported'])
 assert all(sha(ROOT/name)==h for name,h in frozen.items()),'frozen source changed'
 record.update(status='passed',compiler_key=compiler.key,sysroot=str(compiler.sysroot),source_unchanged=True,finished_at=time.time(),free_bytes_after=shutil.disk_usage(ROOT).free);save()
 print(json.dumps({k:record[k] for k in ['status','pid','importer_pid','compiler_key','sysroot','package_files','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());save();raise
