#!/usr/bin/env python3
"""Preserve accepted metadata03 and failed01/02; never inspect live runtime files."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-runtime-metadata-evidence-20260913')
METADATA = Path('/Users/danluu/dev/rust-interp-runtime-installation-metadata-20260913')
RAW = METADATA / '.work/runtime-installation-inspection-03'
SOURCE = METADATA / 'experiments/runtime-compiler-installation/metadata-03'
OUT = ROOT / 'results/runtime-installation-metadata-03'
WORK = ROOT / '.work/runtime-installation-metadata-archive-01'
OWNED = ROOT / 'experiments/stable-cgu/owned_stage.py'
README = ROOT / '.work/runtime-installation-metadata-archive-README-01.md'
EXPECTED = '14a140927ce8a559bc7487b0622aaa7d3f00238b7bb58dd8435601d9b277f5fc'
NATIVE = Path('/Users/danluu/dev/rust-interp-hir-native-controls-evidence-20260913/results/hir-arena-native-qualification-01/evidence.tar.gz')
NATIVE_SHA = '373719cd01be1ba923581345481ff4b1dfd2e2623cf37cc6c5de7cc0a8fcd700'


def digest(data):
    return hashlib.sha256(data).hexdigest()


assert digest(OWNED.read_bytes()) == '7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e'
sys.path.insert(0, str(OWNED.parent))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write


def ordinary(path):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path
            and stat.S_ISREG(path.lstat().st_mode), 'nonordinary evidence path: ' + str(path))
    return path


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--helper-sha', required=True)
    parser.add_argument('--readme-sha', required=True)
    args = parser.parse_args()
    require(sys.dont_write_bytecode and not sys.flags.optimize and Path.cwd() == ROOT,
            'fixed cwd and Python -B required')
    require(Path(__file__).resolve() == ROOT / '.work/archive_runtime_metadata_03.py'
            and sha(__file__) == args.helper_sha and sha(ordinary(README)) == args.readme_sha,
            'reviewed archive source changed')
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
        started_at=time.time(), helper_sha256=args.helper_sha, lock=str(CANONICAL_LOCK),
        lock_wait_seconds=600, compiler_commands=0, live_runtime_or_source_inspection=False)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            selected = {}

            def capture(path, expected=None, *, origin=None):
                path = ordinary(path)
                data = path.read_bytes()
                row = dict(source=str(path), sha256=digest(data), bytes=len(data))
                if origin is not None:
                    row['origin'] = str(origin)
                require(expected is None or row['sha256'] == expected, 'evidence changed: ' + str(path))
                require(str(path) not in selected or selected[str(path)] == row,
                        'evidence binding changed during capture')
                selected[str(path)] = row
                return data

            current = json.loads(capture(RAW / 'receipt.json', EXPECTED))
            require(current['status'] == 'inspected-pending-review' and len(current['commands']) == 25
                    and current['source_unchanged'] and current['runtime_unchanged']
                    and current['candidate_is_not_installation'] and not current['installation']
                    and not current['application_qualified'] and not current['benchmark']
                    and not current['std_source_paths_qualified'] and not current['final_root_probes_run'],
                    'accepted metadata history or qualification limits differ')
            inputs = current['read_inputs']
            require(len(inputs) == 583 and sum(row['retained'] for row in inputs.values()) == 582,
                    'complete retained input map required')
            require({name for name, row in inputs.items() if not row['retained']} == {str(NATIVE)},
                    'unexpected external archive reference')
            require(inputs[str(NATIVE)]['sha256'] == NATIVE_SHA
                    and inputs[str(NATIVE)]['size'] == 47070795, 'native reference differs')

            def retained(path, expected=None):
                name = str(path)
                row = inputs[name]
                require(row['retained'] and (expected is None or row['sha256'] == expected),
                        'missing or mismatched retained origin')
                copied = RAW / 'inputs' / name.lstrip('/')
                data = capture(copied, row['sha256'], origin=name)
                require(len(data) == row['size'], 'retained origin size differs')
                return data

            for name, row in inputs.items():
                if row['retained']:
                    require(Path(name).suffix in ('', '.json', '.log', '.md', '.patch', '.py', '.stderr', '.stdout', '.toml', '.txt'),
                            'unexpected artifact or nested archive in retained proof map')
                    disk(ROOT)
                    retained(name)
            require({str(p) for p in (RAW / 'inputs').rglob('*') if p.is_file() or p.is_symlink()}
                    == {str(RAW / 'inputs' / name.lstrip('/')) for name, row in inputs.items() if row['retained']},
                    'retained snapshot membership differs')
            plan = json.loads(retained(SOURCE / 'inspection-plan-03.json', current['plan_sha256']))
            frozen = json.loads(retained(SOURCE / 'inspection-inputs-03.json', current['frozen_sha256']))
            require(current['plan_sha256'] == '995ae8eaed50432f66124c832dfc022eb1b0277cc1b1b0b3ab08e7cd7c91f60e'
                    and current['frozen_sha256'] == 'a6f2548d212a97b4408ef45dcc2b44fec5dc5cbd45bb5428ab53d5adda9b5f51'
                    and len(frozen['files']) == 477
                    and all(name in inputs and inputs[name]['sha256'] == value for name, value in frozen['files'].items()),
                    'current frozen source/plan associations differ')

            def envelope(stage, read_bytes, work, count, passed):
                require(stage['status'] == ('inspected-pending-review' if passed else 'failed')
                        and len(stage['commands']) == count and stage['owner'] == str(METADATA),
                        'metadata stage status/count differs')
                for index, ref in enumerate(stage['commands']):
                    path = Path(ref['path'])
                    require(path == work / 'commands' / f'{index:03}' / 'receipt.json', 'child receipt path differs')
                    child = json.loads(read_bytes(path, ref['sha256']))
                    require(child['status'] == 'finished' and child['returncode'] == ref['returncode'] == 0
                            and child['command'] == ref['command'] and child['pid'] == ref['pid']
                            and child['supervisor_pid'] == stage['pid'] and child['parent_pid'] == stage['parent_pid']
                            and list(map(int, child['identity']['ps'].split()[:2])) == [child['pid'], stage['pid']]
                            and stage['admitted_at'] <= child['started_at'] <= child['finished_at'] <= stage['finished_at'],
                            'actual child command/process/time association differs')
                    for stream in ('stdout', 'stderr'):
                        read_bytes(path.parent / stream, child[stream + '_sha256'])

            def outer_history(path, expected, read_bytes, stage, code):
                outer = json.loads(read_bytes(path, expected))
                outer_plan = json.loads(read_bytes(path.parent / 'plan.json', outer['plan_sha256']))
                require(outer['status'] == 'finished' and outer['returncode'] == code
                        and outer['cwd'] == outer_plan['owner'] == str(METADATA)
                        and outer['command'] == outer_plan['command'], 'outer supervisor differs')
                if stage is not None:
                    require(outer['child_pid'] == stage['pid'] and outer['supervisor_pid'] == stage['parent_pid']
                            and outer['started_at'] <= outer['child_started_at'] <= stage['started_at']
                                <= stage['admitted_at'] <= stage['finished_at'] <= outer['finished_at']
                            and outer['command'][2:] == stage['command'], 'outer/helper association differs')
                read_bytes(path.parent / 'command.log', outer['log_sha256'])
                read_bytes(path.parent / 'supervisor.log')
                return outer

            envelope(current, capture, RAW, 25, True)
            outer = outer_history(METADATA / '.work/experiments/runtime-installation-inspection-supervisor-03/status.json',
                'd2a25c422ca3d1721d5f8a236226affe294fc3bf3086f9e981fad4252e298b5a', capture, current, 0)
            failures = []
            for index, count in [(1, 166), (2, 473)]:
                ref = plan['evidence']['failed0' + str(index)]
                failure = json.loads(retained(ref['path'], ref['sha256']))
                require(failure['status'] == 'failed' and len(failure['files']) == count
                        and all(name in inputs and inputs[name]['retained']
                                and inputs[name]['sha256'] == value for name, value in failure['files'].items()),
                        'complete predecessor failure bytes required')
                failed_stage = None
                if index == 1:
                    require(failure['phase'] == 'startup-before-lock' and not failure['canonical_admission']
                            and not failure['stage_receipt_created'] and failure['compiler_or_git_children'] == 0,
                            'startup failure promoted to an admitted stage')
                    require(failure['error'] in retained(failure['log']).decode(), 'startup error raw evidence differs')
                else:
                    failed_stage = json.loads(retained(failure['stage'], failure['stage_sha256']))
                    require(failed_stage['error'] == failure['error'] == 'indirect selected Mach-O inspector'
                            and not failure['completion_claim'] and not failure['initial_component_snapshots_retained'],
                            'selected-tool failure reclassified')
                    envelope(failed_stage, retained, METADATA / '.work/runtime-installation-inspection-02', 6, False)
                failed_outer = outer_history(Path(failure['outer']), failure['outer_sha256'], retained, failed_stage, 1)
                if index == 1:
                    require((failed_outer['supervisor_pid'], failed_outer['child_pid']) == (41368, 41371),
                            'startup failure process identity differs')
                else:
                    require((failed_outer['supervisor_pid'], failed_outer['child_pid'])
                            == (failure['supervisor_pid'], failure['helper_pid']), 'failed02 process identity differs')
                failures.append(dict(reference=ref, status='failed', commands=0 if index == 1 else 6,
                                     phase=failure['phase'], error=failure['error']))

            launch = json.loads(capture(SOURCE / 'inspection-launch-03.json',
                '7979c00c148990515b9dc64a06d5dd6588cee5dbcecf9303dac41077d8125028'))
            admission = json.loads(capture(METADATA / '.work/runtime-installation-inspection-launch-admission-03.json',
                '394af93b651f844f342547b02ec927421f4e4aba96b2e0f1675b97f2fb626321'))
            require(launch['command'] == admission['command']
                    and launch['command'][launch['command'].index('--') + 1:] == outer['command']
                    and launch['environment'] == admission['environment'] == current['environment']
                    and launch['cwd'] == admission['cwd'] == str(METADATA)
                    and admission['status'] == 'launcher-finished' and admission['returncode'] == 0
                    and admission['frozen_sha256'] == current['frozen_sha256'],
                    'current saved launcher association differs')
            # Compare the saved launch bytes, not a reserialization.
            require(admission['launch_sha256'] == sha(SOURCE / 'inspection-launch-03.json')
                    and admission['python'] == frozen['python'], 'launch proof or Python differs')
            for stream in ('stdout', 'stderr'):
                data = capture(METADATA / ('.work/runtime-installation-inspection-launch-03.' + stream), admission[stream + '_sha256'])
                if stream == 'stdout':
                    require(json.loads(data)['supervisor_pid'] == outer['supervisor_pid'], 'launcher supervisor PID differs')
                else:
                    require(not data, 'unexpected launcher stderr')

            candidate = json.loads(capture(RAW / 'candidate-specification.json', current['specification_sha256']))
            initial = capture(RAW / 'components-initial.json', current['initial_components_sha256'])
            final = capture(RAW / 'components-and-stamps.json', current['components_sha256'])
            require(initial == final and current['specification_sha256'] == '1c0ec4abd1432baa8ba5fe24498af99dd8ae1975a0b3ceece4124409d235de33'
                    and current['components_sha256'] == 'd4d2739b1b3d11f37c3d2bf6c92131e5e250b1ca2d8c6088180d532517422070'
                    and 'std_source_paths' not in candidate['provenance'], 'candidate or initial/final proof differs')
            native_summary = json.loads(retained(plan['evidence']['native_summary']['path'], plan['evidence']['native_summary']['sha256']))
            native_manifest = json.loads(retained(plan['evidence']['native_manifest']['path'], plan['evidence']['native_manifest']['sha256']))
            require(native_summary['archive']['sha256'] == NATIVE_SHA
                    and native_summary['archive']['all_member_hashes_verified']
                    and native_summary['archive']['bytes'] == 47070795
                    and len(native_manifest) == native_summary['archive']['members'] == 1012
                    and native_summary['manifest_sha256'] == plan['evidence']['native_manifest']['sha256'],
                    'existing native archive reference differs')

            def guard():
                disk(ROOT)
                for row in selected.values():
                    require(sha(ordinary(row['source'])) == row['sha256'], 'selected evidence changed')
                require(ordinary(NATIVE).stat().st_size == 47070795 and sha(NATIVE) == NATIVE_SHA,
                        'referenced native archive changed')

            readme = capture(README, args.readme_sha)
            for path in [Path(__file__), OWNED, ROOT / 'scripts/supervise_experiment.py',
                         ROOT / '.work/runtime-installation-metadata-archive-launch-01.json']:
                capture(path)
            guard()
            OUT.mkdir(parents=True, exist_ok=False)
            archive = OUT / 'evidence.tar.gz'
            manifest, first = {}, {}
            with archive.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for name, row in sorted(selected.items()):
                            disk(ROOT)
                            data = Path(name).read_bytes()
                            require(digest(data) == row['sha256'], 'evidence changed during compression')
                            member = name.lstrip('/')
                            info = tarfile.TarInfo(member)
                            info.mode, info.mtime = 0o644, 0
                            key = (row['sha256'], row['bytes'])
                            if key in first:
                                info.type, info.linkname = tarfile.LNKTYPE, first[key]
                                tar.addfile(info)
                            else:
                                info.size = len(data)
                                tar.addfile(info, io.BytesIO(data))
                                first[key] = member
                            manifest[member] = row
            seen = set()
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    disk(ROOT)
                    require(member.name in manifest and member.name not in seen
                            and (member.isfile() or member.islnk()), 'invalid archive member')
                    if member.islnk():
                        require(member.linkname in seen and manifest[member.linkname]['sha256'] == manifest[member.name]['sha256'],
                                'invalid deduplicated payload link')
                    with tar.extractfile(member) as stream:
                        data = stream.read()
                    item = manifest[member.name]
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback differs')
                    seen.add(member.name)
            require(seen == set(manifest), 'archive readback incomplete')
            guard()
            write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed', metadata_owner=str(METADATA),
                metadata_receipt_sha256=EXPECTED, metadata_commands=25, retained_input_payloads=582,
                source_inputs=len(frozen['files']), failures=failures,
                candidate_key=current['candidate_key'], candidate_specification_sha256=current['specification_sha256'],
                components_sha256=current['components_sha256'], component_file_counts=current['component_file_counts'],
                candidate_is_not_installation=True, std_source_paths_qualified=False, application_qualified=False,
                benchmark=False, publication=False, live_runtime_or_source_revalidated_by_archival=False,
                native_archive_reference=dict(path=str(NATIVE), sha256=NATIVE_SHA, bytes=47070795,
                    manifest_sha256=plan['evidence']['native_manifest']['sha256'], summary_sha256=plan['evidence']['native_summary']['sha256']),
                archive=dict(path=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
                    members=len(manifest), physical_members=len(first), all_member_hashes_verified=True, gzip_mtime=0),
                manifest_sha256=sha(OUT / 'manifest.json'), archive_helper_sha256=args.helper_sha,
                archive_pid=os.getpid(), archive_parent_pid=os.getppid(), archive_admitted_at=record['admitted_at'],
                native_artifacts_archived=False, nested_archives=False, compiler_commands=0)
            write(OUT / 'summary.json', summary)
            (OUT / 'README.md').write_bytes(readme)
            record.update(status='passed', finished_at=time.time(), free_bytes_after=disk(ROOT),
                result=str(OUT), archive=summary['archive'], summary_sha256=sha(OUT / 'summary.json'))
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
