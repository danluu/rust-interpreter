import gzip,hashlib,json,os,shutil,stat,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
from custom_compiler import load_compiler
from workflow_io import capture,write_json
proof=Path('/Users/danluu/dev/rust-interp-std-source-v2-20260913/.work/obsolete-compiler-package-inspection-01')
work=root/'.work/strict-warm-build/obsolete-package-retirement-05'
work.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=dict(status='waiting',owner=str(root),pid=os.getpid(),started_at=time.time(),deleted=[],benchmark_commands=0)
write_json(work/'summary.json',record)
try:
 with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('r+') as lock:
  acquire_lock(lock,600)
  record.update(lock_acquired_at=time.time(),free_bytes_before=shutil.disk_usage(root).free,canonical_lock=str(Path(lock.name)))
  inspection=json.loads((proof/'inspection.json').read_bytes())
  assert sha(proof/'inspection.json')=='40df53857d8c73780b3ee2c1ef9120373692837388961d1321621070e73ec7d6'
  assert sha(proof/'inventory.jsonl.gz')==inspection['inventory_sha256']=='888b70ea3e07cace0af31869336e0c89d7bb4605a730b1c7057524df6ce07c6c'
  base=Path('/Users/danluu/dev/rust-interp-stable-cgu-20260913/.work/stable-cgu-compiler-build-01')
  selected=[base/'packaged-stage2-03',base/'packaged-stage2-05']
  assert {p['path'] for p in inspection['candidates']}==set(map(str,selected)) and inspection['no_users_proved']
  for p in selected: assert p.resolve(strict=True)==p and p.is_dir() and not p.is_symlink()
  for name,field in [('comparison-maps.json','comparison_maps_sha256'),('retained-evidence.json','retained_evidence_sha256'),('publication-documents.json','publication_documents_sha256')]:
   assert sha(proof/name)==inspection[field]
  comparisons=json.loads((proof/'comparison-maps.json').read_bytes())
  retained=json.loads((proof/'retained-evidence.json').read_bytes())
  publications=json.loads((proof/'publication-documents.json').read_bytes())
  assert len(retained)==776 and len(publications)==24
  retained.update(publications)
  for p in selected:
   comparison=comparisons[str(p)]
   assert sha(Path(comparison['receipt']))==comparison['receipt_sha256']
   receipt=json.loads(Path(comparison['receipt']).read_bytes())
   assert receipt['files']==comparison['files'] and receipt['prefix']==str(p)
   assert sha(Path(comparison['native_control']))==comparison['native_control_sha256']
   assert comparison['native_states']==15 and json.loads(Path(comparison['native_control']).read_bytes())['status']=='passed'
   assert comparison['retained_package']==str(base/'packaged-stage2-06')
   assert comparison['retained_compiler']==str(root/'.work/compilers/60096d7efe02d38269c5694bfd046d4f9facfb65139b2d82173d12345a1c9c46/sysroot')
   for name,digest in comparison['files'].items():
    assert sha(p/name)==digest
    for key in ['retained_package','retained_compiler']:
     retained[str(Path(comparison[key])/name)]=digest
  for path,digest in retained.items():
   assert not any(Path(path).is_relative_to(p) for p in selected) and sha(Path(path))==digest
  for path in publications:
   assert not any(str(p) in Path(path).read_text() for p in selected)
  compiler=load_compiler(root,'60096d7efe02d38269c5694bfd046d4f9facfb65139b2d82173d12345a1c9c46')
  snapshots={p:{} for p in selected};inodes=set()
  with gzip.open(proof/'inventory.jsonl.gz','rt') as stream:
   for line in stream:
    row=json.loads(line);base=Path(row['root'])
    if base in snapshots:snapshots[base][row['path']]=row
  count=0
  for base,expected in snapshots.items():
   entries=[base,*base.rglob('*')];assert {str(p.relative_to(base)) for p in entries}==set(expected)
   for p in entries:
    row=expected[str(p.relative_to(base))];s=p.lstat()
    actual=dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink,blocks=s.st_blocks,link=os.readlink(p) if stat.S_ISLNK(s.st_mode) else None)
    assert all(actual[k]==row[k] for k in actual),(str(p),'candidate changed')
    inodes.add((s.st_dev,s.st_ino));count+=1
  # Inspect active handles and cwd aliases by both path and inode. Keep raw
  # host output local to memory; publish only its digest/count and matching rows.
  matches={}
  for label,argv in [('processes',['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,command=']),('handles',['/usr/sbin/lsof','-nP','-FpcftDin'])]:
   child,out,err=capture(argv,cwd=root,env=os.environ.copy(),receipt_path=work/(label+'-process.json'),receipt={})
   assert child.returncode==0 and not err.strip()
   found=[]
   if label=='processes':found=[line for line in out.splitlines() if any(str(p) in line for p in selected)]
   else:
    process={};entry={}
    def finish():
     name=entry.get('n','')
     try: inode=(int(entry.get('D',''),16),int(entry.get('i','')))
     except ValueError:inode=None
     if inode in inodes or any(name==str(p) or name.startswith(str(p)+'/') for p in selected):found.append(dict(process=process.copy(),file=entry.copy()))
    for line in out.splitlines():
     if not line:continue
     k,v=line[0],line[1:]
     if k=='p':finish();process={'pid':v};entry={}
     elif k=='c':process['command']=v
     elif k=='f':finish();entry={'fd':v}
     else:entry[k]=v
    finish()
   matches[label]=dict(returncode=child.returncode,raw_sha256=hashlib.sha256(out.encode()).hexdigest(),raw_lines=len(out.splitlines()),matching=found,public_output='only candidate matches; complete host output was not retained')
   assert not found,'active candidate user'
  record.update(status='retiring',paths=list(map(str,selected)),entries_verified=count,quiescence=matches,quiescent_at=time.time(),retained_files=retained,proof_files={str(proof/n):sha(proof/n) for n in ['inspection.json','inventory.jsonl.gz','comparison-maps.json','retained-evidence.json','publication-documents.json']})
  write_json(work/'summary.json',record)
  for p in selected:
   assert p.resolve(strict=True)==p and p.is_dir() and not p.is_symlink()
   shutil.rmtree(p);record['deleted'].append(dict(path=str(p),finished_at=time.time(),free_bytes=shutil.disk_usage(root).free));write_json(work/'summary.json',record)
  for p,h in retained.items():assert sha(Path(p))==h
  assert load_compiler(root,compiler.key)==compiler
  record.update(status='passed',finished_at=time.time(),free_bytes_after=shutil.disk_usage(root).free,compiler_installation_retained=True,retained_files_verified_after=True)
  write_json(work/'summary.json',record)
  print(json.dumps({k:record[k] for k in ['status','pid','free_bytes_before','free_bytes_after','entries_verified','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());write_json(work/'summary.json',record);raise
