import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import time

ROOT = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture, write_json


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


from custom_compiler import load_compiler

OWNER = Path('/Users/danluu/dev/rust-interp-stable-cgu-20260913')
BUILD = OWNER / '.work/stable-cgu-compiler-build-01'
CANDIDATES = [BUILD / 'packaged-stage2-03', BUILD / 'packaged-stage2-05']
LATEST = BUILD / 'packaged-stage2-06'
COMPILER_KEY = '60096d7efe02d38269c5694bfd046d4f9facfb65139b2d82173d12345a1c9c46'
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def strings(value):
    if isinstance(value, str): yield value
    elif isinstance(value, dict):
        for key, child in value.items():
            yield key
            yield from strings(child)
    elif isinstance(value, list):
        for child in value: yield from strings(child)


def main():
    summary = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
        cwd=str(Path.cwd()), argv=sys.argv, canonical_lock=str(LOCK), lock_wait_seconds=1800,
        candidates=[str(p) for p in CANDIDATES], inspector_sha256=sha(Path(__file__)),
        mutation_policy='read-only exact superseded package pair; no deletion or process control')
    write_json(WORK / 'inspection.json', summary)
    try:
        require(LOCK.resolve(strict=True) == LOCK, 'canonical lock differs')
        with LOCK.open('r+') as lock:
            acquire_lock(lock, 1800)
            summary.update(status='inspecting', lock_acquired_at=time.time(), free_bytes_before=shutil.disk_usage(ROOT).free)
            write_json(WORK / 'inspection.json', summary)
            print('package pair inspection admitted', os.getpid(), flush=True)
            candidates = CANDIDATES
            latest_receipt = BUILD / 'package-06/receipt.json'
            latest = json.loads(latest_receipt.read_text())
            require(latest['prefix'] == str(LATEST) and latest['previous_package_files_preserved'] == 6982
                    and len(latest['files']) == 6983, 'latest package preservation proof differs')
            compiler = load_compiler(ROOT, COMPILER_KEY)
            require(compiler.identity['files'] == latest['files'], 'installed60096 differs from latest package')
            retained, comparisons, checked = {}, {}, {}
            for number, expected_count, native_name in [('03', 6981, 'native-entry-01'), ('05', 6982, 'native-entry-02')]:
                prefix = BUILD / ('packaged-stage2-' + number)
                receipt_path = BUILD / ('package-' + number) / 'receipt.json'
                receipt = json.loads(receipt_path.read_text())
                require(receipt['prefix'] == str(prefix) and len(receipt['files']) == expected_count
                        and receipt['status'] == 'composed; loader closure and installer qualification still required'
                        and prefix.resolve(strict=True) == prefix and prefix.is_dir(), 'package ownership/layout differs')
                if number == '05':
                    require(sha(receipt_path) == latest['previous_package_receipt_sha256'], 'package06 predecessor proof differs')
                native_path = BUILD / native_name / 'result.json'
                native = json.loads(native_path.read_text())
                require(native['status'] == 'passed' and native['package_files_unchanged']
                        and native['compiler_unchanged'] and native['compiler'] == str(prefix / 'bin/rustc')
                        and len(native['commands']) == 30 and len(native['histories']) == 15,
                        'completed fifteen-state native control proof differs')
                require(native['package_provenance_sha256'] == sha(BUILD / ('package-' + number) / 'provenance.json'),
                        'native control provenance differs')
                actual = {}
                for path in sorted(prefix.rglob('*')):
                    require(not path.is_symlink(), 'package contains a replacement link')
                    if path.is_file(): actual[str(path.relative_to(prefix))] = sha(path)
                    else: require(path.is_dir(), 'unsupported package entry')
                require(actual == receipt['files'], 'candidate package differs from recorded file inventory')
                for name, expected in actual.items():
                    require(latest['files'].get(name) == compiler.identity['files'].get(name) == expected,
                            'candidate content not retained by latest package and installed60096')
                    if name not in checked:
                        require(sha(LATEST / name) == expected and sha(compiler.sysroot / name) == expected,
                                'retained latest package or installed bytes differ')
                        checked[name] = expected
                comparisons[str(prefix)] = dict(files=actual, receipt=str(receipt_path), receipt_sha256=sha(receipt_path),
                    native_control=str(native_path), native_control_sha256=sha(native_path), native_states=15,
                    retained_package=str(LATEST), retained_compiler=str(compiler.sysroot))
            require(load_compiler(ROOT, COMPILER_KEY) == compiler, 'installed compiler changed during hashing')
            # All historical inputs, failures, probe outputs and native artifacts
            # remain outside the exact superseded prefix pair.
            for name in ['package-02','package-03','package-05','package-06','native-entry-01','native-entry-02','native-strip-01',
                         'stage1-02','stage2','stage2-option-hash','stage2-tests','stage2-dist-04']:
                for path in sorted((BUILD / name).rglob('*')):
                    if path.is_file():
                        require(path.resolve(strict=True) == path, 'indirect retained package evidence')
                        retained[str(path)] = sha(path)
            write_json(WORK / 'comparison-maps.json', comparisons)
            write_json(WORK / 'retained-evidence.json', retained)
            summary.update(comparison_maps_sha256=sha(WORK / 'comparison-maps.json'),
                retained_evidence_sha256=sha(WORK / 'retained-evidence.json'), retained_evidence_files=len(retained),
                retained_identical_files=len(checked), latest_package_receipt_sha256=sha(latest_receipt),
                installed_compiler_key=compiler.key)
            guards = {}
            for owner in [ROOT, OWNER, Path('/Users/danluu/dev/rust-interp-proc-macro-opt-20260913')]:
                for installation in sorted((owner / '.work/interpreter-tools').glob('*')):
                    if not installation.is_dir(): continue
                    for name in ['source.json','publication.json','publication-guard.json','compiler.json',
                                 'provenance/compiler-inputs.json','provenance/libraries.json','provenance/dependencies.json',
                                 'provenance/correctness.json','provenance/std-ready.json']:
                        path = installation / name
                        if not path.exists(): continue
                        require(path.resolve(strict=True) == path and path.is_file(), 'indirect publication guard')
                        value = json.loads(path.read_text())
                        require(not any(str(c) in s for s in strings(value) for c in candidates),
                                'published tool depends on superseded package')
                        guards[str(path)] = sha(path)
            for path in sorted((ROOT / '.work/compilers').glob('*/ready.json')):
                identity = json.loads(path.read_text())['identity']
                require(not any(str(c) in s for s in strings(identity) for c in candidates),
                        'installed compiler identity depends on superseded package')
                guards[str(path)] = sha(path)
            plan_path = Path('/Users/danluu/dev/rust-interp-stable-mono-compiler-build-20260913/experiments/stable-cgu/planned-mono-production-build-02.json')
            require(not any(str(c) in s for s in strings(json.loads(plan_path.read_text())) for c in candidates),
                    'new production plan depends on superseded package')
            guards[str(plan_path)] = sha(plan_path)
            write_json(WORK / 'publication-documents.json', guards)
            summary['publication_documents_sha256'] = sha(WORK / 'publication-documents.json')
            summary['publication_documents'] = len(guards)
            rows, inodes, all_inodes = [], {}, set()
            with gzip.open(WORK / 'inventory.jsonl.gz', 'wt') as output:
                for path in candidates:
                    totals = dict(path=str(path), entries=0, files=0, symlinks=0, logical_bytes=0, allocated_bytes=0)
                    for directory, dirs, files in os.walk(path, followlinks=False):
                        current = Path(directory)
                        names = [current] if current == path else []
                        names += [current / name for name in [*dirs, *files]]
                        for item in names:
                            st = item.lstat()
                            all_inodes.add((st.st_dev, st.st_ino))
                            row = dict(root=str(path), path=str(item.relative_to(path)), device=st.st_dev,
                                inode=st.st_ino, mode=st.st_mode, bytes=st.st_size, blocks=st.st_blocks,
                                nlink=st.st_nlink, mtime_ns=st.st_mtime_ns, ctime_ns=st.st_ctime_ns,
                                link=os.readlink(item) if stat.S_ISLNK(st.st_mode) else None)
                            output.write(json.dumps(row, sort_keys=True) + '\n')
                            totals['entries'] += 1
                            if stat.S_ISREG(st.st_mode):
                                totals['files'] += 1
                                totals['logical_bytes'] += st.st_size
                                totals['allocated_bytes'] += st.st_blocks * 512
                                identity = (st.st_dev, st.st_ino)
                                inode = inodes.setdefault(identity, dict(blocks=st.st_blocks, nlink=st.st_nlink, count=0))
                                inode['count'] += 1
                            elif stat.S_ISLNK(st.st_mode):
                                totals['symlinks'] += 1
                            elif not stat.S_ISDIR(st.st_mode):
                                raise RuntimeError('unsupported candidate entry: ' + str(item))
                    rows.append(totals)
            summary['candidates'] = rows
            summary['unique_inode_allocated_bytes'] = sum(v['blocks'] * 512 for v in inodes.values())
            summary['candidate_only_link_allocated_bytes'] = sum(v['blocks'] * 512 for v in inodes.values() if v['count'] == v['nlink'])
            summary['shared_external_link_inodes'] = sum(v['count'] < v['nlink'] for v in inodes.values())
            summary['inventory_sha256'] = sha(WORK / 'inventory.jsonl.gz')
            for label, command in [('processes', ['/bin/ps', '-axo', 'pid=,ppid=,pgid=,lstart=,command=']),
                                   ('handles', ['/usr/sbin/lsof', '-nP', '-FpcftDin'])]:
                child, stdout, stderr = capture(command, cwd=WORK, env=os.environ.copy(),
                    receipt_path=WORK / (label + '-process.json'), receipt=dict(phase=label))
                proof = dict(command=command, returncode=child.returncode,
                    raw_stdout_sha256=hashlib.sha256(stdout.encode()).hexdigest(), stdout_lines=len(stdout.splitlines()),
                    raw_stderr_sha256=hashlib.sha256(stderr.encode()).hexdigest(), stderr_lines=len(stderr.splitlines()),
                    raw_host_output_retained=False, filtering='only exact candidate paths or inventoried inodes')
                if label == 'processes':
                    matches = [line for line in stdout.splitlines() if any(str(p) in line for p in candidates)]
                else:
                    matches, process, opened = [], {}, {}
                    def finish():
                        name = opened.get('n', '')
                        exact = any(name == str(p) or name.startswith(str(p) + '/') for p in candidates)
                        try: inode = (int(opened.get('D', ''), 16), int(opened.get('i', '')))
                        except ValueError: inode = None
                        if exact or inode in all_inodes:
                            matches.append(dict(process=process.copy(), file=opened.copy(),
                                                path_match=exact, inode_match=inode in all_inodes))
                    for line in stdout.splitlines():
                        if not line: continue
                        field, value = line[0], line[1:]
                        if field == 'p': finish(); opened = {}; process = dict(pid=value)
                        elif field == 'c': process['command'] = value
                        elif field == 'f': finish(); opened = dict(fd=value)
                        else: opened[field] = value
                    finish()
                proof['candidate_matches'] = matches
                write_json(WORK / (label + '-filtered.json'), proof)
                summary[label] = proof
            summary.update(status='inspection completed; no retirement performed', finished_at=time.time(),
                free_bytes_after=shutil.disk_usage(ROOT).free,
                no_users_proved=all(p['returncode'] == 0 and p['stderr_lines'] == 0 and not p['candidate_matches']
                                    for p in [summary['processes'], summary['handles']]),
                limitations='current user visibility; APFS extent sharing may reduce actual reclaimed bytes',
                recheck_required_before_retirement=True)
            write_json(WORK / 'inspection.json', summary)
            print(json.dumps({k:summary[k] for k in ['status','pid','candidates','candidate_only_link_allocated_bytes',
                'free_bytes_after','no_users_proved']}), flush=True)
    except BaseException as error:
        summary.update(status='failed inspection; no retirement performed', error=repr(error), finished_at=time.time())
        write_json(WORK / 'inspection.json', summary)
        raise


if __name__ == '__main__':
    main()
