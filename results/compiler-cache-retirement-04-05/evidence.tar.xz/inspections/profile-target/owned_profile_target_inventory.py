"""One exact owned completed profiling target; inspection only, no retirement."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import tarfile
import time

OWNER = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
TARGET = OWNER / '.work/strict-warm-profile-01/target'
WORK = Path(__file__).resolve().parent
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
ARCHIVE_SHA = '545c6c4b1ea2156b85e8433d20bf47396e3df95d18ea19dbf66dcc543edb458c'
sys.path.insert(0, str(PRIMARY / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture, write_json


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def record_paths(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for key, child in value.items():
            yield key
            yield from record_paths(child)
    elif isinstance(value, list):
        for child in value:
            yield from record_paths(child)


def main():
    result = dict(schema_version=1, status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
        started_at=time.time(), cwd=str(Path.cwd()), command=sys.argv, target=str(TARGET),
        canonical_lock=str(LOCK), lock_wait_seconds=1800,
        mutation_policy='read-only single-target inspection; no deletion or process control',
        inspector_sha256=sha(Path(__file__)))
    write_json(WORK / 'inspection.json', result)
    try:
        require(LOCK.resolve(strict=True) == LOCK and LOCK.is_file(), 'canonical lock differs')
        with LOCK.open('r+') as lock:
            acquire_lock(lock, 1800)
            result.update(status='inspecting', lock_acquired_at=time.time(),
                          free_bytes_before=shutil.disk_usage(OWNER).free)
            write_json(WORK / 'inspection.json', result)
            print('single-target inspection admitted', os.getpid(), flush=True)
            names = ['strict-warm-profile-01', 'strict-warm-self-profile-02', 'strict-warm-cargo-profile-03']
            expected_reports = ['abc25224a69e529fcf6d7a1320e97fbd5c9fef9e4a1de4ebcdd43e8dd3ef5bb8',
                '9c977a4fa412d1e2dd97afaf76acef96bd66a41223a6568ff3f78dbe4941da37',
                '92cc2d6635a1e2ba83c4c546ecd8da4377fd7a4724ba2f47463e9fa5c45f778b']
            expected_archives = ['f33b40296164b173940bc37db2cd67fc8ec087f1c9650254d107f26721b36896',
                'def3fb183e0773b125f571f00887c707cda8684154871d39d502d63bf102f781',
                'c8ed93b29ddcd58a5aa5622b506ee707c214f4beb6a47a0f12a8e0265d540f2b']
            retained, states, archive_proofs = {}, [], []
            for index, name in enumerate(names):
                raw, public = OWNER / '.work' / name, OWNER / 'results' / name
                report_path, archive = raw / 'report.json', public / 'report.json.gz'
                require(sha(report_path) == expected_reports[index] and sha(archive) == expected_archives[index],
                        'completed profile report/archive changed')
                require(gzip.decompress(archive.read_bytes()) == report_path.read_bytes(), 'profile archive differs from raw report')
                report = json.loads(report_path.read_text())
                require(report['owner'] == str(OWNER) and report['status'] == 'passed'
                        and report['source_restored'] and report['lock'] == str(LOCK), 'profile owner/completion differs')
                require(report['supervisor_pid'] == [37082, 49089, 26031][index], 'profile supervisor differs')
                if index:
                    require(report['target_directory'] == str(TARGET)
                            and report['continuation']['prior_report_sha256'] == expected_reports[index-1],
                            'profile continuation/target differs')
                expected_states = ['prime', 'edited', 'restored'] if index == 0 else ['edited', 'restored']
                require([r['state'] for r in report['records']] == expected_states, 'profile state history differs')
                for row in report['records']:
                    directory = raw / row['state']
                    require(sha(directory / 'program.rbc') == row['artifact_sha256']
                            and sha(directory / 'suite.json') == row['suite_sha256'], 'retained artifact or suite differs')
                    for role in ['cargo', 'vm']:
                        require(row[role]['returncode'] == 0
                                and row[role]['parent_pid'] == report['supervisor_pid']
                                and row[role]['finished_unix_ns'] >= row[role]['started_unix_ns'], 'profile child completion differs')
                        require(sha(directory / (role + '.stdout')) == row[role]['stdout_sha256']
                                and sha(directory / (role + '.stderr')) == row[role]['stderr_sha256'], 'profile raw child output differs')
                        require(json.loads((directory / (role + '.json')).read_text()) == row[role], 'profile process receipt differs')
                    require(all(Path(p).is_relative_to(TARGET) for p in row['selected_cargo_event']['filenames']),
                            'profile selected output is outside the candidate target')
                    states.append(dict(profile=name, state=row['state'], supervisor=report['supervisor_pid'],
                        cargo_pid=row['cargo']['pid'], vm_pid=row['vm']['pid'], artifact_sha256=row['artifact_sha256']))
                published = json.loads((public / 'summary.json').read_text())
                archive_rows = ([published['compressed_report']] if index == 0 else
                    list(published['archives'].values()) if index == 1 else published['archives'])
                if index == 1:
                    archive_rows = [dict(value, path=key) for key, value in published['archives'].items()]
                for proof in archive_rows:
                    selected = public / proof.get('path', proof.get('file', ''))
                    require(selected.is_file() and sha(selected) == proof['sha256']
                            and selected.stat().st_size == proof['bytes'], 'published profile archive differs')
                    archive_proofs.append(dict(path=str(selected), sha256=proof['sha256']))
                # Keep every raw receipt, artifact, profiling trace and published
                # result outside this sole target, recording exact retained bytes.
                for preserve in [raw, public]:
                    for directory, dirs, files in os.walk(preserve, followlinks=False):
                        dirs[:] = [d for d in dirs if Path(directory) / d != TARGET]
                        for name in files:
                            selected = Path(directory) / name
                            require(selected.resolve(strict=True) == selected and not selected.is_relative_to(TARGET),
                                    'preserved profile evidence is indirect or inside target')
                            retained[str(selected)] = sha(selected)
            require(len(states) == 7, 'expected seven completed profile states')
            history = TARGET / '.strict-warm-profile-history.json'
            require(history.resolve(strict=True) == history and history.is_file(), 'missing recorded target history')
            shutil.copy2(history, WORK / 'retained-profile-history.json')
            require(sha(history) == sha(WORK / 'retained-profile-history.json'), 'target history copy differs')
            result['retained_profile_history'] = dict(original=str(history),
                copy=str(WORK / 'retained-profile-history.json'), sha256=sha(history))
            result['ownership'] = dict(states=states, archives=archive_proofs,
                rule='completed task-owned diagnostic project cache; all raw results and artifacts retained outside target')
            write_json(WORK / 'retained-evidence.json', retained)
            result['retained_evidence_sha256'] = sha(WORK / 'retained-evidence.json')
            # Inspect publication documents only, never another build/cache tree.
            guards = {}
            for owner in [OWNER, Path('/Users/danluu/dev/rust-interp-proc-macro-opt-20260913')]:
                for installation in sorted((owner / '.work/interpreter-tools').glob('*')):
                    if not installation.is_dir():
                        continue
                    for name in ['source.json', 'publication.json', 'publication-guard.json',
                                 'compiler.json', 'provenance/compiler-inputs.json',
                                 'provenance/libraries.json', 'provenance/dependencies.json',
                                 'provenance/correctness.json', 'provenance/std-ready.json']:
                        path = installation / name
                        if not path.exists():
                            continue
                        require(path.resolve(strict=True) == path and path.is_file(), 'indirect publication document')
                        value = json.loads(path.read_text())
                        require(not any(str(TARGET) in text for text in record_paths(value)),
                                'published tool evidence depends on candidate target')
                        guards[str(path)] = sha(path)
            write_json(WORK / 'publication-documents.json', guards)
            result['publication_documents'] = len(guards)
            result['publication_documents_sha256'] = sha(WORK / 'publication-documents.json')
            require(TARGET.resolve(strict=True) == TARGET and TARGET.is_dir(), 'target is missing or indirect')
            totals = dict(entries=0, files=0, directories=0, symlinks=0, logical_bytes=0)
            inodes, all_inodes = {}, set()
            with gzip.open(WORK / 'inventory.jsonl.gz', 'wt') as output:
                for directory, dirs, files in os.walk(TARGET, followlinks=False):
                    current = Path(directory)
                    paths = ([current] if current == TARGET else []) + [current / n for n in [*dirs, *files]]
                    for path in paths:
                        item = path.lstat()
                        identity = (item.st_dev, item.st_ino)
                        all_inodes.add(identity)
                        record = dict(path=str(path.relative_to(TARGET)), device=item.st_dev, inode=item.st_ino,
                            mode=item.st_mode, bytes=item.st_size, blocks=item.st_blocks, nlink=item.st_nlink,
                            mtime_ns=item.st_mtime_ns, ctime_ns=item.st_ctime_ns,
                            link=os.readlink(path) if stat.S_ISLNK(item.st_mode) else None)
                        output.write(json.dumps(record, sort_keys=True) + '\n')
                        totals['entries'] += 1
                        if stat.S_ISREG(item.st_mode):
                            totals['files'] += 1; totals['logical_bytes'] += item.st_size
                            inode = inodes.setdefault(identity, dict(blocks=item.st_blocks, nlink=item.st_nlink, count=0))
                            inode['count'] += 1
                        elif stat.S_ISDIR(item.st_mode): totals['directories'] += 1
                        elif stat.S_ISLNK(item.st_mode): totals['symlinks'] += 1
                        else: raise RuntimeError('unsupported target entry: ' + str(path))
            totals.update(unique_inode_allocated_bytes=sum(v['blocks'] * 512 for v in inodes.values()),
                candidate_only_link_allocated_bytes=sum(v['blocks'] * 512 for v in inodes.values() if v['nlink'] == v['count']),
                shared_external_link_inodes=sum(v['nlink'] > v['count'] for v in inodes.values()))
            result['target_inventory'] = totals
            result['inventory_sha256'] = sha(WORK / 'inventory.jsonl.gz')
            for label, command in [('processes', ['/bin/ps', '-axo', 'pid=,ppid=,pgid=,lstart=,command=']),
                                   ('handles', ['/usr/sbin/lsof', '-nP', '-FpcftDin'])]:
                child, stdout, stderr = capture(command, cwd=WORK, env=os.environ.copy(),
                    receipt_path=WORK / (label + '-process.json'), receipt=dict(phase=label))
                proof = dict(command=command, returncode=child.returncode,
                    raw_stdout_sha256=hashlib.sha256(stdout.encode()).hexdigest(), stdout_lines=len(stdout.splitlines()),
                    raw_stderr_sha256=hashlib.sha256(stderr.encode()).hexdigest(), stderr_lines=len(stderr.splitlines()),
                    raw_host_output_retained=False, filtering='only exact candidate paths or inventoried inodes')
                if label == 'processes':
                    matches = [line for line in stdout.splitlines() if str(TARGET) in line]
                else:
                    matches, process, opened = [], {}, {}
                    def finish():
                        name = opened.get('n', '')
                        exact = name == str(TARGET) or name.startswith(str(TARGET) + '/')
                        try: inode = (int(opened.get('D', ''), 16), int(opened.get('i', '')))
                        except ValueError: inode = None
                        if exact or inode in all_inodes:
                            matches.append(dict(process=process.copy(), file=opened.copy(),
                                                path_match=exact, inode_match=inode in all_inodes))
                    for line in stdout.splitlines():
                        if not line: continue
                        field, value = line[0], line[1:]
                        if field == 'p': finish(); opened = {}; process = dict(pid=value)
                        elif field == 'c': process['command'] = value
                        elif field == 'f': finish(); opened = dict(fd=value)
                        else: opened[field] = value
                    finish()
                proof['candidate_matches'] = matches
                write_json(WORK / (label + '-filtered.json'), proof)
                result[label] = proof
            result.update(status='inspection completed; no retirement performed', finished_at=time.time(),
                free_bytes_after=shutil.disk_usage(OWNER).free,
                no_users_proved=all(p['returncode'] == 0 and p['stderr_lines'] == 0 and not p['candidate_matches']
                                    for p in [result['processes'], result['handles']]),
                limitations='current user process visibility; APFS extent sharing may reduce actual reclaimed bytes',
                recheck_required_before_retirement=True)
            write_json(WORK / 'inspection.json', result)
            print(json.dumps({k: result[k] for k in ['status', 'pid', 'target_inventory', 'free_bytes_after', 'no_users_proved']}), flush=True)
    except BaseException as error:
        result.update(status='failed inspection; no retirement performed', error=repr(error), finished_at=time.time())
        write_json(WORK / 'inspection.json', result)
        raise


if __name__ == '__main__':
    main()
