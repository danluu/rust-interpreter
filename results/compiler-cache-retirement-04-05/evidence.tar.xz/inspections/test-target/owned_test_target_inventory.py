"""One exact owned completed test target; inspection only, no retirement."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import tarfile
import time

OWNER = Path('/Users/danluu/dev/rust-interp-mono-production-integration-20260913')
PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
TARGET = OWNER / '.work/mono-integration-rust-tests-01/target'
WORK = Path(__file__).resolve().parent
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
ARCHIVE_SHA = '545c6c4b1ea2156b85e8433d20bf47396e3df95d18ea19dbf66dcc543edb458c'
sys.path.insert(0, str(PRIMARY / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture, write_json


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def record_paths(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for key, child in value.items():
            yield key
            yield from record_paths(child)
    elif isinstance(value, list):
        for child in value:
            yield from record_paths(child)


def main():
    result = dict(schema_version=1, status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
        started_at=time.time(), cwd=str(Path.cwd()), command=sys.argv, target=str(TARGET),
        canonical_lock=str(LOCK), lock_wait_seconds=1800,
        mutation_policy='read-only single-target inspection; no deletion or process control',
        inspector_sha256=sha(Path(__file__)))
    write_json(WORK / 'inspection.json', result)
    try:
        require(LOCK.resolve(strict=True) == LOCK and LOCK.is_file(), 'canonical lock differs')
        with LOCK.open('r+') as lock:
            acquire_lock(lock, 1800)
            result.update(status='inspecting', lock_acquired_at=time.time(),
                          free_bytes_before=shutil.disk_usage(OWNER).free)
            write_json(WORK / 'inspection.json', result)
            print('single-target inspection admitted', os.getpid(), flush=True)
            evidence_root = OWNER / 'results/mono-production-integration-source-tests-01'
            summary_path = evidence_root / 'summary.json'
            summary = json.loads(summary_path.read_text())
            archive = evidence_root / summary['archive']['path']
            require(sha(archive) == ARCHIVE_SHA == summary['archive']['sha256']
                    and archive.stat().st_size == 831133 and summary['archive']['members'] == 336,
                    'completed test archive identity differs')
            require(summary['status'] == 'passed' and summary['owner'] == str(OWNER)
                    and summary['rust_tests'] == dict(passed=490, failed=0, ignored=1),
                    'completed test summary differs')
            retained = {str(summary_path): sha(summary_path), str(archive): ARCHIVE_SHA}
            with tarfile.open(archive, 'r:gz') as bundle:
                members = bundle.getmembers()
                require(len(members) == 336 and {m.name for m in members} == set(summary['files']),
                        'archive members differ from the completed summary')
                for member in members:
                    relative = Path(member.name)
                    require(member.isfile() and not relative.is_absolute() and '..' not in relative.parts,
                            'unexpected archive entry')
                    proof = summary['files'][member.name]
                    payload = bundle.extractfile(member).read()
                    require(len(payload) == proof['bytes'] == member.size
                            and hashlib.sha256(payload).hexdigest() == proof['sha256'],
                            'archived source/test evidence changed')
                    original = OWNER / relative
                    require(not original.is_relative_to(TARGET) and original.resolve(strict=True) == original
                            and sha(original) == proof['sha256'], 'raw evidence changed or overlaps target')
                    retained[str(original)] = proof['sha256']
            raw = json.loads((TARGET.parent / 'summary.json').read_text())
            process = json.loads((TARGET.parent / 'process.json').read_text())
            supervisor = json.loads((OWNER / '.work/experiments/mono-integration-rust-tests-supervisor-01/status.json').read_text())
            expected_command = ['cargo', '+nightly-2026-09-08', 'test', '--workspace', '--release',
                '--locked', '--offline', '--jobs', '2', '--target-dir', str(TARGET)]
            require(raw['status'] == 'passed' and raw['returncode'] == 0
                    and raw['test_totals'] == dict(passed=490, failed=0, ignored=1)
                    and raw['canonical_lock'] == str(LOCK) and raw['pid'] == 16263
                    and raw['child_pid'] == process['pid'] == 16267
                    and process['parent_pid'] == 16263 and process['status'] == 'finished'
                    and process['returncode'] == 0 and process['cwd'] == str(OWNER)
                    and raw['command'] == process['command'] == expected_command
                    and supervisor['status'] == 'finished' and supervisor['returncode'] == 0
                    and supervisor['supervisor_pid'] == 16259 and supervisor['child_pid'] == 16263,
                    'completed target command/process ownership differs')
            result['ownership'] = dict(command=expected_command, producer_revision=raw['revision'],
                supervisor_pid=16259, helper_pid=16263, cargo_pid=16267,
                test_totals=raw['test_totals'], finished_at=raw['finished_at'], archive_members=336)
            write_json(WORK / 'retained-evidence.json', retained)
            result['retained_evidence_sha256'] = sha(WORK / 'retained-evidence.json')
            # Inspect publication documents only, never another build/cache tree.
            guards = {}
            for owner in [OWNER, PRIMARY, Path('/Users/danluu/dev/rust-interp-proc-macro-opt-20260913')]:
                for installation in sorted((owner / '.work/interpreter-tools').glob('*')):
                    if not installation.is_dir():
                        continue
                    for name in ['source.json', 'publication.json', 'publication-guard.json',
                                 'compiler.json', 'provenance/compiler-inputs.json',
                                 'provenance/libraries.json', 'provenance/dependencies.json',
                                 'provenance/correctness.json', 'provenance/std-ready.json']:
                        path = installation / name
                        if not path.exists():
                            continue
                        require(path.resolve(strict=True) == path and path.is_file(), 'indirect publication document')
                        value = json.loads(path.read_text())
                        require(not any(str(TARGET) in text for text in record_paths(value)),
                                'published tool evidence depends on candidate target')
                        guards[str(path)] = sha(path)
            write_json(WORK / 'publication-documents.json', guards)
            result['publication_documents'] = len(guards)
            result['publication_documents_sha256'] = sha(WORK / 'publication-documents.json')
            require(TARGET.resolve(strict=True) == TARGET and TARGET.is_dir(), 'target is missing or indirect')
            totals = dict(entries=0, files=0, directories=0, symlinks=0, logical_bytes=0)
            inodes, all_inodes = {}, set()
            with gzip.open(WORK / 'inventory.jsonl.gz', 'wt') as output:
                for directory, dirs, files in os.walk(TARGET, followlinks=False):
                    current = Path(directory)
                    paths = ([current] if current == TARGET else []) + [current / n for n in [*dirs, *files]]
                    for path in paths:
                        item = path.lstat()
                        identity = (item.st_dev, item.st_ino)
                        all_inodes.add(identity)
                        record = dict(path=str(path.relative_to(TARGET)), device=item.st_dev, inode=item.st_ino,
                            mode=item.st_mode, bytes=item.st_size, blocks=item.st_blocks, nlink=item.st_nlink,
                            mtime_ns=item.st_mtime_ns, ctime_ns=item.st_ctime_ns,
                            link=os.readlink(path) if stat.S_ISLNK(item.st_mode) else None)
                        output.write(json.dumps(record, sort_keys=True) + '\n')
                        totals['entries'] += 1
                        if stat.S_ISREG(item.st_mode):
                            totals['files'] += 1; totals['logical_bytes'] += item.st_size
                            inode = inodes.setdefault(identity, dict(blocks=item.st_blocks, nlink=item.st_nlink, count=0))
                            inode['count'] += 1
                        elif stat.S_ISDIR(item.st_mode): totals['directories'] += 1
                        elif stat.S_ISLNK(item.st_mode): totals['symlinks'] += 1
                        else: raise RuntimeError('unsupported target entry: ' + str(path))
            totals.update(unique_inode_allocated_bytes=sum(v['blocks'] * 512 for v in inodes.values()),
                candidate_only_link_allocated_bytes=sum(v['blocks'] * 512 for v in inodes.values() if v['nlink'] == v['count']),
                shared_external_link_inodes=sum(v['nlink'] > v['count'] for v in inodes.values()))
            result['target_inventory'] = totals
            result['inventory_sha256'] = sha(WORK / 'inventory.jsonl.gz')
            for label, command in [('processes', ['/bin/ps', '-axo', 'pid=,ppid=,pgid=,lstart=,command=']),
                                   ('handles', ['/usr/sbin/lsof', '-nP', '-FpcftDin'])]:
                child, stdout, stderr = capture(command, cwd=WORK, env=os.environ.copy(),
                    receipt_path=WORK / (label + '-process.json'), receipt=dict(phase=label))
                proof = dict(command=command, returncode=child.returncode,
                    raw_stdout_sha256=hashlib.sha256(stdout.encode()).hexdigest(), stdout_lines=len(stdout.splitlines()),
                    raw_stderr_sha256=hashlib.sha256(stderr.encode()).hexdigest(), stderr_lines=len(stderr.splitlines()),
                    raw_host_output_retained=False, filtering='only exact candidate paths or inventoried inodes')
                if label == 'processes':
                    matches = [line for line in stdout.splitlines() if str(TARGET) in line]
                else:
                    matches, process, opened = [], {}, {}
                    def finish():
                        name = opened.get('n', '')
                        exact = name == str(TARGET) or name.startswith(str(TARGET) + '/')
                        try: inode = (int(opened.get('D', ''), 16), int(opened.get('i', '')))
                        except ValueError: inode = None
                        if exact or inode in all_inodes:
                            matches.append(dict(process=process.copy(), file=opened.copy(),
                                                path_match=exact, inode_match=inode in all_inodes))
                    for line in stdout.splitlines():
                        if not line: continue
                        field, value = line[0], line[1:]
                        if field == 'p': finish(); opened = {}; process = dict(pid=value)
                        elif field == 'c': process['command'] = value
                        elif field == 'f': finish(); opened = dict(fd=value)
                        else: opened[field] = value
                    finish()
                proof['candidate_matches'] = matches
                write_json(WORK / (label + '-filtered.json'), proof)
                result[label] = proof
            result.update(status='inspection completed; no retirement performed', finished_at=time.time(),
                free_bytes_after=shutil.disk_usage(OWNER).free,
                no_users_proved=all(p['returncode'] == 0 and p['stderr_lines'] == 0 and not p['candidate_matches']
                                    for p in [result['processes'], result['handles']]),
                limitations='current user process visibility; APFS extent sharing may reduce actual reclaimed bytes',
                recheck_required_before_retirement=True)
            write_json(WORK / 'inspection.json', result)
            print(json.dumps({k: result[k] for k in ['status', 'pid', 'target_inventory', 'free_bytes_after', 'no_users_proved']}), flush=True)
    except BaseException as error:
        result.update(status='failed inspection; no retirement performed', error=repr(error), finished_at=time.time())
        write_json(WORK / 'inspection.json', result)
        raise


if __name__ == '__main__':
    main()
