import gzip,hashlib,json,os,shutil,stat,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
from custom_compiler import load_compiler
from workflow_io import capture,write_json
proof=Path('/Users/danluu/dev/rust-interp-std-source-v2-20260913/.work/mono-profile-target-retirement-inspection-01')
work=root/'.work/strict-warm-build/profile-cache-retirement-04'
work.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=dict(status='waiting',owner=str(root),pid=os.getpid(),started_at=time.time(),deleted=[],benchmark_commands=0)
write_json(work/'summary.json',record)
try:
 with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('r+') as lock:
  acquire_lock(lock,600)
  record.update(lock_acquired_at=time.time(),free_bytes_before=shutil.disk_usage(root).free,canonical_lock=str(Path(lock.name)))
  inspection=json.loads((proof/'inspection.json').read_bytes())
  assert sha(proof/'inspection.json')=='2e3452b5981047a63273a3fbbc8a3a7962e07b970439ef5be786953c79aca911'
  assert sha(proof/'inventory.jsonl.gz')==inspection['inventory_sha256']=='84f42ee99499d9a848320d7f94e388413671627d39633a2d42601b9517ac3bba'
  target=root/'.work/strict-warm-profile-01/target'
  selected=[target]
  assert inspection['target']==str(target) and inspection['no_users_proved'] is True
  assert target.resolve(strict=True)==target and target.is_dir() and not target.is_symlink()
  assert len(inspection['ownership']['states'])==7
  for name, field in [('retained-evidence.json','retained_evidence_sha256'),('publication-documents.json','publication_documents_sha256')]:
   assert sha(proof/name)==inspection[field]
  retained=json.loads((proof/'retained-evidence.json').read_bytes())
  publications=json.loads((proof/'publication-documents.json').read_bytes())
  assert len(retained)==1951 and len(publications)==21
  retained.update(publications)
  history=inspection['retained_profile_history']
  assert history['original']==str(target/'.strict-warm-profile-history.json')
  assert sha(Path(history['original']))==sha(Path(history['copy']))==history['sha256']
  retained[history['copy']]=history['sha256']
  for path,digest in retained.items():
   assert not Path(path).is_relative_to(target) and sha(Path(path))==digest
  for path in publications: assert str(target) not in Path(path).read_text()
  compiler=load_compiler(root,'60096d7efe02d38269c5694bfd046d4f9facfb65139b2d82173d12345a1c9c46')
  snapshots={p:{} for p in selected};inodes=set()
  with gzip.open(proof/'inventory.jsonl.gz','rt') as stream:
   for line in stream:
    row=json.loads(line);base=target
    if base in snapshots:snapshots[base][row['path']]=row
  count=0
  for base,expected in snapshots.items():
   entries=[base,*base.rglob('*')];assert {str(p.relative_to(base)) for p in entries}==set(expected)
   for p in entries:
    row=expected[str(p.relative_to(base))];s=p.lstat()
    actual=dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,nlink=s.st_nlink,blocks=s.st_blocks,link=os.readlink(p) if stat.S_ISLNK(s.st_mode) else None)
    assert all(actual[k]==row[k] for k in actual),(str(p),'candidate changed')
    inodes.add((s.st_dev,s.st_ino));count+=1
  # Inspect active handles and cwd aliases by both path and inode. Keep raw
  # host output local to memory; publish only its digest/count and matching rows.
  matches={}
  for label,argv in [('processes',['/bin/ps','-axo','pid=,ppid=,pgid=,lstart=,command=']),('handles',['/usr/sbin/lsof','-nP','-FpcftDin'])]:
   child,out,err=capture(argv,cwd=root,env=os.environ.copy(),receipt_path=work/(label+'-process.json'),receipt={})
   assert child.returncode==0 and not err.strip()
   found=[]
   if label=='processes':found=[line for line in out.splitlines() if any(str(p) in line for p in selected)]
   else:
    process={};entry={}
    def finish():
     name=entry.get('n','')
     try: inode=(int(entry.get('D',''),16),int(entry.get('i','')))
     except ValueError:inode=None
     if inode in inodes or any(name==str(p) or name.startswith(str(p)+'/') for p in selected):found.append(dict(process=process.copy(),file=entry.copy()))
    for line in out.splitlines():
     if not line:continue
     k,v=line[0],line[1:]
     if k=='p':finish();process={'pid':v};entry={}
     elif k=='c':process['command']=v
     elif k=='f':finish();entry={'fd':v}
     else:entry[k]=v
    finish()
   matches[label]=dict(returncode=child.returncode,raw_sha256=hashlib.sha256(out.encode()).hexdigest(),raw_lines=len(out.splitlines()),matching=found,public_output='only candidate matches; complete host output was not retained')
   assert not found,'active candidate user'
  record.update(status='retiring',paths=list(map(str,selected)),entries_verified=count,quiescence=matches,quiescent_at=time.time(),retained_files=retained,proof_files={str(proof/n):sha(proof/n) for n in ['inspection.json','inventory.jsonl.gz','retained-evidence.json','publication-documents.json','retained-profile-history.json']})
  write_json(work/'summary.json',record)
  for p in selected:
   assert p.resolve(strict=True)==p and p.is_dir() and not p.is_symlink()
   shutil.rmtree(p);record['deleted'].append(dict(path=str(p),finished_at=time.time(),free_bytes=shutil.disk_usage(root).free));write_json(work/'summary.json',record)
  for p,h in retained.items():assert sha(Path(p))==h
  assert load_compiler(root,compiler.key)==compiler
  record.update(status='passed',finished_at=time.time(),free_bytes_after=shutil.disk_usage(root).free,compiler_installation_retained=True,retained_files_verified_after=True)
  write_json(work/'summary.json',record)
  print(json.dumps({k:record[k] for k in ['status','pid','free_bytes_before','free_bytes_after','entries_verified','finished_at']}))
except BaseException as error:
 record.update(status='failed',error=repr(error),finished_at=time.time());write_json(work/'summary.json',record);raise
