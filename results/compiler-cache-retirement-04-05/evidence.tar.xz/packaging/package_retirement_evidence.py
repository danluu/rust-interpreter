#!/usr/bin/env python3
"""Archive saved, scoped retirement evidence; never scan or retire cache roots."""
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-std-source-v2-20260913')
PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
DRIVER = Path('/Users/danluu/dev/rust-interp-stable-mono-compiler-build-20260913')
OLD = Path('/Users/danluu/dev/rust-interp-stable-cgu-20260913/.work/stable-cgu-compiler-build-01')
RUN = Path(__file__).resolve().parent
OUT = ROOT / 'results/compiler-cache-retirement-04-05'
sys.path.insert(0, str(DRIVER / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, require, sha, workload_lock, write


def read(path):
    return json.loads(Path(path).read_text())


def main():
    receipt = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
        started_at=time.time(), canonical_lock=str(CANONICAL_LOCK), lock_wait_seconds=1800,
        action='archive saved retirement evidence only; no cache scan, deletion, compiler or benchmark',
        runner_sha256=sha(__file__))
    require(not (RUN / 'receipt.json').exists(), 'archive attempt already exists')
    write(RUN / 'receipt.json', receipt)
    try:
        with workload_lock(CANONICAL_LOCK, 1800):
            receipt.update(status='admitted', admitted_at=time.time())
            write(RUN / 'receipt.json', receipt)
            require(not (OUT / 'evidence.tar.xz').exists(), 'archive already exists')
            sources = {}

            def add(name, path):
                path = Path(path)
                require(name not in sources and path.is_file() and not path.is_symlink(), 'bad archive member')
                require(path.stat().st_size < 20 * 1024 * 1024, 'unexpected large evidence member')
                sources[name] = path

            inspections = {}
            for label, directory in [
                ('test-target', 'mono-test-target-retirement-inspection-01'),
                ('profile-target', 'mono-profile-target-retirement-inspection-01'),
                ('package-pair', 'obsolete-compiler-package-inspection-01')]:
                base = ROOT / '.work' / directory
                inspections[label] = read(base / 'inspection.json')
                require(inspections[label]['status'] == 'inspection completed; no retirement performed', 'inspection did not pass')
                for kind in ['handles', 'processes']:
                    filtered = read(base / (kind + '-filtered.json'))
                    require(filtered['candidate_matches'] == [] and filtered['raw_host_output_retained'] is False,
                            'unexpected process data for publication')
                for path in sorted(base.iterdir()):
                    require(path.name.endswith(('.json', '.jsonl.gz', '.py')), 'unexpected unfiltered inspection output')
                    add('inspections/' + label + '/' + path.name, path)
                require(sha(base / 'inventory.jsonl.gz') == inspections[label]['inventory_sha256'], 'inventory changed')
                for field, filename in [('retained_evidence_sha256', 'retained-evidence.json'),
                                        ('publication_documents_sha256', 'publication-documents.json')]:
                    require(sha(base / filename) == inspections[label][field], 'saved inspection proof changed')

            retirements = {}
            for number, name, runner in [
                ('04', 'profile-cache-retirement', 'retire-profile-cache-04.py'),
                ('05', 'obsolete-package-retirement', 'retire-obsolete-packages-05.py')]:
                base = PRIMARY / '.work/strict-warm-build' / (name + '-' + number)
                result = read(base / 'summary.json')
                require(result['status'] == 'passed' and result['benchmark_commands'] == 0
                        and result['retained_files_verified_after'] is True, 'retirement result is incomplete')
                for record in result['quiescence'].values():
                    require(record['matching'] == [], 'unexpected process data in retirement')
                retirements[number] = result
                for path in sorted(base.iterdir()):
                    require(path.suffix == '.json', 'unexpected retirement output')
                    add('retirement-' + number + '/' + path.name, path)
                add('retirement-' + number + '/runner.py', PRIMARY / '.work' / runner)
                supervisor = PRIMARY / '.work/experiments' / (name + '-supervisor-' + number)
                for path in sorted(supervisor.iterdir()):
                    require(path.name in ['plan.json', 'status.json', 'command.log', 'supervisor.log'], 'unexpected supervisor output')
                    add('retirement-' + number + '/supervisor/' + path.name, path)

            for label in ['03', '05', '06']:
                for filename in ['receipt.json', 'provenance.json']:
                    add('ownership/package-' + label + '/' + filename, OLD / ('package-' + label) / filename)
            for label in ['native-entry-01', 'native-entry-02', 'native-strip-01']:
                add('ownership/' + label + '/result.json', OLD / label / 'result.json')
            for label in ['prepare-01', 'prepare-02']:
                add('capacity/' + label + '/receipt.json', DRIVER / '.work/mono-production-build-02/stages' / label / 'receipt.json')
            add('capacity/original-plan02.json', DRIVER / 'experiments/stable-cgu/planned-mono-production-build-02.json')
            require(read(sources['capacity/prepare-01/receipt.json'])['commands'] == [], 'capacity failure had a child')
            add('prior-retirement/summary.json', ROOT / 'results/compiler-cache-retirement-03/summary.json')
            add('prior-retirement/members.json', ROOT / 'results/compiler-cache-retirement-03/members.json')
            add('packaging/package_retirement_evidence.py', __file__)
            members = {}
            OUT.mkdir(exist_ok=True)
            with tarfile.open(OUT / 'evidence.tar.xz', 'w:xz', preset=6) as archive:
                for name, path in sorted(sources.items()):
                    data = path.read_bytes()
                    members[name] = dict(source=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), derived=False)
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    archive.addfile(info, io.BytesIO(data))
            with tarfile.open(OUT / 'evidence.tar.xz', 'r:xz') as archive:
                require(archive.getnames() == sorted(members), 'archive members differ')
                for entry in archive:
                    require(hashlib.sha256(archive.extractfile(entry).read()).hexdigest() == members[entry.name]['sha256'], 'archive member changed')
            require(all(sha(sources[name]) == item['sha256'] for name, item in members.items()), 'saved evidence changed during packaging')
            write(OUT / 'members.json', members)
            summary = dict(schema_version=1, status='passed', kind='owned historical cache and superseded package retirement',
                benchmark_commands=0, performance_claim=False, full_host_ps_lsof_published=False,
                canonical_lock=str(CANONICAL_LOCK), current_user_visibility_only=True,
                artifact_bytes_duplicated=False,
                archive=dict(path='evidence.tar.xz', bytes=(OUT / 'evidence.tar.xz').stat().st_size,
                             sha256=sha(OUT / 'evidence.tar.xz'), members=len(members)),
                original_capacity_failure=dict(free_bytes=36403642368, required_bytes=36 * 2**30, commands=0,
                                               receipt=members['capacity/prepare-01/receipt.json']),
                not_deleted=['127295488-byte completed integration test target', 'old extracted CI LLVM',
                             'additional old raw compiler stage roots; earlier retirement03 remains separate'],
                protected='source, latest package06, installed compilers, tool publication roots, macro build05, LLVM/stage0 archives, raw receipts/profiles/artifacts',
                free_space_caveat='Whole-volume observations affected by concurrent disk usage and APFS extent sharing; not exact per-root physical reclaim.',
                retirements={number: {k: result[k] for k in ['pid', 'lock_acquired_at', 'finished_at', 'entries_verified',
                    'paths', 'free_bytes_before', 'free_bytes_after', 'retained_files_verified_after']} for number, result in retirements.items()},
                inspection_totals={label: dict(pid=item['pid'], lock_acquired_at=item['lock_acquired_at'],
                    finished_at=item['finished_at'], inventory_sha256=item['inventory_sha256']) for label, item in inspections.items()})
            write(OUT / 'summary.json', summary)
            receipt.update(status='passed', finished_at=time.time(), summary_sha256=sha(OUT / 'summary.json'),
                           archive_sha256=summary['archive']['sha256'], members=len(members))
            write(RUN / 'receipt.json', receipt)
            print(json.dumps(receipt))
    except BaseException as error:
        receipt.update(status='failed', finished_at=time.time(), error_type=type(error).__name__, error=str(error))
        write(RUN / 'receipt.json', receipt)
        raise


if __name__ == '__main__':
    main()
