from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, workload_lock, run, sha, write, require, disk
spec=importlib.util.spec_from_file_location('fixture_phase_upgrade',ROOT/'experiments/hir-fixture-env-upgrade/upgrade.py')
u=importlib.util.module_from_spec(spec);sys.modules[spec.name]=u;spec.loader.exec_module(u)
r=dict(status='waiting',started_at=time.time(),pid=os.getpid(),parent_pid=os.getppid(),
       lock=str(CANONICAL_LOCK),lock_wait_seconds=600,expected_controls=4)
write(WORK/'summary.json',r)
try:
    with workload_lock(CANONICAL_LOCK,600):
        r.update(status='running',admitted_at=time.time(),free_bytes_before=disk(ROOT))
        write(WORK/'summary.json',r)
        frozen=u.inputs() | u.engine.old.frozen_plan()['inputs'] | {str(Path(__file__).resolve()):sha(Path(__file__))}
        fixtures=[ROOT/'results/hir-native-correctness-failed-01'/name for name in ['summary.json','manifest.json']]
        frozen.update({str(p):sha(p) for p in fixtures})
        snapshots={}
        for path,expected in frozen.items():
            p=Path(path)
            require(p.resolve(strict=True)==p and p.is_file() and not p.is_symlink(),'nonordinary frozen input')
            if p.name.endswith('.tar.gz'):
                snapshots[path]=dict(sha256=expected,archive_reference=True);continue
            data=p.read_bytes();require(hashlib.sha256(data).hexdigest()==expected,'source changed during snapshot')
            dest=WORK/'sources'/str(p).lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
            snapshots[path]=dict(path=str(dest),sha256=expected,bytes=len(data))
        source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
        require(source_revision=='0c6be4183572119f0a463e9334888607af21ec47', 'unexpected source revision')
        r.update(inputs=frozen,snapshots=snapshots,source_revision=source_revision)
        write(WORK/'summary.json',r)
        env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','LC_CTYPE','SYSTEMROOT']}
        env['PYTHONDONTWRITEBYTECODE']='1'
        result=run([sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test_hir_fixture_env_upgrade.py','-v'],
                   cwd=ROOT,env=env,out=WORK/'command',capacity_root=ROOT)
        require(all(sha(p)==h for p,h in frozen.items()),'test source changed')
        output=(WORK/'command/stderr').read_text()
        require(len(re.findall(r'^test_[^\n]+ \.\.\. ok$',output,re.M))==4
                and re.search(r'^Ran 4 tests in [0-9.]+s$',output,re.M)
                and output.rstrip().endswith('OK'),'four actual passing controls required')
        r.update(status='passed',finished_at=time.time(),command_receipt_sha256=sha(WORK/'command/receipt.json'),
                 free_bytes_after=disk(ROOT),all_inputs_unchanged=True)
        write(WORK/'summary.json',r)
except BaseException as e:
    r.update(status='failed',finished_at=time.time(),error=repr(e));write(WORK/'summary.json',r);raise
