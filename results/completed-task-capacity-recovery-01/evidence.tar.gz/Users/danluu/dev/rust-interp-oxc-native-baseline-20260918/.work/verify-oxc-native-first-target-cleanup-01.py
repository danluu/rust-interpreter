import gzip,hashlib,json,tarfile
from pathlib import Path
O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
W=O/'.work/oxc-native-first-target-cleanup-01';P=O/'experiments/oxc-native-first-target-cleanup/plan-01';R=O/'results/oxc-native-first-target-preservation-01'
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=read(W/'receipt.json');a=read(O/'.work/oxc-native-first-target-assessment-01.json');plan=read(P/'plan.json');outer=read(O/'.work/experiments/oxc-native-first-target-cleanup-supervisor-01/status.json')
assert r['status']=='passed' and r['deleted_entries']==4595 and r['target_absent'] and not r['clean_native_performance_qualified']
assert outer['status']=='finished' and outer['returncode']==0 and r['pid']==outer['child_pid'] and r['parent_pid']==outer['supervisor_pid']
assert outer['started_at']<=r['started_at']<=r['admitted_at']<=r['finished_at']<=outer['finished_at']
assert not Path(a['root']).exists()
expected={str(Path(a['root'])/name) if name!='.' else a['root'] for name in a['entries']}
ledger=[json.loads(line) for line in (W/'deleted.jsonl').read_text().splitlines()]
assert len(r['deleted'])==len(set(r['deleted']))==len(ledger)==len(expected)==4595
assert set(r['deleted'])==expected and [row['path'] for row in ledger]==r['deleted']
assert all(r['admitted_at']<=row['time']<=r['finished_at'] for row in ledger)
assert read(W/'admitted-inventory.json')==a['entries']
assert r['directory_permissions']==[]
assert len(r['children'])==len(plan['commands'])==2
previous=r['admitted_at']
for item,spec in zip(r['children'],plan['commands'],strict=True):
 p=Path(item['path']);child=read(p)
 assert item['label']==spec['label'] and sha(p)==item['sha256']
 assert child['command']==spec['argv'] and child['cwd']==str(O) and child['environment']==plan['environment']
 assert child['status']=='finished' and child['returncode'] in spec['expected'] and child['supervisor_pid']==r['pid']
 assert previous<=child['started_at']<=child['finished_at']<=r['finished_at'];previous=child['finished_at']
 for stream in ['stdout','stderr']:assert sha(p.parent/stream)==child[stream+'_sha256']
 assert (p.parent/'stderr').read_bytes()==b'' and (p.parent/'stdout').read_bytes()==b''
 fields=child['identity']['ps'].split();assert int(fields[0])==child['pid'] and int(fields[1])==r['pid']
for directory,count,live in [(R,7,False),(O/'results/oxc-native-compatibility-01',286,True)]:
 m=read(directory/'manifest.json')['members']
 with tarfile.open(directory/'evidence.tar.gz','r:gz') as t:
  members=t.getmembers();assert len(members)==count and {x.name for x in members}==set(m)
  for x in members:
   assert x.isfile() and x.size==m[x.name]['bytes'];assert hashlib.sha256(t.extractfile(x).read()).hexdigest()==m[x.name]['sha256']
   if live:assert sha(O/x.name)==m[x.name]['sha256']
  while t.fileobj.read(2**20):pass
 if not live:assert m=={n:{k:v[k] for k in ['bytes','sha256']} for n,v in a['final_artifacts'].items()}
assert sha(R/'evidence.tar.gz')==r['retention']['archive_sha256'] and sha(R/'manifest.json')==r['retention']['manifest_sha256']
freeze=read(P/'inputs.json')
for name,row in freeze['files'].items():
 p=Path(name);st=p.lstat();assert {key:getattr(st,'st_'+key) for key in row['identity']}==row['identity'] and sha(p)==row['sha256']
result=dict(status='verified',receipt_sha256=sha(W/'receipt.json'),supervisor_sha256=sha(O/'.work/experiments/oxc-native-first-target-cleanup-supervisor-01/status.json'),exact_deleted_entries=4595,readonly_children=2,frozen_inputs=len(freeze['files']),archive_members=293,archive_full_gzip_eof=True,seven_actual_final_files_preserved=True,source_and_prior_evidence_unchanged=True,clean_native_performance_qualified=False,finished_at=r['finished_at'],free_bytes_after=r['free_bytes_after'])
out=O/'.work/oxc-native-first-target-cleanup-actual-verification-01.json'
with out.open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(dict(path=str(out),sha256=sha(out),**result),indent=2))
