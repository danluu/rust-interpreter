"""Independently audit actual publication children, copies and retained inputs."""
import json
from pathlib import Path
import stat
import sys
import time

ROOT = Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
sys.path.insert(0, str(ROOT / 'experiments/runtime-exporter/publication-03'))
import publish as p
m, f = p.m, p.f


def main():
    work, here = p.WORK, p.HERE
    terminal = m.read(work / 'receipt.json'); plan = m.read(here / 'plan.json'); frozen = m.read(here / 'inputs.json')
    outer_path = ROOT / '.work/experiments/runtime-exporter-publication-supervisor-03/status.json'
    outer = m.read(outer_path)
    assert terminal['status'] == 'passed' and outer['status'] == 'finished' and outer['returncode'] == 0
    assert terminal['parent_pid'] == outer['supervisor_pid'] and terminal['pid'] == outer['child_pid']
    assert terminal['inputs_sha256'] == m.sha(here / 'inputs.json')
    assert terminal['plan_sha256'] == frozen['plan_sha256'] == m.sha(here / 'plan.json')
    assert terminal['publication'] and terminal['frontend_qualified'] and terminal['source_unchanged']
    assert terminal['D_B2_R_unchanged'] and terminal['adopted_VM_unchanged']
    assert not terminal['guest_execution'] and not terminal['application_qualified'] and not terminal['benchmark']
    assert len(terminal['commands']) == len(plan['children']) == 23
    previous = terminal['admitted_at']
    for ref, expected in zip(terminal['commands'], plan['children'], strict=True):
        path = Path(ref['path']); child = m.read(path)
        assert m.sha(path) == ref['sha256'] and child['status'] == 'finished' and child['returncode'] == 0
        assert child['command'] == ref['command'] == expected['argv'] and child['cwd'] == expected['cwd']
        assert child['environment'] == expected['environment'] and child['pid'] == ref['pid']
        assert child['supervisor_pid'] == terminal['pid'] and child['parent_pid'] == terminal['parent_pid']
        assert previous <= child['started_at'] <= child['finished_at'] <= terminal['finished_at']
        previous = child['finished_at']
        for stream in ('stdout', 'stderr'): assert m.sha(path.parent / stream) == child[stream + '_sha256']
    snapshots = m.read(work / 'source-snapshots.json')
    files = frozen['files'] | {str(here / 'inputs.json'): m.sha(here / 'inputs.json')}
    assert set(snapshots) == set(files)
    for path, expected in files.items():
        assert m.sha(path) == expected == snapshots[path]['sha256'] == m.sha(snapshots[path]['path']), path
    result_path = work / 'published-tools.json'; result = m.read(result_path)
    assert m.sha(result_path) == terminal['published_tools_sha256']
    directory = Path(result['directory'])
    assert str(directory) == terminal['published_directory'] == plan['publication_directory']
    assert result['tool_key'] == terminal['tool_key'] == plan['tool_key'] == m.runtime_tools.digest(plan['composition'])
    assert result['composition'] == plan['composition'] == m.read(directory / 'compiler.json')
    assert stat.S_IMODE(directory.stat().st_mode) == 0o555 and directory.resolve(strict=True) == directory
    assert {path.name for path in directory.iterdir()} == {
        'rust-interp-mir-export','rust-interp-rustc-wrapper','rust-interp-vm','compiler.json','capabilities.json','ready.json'}
    built = m.read(f.b.WORK / 'built-tools.json')
    assert m.read(directory / 'ready.json') == built['binaries']
    assert set(result['copied']) == set(built['binaries'])
    for name, pair in result['copied'].items():
        source = m.file_record(pair['source']['path']); destination = m.file_record(directory / name)
        assert source == pair['source'] and destination == pair['destination']
        assert source['sha256'] == destination['sha256'] == built['binaries'][name]
        assert (source['identity']['dev'], source['identity']['ino']) != (destination['identity']['dev'], destination['identity']['ino'])
        assert destination['identity']['nlink'] == 1 and stat.S_IMODE((directory / name).stat().st_mode) == 0o555
    for name in ('compiler.json','capabilities.json','ready.json'):
        assert stat.S_IMODE((directory / name).stat().st_mode) == 0o444
    assert result['capabilities'] == m.read(directory / 'capabilities.json')
    validation = Path(result['installed_validation'])
    output = json.loads((validation.parent / 'stdout').read_bytes())
    assert output['status'] == 'passed' and not (validation.parent / 'stderr').read_bytes()
    assert output['tool_key'] == terminal['tool_key'] and output['compiler_key'] == m.RKEY
    assert output['compiler_sysroot'] == str(m.R) and output['owner'] == str(m.ROWNER)
    assert output['required_export_options'] == plan['required_export_options'] and not output['guest_execution']
    for path, expected in output['loaded_launcher_sources'].items():
        assert plan['runtime_launcher_sources'][path] == expected == m.sha(path)
    assert str(validation) == terminal['commands'][12]['path']
    exporter_probe = Path(result['actual_exporter_probe'])
    assert str(exporter_probe) == terminal['commands'][10]['path']
    actual_caps = json.loads((exporter_probe.parent / 'stdout').read_bytes())
    assert actual_caps == {key: value for key, value in built['capabilities'].items() if key != 'runtime_wrapper'}
    wrapper_probe = Path(result['actual_wrapper_probe'])
    assert str(wrapper_probe) == terminal['commands'][11]['path'] and not (wrapper_probe.parent / 'stderr').read_bytes()
    data = m.read(m.WORK / 'planned.json')
    for group in ('records', 'b2_files', 'registry_files'):
        for path, row in data[group].items(): assert m.file_record(path) == row, path
    assert set(map(str, m.ordinary_files(m.B2))) == set(data['b2_files'])
    for package in data['registry_packages']:
        assert set(map(str, m.ordinary_files(Path(package['manifest_path']).parent))) == set(package['source_files'])
    runtime = m.runtime_compiler.load_runtime_compiler(m.ROWNER, m.RKEY)
    assert m.tree_stamps(m.R) == data['runtime_stamps']
    for name, expected in runtime.identity['files'].items(): assert m.sha(m.R / name) == expected
    runtime.revalidate(m.ROWNER)
    m.runtime_tools.bind_recorded_wrapper(actual_caps, built['binaries'], runtime, (wrapper_probe.parent / 'stdout').read_bytes())
    actual_caps.update(tool_key=terminal['tool_key'], exporter_sha256=built['binaries']['rust-interp-mir-export'])
    assert actual_caps == result['capabilities']
    assert {str(path) for path in (m.ROWNER / 'scripts').rglob('*.py')} == set(plan['runtime_launcher_sources'])
    for path, expected in plan['runtime_launcher_sources'].items(): assert m.sha(path) == expected
    record = dict(status='passed', time=time.time(), terminal_sha256=m.sha(work / 'receipt.json'),
        outer_sha256=m.sha(outer_path), result_sha256=m.sha(result_path), actual_publication_commands=23,
        source_records_live_and_retained=len(files), tool_key=terminal['tool_key'], published_directory=str(directory),
        complete_input_records={group:len(data[group]) for group in ('records','b2_files','registry_files')},
        runtime_files=len(runtime.identity['files']), tool_hashes=built['binaries'], ordinary_reader_result=output,
        distinct_source_destination_inodes=True, ordinary_readonly_copies=True, publication=True,
        frontend_qualified=True, application_qualified=False, guest_execution=False, benchmark=False)
    path = ROOT / '.work/runtime-exporter-publication-independent-verification-03.json'
    with path.open('x') as stream: json.dump(record, stream, indent=2, sort_keys=True); stream.write('\n')
    print(json.dumps(record, indent=2)); print('independent verification', m.sha(path))


if __name__ == '__main__':
    main()
