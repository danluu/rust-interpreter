"""Retain exporter source/build/frontend/publication proof without live compiler/tool payloads."""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
FREEZE = ROOT / '.work/runtime-exporter-evidence-freeze-01.json'
WORK = ROOT / '.work/runtime-exporter-evidence-archive-01'
OUT = ROOT / 'results/runtime-exporter-publication-01'
OWNED = ROOT / 'experiments/stable-cgu/owned_stage.py'
PUBLICATION = ROOT / '.work/runtime-exporter-publication-03'
MIB = 2 ** 20


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def stamp(path):
    s = path.lstat()
    return (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_nlink)


def capture(path, expected):
    require(path.resolve(strict=True) == path, 'indirect proof path')
    before = stamp(path)
    require(stat.S_ISREG(before[2]) and before[3] <= 32 * MIB, 'unbounded or nonordinary proof')
    data = path.read_bytes()
    require(stamp(path) == before and digest(data) == expected, 'proof bytes or identity changed')
    return data


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--freeze-sha', required=True)
    args = parser.parse_args()
    require(Path.cwd() == ROOT and sys.dont_write_bytecode and not sys.flags.optimize, 'fixed owner/Python -B required')
    freeze_bytes = capture(FREEZE, args.freeze_sha)
    freeze = json.loads(freeze_bytes)
    require(freeze['owner'] == str(ROOT) and freeze['source_commit'] == '185efda9403389fcb408100e5765306179be2cbe', 'foreign source freeze')
    require(digest(Path(sys.executable).resolve().read_bytes()) == freeze['python_sha256'], 'Python changed')
    require(freeze['files'][str(OWNED)]['sha256'] == '7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e', 'owned helper differs')
    capture(OWNED, freeze['files'][str(OWNED)]['sha256'])
    capture(Path(__file__), freeze['files'][str(Path(__file__))]['sha256'])
    spec = importlib.util.spec_from_file_location('runtime_source_archive_owned', OWNED)
    owned = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = owned
    spec.loader.exec_module(owned)
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(), freeze_sha256=args.freeze_sha)
    owned.write(WORK / 'summary.json', record)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK, 600):
            free = owned.disk(ROOT, 8)
            require(free >= 8 * 2**30 + 192 * MIB, 'archive reservation unavailable')
            record.update(status='running', admitted_at=time.time(), free_bytes_before=free)
            owned.write(WORK / 'summary.json', record)
            payloads, contents, source_stamps = {}, {}, {}
            for name, item in freeze['files'].items():
                owned.disk(ROOT, 8)
                source_stamps[name] = stamp(Path(name))
                data = capture(Path(name), item['sha256'])
                require(stamp(Path(name)) == source_stamps[name], 'proof changed during admission read')
                require(len(data) == item['bytes'], 'frozen proof size differs')
                payloads[name] = contents.setdefault((item['sha256'], len(data)), data)
            require(len(payloads) <= 16384 and sum(map(len, payloads.values())) == freeze['input_bytes'] <= 1024 * MIB
                    and sum(map(len, contents.values())) == freeze['unique_input_bytes'] <= 128 * MIB, 'proof retention bound differs')
            for directory, members in freeze['directories'].items():
                actual = sorted(str(p) for p in Path(directory).rglob('*') if p.is_symlink() or not p.is_dir())
                require(actual == members, 'completed evidence directory membership changed')
            stages = {}
            for name, item in freeze['stages'].items():
                terminal = json.loads(payloads[item['receipt']['path']])
                require(digest(payloads[item['receipt']['path']]) == item['receipt']['sha256']
                        and terminal['status'] == item['status'] and len(terminal['commands']) == item['children'],
                        'stage terminal differs: ' + name)
                plan = json.loads(payloads[item['plan']['path']])
                for child_ref, expected in zip(terminal['commands'], plan['children'][:item['children']], strict=True):
                    child = json.loads(payloads[child_ref['path']])
                    require(digest(payloads[child_ref['path']]) == child_ref['sha256']
                            and child['status'] == 'finished' and child['returncode'] in expected.get('expected', [0])
                            and child['command'] == child_ref['command'] == expected['argv']
                            and child['pid'] == child_ref['pid']
                            and child['cwd'] == expected['cwd'] and child['environment'] == expected['environment']
                            and child['supervisor_pid'] == terminal['pid'] and child['parent_pid'] == terminal['parent_pid']
                            and terminal['admitted_at'] <= child['started_at'] <= child['finished_at'] <= terminal['finished_at'],
                            'stage actual child association differs: ' + name)
                    for stream in ('stdout', 'stderr'):
                        raw = payloads[str(Path(child_ref['path']).parent / stream)]
                        require(digest(raw) == child[stream + '_sha256'], 'stage raw stream differs')
                stages[name] = dict(receipt_sha256=item['receipt']['sha256'], status=item['status'], children=item['children'])
            publication = json.loads(payloads[str(PUBLICATION / 'receipt.json')])
            require(publication['status'] == 'passed' and publication['publication']
                    and publication['frontend_qualified'] and not publication['guest_execution']
                    and not publication['benchmark'], 'publication scope differs')
            independent = json.loads(payloads[str(ROOT / '.work/runtime-exporter-publication-independent-verification-03.json')])
            require(independent['status'] == 'passed' and independent['terminal_sha256'] ==
                    digest(payloads[str(PUBLICATION / 'receipt.json')]), 'publication independent audit differs')
            controls = {}
            for name, item in freeze['controls'].items():
                value = json.loads(payloads[item['path']])
                require(digest(payloads[item['path']]) == item['sha256'] and value['status'] == 'passed'
                        and value['controls'] == item['tests'], 'control summary differs')
                child_path = Path(item['path']).parent / 'command/receipt.json'
                child = json.loads(payloads[str(child_path)])
                require(child['returncode'] == 0 and digest(payloads[str(child_path)]) == value['child_receipt_sha256']
                        and child['supervisor_pid'] == value['pid'] and child['parent_pid'] == value['parent_pid'],
                        'control child differs')
                for stream in ('stdout', 'stderr'):
                    require(digest(payloads[str(child_path.parent / stream)]) == child[stream + '_sha256'], 'control raw stream differs')
                controls[name] = dict(tests=item['tests'], summary_sha256=item['sha256'])
            payloads[str(FREEZE)] = freeze_bytes
            source_stamps[str(FREEZE)] = stamp(FREEZE)
            OUT.mkdir(parents=True, exist_ok=False)
            archive = OUT / 'evidence.tar.gz'
            manifest, first = {}, {}
            with archive.open('xb') as stream:
                with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for path, data in sorted(payloads.items()):
                            owned.disk(ROOT, 8)
                            name = path.lstrip('/')
                            member = tarfile.TarInfo(name)
                            member.mode = 0o644
                            key = (digest(data), len(data))
                            if key in first:
                                member.type, member.linkname = tarfile.LNKTYPE, first[key]
                                tar.addfile(member)
                            else:
                                member.size = len(data)
                                tar.addfile(member, io.BytesIO(data))
                                first[key] = name
                            manifest[name] = dict(source=path, sha256=key[0], bytes=key[1])
            require(archive.stat().st_size <= 96 * MIB, 'compressed proof bound exceeded')
            seen = set()
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    owned.disk(ROOT, 8)
                    require(member.name in manifest and member.name not in seen and (member.isfile() or member.islnk()), 'unexpected archive member')
                    if member.islnk():
                        require(member.linkname in seen, 'forward or missing proof link')
                    data = tar.extractfile(member).read()
                    item = manifest[member.name]
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback differs')
                    seen.add(member.name)
            require(seen == set(manifest), 'incomplete archive readback')
            uncompressed = 0
            with gzip.open(archive, 'rb') as compressed:
                while block := compressed.read(MIB):
                    owned.disk(ROOT, 8)
                    uncompressed += len(block)
                    require(uncompressed <= 160 * MIB, 'archive framing exceeds bound')
            # Reading gzip to EOF separately verifies its complete trailer/CRC.

            for path, data in payloads.items():
                owned.disk(ROOT, 8)
                require(stamp(Path(path)) == source_stamps[path]
                        and capture(Path(path), digest(data)) == data, 'proof changed during archival')
            for directory, members in freeze['directories'].items():
                actual = sorted(str(p) for p in Path(directory).rglob('*') if p.is_symlink() or not p.is_dir())
                require(actual == members, 'completed evidence directory membership changed during archival')
            owned.write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed', source_commit=freeze['source_commit'],
                runtime_key=publication['runtime_key'], tool_key=publication['tool_key'],
                publication_receipt_sha256=digest(payloads[str(PUBLICATION / 'receipt.json')]),
                stages=stages, controls=controls, source_and_proof_files=len(payloads),
                actual_commands_rerun=False, live_compiler_or_tool_payload_read_by_archive=False,
                frontend_qualified=True, application_qualified=False, guest_execution=False,
                benchmark=False, performance_target_met=False, prior_failed_frontend_preserved=True,
                prior_failed_publication_admission_preserved=True, source_identities_and_membership_unchanged=True,
                archive=dict(path='evidence.tar.gz', sha256=digest(archive.read_bytes()), bytes=archive.stat().st_size,
                    members=len(manifest), physical_members=len(first), all_member_hashes_verified=True,
                    full_gzip_eof_crc_verified=True, uncompressed_bytes=uncompressed),
                manifest_sha256=digest((OUT / 'manifest.json').read_bytes()),
                archive_pid=os.getpid(), archive_parent_pid=os.getppid(), archive_admitted_at=record['admitted_at'])
            owned.write(OUT / 'summary.json', summary)
            record.update(status='passed', finished_at=time.time(), free_bytes_after=owned.disk(ROOT, 8),
                summary_sha256=digest((OUT / 'summary.json').read_bytes()), archive=summary['archive'])
            owned.write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        owned.write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
