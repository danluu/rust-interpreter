"""One exact eight-test saved-telemetry control run; never construct the continuation stage."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

OWNER = Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
HERE = OWNER / 'experiments/runtime-exporter/frontend-continue-01'
WORK = OWNER / '.work/runtime-exporter-telemetry-controls-01'
INPUTS = OWNER / '.work/runtime-exporter-telemetry-controls-inputs-01.json'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--inputs-sha256', required=True)
    args = parser.parse_args()
    require(Path.cwd() == OWNER and sys.dont_write_bytecode and not sys.flags.optimize, 'fixed control invocation required')
    require(sha(INPUTS) == args.inputs_sha256, 'reviewed control source freeze required')
    frozen = json.loads(INPUTS.read_bytes())
    def guard():
        require(sha(INPUTS) == args.inputs_sha256, 'control freeze changed')
        for path, expected in frozen['files'].items():
            require(Path(path).resolve(strict=True) == Path(path) and not Path(path).is_symlink()
                    and sha(path) == expected, 'control source changed: ' + path)
        require(str(Path(sys.executable).resolve()) == frozen['python']['resolved']
                and sha(sys.executable) == frozen['python']['sha256'], 'control Python changed')
    guard()
    spec = importlib.util.spec_from_file_location('b2_controls_owned', frozen['owned'])
    owned = importlib.util.module_from_spec(spec); spec.loader.exec_module(owned)
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', owner=str(OWNER), pid=os.getpid(), parent_pid=os.getppid(),
        started_at=time.time(), inputs_sha256=args.inputs_sha256, controls=8,
        metadata_executed=False, compiler_commands=0, assembly=False)
    owned.write(WORK / 'summary.json', record)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=owned.disk(OWNER, 8))
            owned.write(WORK / 'summary.json', record)
            guard()
            snapshots = WORK / 'source-snapshots'; snapshots.mkdir()
            for path, expected in frozen['files'].items():
                copy = snapshots / expected
                if not copy.exists():
                    with copy.open('xb') as stream:
                        stream.write(Path(path).read_bytes())
                require(sha(copy) == expected, 'control source snapshot failed')
            child = owned.run(frozen['command'], cwd=HERE, env=frozen['environment'],
                              out=WORK / 'command', capacity_root=OWNER)
            output = (WORK / 'command/stderr').read_text()
            require((WORK / 'command/stdout').read_bytes() == b''
                    and '\nRan 8 tests in ' in output and output.endswith('\nOK\n')
                    and 'skipped=' not in output and all(name + ' (test_telemetry.TelemetryControls.' + name + ') ... ok'
                    in output for name in frozen['test_names']), 'exact eight unfiltered passing controls required')
            guard()
            for expected in frozen['files'].values():
                require(sha(snapshots / expected) == expected, 'retained control source changed')
            record.update(status='passed', finished_at=time.time(), child_pid=child['pid'],
                child_receipt_sha256=sha(WORK / 'command/receipt.json'),
                helper_sha256=frozen['files'][str(HERE / 'telemetry.py')],
                stdout_sha256=child['stdout_sha256'], stderr_sha256=child['stderr_sha256'],
                free_bytes_after=owned.disk(OWNER))
            owned.write(WORK / 'summary.json', record)
    except BaseException as exc:
        record.update(status='failed', error=repr(exc), finished_at=time.time())
        owned.write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
