"""Freeze only completed exporter source and proof, excluding live build/tool payloads."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
WORK = ROOT / '.work'
HERE = ROOT / 'experiments/runtime-exporter'
FREEZE = WORK / 'runtime-exporter-evidence-freeze-01.json'
HELPER = WORK / 'archive_runtime_exporter_evidence_01.py'
STD_TEMPLATE = Path('/Users/danluu/dev/rust-interp-runtime-installation-r-20260918/.work/archive_runtime_std_evidence_01.py')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True); stream.write('\n')


def main():
    pub = read(WORK / 'runtime-exporter-publication-03/receipt.json')
    assert pub['status'] == 'passed' and pub['publication'] and pub['frontend_qualified']
    verified = read(WORK / 'runtime-exporter-publication-independent-verification-03.json')
    assert verified['status'] == 'passed' and verified['terminal_sha256'] == sha(WORK / 'runtime-exporter-publication-03/receipt.json')
    prior = read(HERE / 'publication-03/inputs.json')
    files = {}
    for path, expected in prior['files'].items():
        assert sha(path) == expected, path
        files[path] = dict(sha256=expected, bytes=Path(path).stat().st_size)
    directories = {}
    additions = [HELPER, Path(__file__).resolve(), STD_TEMPLATE, HERE / 'publication-03/inputs.json',
                 ROOT / 'experiments/stable-cgu/owned_stage.py', ROOT / 'scripts/supervise_experiment.py']
    roots = [HERE]
    for path in WORK.iterdir():
        if path.name.startswith('runtime-exporter-evidence'):
            continue
        if path.is_dir() and path.name.startswith('runtime-exporter-') and path.name != 'runtime-exporter-target-01':
            roots.append(path)
        elif path.is_file() and path.name.startswith(('runtime-exporter-', 'run_runtime_exporter_', 'verify_runtime_exporter_')):
            additions.append(path)
    for path in (WORK / 'experiments').iterdir():
        if path.is_dir() and path.name.startswith('runtime-exporter-') and not path.name.startswith('runtime-exporter-evidence'):
            roots.append(path)
    for directory in roots:
        members = sorted(str(path) for path in directory.rglob('*') if path.is_symlink() or not path.is_dir())
        assert not any(Path(path).is_symlink() for path in members)
        directories[str(directory)] = members
        additions += [Path(path) for path in members]
    published = Path(pub['published_directory'])
    additions += [published / name for name in ('ready.json', 'capabilities.json', 'compiler.json')]
    for path in additions:
        assert path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
        item = dict(sha256=sha(path), bytes=path.stat().st_size)
        assert str(path) not in files or files[str(path)] == item
        files[str(path)] = item
    stages = {}
    for name, source, count, status in [('metadata-01','metadata-02',53,'passed'), ('build-01','build-02',19,'passed'),
            ('frontend-01','frontend-01',32,'failed'), ('frontend-continue-01','frontend-continue-01',8,'passed'),
            ('publication-01','publication-01',0,'failed'), ('publication-02','publication-02',0,'failed'), ('publication-03','publication-03',23,'passed')]:
        receipt = WORK / ('runtime-exporter-' + name) / 'receipt.json'; plan = HERE / source / 'plan.json'
        stages[name] = dict(receipt=dict(path=str(receipt), sha256=sha(receipt)),
                           plan=dict(path=str(plan), sha256=sha(plan)), children=count, status=status)
    controls = {}
    for name, count in [('metadata-controls-01',5),('build-controls-02',6),('frontend-controls-01',4),('telemetry-controls-01',8)]:
        path = WORK / ('runtime-exporter-' + name) / 'summary.json'
        controls[name] = dict(path=str(path), sha256=sha(path), tests=count)
    unique = {(item['sha256'], item['bytes']) for item in files.values()}
    frozen = dict(schema_version=1, owner=str(ROOT), source_commit='185efda9403389fcb408100e5765306179be2cbe',
        files=files, directories=directories, stages=stages, controls=controls,
        input_bytes=sum(item['bytes'] for item in files.values()), unique_input_bytes=sum(size for _, size in unique),
        python_sha256=prior['python']['sha256'], source_template=dict(path=str(STD_TEMPLATE), sha256=sha(STD_TEMPLATE)),
        bounds=dict(logical_input_bytes=1024*2**20, unique_input_bytes=128*2**20, compressed_output_bytes=96*2**20,
                    evidence_reservation_bytes=192*2**20, source_files=16384, single_file_bytes=32*2**20))
    assert len(files) <= 16384 and frozen['input_bytes'] <= 1024*2**20 and frozen['unique_input_bytes'] <= 128*2**20
    assert max(item['bytes'] for item in files.values()) <= 32*2**20
    write(FREEZE, frozen)
    python = prior['python']['path']; supervisor = ROOT / 'scripts/supervise_experiment.py'
    launch = dict(status='prepared-unexecuted-awaiting-root-review', owner=str(ROOT), environment=prior['launch_environment'],
        command=[python,'-B',str(supervisor),'--run-id','runtime-exporter-evidence-supervisor-01','--',
                 python,'-B',str(HELPER),'--freeze-sha',sha(FREEZE)],
        helper_sha256=sha(HELPER), freeze_sha256=sha(FREEZE), supervisor_sha256=sha(supervisor),
        canonical_lock='/Users/danluu/dev/rust-interp/.work/benchmark.lock', wait_seconds=600,
        entry_gib=8, floor_gib=8, evidence_reservation_mib=192, compiler_commands=0, guest_execution=False, benchmark=False)
    path = WORK / 'runtime-exporter-evidence-launch-01.json'; write(path, launch)
    for code in (HELPER, Path(__file__).resolve()): ast.parse(code.read_text())
    print(json.dumps(dict(launch=str(path), launch_sha256=sha(path), helper_sha256=sha(HELPER),
        freeze_sha256=sha(FREEZE), files=len(files), logical_bytes=frozen['input_bytes'], unique_bytes=frozen['unique_input_bytes']), indent=2))


if __name__ == '__main__':
    main()
