#!/usr/bin/env python3
"""Three explicit stages: metadata plan, fresh B assembly, stock-main smoke."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time

OWNER = Path('/Users/danluu/dev/rust-interp-embedded-frontend-bootstrap-20260913')
HERE = OWNER / '.work/embedded-frontend-compatibility-source-02'
ROOT = OWNER / '.work/embedded-frontend-compatibility-02'
FROZEN = HERE / 'frozen.json'
INSPECT = OWNER / '.work/embedded-frontend-input-inspection-03'
INSPECT_SHA = '700e6aff03cbb0e1e74d4d99a609c2b138a8eab22fff46eb732bd85b5e2205e8'
SOURCE = Path('/Users/danluu/dev/rustc-hir-capture-check-20260913')
STAGE2 = Path('/Users/danluu/dev/rust-interp-hir-arena-stage2-20260913')
HOST = 'aarch64-apple-darwin'
REVISION = '7efc0d9484da82cd327deb3b48616f8ec81eaf8d'
D = SOURCE / 'build' / HOST / 'stage0/bin/rustc'
E = SOURCE / 'build' / HOST / 'stage1'
B = ROOT / 'build-sysroot'
DRIVER = 'librustc_driver-88dbe03d702a9b6c.dylib'
FIXTURE = ROOT / 'fixture/input.rs'
ORIGINAL = b'fn anchor() -> u32 { 42 }\nfn main() { println!("{}", anchor()); }\n'
ERROR = ORIGINAL + b'fn uncalled() -> u8 { "wrong" }\n'
PLAN = ROOT / 'planned.json'
POLICY = 'embedded-frontend-stock-smoke-v1'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read(path, expected=None):
    require(expected is None or sha(path) == expected, 'JSON input changed: ' + str(path))
    return json.loads(Path(path).read_bytes())


def environment():
    return dict(PATH='/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin', HOME='/Users/danluu',
                LANG='C', LC_ALL='C', TZ='UTC', TMPDIR='/private/tmp/',
                CARGO_BUILD_JOBS='2', CARGO_NET_OFFLINE='true',
                PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')


def parse_dyld(text, pid, allowed, driver):
    """Pure two-form parser; delayed system-image notices are not load proof."""
    require(isinstance(pid, int) and pid > 0, 'actual loader child PID required')
    prefix = rf'dyld\[{pid}\]: '
    images, delayed, basenames, loaded = [], [], {}, set()
    for number, line in enumerate(text.splitlines(), 1):
        image = re.fullmatch(prefix + r'(?:<[0-9A-Fa-f-]{36}>\s+)?(/.+)', line)
        move = re.fullmatch(prefix + r'move loaded to delayed: ([^/\r\n]+)', line)
        if image:
            path = image[1]
            require(str(Path(path)) == path and '..' not in Path(path).parts, 'noncanonical dyld image path')
            system = path.startswith(('/usr/lib/', '/System/Library/'))
            images.append(dict(line=number, raw=line, path=path, system=system))
            basenames.setdefault(Path(path).name, set()).add(path)
            if not system:
                require(path in allowed, 'foreign non-system dyld image: ' + path)
                loaded.add(path)
        elif move:
            name = move[1]
            matches = basenames.get(name, set())
            require(len(matches) == 1 and all(p.startswith(('/usr/lib/', '/System/Library/')) for p in matches),
                    'delayed notice is not one previously observed system image: ' + name)
            delayed.append(dict(line=number, raw=line, basename=name, image=next(iter(matches))))
        else:
            raise RuntimeError('unexpected raw dyld diagnostic: ' + line)
    require(driver in loaded, 'actual required driver image missing')
    return dict(loaded_non_system=sorted(loaded), images=images, delayed=delayed)


class Stage:
    def __init__(self, args):
        self.args = args
        require(sha(FROZEN) == args.frozen_sha, 'runner freeze changed')
        self.frozen = read(FROZEN)
        self.check_sources()
        self.owned = load('embedded_smoke_owned', OWNER / 'experiments/stable-cgu/owned_stage.py')
        self.comp = load('embedded_smoke_compositor', OWNER / 'experiments/embedded-frontend-bootstrap/compose_sysroot.py')
        sys.path.insert(0, str(OWNER / 'scripts'))
        self.libs = load('embedded_smoke_libraries', OWNER / 'scripts/custom_cargo_libraries.py')
        self.stage2 = load('embedded_smoke_stage2', STAGE2 / 'experiments/hir-stage2-package/check.py')
        for module in list(sys.modules.values()):
            path = getattr(module, '__file__', None)
            if path and str(path).startswith('/Users/danluu/dev/rust-interp'):
                require(str(Path(path).resolve()) in self.frozen['files'], 'unfrozen import: ' + path)
        self.work = ROOT / 'stages' / (args.stage + '-' + args.attempt)
        self.work.mkdir(parents=True, exist_ok=False)
        self.env = environment()
        self.record = dict(schema_version=1, policy=POLICY, status='waiting', stage=args.stage,
            owner=str(OWNER), pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
            command=sys.argv, cwd=os.getcwd(), frozen_sha256=args.frozen_sha,
            canonical_lock=str(self.owned.CANONICAL_LOCK), wait_seconds=600,
            benchmark=False, commands=[], environment=self.env,
            python=dict(path=sys.executable, resolved=str(Path(sys.executable).resolve()), sha256=sha(sys.executable)))
        self.save()

    def save(self):
        self.owned.write(self.work / 'receipt.json', self.record)

    def check_sources(self):
        require(sha(FROZEN) == self.args.frozen_sha, 'runner freeze changed during stage')
        for path, expected in self.frozen['files'].items():
            p = Path(path)
            require(p.is_file() and not p.is_symlink() and p.resolve() == p and sha(p) == expected,
                    'frozen source/evidence changed: ' + path)
        require(str(Path(sys.executable).resolve()) == self.frozen['python']['resolved']
                and sha(sys.executable) == self.frozen['python']['sha256'], 'Python identity changed')

    def run(self, argv, *, env=None, cwd=ROOT, expected=(0,), role='guard'):
        self.check_sources()
        out = self.work / 'commands' / f'{len(self.record["commands"]):03}'
        try:
            child = self.owned.run(argv, cwd=cwd, env=env or self.env, out=out,
                                   capacity_root=OWNER, expected=expected)
        finally:
            if (out / 'receipt.json').exists():
                child = read(out / 'receipt.json')
                self.record['commands'].append(dict(path=str(out / 'receipt.json'),
                    sha256=sha(out / 'receipt.json'), role=role, command=child['command'],
                    pid=child.get('pid'), returncode=child.get('returncode')))
                self.save()
        return dict(receipt=child, path=str(out / 'receipt.json'),
                    stdout=(out / 'stdout').read_bytes(), stderr=(out / 'stderr').read_bytes())

    def inspect(self, argv, text=True):
        require(text and argv[:2] == ['/usr/bin/otool', '-arch'], 'unexpected library inspector command')
        return self.run(argv)['stdout'].decode()

    def guard(self):
        self.check_sources()
        failed = read(self.frozen['prior_failure']['path'], self.frozen['prior_failure']['sha256'])
        require(failed['files'].items() <= self.frozen['files'].items(), 'failed01 evidence omitted from freeze')
        failure, outer = read(failed['receipt']), read(failed['supervisor'])
        require(failure['status'] == 'failed' and failure['error'] == failed['error']
                and len(failure['commands']) == 14 and failure['pid'] == 71481
                and outer['status'] == 'finished' and outer['returncode'] == 1
                and outer['child_pid'] == failure['pid'] and outer['supervisor_pid'] == failure['parent_pid'] == 71478,
                'failed metadata01 association changed')
        summary = read(INSPECT / 'summary.json', INSPECT_SHA)
        require(summary['status'] == 'inspected-pending-review' and summary['complete_map']
                and summary['stamp_rows'] == summary['hashed_artifacts'] == 256 and not summary['row_issues']
                and summary['source_unchanged'] and summary['runtime_unchanged'], 'complete inspection03 required')
        old_freeze = read(OWNER / '.work/embedded-frontend-input-inspection-freeze-03.json', summary['frozen_sha256'])
        require(old_freeze['files'].items() <= self.frozen['files'].items(), 'inspection163 closure not frozen')
        for item in read(INSPECT / 'read-inputs.json', summary['read_inputs_sha256']).values():
            self.comp.check_file(item)
        proposal = read(OWNER / 'experiments/embedded-frontend-bootstrap/INSPECTION.json')
        require(self.stage2.inputs() == proposal['guard_reuse']['helper_inputs'], 'stage2 helper135 changed')
        prior = read(proposal['guard_reuse']['materialized_stage2_plan']['path'],
                     proposal['guard_reuse']['materialized_stage2_plan']['sha256'])['previous']
        require(prior['source']['revision'] == REVISION and prior['actual_complete_direct_replay'],
                'qualified native source changed')
        # Original archives are content-bound by inspection03/read-inputs. Reuse
        # the existing current-source and exact runtime guards, not filename inference.
        def git(argv, cwd=SOURCE):
            require(argv[:1] == ['git'], 'source guard may only invoke Git')
            result = self.run(argv, cwd=cwd, env=prior['old_plan']['environment'])
            require(not result['stderr'], 'source guard emitted stderr')
            return dict(stdout=result['stdout'].decode(), stderr='')
        self.stage2.engine.source_guard(prior['source'], git,
            'd97d608124128bf203375125786683ada8c6d9a758971be8e861301b9835cf42')
        require(self.stage2.native.artifacts() == prior['stage1']
                == read(INSPECT / 'qualified-runtime.json'), 'qualified E runtime changed')
        return summary, prior

    def file(self, path, expected=None):
        path = Path(path)
        return self.comp.check_file(dict(path=str(path), sha256=expected or sha(path)))

    def load_check(self, result, closure, driver):
        allowed = {x['resolved'] for x in closure['libraries']}
        # dyld lists the main image too; it is separately hash-bound by caller.
        allowed.add(str(Path(result['receipt']['command'][0]).resolve(strict=True)))
        parsed = parse_dyld(result['stderr'].decode(), result['receipt']['pid'], allowed,
                            str(Path(driver).resolve(strict=True)))
        self.record.setdefault('loader_logs', []).append(dict(receipt=result['path'],
            stderr_sha256=result['receipt']['stderr_sha256'], **parsed))
        self.save()
        return parsed['loaded_non_system']

    def probe(self, executable, sysroot, expected_file, approved_libraries, expected_commit=None):
        self.file(executable, expected_file)
        closure, state = self.libs.library_closure(Path(executable), HOST, inspect=self.inspect)
        require(all(approved_libraries.get(x['resolved']) == x['sha256'] for x in closure['libraries']),
                'compiler loader library is not an approved beta/E file')
        drivers = [x for x in closure['libraries'] if Path(x['resolved']).name.startswith('librustc_driver-')]
        require(len(drivers) == 1, 'exactly one native compiler driver required')
        version = self.run([str(executable), '-vV'], env=self.env | {'DYLD_PRINT_LIBRARIES': '1'})
        text = version['stdout'].decode()
        fields = dict(line.split(': ', 1) for line in text.splitlines() if ': ' in line)
        require(fields.get('host') == HOST and fields.get('commit-hash')
                and (expected_commit is None or fields['commit-hash'] == expected_commit), 'compiler version mismatch')
        loaded = self.load_check(version, closure, drivers[0]['resolved'])
        root = self.run([str(executable), '--print', 'sysroot'])
        require(root['stdout'].decode().strip() == str(sysroot) and not root['stderr'], 'default sysroot mismatch')
        return dict(path=str(executable), sha256=expected_file, version=text, default_sysroot=str(sysroot),
                    driver=drivers[0], closure=closure, state=state, loaded=loaded,
                    version_receipt=version['path'], sysroot_receipt=root['path'])

    def check_plan(self):
        require(self.args.plan_sha is not None and sha(PLAN) == self.args.plan_sha, 'reviewed exact plan SHA required')
        plan = read(PLAN)
        require(plan['policy'] == POLICY and plan['runner_freeze_sha256'] == self.args.frozen_sha,
                'plan belongs to another runner')
        metadata = read(plan['metadata_receipt'])
        require(metadata['status'] == 'passed' and metadata['plan_sha256'] == self.args.plan_sha,
                'metadata stage must have completed successfully')
        for path, expected in plan['input_snapshots'].items():
            require(sha(path) == expected, 'frozen input snapshot changed')
        self.comp.recheck_inputs(plan['composition'])
        for record in plan['guard_files']:
            self.comp.check_file(record)
        for key in ['build_compiler', 'runtime_compiler']:
            item = plan[key]
            require(self.libs.library_state(item['closure']) == item['state'], 'compiler loader state changed')
            for library in item['closure']['libraries']:
                self.file(library['resolved'], library['sha256'])
        return plan

    def metadata(self):
        require(not PLAN.exists() and not B.exists(), 'metadata plan/output must be fresh')
        summary, prior = self.guard()
        snapshots = {}
        directory = ROOT / 'input-snapshots'
        directory.mkdir()
        for path, expected in self.frozen['files'].items() | {str(FROZEN): self.args.frozen_sha}.items():
            data = Path(path).read_bytes()
            require(self.comp.digest(data) == expected, 'snapshot source changed')
            copy = directory / expected
            if not copy.exists():
                self.comp.write_new(copy, data, lambda: self.owned.disk(OWNER))
            require(sha(copy) == expected, 'input snapshot changed')
            snapshots[str(copy)] = expected
        beta = read(INSPECT / 'beta-library-files.json')
        d_record = read(INSPECT / 'build-compiler.json')['file']
        # Bind the executable's actual loader/codegen/std files to its original
        # archive, separately from the not-yet-created B copies.
        guards = [self.file(D.parent.parent / rel, row['sha256']) for rel, row in beta.items()]
        build = self.probe(D, D.parent.parent, d_record['sha256'],
            {str(D.parent.parent / rel): row['sha256'] for rel, row in beta.items()})
        runtime = self.probe(E / 'bin/rustc', E, prior['stage1']['files']['bin/rustc']['sha256'],
            {str(E / rel): row['sha256'] for rel, row in prior['stage1']['files'].items()}, REVISION)
        require(runtime['driver']['resolved'] == str(E / 'lib' / DRIVER), 'E driver loaded from wrong location')
        runtime.update(source_commit=REVISION, sysroot=str(E), driver_path=str(E / 'lib' / DRIVER),
                       driver_sha256=runtime['driver']['sha256'])
        developer = self.run(['/usr/bin/xcode-select', '-p'])['stdout'].decode().strip()
        sdk = self.run(['/usr/bin/xcrun', '--sdk', 'macosx', '--show-sdk-path'])['stdout'].decode().strip()
        clang = self.run(['/usr/bin/xcrun', '--sdk', 'macosx', '--find', 'clang'])['stdout'].decode().strip()
        linker = self.run(['/usr/bin/xcrun', '--sdk', 'macosx', '--find', 'ld'])['stdout'].decode().strip()
        require(all(Path(x).is_absolute() for x in [developer, sdk, clang, linker]), 'SDK/tool path missing')
        discovered = dict(developer=developer, sdk=sdk, clang=clang, linker=linker)
        # Record real resolved tool paths, preserving the discovery command too.
        clang, linker, sdk = (str(Path(x).resolve(strict=True)) for x in [clang, linker, sdk])
        for path in ['/usr/bin/xcode-select', '/usr/bin/xcrun', '/usr/bin/otool', clang, linker, str(Path(sdk) / 'SDKSettings.json')]:
            guards.append(self.file(Path(path).resolve(strict=True)))
        clang_version = self.run([clang, '--version'])['stdout'].decode()
        rows = read(INSPECT / 'stamp-artifacts.json')
        private = read(INSPECT / 'candidate-private-files.json', summary['candidate_map_sha256'])
        native = read(INSPECT / 'native005-producers.json')['commands'][172]
        require(native['crate'] == 'rustc_main' and native['line_sha256'] ==
                'e0b378f869409ab88a43e243507ac9fe4609cc7b2453ca9d61f74c1e3f11b794'
                and any(x['name'] == 'rustc_driver' and x['path'].endswith('/' + DRIVER) for x in native['externs']),
                'saved native driver extern proof changed')
        proof_map = read(INSPECT / 'retained-proofs.json', summary['retained_proofs_sha256'])
        proof_files = {item['copy']: item['sha256'] for versions in proof_map.values() for item in versions.values()}
        proof_files.update({str(p): sha(p) for p in [FROZEN, HERE / 'stamp-reconciliation.json', INSPECT / 'summary.json',
            INSPECT / 'stamp-artifacts.json', INSPECT / 'candidate-private-files.json', INSPECT / 'read-inputs.json',
            INSPECT / 'beta-library-files.json', INSPECT / 'build-compiler.json', INSPECT / 'qualified-runtime.json']})
        proof_files.update(snapshots)
        archives = [x['file'] for x in read(INSPECT / 'beta-archive-selection.json')]
        stamp = read(INSPECT / 'raw-stamp.json')['file']
        composition = self.comp.inspect_inputs(archives=archives, stamp=stamp,
            approved_private_files=private, build_compiler=d_record, runtime_source_commit=REVISION,
            runtime_driver=dict(path=str(E / 'lib' / DRIVER), sha256=runtime['driver']['sha256']),
            proofs=[dict(path=p, sha256=h) for p, h in sorted(proof_files.items())])
        require(len(composition['files']) == 334 and len(composition['private']) == len(rows) == 256,
                'full inspected composition changed')
        build_argv = [str(D), '--sysroot=' + str(B), '--edition=2024', '--crate-name', 'rustc_main', '--print=link-args',
            str(SOURCE / 'compiler/rustc/src/main.rs'), '--extern',
            'rustc_driver=' + str(B / 'lib/rustlib' / HOST / 'lib' / DRIVER),
            '-Lnative=' + str(E / 'lib'), '-Clinker=' + clang,
            '-C', 'link-arg=-Wl,-rpath,' + str(E / 'lib'), '-o', str(ROOT / 'smoke-rustc')]
        plan = dict(schema_version=1, policy=POLICY, status='planned-unexecuted',
            runner_freeze_sha256=self.args.frozen_sha, inspection=dict(path=str(INSPECT / 'summary.json'), sha256=INSPECT_SHA),
            metadata_receipt=str(self.work / 'receipt.json'), input_snapshots=snapshots,
            build_compiler=build, runtime_compiler=runtime, guard_files=guards,
            sdk=dict(path=sdk, clang=clang, linker=linker, clang_version=clang_version, discovered=discovered),
            composition=composition, composition_sha256=self.comp.digest(self.comp.encoded(composition)),
            destination=str(B), assembly_evidence=str(ROOT / 'composition'),
            copy_payload_bytes=sum(x['size'] for x in composition['files'].values()),
            proof_copy_bytes=sum(x['size'] for x in composition['proofs']),
            build_argv=build_argv, build_environment=self.env | {'SDKROOT': sdk, 'RUSTC_BOOTSTRAP': '1'},
            application_environment=self.env | {'SDKROOT': sdk},
            source=str(SOURCE / 'compiler/rustc/src/main.rs'), source_sha256=sha(SOURCE / 'compiler/rustc/src/main.rs'))
        self.guard()
        for file in guards:
            self.comp.check_file(file)
        self.owned.write(PLAN, plan)
        self.record.update(plan_path=str(PLAN), plan_sha256=sha(PLAN), compiler_builds=0,
                           assemblies=0, copy_payload_bytes=plan['copy_payload_bytes'])

    def assembly(self):
        self.guard()
        plan = self.check_plan()
        require(not B.exists() and not (ROOT / 'composition').exists(), 'fresh B and evidence required')
        need = plan['copy_payload_bytes'] + plan['proof_copy_bytes'] + 8 * 1024**3
        require(shutil.disk_usage(OWNER).free >= need, 'full composition plus 8GiB floor does not fit')
        result = self.comp.assemble(plan['composition'], expected_plan_sha256=plan['composition_sha256'],
            destination=B, evidence=ROOT / 'composition', capacity_guard=lambda: self.owned.disk(OWNER))
        self.guard()
        self.check_plan()
        self.record.update(assembly=result, plan_sha256=self.args.plan_sha,
            manifest_path=str(ROOT / 'composition/private-sysroot.json'),
            manifest_sha256=sha(ROOT / 'composition/private-sysroot.json'))

    def b_guard(self, plan):
        actual = self.comp.output_inventory(B)
        expected = {path: {k: row[k] for k in ('sha256', 'size', 'mode')} for path, row in plan['composition']['files'].items()}
        require({path: {k: row[k] for k in ('sha256', 'size', 'mode')} for path, row in actual.items()} == expected,
                'complete B output differs')
        manifest = read(ROOT / 'composition/private-sysroot.json')
        require(manifest == dict(schema_version=1, build_compiler_sha256=plan['build_compiler']['sha256'],
            runtime_source_commit=REVISION, sysroot=str(B), host=HOST,
            files={path: row['sha256'] for path, row in actual.items()}), 'private B manifest differs')
        return manifest

    def smoke(self):
        self.guard()
        plan = self.check_plan()
        assembly = read(ROOT / 'stages/assemble-01/receipt.json', self.args.assembly_sha)
        require(assembly['status'] == 'passed' and assembly['plan_sha256'] == self.args.plan_sha,
                'successful exact assembly required')
        self.b_guard(plan)
        smoke = ROOT / 'smoke-rustc'
        require(not smoke.exists() and not FIXTURE.parent.exists(), 'smoke outputs must be fresh')
        env = plan['application_environment']
        def run(argv, **kwargs):
            return self.run(argv, env=kwargs.pop('env', env), role='smoke-control', **kwargs)
        versions = {}
        for label, compiler in [('build', plan['build_compiler']), ('runtime', plan['runtime_compiler'])]:
            result = run([compiler['path'], '-vV'])
            require(result['stdout'].decode() == compiler['version'] and not result['stderr'], 'pre-smoke version changed')
            result = run([compiler['path'], '--print', 'sysroot'])
            require(result['stdout'].decode().strip() == compiler['default_sysroot'] and not result['stderr'], 'pre-smoke sysroot changed')
            versions[label] = compiler
        build = run(plan['build_argv'], env=plan['build_environment'])
        require(plan['sdk']['clang'].encode() in build['stdout'], 'actual native linker command was not retained')
        binary = self.file(smoke)
        run(['/usr/bin/otool', '-L', str(smoke)])
        loaded = run([str(smoke), '-vV'], env=env | {'DYLD_PRINT_LIBRARIES': '1'})
        require(loaded['stdout'].decode() == plan['runtime_compiler']['version'], 'embedded compiler is not E')
        self.load_check(loaded, plan['runtime_compiler']['closure'], E / 'lib' / DRIVER)
        FIXTURE.parent.mkdir()
        common = [str(FIXTURE), '--sysroot=' + str(E), '--edition=2024', '--crate-name', 'embedded_driver_smoke',
            '-Cmetadata=embedded_driver_smoke', '-Cdebuginfo=2', '-Clinker=' + plan['sdk']['clang'],
            '-Zhir-body-cache-capture=false', '-o', str(FIXTURE.parent / 'program')]
        def compile(reuse, info=False, fails=False, raw=False):
            args = [str(smoke if reuse else E / 'bin/rustc'), *common,
                    '-Cincremental=' + str(ROOT / ('incremental-reuse' if reuse else 'incremental-ordinary'))]
            if reuse: args += ['-Zhir-body-cache-reuse=true']
            if info: args += ['-Zincremental-info']
            if raw: args += ['--error-format=json']
            source_bytes = FIXTURE.read_bytes()
            result = run(args, expected=(1,) if fails else (0,))
            require(FIXTURE.read_bytes() == source_bytes, 'fixture changed during compiler command')
            self.record.setdefault('fixture_compilations', []).append(dict(receipt=result['path'],
                source_sha256=self.comp.digest(source_bytes), reuse=reuse, info=info, raw=raw, fails=fails))
            self.save()
            return result
        def output():
            artifact = self.file(FIXTURE.parent / 'program')
            directory = self.work / 'artifacts'; directory.mkdir(exist_ok=True)
            copy = directory / (str(len(self.record.get('native_executions', []))) + '.bin')
            with copy.open('xb') as target:
                self.comp.check_file(artifact, target, lambda: self.owned.disk(OWNER))
            require(sha(copy) == artifact['sha256'], 'native artifact snapshot differs')
            result = run([artifact['path']])
            require(result['stdout'] == b'42\n' and not result['stderr'], 'native fixture output differs')
            self.comp.check_file(artifact)
            self.record.setdefault('native_executions', []).append(dict(receipt=result['path'],
                artifact=artifact, snapshot=str(copy), snapshot_sha256=artifact['sha256']))
            self.save()
        def hit(result, cold=False):
            text = result['stderr'].decode()
            prefix = '[hir-body-capture] anchor cold-tree-and-journal-after-stock-lowering' if cold else \
                '[hir-body-reuse] anchor hit cache_hits=1 verify_tree=1 verify_journal=1 verify_poststate=1'
            matching = [line for line in text.splitlines() if line.startswith(prefix)]
            require(len(matching) == 1, 'exact actual anchor cold/hit record required')
            match = re.search(r'\bS=(\d+) E=(\d+)\b', matching[0])
            require(match and 0 < int(match[1]) < int(match[2]) <= 0xFFFF_FF00, 'invalid actual S/E')
            if cold:
                require('cache_hits=0 body_codec=1 prepared_values=1 cold_materialization_audit=1 hit_materializer=0' in matching[0],
                        'cold audit evidence missing')
        try:
            FIXTURE.write_bytes(ORIGINAL)
            (self.work / 'original.rs').write_bytes(ORIGINAL)
            compile(False); output()
            hit(compile(True, info=True), cold=True); output()
            hit(compile(True, info=True)); output()
            FIXTURE.write_bytes(ERROR)
            (self.work / 'error.rs').write_bytes(ERROR)
            ordinary = compile(False, fails=True, raw=True)
            candidate = compile(True, fails=True, raw=True)
            require(ordinary['stderr'] == candidate['stderr'] and b'E0308' in candidate['stderr']
                    and not ordinary['stdout'] and not candidate['stdout'], 'raw uncalled error differs')
            hit(compile(True, info=True, fails=True))
            FIXTURE.write_bytes(ORIGINAL)
            hit(compile(True, info=True)); output()
        finally:
            FIXTURE.write_bytes(ORIGINAL)
            (self.work / 'restored.rs').write_bytes(FIXTURE.read_bytes())
        require(sum(x['role'] == 'smoke-control' for x in self.record['commands']) == 18, 'exact 18 controls required')
        self.file(smoke, binary['sha256'])
        self.guard(); self.check_plan(); self.b_guard(plan)
        self.record.update(inspection=plan['inspection'], plan_sha256=self.args.plan_sha,
            composition=dict(plan_sha256=plan['composition_sha256'], manifest_path=str(ROOT / 'composition/private-sysroot.json'),
                manifest_sha256=sha(ROOT / 'composition/private-sysroot.json')),
            build_compiler=plan['build_compiler'], runtime_compiler=plan['runtime_compiler'],
            smoke=dict(path=str(smoke), sha256=binary['sha256'], source_path=plan['source'], source_sha256=plan['source_sha256'],
                       build_receipt=build['path'], loader_receipt=loaded['path']),
            checks=dict(ordinary_output=True, cold_capture=True, actual_hit=True,
                        uncalled_error_raw_equal=True, uncalled_error_hit=True, restored=True),
            source_unchanged=True, runtime_unchanged=True, source_restored=True)

    def execute(self):
        try:
            with self.owned.workload_lock(self.owned.CANONICAL_LOCK, 600):
                self.record.update(status='running', admitted_at=time.time(), free_bytes_before=self.owned.disk(OWNER))
                self.save()
                getattr(self, {'plan': 'metadata', 'assemble': 'assembly', 'smoke': 'smoke'}[self.args.stage])()
                self.check_sources()
                self.record['evidence_files'] = {str(p): sha(p) for p in sorted(self.work.rglob('*'))
                    if p.is_file() and p != self.work / 'receipt.json'}
                self.record.update(status='passed', finished_at=time.time(), free_bytes_after=self.owned.disk(OWNER))
                self.save()
        except BaseException as error:
            self.record.update(status='failed', finished_at=time.time(), error=repr(error)); self.save()
            raise


def main():
    require(sys.dont_write_bytecode and not sys.flags.optimize, 'use Python -B without optimization')
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['plan', 'assemble', 'smoke'], required=True)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--frozen-sha', required=True)
    parser.add_argument('--plan-sha')
    parser.add_argument('--assembly-sha')
    args = parser.parse_args()
    require(re.fullmatch(r'[0-9]{2}', args.attempt), 'fresh two-digit attempt required')
    require(re.fullmatch(r'[0-9a-f]{64}', args.frozen_sha), 'exact freeze SHA required')
    require(args.stage == 'plan' or args.plan_sha and re.fullmatch(r'[0-9a-f]{64}', args.plan_sha), 'exact plan SHA required')
    require(args.stage != 'smoke' or args.assembly_sha and re.fullmatch(r'[0-9a-f]{64}', args.assembly_sha), 'exact assembly receipt SHA required')
    Stage(args).execute()


if __name__ == '__main__':
    main()
