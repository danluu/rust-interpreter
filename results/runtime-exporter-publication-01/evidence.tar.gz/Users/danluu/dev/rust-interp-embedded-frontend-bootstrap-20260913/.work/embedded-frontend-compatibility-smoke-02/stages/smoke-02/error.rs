fn anchor() -> u32 { 42 }
fn main() { println!("{}", anchor()); }
fn uncalled() -> u8 { "wrong" }
