# Stock driver compatibility smoke (source-only proposal)

This recipe has not assembled B, probed D, compiled a tool, or run a fixture.
It consumes reviewed inspection03 rather than replacing its pending approval.
The eight compositor controls and six parser controls passed separately.
No compiler source, frozen controller, or current stage0 sysroot changes.

Metadata attempt01 is retained unchanged in the preceding compatibility-01
root. Its genuine beta3 version child returned0, but the old parser rejected
dyld's ordinary delayed-system-image notices. Attempt02 uses fresh source and
output roots. Its pure parser retains absolute image rows and delayed-move
rows with the exact child PID; every delayed basename must name exactly one
already observed system image. Unknown formats, foreign images and a missing
required driver still fail. Six saved-raw/tamper controls are prepared, unrun.

## Fixed roles and owned output

SOURCE = /Users/danluu/dev/rustc-hir-capture-check-20260913, commit
7efc0d9484da82cd327deb3b48616f8ec81eaf8d; HOST = aarch64-apple-darwin.
D = SOURCE/build/HOST/stage0/bin/rustc, SHA
64ea4e574ddc2e589ad1aedfe738e19a34215e0d46024ee98c722eebd3debd56.
Its version/default sysroot still need actual probes.
E = SOURCE/build/HOST/stage1; its qualified driver SHA is
c8c9b0183af095938cdef57264acf7021b05080ad411d28ae291e185c58170a0.
Use EMBED = /Users/danluu/dev/rust-interp-embedded-frontend-bootstrap-20260913.

The proposed fresh root is EMBED/.work/embedded-frontend-compatibility-02.
B = ROOT/build-sysroot; assembly evidence = ROOT/composition.
The external manifest is ROOT/composition/private-sysroot.json, exactly the
existing compositor / role-binding schema. The executable is ROOT/smoke-rustc;
the application source is ROOT/fixture/input.rs and output ROOT/fixture/program.
All paths are separate from SOURCE and from inspection01/02/03.

Inspection03 retained all 256 private files (508,977,943 bytes) and both beta
archives' 78 library files (402,902,037 bytes), with no destination collision.
The proposed 334-file B is 911,879,980 payload bytes, plus filesystem overhead.
It preserves all 239 target and 17 host stamp rows, including the two rlibs;
there is no hand-selected extern subset or metadata renaming.

## Assembly boundary

Before any copy, review the saved stamp reconciliation and approve its complete
candidate-private-files.json SHA fcd05494db58f608533d444076fcbeb8b53387e4cd512fe67a5a6481f4c94d39.
The inspected stamp SHA is 21ab849a8d162db47b07a804ef5e8834ed3de334a7738c87981b311be3a6a96c.
The runner must revalidate the full frozen source/native/archive/input closure,
then call existing inspect_inputs with that exact full map. Freeze its complete
returned composition plan SHA before assemble. Retain each input/proof record,
the plan, and fresh-copy inventory. The assembly marker remains
assembled-unqualified until the separate smoke succeeds.

Use supervise_experiment + owned_stage, canonical lock600, jobs2, and the
existing running capacity guard before/after each copy and per MiB. Admission
must account for the full copy size plus an 8 GiB floor; do not lower another
active task's 16 GiB admission threshold or start this copy ahead of that task.
No deletion or automatic retry on capacity/input/linker failure. Keep partial B.

## Small first compatibility check

Use the unchanged SOURCE/compiler/rustc/src/main.rs, including its
rustc_private feature, stock driver main and override_c_allocator_in_binary!.
The first source compile is exactly:

```text
RUSTC_BOOTSTRAP=1 D --sysroot=B --edition=2024 --crate-name rustc_main \
  --print=link-args SOURCE/compiler/rustc/src/main.rs \
  --extern rustc_driver=B/lib/rustlib/HOST/lib/librustc_driver-88dbe03d702a9b6c.dylib \
  -Lnative=E/lib -Clinker=ACTUAL_SDK_CLANG \
  -C link-arg=-Wl,-rpath,E/lib -o ROOT/smoke-rustc
```

The explicit driver binding follows saved native005 consumer172; Edition2024
stock main requires it. Native LLVM search uses the already qualified
E/lib/libLLVM.dylib (SHA633f96d0dae9a052794a9687237d35cff7ee48ddd33f113942e7304842f819e3).
Pinned link.rs3621-3661 links upstream native dynamic libraries even through a
Rust dylib; rustc_llvm/build.rs422-439 declares Darwin dylib=LLVM. The analogous
native static dependencies are already in the driver (link.rs3595-3604), so the
old blake3/llvm-wrapper build directories are not imported. No caller feature
flags or mandatory prefer-dynamic are added. The beta codegen/loader libraries
remain in B and D; E's qualified driver/LLVM remain in E/lib. If this exact link
needs an additional native search input,
retain the actual failure and source-backed requirement before revising a
fresh attempt. Never overlay beta LLVM with E LLVM or rename a metadata file.

Probe D and E with -vV and --print sysroot first. Validate D against its genuine
archive identity and E against the qualified source/version/runtime inventory.
Before launch, hash the complete explicitly enumerated beta lib files at D's
default sysroot and the existing E closure, preserving every mismatch.
Read the SDK/linker identity through recorded existing helpers. No downloaded
fallback, inherited RUSTFLAGS/Cargo wrappers, or version overrides are allowed.

After the compile, record otool -L for the new binary and run its -vV once with
DYLD_PRINT_LIBRARIES=1. Require exact E version output and the actual loaded
E driver path/hash; preserve raw loader output and validate the native LLVM
closure against E's qualified files. This diagnostic-only environment does not
carry into application compilation. No DYLD_LIBRARY_PATH substitution.

## Native checking and actual-hit controls

The owned original fixture is exactly:

```rust
fn anchor() -> u32 { 42 }
fn main() { println!("{}", anchor()); }
```

Every application compile uses the same source/output path and explicit
--sysroot=E, --edition=2024, --crate-name embedded_driver_smoke,
-Cmetadata=embedded_driver_smoke, -Cdebuginfo=2 and
-Zhir-body-cache-capture=false. Ordinary E and smoke reuse have separate owned
incremental directories. Reuse adds -Zhir-body-cache-reuse=true. Info probes
add -Zincremental-info; raw JSON comparisons do not.

The proposed sequence has 18 probe/control children, in this order, in addition
to separately enumerated ordinary source/linker guard children:

1. D -vV; D --print sysroot; E -vV; E --print sysroot (four children).
2. Compile the unchanged stock main with D (one child).
3. otool -L smoke; smoke -vV with loader logging (two children).
4. E ordinary compile and run the original fixture (two children).
5. Smoke reuse cold compile with info and run (two children).
6. Smoke reuse unchanged compile with info and run (two children).
7. Append `fn uncalled() -> u8 { "wrong" }` after the unchanged original bytes.
   E ordinary and smoke reuse each compile with --error-format=json (two
   children); require both fail with E0308 and byte-identical raw stderr.
8. A separate smoke info compile of that same failing source must fail and
   report exactly one anchor hit (one child).
9. Restore the exact original bytes, smoke info compile and run (two children).

All four successful program runs must print exactly `42\n`. Require exactly
one cold anchor record on the first reuse compile; later info compiles must
report exactly one actual anchor hit with verify_tree=1, verify_journal=1 and
verify_poststate=1, plus a valid S/E suffix (0 < S < E <= 0xFFFF_FF00).
The failing info probe establishes that ordinary checking still runs on a hit;
do not infer that from matching output or from a raw comparison that could miss.
Restore the fixture in finally and retain original/error/restored source copies.
No patch to SOURCE or the previously qualified native run-make fixture.

## Runner and consumer handoff

Use one bounded experiment runner with a frozen JSON plan, exact owned_stage
children, raw stdout/stderr, executable hashes and source snapshots. It must
fail before the next command on any assertion, never silently retry or relax
an input. Preserve inspection failures01/02 and parser-controls01 as linked
prerequisites. Recheck B, D, E and SOURCE after the terminal smoke result.

A passing compatibility receipt will have status=passed, policy=
embedded-frontend-stock-smoke-v1, benchmark=false, source_unchanged=true,
inspection={path,sha256}, composition={plan_sha256,manifest_path,manifest_sha256},
build_compiler={path,sha256,version,default_sysroot,probe_receipts},
runtime_compiler={path,sha256,source_commit,version,sysroot,driver_path,driver_sha256},
smoke={path,sha256,source_path,source_sha256,build_receipt,loader_receipt},
checks={ordinary_output,cold_capture,actual_hit,uncalled_error_raw_equal,
uncalled_error_hit,restored}, commands=[exact receipt/hash pairs], and
evidence_files={path:sha256}. Failed or partial results cannot satisfy this.

The concrete runner is sibling run.py. Its three stages are --stage plan
with --attempt 02, then --stage assemble and --stage smoke with --attempt 01,
all with the exact
--frozen-sha. Assemble additionally requires the actual --plan-sha; smoke
requires both that hash and --assembly-sha for the completed assembly receipt.
The metadata stage performs actual D/E/SDK/library inspection and freezes the
full composition plus exact build argv into ROOT/planned.json. Each later
stage revalidates those inputs before using them. No stage invokes another.
Passing smoke receipt: ROOT/stages/smoke-01/receipt.json; assembly receipt:
ROOT/stages/assemble-01/receipt.json. The plan is ROOT/planned.json.
The planned metadata and smoke probes intentionally repeat D/E identity across
the assembly boundary. Metadata's helper/Git/otool/SDK probes are separate from
the exactly18 stock-smoke controls; every actual child receives a raw receipt.

The subsequent exporter98 role-binding plan consumes the actual B manifest,
D/E probes and passing stock-smoke receipt. This proposal proves no exporter
API compatibility, complete native qualification, cache speed, or publication.
