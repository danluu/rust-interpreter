fn anchor() -> u32 { 42 }
fn main() { println!("{}", anchor()); }
