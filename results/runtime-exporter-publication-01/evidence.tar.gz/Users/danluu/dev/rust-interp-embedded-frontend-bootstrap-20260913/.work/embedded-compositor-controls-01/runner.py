"""Eight synthetic controls; no compiler, real sysroot, archive or target reads."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
FROZEN = WORK / 'frozen-inputs.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if not sys.dont_write_bytecode or sys.flags.optimize:
        raise RuntimeError('run with python -B, without optimization')
    if len(sys.argv) != 3 or sys.argv[1] != '--frozen-sha' or not re.fullmatch('[0-9a-f]{64}', sys.argv[2]):
        raise RuntimeError('supply the reviewed --frozen-sha from the launcher')
    expected_manifest_sha = sys.argv[2]
    data = FROZEN.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected_manifest_sha:
        raise RuntimeError('reviewed control manifest changed before loading')
    frozen = json.loads(data)

    def check():
        if sha(FROZEN) != expected_manifest_sha:
            raise RuntimeError('reviewed control manifest changed')
        for path, expected in frozen['files'].items():
            p = Path(path)
            if not p.is_file() or p.is_symlink() or p.resolve() != p or sha(p) != expected:
                raise RuntimeError('frozen source changed: ' + path)
        if str(Path(sys.executable).resolve()) != frozen['python']['resolved'] or sha(sys.executable) != frozen['python']['sha256']:
            raise RuntimeError('actual Python identity changed')

    check()
    sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
    from owned_stage import CANONICAL_LOCK, workload_lock, run, write, require
    env = {'PATH': '/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', 'HOME': '/Users/danluu',
        'TMPDIR': str(WORK / 'tmp') + '/', 'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC',
        'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1'}
    (WORK / 'tmp').mkdir()
    receipt = dict(schema_version=1, status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
        source_revision=frozen['source_revision'], frozen_inputs_sha256=sha(FROZEN),
        runner_sha256=sha(__file__), started_at=time.time(), canonical_lock=str(CANONICAL_LOCK),
        lock_wait_seconds=600, environment=env, python=dict(path=sys.executable,
            resolved=str(Path(sys.executable).resolve()), sha256=sha(sys.executable)),
        compiler_commands=0, real_compiler_artifact_reads=0, sysroot_assemblies=0)
    write(WORK / 'summary.json', receipt)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            check()
            receipt.update(status='running', admitted_at=time.time())
            write(WORK / 'summary.json', receipt)
            snapshots = {}
            for path, expected in frozen['files'].items():
                destination = WORK / 'sources' / path.lstrip('/')
                destination.parent.mkdir(parents=True, exist_ok=True)
                with destination.open('xb') as output:
                    output.write(Path(path).read_bytes())
                require(sha(destination) == expected, 'source snapshot differs')
                snapshots[path] = dict(path=str(destination), sha256=expected)
            write(WORK / 'source-snapshots.json', snapshots)
            run(frozen['command'], cwd=ROOT, env=env, out=WORK / 'command', capacity_root=ROOT)
            check()
            raw = (WORK / 'command/stderr').read_text()
            tests = re.findall(r'^test_[^\n]* \(([^)]+)\) \.\.\. ok$', raw, re.M)
            require(sorted(tests) == frozen['required_tests'], 'exact eight named passes required')
            require(re.findall(r'^Ran (\d+) tests? in [\d.]+s$', raw, re.M) == ['8']
                and re.search(r'^OK$', raw, re.M)
                and not re.search(r'\b(skipped|FAILED|ERROR|FAIL:)\b', raw), 'eight passing controls required')
            receipt.update(status='passed', tests=8, finished_at=time.time(),
                command_receipt_sha256=sha(WORK / 'command/receipt.json'),
                source_snapshots_sha256=sha(WORK / 'source-snapshots.json'))
            write(WORK / 'summary.json', receipt)
    except BaseException as error:
        receipt.update(status='failed', finished_at=time.time(), error=repr(error))
        write(WORK / 'summary.json', receipt)
        raise


if __name__ == '__main__':
    main()
