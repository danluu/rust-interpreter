# Smoke 02: explicit full driver metadata binding

Metadata02 and assembly01 passed. The original plan remains 7af688db0a0881b22bf5257b808e921697a338bd77ae81bd8ed2ca32c3f1c029,
metadata receipt a00864ec817482acde7d9e7b62bfa237adb6b4af50fc50afa4f300a5651cc7fc,
and assembly receipt 5995f293871e5de5cc8d90caa3adaf5d463bf9f51f618b7e3fc88be04dd8f0b9.
B is the existing compatibility-02/build-sysroot: 334 ordinary files,
911,879,980 bytes. Its manifest f4744d94cea0e63b1e0b2044c7d95b1f21269e7c60716382db2d6164199c1e96
and inventory 734dd3d6e58aeb096b857e76be04148b2be164c9dd89839bf8c15af2a02685af
remain unchanged. This runner cannot plan or assemble another B.

Smoke01 failed at its first stock-main compilation after five source guard
children and four successful compiler identity probes. Supervisor62045/helper62060,
child62314 returned1: only a metadata stub was supplied for rustc_driver's dylib.
Raw stderr SHA9282178c00003c9e4d2763aabf4784004a4c9cdd6e0d27e0bbe94cea26132246;
failed receipt a0703ce69e4cb3b0cd107a2b3ed460786c13f9fee131997c46b3ed5b5ed52300.
No link, smoke loader or application controls ran. All raw receipts, original
source/freeze/plan, completed assembly and launch/process records are retained.

The source correction is an explicit second --extern rustc_driver binding to
the matching full .rmeta. Saved native005 consumer172 supplied both files, in
order. Its exact raw argv/line hash is checked, and both source paths are matched
to the complete composition's destinations, sizes and hashes. Some metadata
files elsewhere in B are not substitutes. No library rename, copy, fake
metadata, changed source, prefer-dynamic flag or extra native search path is used.

The exact amended command is stored in amendment.json. Relative to original
plan.build_argv it adds only the matching .rmeta --extern, then changes -o to a
fresh smoke02 path. All D/E, SDK, environment, unchanged stock-main source,
--sysroot=B, E LLVM search and rpath arguments remain exact. The original plan
is neither rewritten nor labeled as corrected. The new receipt explicitly
records the amendment, original plan/metadata/assembly, native pair proof and
failed smoke01 receipt.

The proposed output root is .work/embedded-frontend-compatibility-smoke-02.
Its executable is smoke-rustc; its fixture/input.rs, fixture/program,
incremental-ordinary and incremental-reuse are fresh. Receipt location:
.work/embedded-frontend-compatibility-smoke-02/stages/smoke-02/receipt.json.
Passing policy remains embedded-frontend-stock-smoke-v1 with the same six checks
and now an amendment field. No passing receipt exists for smoke02 yet.

All 18 correctness controls from source02 remain in the same order: four D/E
probes; unchanged stock-main compile; otool and actual E loader proof; ordinary
fixture compile/run; reuse cold compile/run; reuse hit compile/run; two exact
raw JSON uncalled-error compilations; actual-hit error info probe; restoration
compile/run. All four programs must print 42 followed by newline. The actual
cold and hit records, S/E bounds, full tree/journal/poststate assertions and
byte-identical E0308 diagnostics remain required. Fixture restoration uses the
same finally block. Full current source, runtime, beta/private/stamp input,
original plan/snapshots, B inventory and amended-argv guards run before and after.

Use the saved supervisor launch with canonical600 and the unchanged sanitized
environment. This source checkpoint has only AST and whitespace checks; smoke02
has not run. The source02 six loader parser controls, eight compositor controls,
and six earlier saved-Cargo parser controls passed separately. This correction
introduces no compiler, exporter, cache policy, benchmark or application changes.
