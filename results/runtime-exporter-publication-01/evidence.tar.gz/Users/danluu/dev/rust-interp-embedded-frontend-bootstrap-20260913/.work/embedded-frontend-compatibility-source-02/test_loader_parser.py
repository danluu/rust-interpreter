"""Prepared pure controls; only exact saved dyld stderr is read, no runtime inputs."""
import ast
import hashlib
from pathlib import Path
import re
import unittest

HERE = Path(__file__).resolve().parent
RAW = HERE.parent / 'embedded-frontend-compatibility-01/stages/plan-01/commands/013/stderr'
RAW_SHA = '498b9e58a664d3f36cd32f59ffb6edef6371196bb4864259d7b2cd63fb51d548'
BASE = '/Users/danluu/dev/rustc-hir-capture-check-20260913/build/aarch64-apple-darwin/stage0'
DRIVER = BASE + '/lib/librustc_driver-9ef202210fe39e05.dylib'
ALLOWED = {BASE + '/bin/rustc', DRIVER, BASE + '/lib/libLLVM.dylib'}


class LoaderParserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        payload = RAW.read_bytes()
        if hashlib.sha256(payload).hexdigest() != RAW_SHA:
            raise RuntimeError('exact failed01 raw dyld evidence required')
        cls.raw = payload.decode()
        source = ast.parse((HERE / 'run.py').read_bytes())
        names = {'require', 'parse_dyld'}
        nodes = [node for node in source.body if isinstance(node, ast.FunctionDef) and node.name in names]
        if {node.name for node in nodes} != names:
            raise RuntimeError('exact two pure parser functions required')
        namespace = dict(re=re, Path=Path)
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(HERE / 'run.py'), 'exec'), namespace)
        cls.parse = staticmethod(namespace['parse_dyld'])

    def test_actual_saved_raw(self):
        result = self.parse(self.raw, 72255, ALLOWED, DRIVER)
        self.assertEqual(result['loaded_non_system'], sorted(ALLOWED))
        self.assertEqual(len(result['images']), 602)
        self.assertEqual(len(result['delayed']), 253)
        self.assertEqual(len({row['line'] for row in result['images'] + result['delayed']}), 855)
        self.assertTrue(all(row['raw'] == self.raw.splitlines()[row['line'] - 1]
                            for row in result['images'] + result['delayed']))

    def test_foreign_non_system_image_rejected(self):
        changed = self.raw + 'dyld[72255]: /foreign/libLLVM.dylib\n'
        with self.assertRaisesRegex(RuntimeError, 'foreign non-system'):
            self.parse(changed, 72255, ALLOWED, DRIVER)

    def test_unknown_record_rejected(self):
        with self.assertRaisesRegex(RuntimeError, 'unexpected raw dyld'):
            self.parse(self.raw + 'dyld[72255]: warning: unrecognized event\n', 72255, ALLOWED, DRIVER)

    def test_missing_driver_rejected(self):
        changed = '\n'.join(line for line in self.raw.splitlines() if not line.endswith(' ' + DRIVER)) + '\n'
        with self.assertRaisesRegex(RuntimeError, 'required driver image missing'):
            self.parse(changed, 72255, ALLOWED, DRIVER)

    def test_foreign_pid_rejected(self):
        with self.assertRaisesRegex(RuntimeError, 'unexpected raw dyld'):
            self.parse(self.raw, 72256, ALLOWED, DRIVER)

    def test_delayed_requires_prior_unique_system_image(self):
        for suffix in [
            'dyld[72255]: move loaded to delayed: unobserved.dylib\n',
            'dyld[72255]: move loaded to delayed: librustc_driver-9ef202210fe39e05.dylib\n',
            'dyld[72255]: /System/Library/Other/XPCSupport\ndyld[72255]: move loaded to delayed: XPCSupport\n',
        ]:
            with self.subTest(suffix=suffix), self.assertRaisesRegex(RuntimeError, 'previously observed system image'):
                self.parse(self.raw + suffix, 72255, ALLOWED, DRIVER)


if __name__ == '__main__':
    unittest.main(verbosity=2)
