#!/usr/bin/env python3
"""Explicit split-role exporter compatibility, after the stock-driver smoke.

Source-only until a reviewed input manifest, passing stock receipt and exact
metadata plan are supplied. No compiler checkout mutation or publication.
"""
import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import sys
import tarfile
import time
import tomllib
from types import SimpleNamespace

OWNER = Path('/Users/danluu/dev/rust-interp-hir-native-controls-evidence-20260913')
HERE = OWNER / '.work/exporter-split-role-source-02'
WORK = OWNER / '.work/exporter-split-role-compatibility-02'
SOURCE = WORK / 'source'
TARGET = WORK / 'target'
PLAN = WORK / 'plan.json'
BINDING = WORK / 'compiler-roles.json'
FIXTURE = WORK / 'fixture'
OUTPUT = WORK / 'outputs'
ROLES = Path('/Users/danluu/dev/rust-interp-exporter-role-binding-20260913')
BASE = ROLES / '.work/qualify_exporter_roles_default_02.py'
BASE_SHA = 'aa045d96d4bb0beb67b5da268074f52138cd0d18887634e34b6994c68047a912'
PRIMARY = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
CHECKPOINT = '56e9aea9ec157c716f8cc4ab3e3f4e1c6068b532'
QUAL = PRIMARY / '.work/exporter-roles-getcwd-qualification-01'
ARCHIVE = OWNER / 'results/exporter-roles-getcwd-qualification-01'
ARCHIVE_HASHES = dict(summary='eaf3626ee40cf95ab47160bb6cfe780e0a128f57c37a5b5d893d2ed413b50858',
    manifest='c4d3be847123e3dc78e799dcc65d875524ef5fb2d6e045f838b49321c741a1cc',
    archive='d3cdd3ea257f041cee700aab59d91bfe13fdc3c19a5b82d4ed7c9de48af637ff')
PUBLIC = Path('/Users/danluu/.rustup/toolchains/nightly-2026-09-08-aarch64-apple-darwin')
EMBED = Path('/Users/danluu/dev/rust-interp-embedded-frontend-bootstrap-20260913')
STOCK_CODE = EMBED / '.work/embedded-frontend-compatibility-source-03/run.py'
STOCK_CODE_SHA = '267d224a895ff3981931e8e868b21789c25b77e5bcb66aba1f31b287a80c1cf9'
STOCK_ROOT = EMBED / '.work/embedded-frontend-compatibility-02'
STOCK_RECEIPT = EMBED / '.work/embedded-frontend-compatibility-smoke-02/stages/smoke-02/receipt.json'
STOCK_SMOKE_SHA = '340c7e7b7e2fd96412fc1584f5de31f2d752a8bed924b4d0ff91841aadf02374'
STOCK_PLAN_SHA = '7af688db0a0881b22bf5257b808e921697a338bd77ae81bd8ed2ca32c3f1c029'
STOCK_FROZEN_SHA = '010a3cd179c22ce9335c0992796dabbd7d22eefe91e1daed697eb840ace7f6ec'
STOCK_ASSEMBLY_SHA = '5995f293871e5de5cc8d90caa3adaf5d463bf9f51f618b7e3fc88be04dd8f0b9'
COMPILER_SOURCE = Path('/Users/danluu/dev/rustc-hir-capture-check-20260913')
RUNTIME_REVISION = '7efc0d9484da82cd327deb3b48616f8ec81eaf8d'
HOST = 'aarch64-apple-darwin'
D = COMPILER_SOURCE / 'build' / HOST / 'stage0/bin/rustc'
E = COMPILER_SOURCE / 'build' / HOST / 'stage1'
B = STOCK_ROOT / 'build-sysroot'
DRIVER = E / 'lib/librustc_driver-88dbe03d702a9b6c.dylib'
PRIVATE = STOCK_ROOT / 'composition/private-sysroot.json'
PYTHON = Path('/opt/homebrew/bin/python3')
POLICY = 'exporter-separate-role-compatibility-v1'
PREFIXES = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'EXPORTER_COMPILER_ROLES.md', 'crates',
    'tests/fixtures/borrowck-cache/basic.rs', 'tests/fixtures/borrowck-cache/test_export.rs', 'tests/test_borrowck_cache.py']
EXTRA_SOURCES = {
    'tests/fixtures/borrowck-cache/basic.rs': 'e5400ddc19b5da5a87d698642bfd3cfc4b2456baf15135a53eb0fba08b1ab14d',
    'tests/fixtures/borrowck-cache/test_export.rs': 'e5f06fdb221e6cf08886396ba3430a090e1e3b3e4cc5a39dfb7f86e096e03bbd',
    'tests/test_borrowck_cache.py': 'b7216acfff870a1e5b2b669b7705d638d8343e1d9a687838a97943d5a395a4c0'}
ERRORS = [('type', 'E0308', b'\nfn uncalled_type_error() -> u32 { "wrong" }\n'),
    ('borrow', 'E0515', b"\nfn uncalled_borrow_error() -> &'static u32 { let value = 3; &value }\n")]
CHECKS = dict(ordinary_output=True, cold_capture=True, actual_hit=True,
    uncalled_error_raw_equal=True, uncalled_error_hit=True, restored=True)


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def ordinary(path):
    path = Path(path)
    require(path.is_absolute() and path.is_file() and not path.is_symlink()
        and path.resolve(strict=True) == path, 'expected ordinary file: ' + str(path))
    return path


def read(path, expected=None):
    raw = ordinary(path).read_bytes()
    require(expected is None or digest(raw) == expected, 'input digest differs: ' + str(path))
    return json.loads(raw)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def fixed_environment():
    return dict(HOME='/Users/danluu', CARGO_HOME='/Users/danluu/.cargo', RUSTUP_HOME='/Users/danluu/.rustup',
        PATH=str(D.parent)+':'+str(PUBLIC/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
        TMPDIR=str(WORK/'tmp')+'/', LANG='C', LC_ALL='C', TZ='UTC', CARGO_TERM_COLOR='never',
        CARGO_NET_OFFLINE='true', PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')


def flags(sdk):
    return ['--sysroot='+str(B), '-Lnative='+str(E/'lib'), '-Clinker='+sdk['clang']]


def build_environment(sdk):
    return fixed_environment() | dict(SDKROOT=sdk['path'], RUSTC=str(D), RUSTDOC=str(D.with_name('rustdoc')),
        RUSTC_BOOTSTRAP='1', RUST_INTERP_COMPILER_ROLES=str(BINDING), CARGO_ENCODED_RUSTFLAGS='\x1f'.join(flags(sdk)))


def app_environment(sdk):
    return fixed_environment() | dict(SDKROOT=sdk['path'])


def build_command():
    return [str(PUBLIC/'bin/cargo'), 'build', '--release', '--locked', '--offline', '--jobs', '2', '-vv',
        '--message-format=json-render-diagnostics', '--manifest-path', str(SOURCE/'Cargo.toml'),
        '--target-dir', str(TARGET), '-p', 'rust-interp-mir-export', '--bin', 'rust-interp-mir-export',
        '--bin', 'rust-interp-rustc-wrapper']


def application_commands(sdk):
    x, w = [str(TARGET/'release'/name) for name in ['rust-interp-mir-export','rust-interp-rustc-wrapper']]
    def args(test=False, sysroot=E):
        result = ['--crate-name', 'role_test' if test else 'role_basic', '--edition=2024',
            '--crate-type', 'lib' if test else 'bin', '-Copt-level=0', '-Cdebuginfo=0',
            '-Clinker='+sdk['clang'], '--error-format=json', '--emit=metadata']
        if test: result += ['--test','-Zalways-encode-mir=yes']
        if sysroot is not None: result += ['--sysroot',str(sysroot)]
        return result + [str(FIXTURE/('test_export.rs' if test else 'basic.rs'))]
    def row(name, executable, *, test=False, sysroot=E, profile='native', state='original', error=None, wrapper=None):
        argv = [executable] + ([str(wrapper)] if wrapper is not None else [])
        return dict(name=name, argv=argv+args(test,sysroot)+['-o',str(OUTPUT/(name+'.rmeta'))],
            profile=profile, state=state, error=error)
    rows = [dict(name='exporter-capabilities',argv=[x,'--rust-interp-capabilities'],profile='native',state='original',error=None),
        dict(name='wrapper-roles',argv=[w,'--rust-interp-compiler-roles'],profile='native',state='original',error=None),
        row('basic-native',str(E/'bin/rustc')), row('basic-export-explicit-E',x,profile='basic'),
        row('basic-export-default-E',x,profile='basic',sysroot=None),
        row('wrapper-export-E',w,profile='basic',wrapper=E/'bin/rustc'),
        row('wrapper-reject-D',w,profile='basic',wrapper=D,error='wrong-role'),
        row('test-native',str(E/'bin/rustc'),test=True),row('test-export',x,test=True,profile='test'),
        row('test-discovery',x,test=True,profile='list')]
    for state,code,_ in ERRORS:
        rows += [row('uncalled-'+state+'-native',str(E/'bin/rustc'),state=state,error=code),
            row('uncalled-'+state+'-export',x,profile='basic',state=state,error=code)]
    rows += [row('restored-native',str(E/'bin/rustc')),row('restored-export',x,profile='basic'),
        row('reject-build-sysroot-native',str(E/'bin/rustc'),sysroot=B,error='metadata'),
        row('reject-build-sysroot-export',x,sysroot=B,profile='basic',error='metadata')]
    require(len(rows)==18, 'fixed application command count differs')
    return rows


def cargo_compiles(stderr, sdk):
    """Retain Cargo's actual verbose compiler argv, without synthesizing children."""
    compiled = []
    for line in stderr.decode().splitlines():
        match = re.fullmatch(r'\s*Running `(.*)`', line)
        if not match:
            continue
        argv = shlex.split(match[1])
        if '--crate-name' not in argv:
            continue
        require(argv.count(str(D)) == 1, 'Cargo compiler is not exact D')
        at = argv.index(str(D)); command = argv[at:]
        prefix=argv[:at]
        if prefix[:1]==['env']: prefix=prefix[1:]
        require(all('=' in word for word in prefix), 'unexpected Cargo compiler command prefix')
        require(all(flag in command for flag in flags(sdk)) and sum(a.startswith('--sysroot') for a in command)==1,
            'Cargo compiler sysroot/native flags differ')
        require(not any('RUSTC_FORCE_RUSTC_VERSION=' in a or 'RUSTC_OVERRIDE_VERSION_STRING=' in a for a in argv),
            'Cargo version override appeared')
        sources = [a for a in command if a.endswith('.rs')]
        require(len(sources)==1, 'Cargo source path is ambiguous')
        path=Path(sources[0]);path=path if path.is_absolute() else SOURCE/path
        compiled.append(dict(command=command, environment_assignments=argv[:at], source=str(ordinary(path.resolve(strict=True)))))
    require(compiled and {'rust_interp_mir_export','rust_interp_rustc_wrapper'} <=
        {r['command'][r['command'].index('--crate-name')+1] for r in compiled}, 'both actual compiler commands required')
    return compiled


def check_compiler_sources(compiles, records):
    source_hashes={r['path']:r['sha256'] for r in records}
    require(all(r['source'] in source_hashes for r in compiles),'Cargo compiled an unfrozen source')


def check_amended_smoke(smoke, amendment, build, expected_argv, expected_env):
    require(smoke['status']=='passed' and smoke['stage']=='smoke' and smoke['checks']==CHECKS
        and smoke['source_unchanged'] and smoke['runtime_unchanged'] and smoke['source_restored']
        and smoke['benchmark'] is False, 'passing amended stock smoke required')
    require(smoke['amendment']==amendment and amendment['build_argv']==expected_argv
        and sum(row['role']=='smoke-control' for row in smoke['commands'])==18
        and len(smoke['commands'])==28, 'exact amended stock history required')
    require(build['status']=='finished' and build['returncode']==0 and build['command']==expected_argv
        and build['environment']==expected_env and build['cwd']==str(STOCK_ROOT)
        and smoke['smoke']['path']==expected_argv[-1], 'actual amended stock build differs')


class Stage:
    def __init__(self, args):
        self.args = args
        self.freeze = read(HERE/'inputs.json', args.inputs_sha)
        self.check_sources()
        require(sha(BASE)==BASE_SHA and sha(STOCK_CODE)==STOCK_CODE_SHA, 'reviewed adapter dependency changed')
        self.q = load('split_roles_base',BASE)
        self.stock = load('split_roles_stock',STOCK_CODE)
        require((args.stock_smoke_sha,args.stock_plan_sha,args.stock_frozen_sha)==
            (STOCK_SMOKE_SHA,STOCK_PLAN_SHA,STOCK_FROZEN_SHA), 'exact qualified stock smoke02 pins required')
        self.stock_freeze = read(self.stock.FROZEN,args.stock_frozen_sha)
        self.stock_stage = SimpleNamespace(args=SimpleNamespace(frozen_sha=args.stock_frozen_sha,plan_sha=args.stock_plan_sha,
            assembly_sha=STOCK_ASSEMBLY_SHA), frozen=self.stock_freeze, record={})
        g = self.stock_stage
        g.amendment = lambda: self.stock.Stage.amendment(g)
        g.amended_build_argv = lambda plan: self.stock.Stage.amended_build_argv(g,plan)
        g.check_sources = lambda: self.stock.Stage.check_sources(g)
        g.check_sources()
        g.owned = self.q.owned
        g.comp = self.stock.load('split_roles_compositor',EMBED/'experiments/embedded-frontend-bootstrap/compose_sysroot.py')
        g.libs = self.q.loaders
        g.stage2 = self.stock.load('split_roles_stock_stage2',self.stock.STAGE2/'experiments/hir-stage2-package/check.py')
        g.run = self.stock_run
        g.file = lambda path,expected=None: self.stock.Stage.file(g,path,expected)
        self.work = WORK/args.stage
        self.current = None
        self.records = []
        self.source_records = []
        self.closures = []
        self.initial = []
        self.initial_configuration = None
        if args.stage=='plan':
            WORK.mkdir(parents=True,exist_ok=False); (WORK/'tmp').mkdir()
        self.work.mkdir(exist_ok=False)
        self.receipt = dict(schema_version=1,policy=POLICY,stage=args.stage,status='waiting',owner=str(OWNER),
            pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),command=sys.argv,cwd=os.getcwd(),
            inputs_sha256=args.inputs_sha,stock_frozen_sha256=args.stock_frozen_sha,stock_plan_sha256=args.stock_plan_sha,
            stock_smoke_sha256=args.stock_smoke_sha,metadata_receipt_sha256=args.metadata_sha,commands=[],benchmark=False,publication=False,
            canonical_lock=str(self.q.owned.CANONICAL_LOCK),wait_seconds=600)
        self.save()
        self.check_imports()

    def save(self):
        self.q.write(self.work/'receipt.json',self.receipt)

    def check_sources(self):
        require(sha(HERE/'inputs.json')==self.args.inputs_sha,'independent freeze changed')
        require({str(HERE/'check.py'),str(BASE),str(OWNER/'scripts/supervise_experiment.py')}<=set(self.freeze['files']),
            'independent freeze omits actual runner/base/supervisor')
        for path,expected in self.freeze['files'].items():
            require(sha(ordinary(path))==expected,'frozen helper input changed: '+path)
            require(sha(ordinary(self.freeze['snapshots'][path]))==expected,'frozen helper snapshot changed: '+path)
        require(str(Path(sys.executable).resolve(strict=True))==self.freeze['python']['resolved']
            and sha(sys.executable)==self.freeze['python']['sha256'],'exact Python changed')

    def check_imports(self):
        allowed = self.freeze['files'] | self.stock_freeze['files']
        for module in list(sys.modules.values()):
            path = getattr(module,'__file__',None)
            if path and str(path).startswith('/Users/danluu/dev/rust-interp'):
                require(str(Path(path).resolve()) in allowed,'unfrozen local import: '+path)

    def configuration(self):
        paths = [Path('/Users/danluu/.cargo'),*[p/'.cargo' for p in [SOURCE,*SOURCE.parents]]]
        searches = {str(p/name): (p/name).exists() or (p/name).is_symlink() for p in paths for name in ['config','config.toml']}
        require(not any(searches.values()),'Cargo configuration needs a separate recipe')
        for name in searches:
            require(not any(p.is_symlink() for p in Path(name).parents),'symlinked Cargo configuration search')
        return searches

    def guard(self, full=False):
        self.q.owned.disk(OWNER,9); self.check_sources(); self.stock_stage.check_sources(); self.check_imports()
        require(WORK.resolve(strict=True)==WORK and (WORK/'tmp').resolve(strict=True)==WORK/'tmp'
            and (WORK/'tmp').is_dir(),'owned work/temporary route changed')
        self.q.guard_records(self.records+self.source_records+self.initial,full=full)
        if self.source_records:
            require(self.configuration()==self.initial_configuration,'Cargo config changed after source materialization')
            require([str(p) for p in self.q.files(SOURCE)]==[r['path'] for r in self.source_records],'source membership changed')
        if self.current:
            require(self.configuration()==self.current['configuration'],'Cargo config changed')
            require([str(p) for p in self.q.files(SOURCE)]==[r['path'] for r in self.source_records],'source membership changed')
            require({str(p.relative_to(B)) for p in self.q.files(B)}==set(self.current['private']['files']),'B membership changed')
            if full:
                require(all(sha(B/path)==expected for path,expected in self.current['private']['files'].items()),'B bytes changed')
            for package in self.current['dependencies']['packages']:
                base=Path(package['manifest_path']).parent
                require({str(p) for p in self.q.files(base)}=={r['path'] for r in package['files'] if Path(r['path']).is_relative_to(base)},
                    'dependency membership changed')
            require(sha(BINDING)==self.current['binding_sha256'],'binding changed')
            require(all(str(Path(path).resolve(strict=True))==resolved for path,resolved in self.current['sdk_routes'].items()),
                'SDK/compiler discovery route changed')
            if self.args.stage=='run': require(sha(PLAN)==self.args.plan_sha,'reviewed plan changed')
        for closure in self.closures:
            require(self.q.loaders.library_state(closure['identity'])==closure['state'],'loader/search state changed')

    def command(self, argv, *, env=None, cwd=SOURCE, expected=(0,), label='metadata'):
        self.guard()
        out=self.work/'commands'/f'{len(self.receipt["commands"]):03d}'
        try:
            row=self.q.owned.run(argv,cwd=cwd,env=env or fixed_environment(),out=out,capacity_root=OWNER,expected=expected)
        finally:
            if (out/'receipt.json').exists():
                row=read(out/'receipt.json')
                self.receipt['commands'].append(dict(path=str(out/'receipt.json'),sha256=sha(out/'receipt.json'),
                    command=row['command'],label=label));self.save()
        self.guard()
        return dict(receipt=row,path=str(out/'receipt.json'),stdout=(out/'stdout').read_bytes(),stderr=(out/'stderr').read_bytes())

    def stock_run(self, argv, *, env=None, cwd=COMPILER_SOURCE, expected=(0,), role='guard'):
        require(argv[:1]==['git'],'stock source guard must only run its unchanged Git commands')
        return self.command(argv,env=env,cwd=cwd,expected=expected,label='stock-source-guard')

    def predecessor(self):
        smoke=read(STOCK_RECEIPT,self.args.stock_smoke_sha)
        require(smoke['policy']==self.stock.POLICY and smoke['status']=='passed' and smoke['stage']=='smoke'
            and smoke['plan_sha256']==self.args.stock_plan_sha and smoke['frozen_sha256']==self.args.stock_frozen_sha
            and smoke['checks']==CHECKS and smoke['source_unchanged'] and smoke['runtime_unchanged']
            and smoke['source_restored'] and smoke['benchmark'] is False,'passing exact stock compatibility receipt required')
        for path,expected in smoke['evidence_files'].items(): require(sha(ordinary(path))==expected,'stock raw evidence changed')
        for ref in smoke['commands']:
            row=read(ref['path'],ref['sha256'])
            require(row['status']=='finished' and row['command']==ref['command'] and row['supervisor_pid']==smoke['pid']
                and smoke['admitted_at']<=row['started_at']<=row['finished_at']<=smoke['finished_at'],'stock child association differs')
            for stream in ['stdout','stderr']:
                require(sha(ordinary(Path(ref['path']).parent/stream))==row[stream+'_sha256'],'stock raw stream differs')
        _,prior=self.stock.Stage.guard(self.stock_stage)
        self.runtime_files=prior['stage1']['files']
        plan=self.stock.Stage.check_plan(self.stock_stage)
        private=self.stock.Stage.b_guard(self.stock_stage,plan)
        expected_build=self.stock_stage.amended_build_argv(plan)
        refs=[row for row in smoke['commands'] if row['path']==smoke['smoke']['build_receipt']]
        require(len(refs)==1, 'one actual amended stock build receipt required')
        build=read(refs[0]['path'],refs[0]['sha256'])
        check_amended_smoke(smoke,self.stock_stage.record['amendment'],build,expected_build,plan['build_environment'])
        self.receipt['stock_amendment']=self.stock_stage.record['amendment']
        require(smoke['build_compiler']==plan['build_compiler'] and smoke['runtime_compiler']['path']==str(E/'bin/rustc')
            and smoke['runtime_compiler']['source_commit']==RUNTIME_REVISION
            and smoke['composition']['manifest_path']==str(PRIVATE) and sha(PRIVATE)==smoke['composition']['manifest_sha256'],
            'stock role/composition association differs')
        require(plan['build_compiler']['path']==str(D) and plan['runtime_compiler']['default_sysroot']==str(E), 'D/E routes changed')
        require('-Lnative='+str(E/'lib') in plan['build_argv'],'reviewed LLVM search provider missing')
        return smoke,plan,private

    def archive_sources(self):
        summary=read(ARCHIVE/'summary.json',ARCHIVE_HASHES['summary'])
        manifest=read(ARCHIVE/'manifest.json',ARCHIVE_HASHES['manifest'])
        require(sha(ordinary(ARCHIVE/'evidence.tar.gz'))==ARCHIVE_HASHES['archive'] and summary['status']=='passed'
            and summary['source_checkpoint']==CHECKPOINT and summary['source_snapshots']==212
            and summary['archive_members']==len(manifest)==1894 and summary['all_member_hashes_verified'], 'qualified union archive differs')
        payload={}
        with tarfile.open(ARCHIVE/'evidence.tar.gz','r:gz') as archive:
            for member in archive:
                self.q.owned.disk(OWNER,9)
                require(member.name in manifest and member.name not in payload and (member.isfile() or member.islnk()),'union archive membership differs')
                stream=archive.extractfile(member);require(stream is not None,'missing union member')
                with stream: data=stream.read()
                row=manifest[member.name]
                require(row['source'].lstrip('/')==member.name and len(data)==row['bytes'] and digest(data)==row['sha256'],'union member bytes differ')
                payload[member.name]=data
        require(set(payload)==set(manifest),'incomplete union archive')
        previous=json.loads(payload[str(QUAL/'plan.json').lstrip('/')])
        require(previous['source_checkpoint']==CHECKPOINT and len(previous['sources'])==212,'qualified source set differs')
        expected={}
        for row in previous['sources']:
            name=str(Path(row['path']).relative_to(PRIMARY))
            raw=payload[str(Path(row['snapshot'])).lstrip('/')]
            require(digest(raw)==row['sha256'],'qualified source snapshot changed')
            if name in PREFIXES or name.startswith('crates/'):
                expected[name]=raw
        return expected

    def materialize(self):
        expected=self.archive_sources()
        result=self.command(['/usr/bin/git','archive','--format=tar',CHECKPOINT,*PREFIXES],cwd=PRIMARY,label='qualified-source-archive')
        require(not result['stderr'],'source Git archive emitted stderr')
        SOURCE.mkdir()
        found=set()
        with tarfile.open(fileobj=io.BytesIO(result['stdout']),mode='r:') as archive:
            for member in archive:
                name=Path(member.name)
                require(not name.is_absolute() and all(p not in ('.','..') for p in name.parts),'unsafe source path')
                if member.isdir():continue
                require(member.isfile() and member.name not in found and (member.name in expected or member.name in EXTRA_SOURCES),'unexpected source member')
                with archive.extractfile(member) as stream: data=stream.read()
                wanted=digest(expected[member.name]) if member.name in expected else EXTRA_SOURCES[member.name]
                require(digest(data)==wanted,'source checkpoint/archive mismatch')
                path=SOURCE/name;path.parent.mkdir(parents=True,exist_ok=True)
                self.q.owned.disk(OWNER,9)
                with path.open('xb') as output: output.write(data)
                path.chmod(0o755 if member.mode&0o100 else 0o644);found.add(member.name)
        require(found==set(expected)|set(EXTRA_SOURCES),'source materialization incomplete')
        return self.q.snapshot(self.q.files(SOURCE),self.work/'source-snapshots')

    def dependencies(self, metadata, env):
        locked={(r['name'],r['version'],r.get('source')):r for r in tomllib.loads((SOURCE/'Cargo.lock').read_text())['package']}
        features={r['id']:r['features'] for r in metadata['resolve']['nodes']}
        packages=[]
        for package in metadata['packages']:
            manifest=ordinary(Path(package['manifest_path']).resolve(strict=True));base=manifest.parent
            lock=locked[(package['name'],package['version'],package.get('source'))]
            if package.get('source'):
                require(package['source'].startswith('registry+'),'unsupported dependency source')
                paths=self.q.inputs.registry_files(base,lock)
            else:
                require(base.is_relative_to(SOURCE/'crates'),'path dependency escapes owned source')
                paths=self.q.files(base)
            require(manifest in paths,'dependency lacks manifest')
            packages.append(dict(id=package['id'],name=package['name'],version=package['version'],source=package.get('source'),
                manifest_path=str(manifest),features=features[package['id']],lock=lock,files=[self.q.file_identity(p) for p in sorted(paths)]))
        require(len(packages)==30 and sum(p['source'] is not None for p in packages)==26
            and {p['id'] for p in packages}==set(features),'resolved package set differs')
        return dict(lock_sha256=sha(SOURCE/'Cargo.lock'),packages=packages,environment=env)

    def closure(self,path):
        def inspect(argv,*,text):
            require(text,'unexpected loader inspection mode')
            return self.command(argv,label='loader')['stdout'].decode()
        identity,state=self.q.loaders.library_closure(path,HOST,inspect=inspect)
        return dict(identity=identity,state=state)

    def plan(self):
        smoke,stock,private=self.predecessor()
        self.source_records=self.materialize()
        sdk=stock['sdk'];env=build_environment(sdk)
        config=self.configuration()
        self.initial_configuration=config
        role=lambda item: dict(executable=dict(path=item['path'],sha256=item['sha256']),
            verbose_version=item['version'],default_sysroot=item['default_sysroot'])
        binding=dict(schema_version=1,policy='separate-compiler-roles-v1',build=role(stock['build_compiler']),
            runtime=role(stock['runtime_compiler']),runtime_source_commit=RUNTIME_REVISION,
            runtime_driver=dict(path=str(DRIVER),sha256=smoke['runtime_compiler']['driver_sha256']),
            private_sysroot_manifest=dict(path=str(PRIVATE),sha256=sha(PRIVATE)),build_rustflags=flags(sdk))
        self.q.write(BINDING,binding)
        for name,argv in [('developer',['/usr/bin/xcode-select','-p']),
            ('sdk',['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path']),
            ('clang',['/usr/bin/xcrun','--sdk','macosx','--find','clang']),
            ('linker',['/usr/bin/xcrun','--sdk','macosx','--find','ld'])]:
            result=self.command(argv)
            require(not result['stderr'] and result['stdout'].decode().strip()==sdk['discovered'][name],
                'actual SDK/tool discovery differs from stock smoke')
        versions={}
        for key,item in [('build',stock['build_compiler']),('runtime',stock['runtime_compiler'])]:
            result=self.command([item['path'],'-vV']);root=self.command([item['path'],'--print','sysroot'])
            require(not result['stderr'] and not root['stderr'] and result['stdout'].decode()==item['version']
                and root['stdout'].decode()==item['default_sysroot']+'\n','actual role probe differs')
            versions[key]=dict(version_receipt=result['path'],sysroot_receipt=root['path'])
        for key,argv in [('cargo',[str(PUBLIC/'bin/cargo'),'-Vv']),('python',[str(PYTHON),'--version'])]:
            result=self.command(argv);require(not result['stderr'],'identity probe emitted stderr');versions[key]=result['stdout'].decode()
        result=self.command([str(PUBLIC/'bin/cargo'),'metadata','--locked','--offline','--format-version=1','--manifest-path',str(SOURCE/'Cargo.toml')],env=env)
        metadata_path=self.work/'cargo-metadata.json';metadata_path.write_bytes(result['stdout'])
        deps=self.dependencies(json.loads(result['stdout']),env)
        self.records=[self.q.file_identity(p) for p in [D,D.with_name('rustdoc'),E/'bin/rustc',DRIVER,PRIVATE,BINDING,
            PUBLIC/'bin/cargo',PYTHON,Path(sdk['clang']),Path(sdk['linker']),STOCK_RECEIPT,self.stock.PLAN,
            ARCHIVE/'summary.json',ARCHIVE/'manifest.json',ARCHIVE/'evidence.tar.gz',metadata_path]]
        self.records += [self.q.file_identity(p) for p in self.q.files(B)]
        self.records += [self.q.file_identity(ordinary(r['path'])) for r in stock['guard_files']]
        self.records += [self.q.file_identity(ordinary(E/rel)) for rel in self.runtime_files]
        self.records += [r for package in deps['packages'] for r in package['files']]
        self.closures=[self.closure(p) for p in [D,E/'bin/rustc',PUBLIC/'bin/cargo',PYTHON,Path(sdk['clang'])]]
        for closure in self.closures:
            self.records += [self.q.file_identity(Path(r['logical'])) for r in closure['identity']['libraries']]
        self.current=dict(schema_version=1,policy=POLICY,owner=str(OWNER),work=str(WORK),source_checkpoint=CHECKPOINT,
            source_records=self.source_records,configuration=config,sdk=sdk,build_environment=env,application_environment=app_environment(sdk),
            binding=binding,binding_sha256=sha(BINDING),private=private,versions=versions,dependencies=deps,records=self.records,closures=self.closures,
            build_command=build_command(),application_commands=application_commands(sdk),inputs_sha256=self.args.inputs_sha,
            stock_smoke_sha256=self.args.stock_smoke_sha,stock_plan_sha256=self.args.stock_plan_sha,stock_frozen_sha256=self.args.stock_frozen_sha,
            sdk_routes={path:str(Path(path).resolve(strict=True)) for path in sdk['discovered'].values()},
            capacity=dict(initial_free_gib=16,stop_gib=9,floor_gib=8),wait_seconds=600,canonical_lock=str(self.q.owned.CANONICAL_LOCK),
            benchmark=False,publication=False,guest_execution=False)
        self.predecessor();self.guard(full=True)
        self.q.write(PLAN,self.current)
        self.receipt.update(status='planned',plan_sha256=sha(PLAN),source_files=len(self.source_records),dependency_packages=30)

    def check_plan(self):
        plan=read(PLAN,self.args.plan_sha)
        require(plan['schema_version']==1 and plan['policy']==POLICY and plan['owner']==str(OWNER)
            and plan['work']==str(WORK) and plan['source_checkpoint']==CHECKPOINT
            and plan['inputs_sha256']==self.args.inputs_sha and plan['stock_smoke_sha256']==self.args.stock_smoke_sha
            and plan['stock_plan_sha256']==self.args.stock_plan_sha and plan['stock_frozen_sha256']==self.args.stock_frozen_sha
            and plan['build_command']==build_command() and plan['application_commands']==application_commands(plan['sdk'])
            and plan['build_environment']==build_environment(plan['sdk'])
            and plan['application_environment']==app_environment(plan['sdk'])
            and plan['capacity']==dict(initial_free_gib=16,stop_gib=9,floor_gib=8)
            and plan['canonical_lock']==str(self.q.owned.CANONICAL_LOCK) and plan['wait_seconds']==600
            and plan['benchmark'] is False and plan['publication'] is False and plan['guest_execution'] is False,
            'fixed reviewed plan contract differs')
        metadata=read(WORK/'plan/receipt.json',self.args.metadata_sha)
        require(metadata['status']=='planned' and metadata['plan_sha256']==self.args.plan_sha
            and metadata['stock_smoke_sha256']==self.args.stock_smoke_sha,'completed exact metadata stage required')
        self.current=plan;self.records=plan['records'];self.source_records=plan['source_records'];self.closures=plan['closures']
        self.initial_configuration=plan['configuration']
        smoke,stock,private=self.predecessor()
        require(private==plan['private'] and stock['sdk']==plan['sdk'],'current stock composition differs from reviewed plan')
        require(read(BINDING,plan['binding_sha256'])==plan['binding'],'actual role binding changed')
        self.guard(full=True)
        return plan,smoke,stock

    def retain_binary(self,path):
        binary=self.q.file_identity(ordinary(path))
        closure=self.closure(path)
        allowed={r['resolved']:r['sha256'] for r in self.records}
        for row in closure['identity']['libraries']:
            require(allowed.get(row['resolved'])==row['sha256'],'new binary depends on an unbound library: '+row['resolved'])
        self.records.append(binary)
        self.closures.append(closure)
        return dict(binary=binary,closure=closure)

    def argv_record(self,row,root):
        paths=self.q.files(root)
        if row['profile']=='native' or row['error']=='wrong-role':
            require(not paths,'unexpected final compiler argv record')
            return None
        require(len(paths)==1 and paths[0].name.startswith('exported-'),'one actual exported compiler argv required')
        data=paths[0].read_bytes();fields=data.split(b'\0')
        require(fields[-1]==b'' and fields[:4]==[b'rust-interp-compiler-argv-v1',b'exported',str(E).encode(),str(FIXTURE).encode()],
            'compiler argv evidence header differs')
        args=[x.decode() for x in fields[4:-1]]
        expected_first=str(E/'bin/rustc') if row['name']=='wrapper-export-E' else str(TARGET/'release/rust-interp-mir-export')
        require(args[0]==expected_first,'actual final compiler route differs')
        roots=[]
        for i,arg in enumerate(args):
            if arg=='--sysroot':require(i+1<len(args),'missing final sysroot');roots.append(args[i+1])
            elif arg.startswith('--sysroot='):roots.append(arg.split('=',1)[1])
        require(roots==[str(B if row['error']=='metadata' else E)],'final compiler sysroot differs')
        require(str(FIXTURE/('test_export.rs' if row['name'].startswith('test-') else 'basic.rs')) in args,
            'actual compiler source differs')
        return self.q.file_identity(paths[0])

    def applications(self,plan):
        FIXTURE.mkdir();OUTPUT.mkdir()
        original={name:(SOURCE/'tests/fixtures/borrowck-cache'/name).read_bytes() for name in ['basic.rs','test_export.rs']}
        for name,data in original.items():(FIXTURE/name).write_bytes(data)
        results={};observed=[]
        expected_states={'original':original['basic.rs']} | {name:original['basic.rs']+addition for name,_,addition in ERRORS}
        try:
            for row in plan['application_commands']:
                name=row['name'];raw=expected_states[row['state']]
                (FIXTURE/'basic.rs').write_bytes(raw)
                require((FIXTURE/'test_export.rs').read_bytes()==original['test_export.rs'],'test fixture changed')
                retained=self.work/(name+'.source.rs');retained.write_bytes((FIXTURE/'test_export.rs').read_bytes() if name.startswith('test-') else raw)
                env=app_environment(plan['sdk']);record_dir=OUTPUT/(name+'-argv');record_dir.mkdir()
                env['RUST_INTERP_COMPILER_ARGV_RECORD_DIR']=str(record_dir)
                artifact=OUTPUT/(name+('.json' if row['profile']=='list' else '.rbc'))
                if row['profile']!='native':
                    env.update(RUST_INTERP_EXPORT_CRATE='role_test' if row['profile'] in ('test','list') else 'role_basic',
                        RUST_INTERP_OUTPUT=str(artifact))
                    if row['profile'] in ('test','list'):env['RUST_INTERP_EXPORT_TEST']='1'
                    if row['profile']=='list':env['RUST_INTERP_LIST_TESTS']='1'
                    else:env['RUST_INTERP_ENTRY']='selected' if row['profile']=='test' else 'changing_value'
                outcome=self.command(row['argv'],env=env,cwd=FIXTURE,expected=(1,2) if row['error'] else (0,),label=name)
                require((FIXTURE/'basic.rs').read_bytes()==raw and (FIXTURE/'test_export.rs').read_bytes()==original['test_export.rs'],
                    'application modified fixture inputs')
                record=self.argv_record(row,record_dir)
                stdout,stderr=outcome['stdout'],outcome['stderr']
                require(b'internal compiler error' not in stderr,'application compiler panicked')
                if row['error']:
                    require(not artifact.exists(),'failed application published bytecode')
                    if row['error']=='wrong-role':
                        require(stderr==b"compiler executable does not match the exporter's runtime toolchain\n" and not stdout,'wrong-role refusal differs')
                    else:
                        diagnostics=[]
                        for line in stderr.splitlines():
                            message=json.loads(line)
                            if message.get('$message_type')=='diagnostic':diagnostics.append(message)
                        require(any(d.get('level')=='error' for d in diagnostics),'ordinary compiler error required')
                        if row['error'] not in ('metadata',):
                            require(any((d.get('code') or {}).get('code')==row['error'] for d in diagnostics),'required uncalled diagnostic missing')
                elif name=='exporter-capabilities':
                    caps=json.loads(stdout)
                    require(not stderr and caps.get('schema_version')==1 and caps.get('bytecode_version')==5
                        and caps.get('compiler_sysroot')==str(E) and caps.get('compiler_roles')==plan['binding'],
                        'actual exporter roles/capabilities differ')
                elif name=='wrapper-roles':
                    require(not stderr and json.loads(stdout)==plan['binding'],'actual wrapper roles differ')
                elif row['profile']=='list':
                    report=read(artifact);tests=report.get('tests')
                    require(report.get('kind')=='test-discovery' and report.get('schema_version')==1
                        and report.get('strict_frontend') is True and report.get('executed') is False
                        and report.get('harness')=='libtest' and report.get('target')==HOST and report.get('count')==1
                        and isinstance(tests,list) and len(tests)==1 and tests[0]['name']=='selected'
                        and tests[0]['status']=='classified' and tests[0]['ordinary_test'] is True,
                        'actual test discovery differs')
                    sidecar=Path(row['argv'][-1]+'.tests.json')
                    require(ordinary(sidecar).read_bytes()==artifact.read_bytes(),'actual test discovery sidecar differs')
                elif row['profile']!='native':
                    require(ordinary(artifact).stat().st_size>0,'successful export lacks actual RBC')
                    sidecar=Path(row['argv'][-1]+'.rbc')
                    require(ordinary(sidecar).read_bytes()==artifact.read_bytes(),'actual RBC metadata sidecar differs')
                results[name]=dict(stdout=stdout,stderr=stderr,artifact=artifact)
                observed.append(dict(name=name,receipt=outcome['path'],source=self.q.file_identity(retained),compiler_argv=record,
                    artifact=self.q.file_identity(artifact) if artifact.is_file() else None))
            for left,right in [('basic-native','basic-export-explicit-E'),('test-native','test-export'),
                ('uncalled-type-native','uncalled-type-export'),('uncalled-borrow-native','uncalled-borrow-export'),
                ('restored-native','restored-export'),('reject-build-sysroot-native','reject-build-sysroot-export'),
                ('basic-native','basic-export-default-E'),('basic-native','wrapper-export-E'),('test-native','test-discovery')]:
                require((results[left]['stdout'],results[left]['stderr'])==(results[right]['stdout'],results[right]['stderr']),
                    'raw native/export diagnostics differ: '+left+'/'+right)
            for name in ['basic-export-default-E','wrapper-export-E','restored-export']:
                require(results[name]['artifact'].read_bytes()==results['basic-export-explicit-E']['artifact'].read_bytes(),
                    'explicit/default/wrapper/restored RBC differs')
            require((results['basic-native']['stdout'],results['basic-native']['stderr'])==
                (results['restored-native']['stdout'],results['restored-native']['stderr']),'restored native diagnostics differ')
        finally:
            (FIXTURE/'basic.rs').write_bytes(original['basic.rs']);(FIXTURE/'test_export.rs').write_bytes(original['test_export.rs'])
            for name,data in original.items():require((FIXTURE/name).read_bytes()==data,'fixture restoration failed')
        self.q.write(self.work/'application-results.json',dict(children=observed,raw_diagnostic_parity=True,
            bytecode_parity=True,source_restored=True,guest_executions=0))
        return observed

    def run(self):
        plan,smoke,stock=self.check_plan()
        require(all(not path.exists() and not path.is_symlink() for path in [TARGET,FIXTURE,OUTPUT]),
            'fresh target/application outputs required')
        result=self.command(build_command(),env=plan['build_environment'],label='build-exporter-wrapper')
        compiles=cargo_compiles(result['stderr'],plan['sdk'])
        check_compiler_sources(compiles,self.source_records+self.records)
        messages=[json.loads(line) for line in result['stdout'].splitlines()]
        require(messages and messages[-1].get('reason')=='build-finished' and messages[-1].get('success') is True,'Cargo build completion missing')
        expected_bins={str(TARGET/'release'/name) for name in ['rust-interp-mir-export','rust-interp-rustc-wrapper']}
        actual={row.get('executable') for row in messages if row.get('reason')=='compiler-artifact'
            and 'bin' in row.get('target',{}).get('kind',[]) and row.get('executable')}
        require(actual==expected_bins,'actual Cargo executable set differs')
        generated=[]
        for message in messages:
            if message.get('reason')=='build-script-executed' and message.get('out_dir'):
                path=Path(message['out_dir'])/'compiler_roles.rs'
                if path.is_file():
                    require(path.is_relative_to(TARGET),'generated binding outside owned target')
                    generated.append(self.q.file_identity(ordinary(path)))
        require(len(generated)==1,'one generated compiler binding required')
        self.q.write(self.work/'cargo-build-evidence.json',dict(compilers=compiles,messages=messages,generated=generated))
        tools=[self.retain_binary(Path(path)) for path in sorted(expected_bins)]
        exporter=next(row for row in tools if row['binary']['path'].endswith('rust-interp-mir-export'))
        closure=exporter['closure']['identity']
        require(any(r['resolved']==str(DRIVER) and r['sha256']==plan['binding']['runtime_driver']['sha256'] for r in closure['libraries']),
            'actual exporter closure does not link the bound E driver')
        loaded=self.command([str(TARGET/'release/rust-interp-mir-export'),'--rust-interp-capabilities'],
            env=app_environment(plan['sdk'])|{'DYLD_PRINT_LIBRARIES':'1'},label='actual-exporter-loader')
        allowed={r['resolved'] for r in closure['libraries']}|{str(TARGET/'release/rust-interp-mir-export')}
        images=self.stock.parse_dyld(loaded['stderr'].decode(),loaded['receipt']['pid'],allowed,str(DRIVER))
        require(json.loads(loaded['stdout']).get('compiler_roles')==plan['binding'],'loader probe binding differs')
        self.q.write(self.work/'actual-tools.json',dict(tools=tools,loaded_images=images,loader_receipt=loaded['path']))
        observations=self.applications(plan)
        self.predecessor();self.guard(full=True)
        self.receipt.update(status='passed',plan_sha256=self.args.plan_sha,application_commands=len(observations),
            build_commands=1,application_results_sha256=sha(self.work/'application-results.json'),actual_tools_sha256=sha(self.work/'actual-tools.json'),
            source_unchanged=True,source_restored=True,compiler_roles=plan['binding'],split_role_build_load_frontend_compatibility=True,
            public_tool_publication=False,performance_claim=False,guest_execution=False)

    def execute(self):
        try:
            with self.q.owned.workload_lock(self.q.owned.CANONICAL_LOCK,600):
                self.receipt.update(status='running',admitted_at=time.time(),free_bytes_before=self.q.owned.disk(OWNER,16 if self.args.stage=='run' else 9));self.save()
                getattr(self,self.args.stage)()
                self.receipt.update(finished_at=time.time(),free_bytes_after=self.q.owned.disk(OWNER));self.save()
        except BaseException as error:
            self.receipt.update(status='failed',error=repr(error),finished_at=time.time(),free_bytes_after=shutil.disk_usage(OWNER).free);self.save();raise


def main():
    require(sys.dont_write_bytecode and not sys.flags.optimize,'use Python -B without optimization')
    require(Path.cwd()==OWNER and Path(__file__).resolve()==HERE/'check.py','fixed source/cwd required')
    parser=argparse.ArgumentParser()
    parser.add_argument('stage',choices=['plan','run'])
    for name in ['inputs-sha','stock-smoke-sha','stock-plan-sha','stock-frozen-sha']:
        parser.add_argument('--'+name,required=True)
    parser.add_argument('--plan-sha')
    parser.add_argument('--metadata-sha')
    args=parser.parse_args()
    for name,value in vars(args).items():
        if name.endswith('_sha') and value is not None: require(re.fullmatch('[0-9a-f]{64}',value),'exact SHA required: '+name)
    require(args.stage=='plan' or args.metadata_sha and args.plan_sha and sha(ordinary(PLAN))==args.plan_sha,
        'reviewed plan and completed metadata receipt hashes required')
    Stage(args).execute()


if __name__=='__main__': main()
