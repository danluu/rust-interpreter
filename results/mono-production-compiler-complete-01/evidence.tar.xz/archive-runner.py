#!/usr/bin/env python3
"""Archive already completed, explicitly owned compiler evidence. Run no workloads."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tarfile
import time

OWNER = Path('/Users/danluu/dev/rust-interp-mono-completion-evidence-20260913')
DRIVER = Path('/Users/danluu/dev/rust-interp-stable-mono-compiler-build-20260913')
RAW = DRIVER / '.work/mono-production-build-02'
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
OUT = OWNER / 'results/mono-production-compiler-complete-01'
PRIOR = OWNER / 'results/mono-production-bootstrap-through-stage1-01'
PLAN = DRIVER / 'experiments/stable-cgu/planned-mono-production-build-02.json'
STAGES = ['stage2', 'option-hash', 'stage2-controls', 'dist', 'package',
          'native-controls', 'strip-controls', 'complete']
PRIOR_SHA = '701af2f37f6878b77a34da8abfa174c29da1eba006574553ea507b3919ffcc3c'

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def load(path):
    return json.loads(Path(path).read_bytes())

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def main():
    OUT.mkdir(parents=True, exist_ok=False)
    receipt = {'status': 'waiting', 'pid': os.getpid(), 'parent_pid': os.getppid(),
               'cwd': str(Path.cwd()), 'argv': sys.argv, 'started_at': time.time(),
               'lock': str(LOCK), 'lock_wait_seconds': 600,
               'action': 'archive completed owned evidence only',
               'runner_sha256': digest(__file__), 'compiler_commands': 0,
               'test_commands': 0, 'benchmark_commands': 0}
    receipt_path = OUT / 'packaging-receipt.json'
    save(receipt_path, receipt)
    with LOCK.open('a+b') as lock:
        try:
            until = time.monotonic() + 600
            while True:
                try:
                    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    require(time.monotonic() < until, 'canonical admission expired')
                    time.sleep(0.25)
            receipt.update(status='archiving', admitted_at=time.time(),
                           free_bytes_before=shutil.disk_usage(OWNER).free)
            save(receipt_path, receipt)
            entries = {}
            def add(path, name, expected=None):
                path = Path(path)
                require(path.is_file() and not path.is_symlink(), f'not regular source: {path}')
                require(name not in entries and not name.startswith('/') and '..' not in Path(name).parts,
                        f'bad archive member: {name}')
                value = {'source': str(path), 'size': path.stat().st_size, 'sha256': digest(path)}
                require(expected is None or expected == value['sha256'], f'input hash differs: {path}')
                entries[name] = value
                return value['sha256']
            plan = load(PLAN)
            plan_sha = add(PLAN, 'plans/planned-mono-production-build-02.json')
            require(plan['owner'] == str(DRIVER), 'plan owner')
            for path, expected in plan['inputs'].items():
                p = Path(path)
                if p.is_relative_to(DRIVER):
                    name = 'frozen-inputs/' + p.relative_to(DRIVER).as_posix()
                else:
                    require(path == '/Users/danluu/dev/rust-interp-stable-cgu-20260913/.work/stable-cgu-compiler-setup-01/rust-src-comparison.json', 'unexpected external input')
                    name = 'frozen-inputs/external/rust-src-comparison.json'
                add(p, name, expected)
            complete = load(RAW / 'completed.json')
            require(set(complete) == {'prepare', 'freeze-source', 'stage1', 'stage1-controls', *STAGES}, 'completed stages')
            prior = load(PRIOR / 'summary.json')
            require(prior['archive']['sha256'] == PRIOR_SHA and prior['status'] == 'passed', 'prior archive binding')
            require(digest(PRIOR / 'evidence.tar.xz') == PRIOR_SHA, 'prior archive bytes changed')
            for name in ['summary.json', 'packaging-receipt.json']:
                add(PRIOR / name, 'prior-stage1/' + name)
            for name in ['source.json', 'completed.json', 'combined-upstream.patch', 'mono-formatted.patch',
                         'source-capability.json', 'source-comparison.json', 'llvm-source-proof.json']:
                add(RAW / name, 'build/' + name)
            # Earlier command logs remain in the linked prior archive; small stage
            # receipts make completed.json independently replayable here.
            for name in ['prepare', 'freeze-source', 'stage1', 'stage1-controls']:
                item = complete[name]
                p = Path(item['path'])
                add(p, 'prior-stage1/stages/' + p.parent.name + '.json', item['sha256'])
            stages = {}
            for stage in STAGES:
                item = complete[stage]
                directory = RAW / 'stages' / (stage + '-01')
                require(item['path'] == str(directory / 'receipt.json'), 'stage path')
                stage_sha = add(directory / 'receipt.json', 'build/stages/' + stage + '-01/receipt.json', item['sha256'])
                data = load(directory / 'receipt.json')
                require(data['status'] == 'passed' and data['returncode'] == 0, 'failed stage')
                require(data['plan_sha256'] == plan_sha and data['stage'] == stage, 'stage plan')
                require(data['lock'] == str(LOCK), 'stage lock')
                expected_dirs = set()
                for command in data['commands']:
                    cp = Path(command['receipt'])
                    require(cp.parent.parent == directory / 'commands', 'command outside stage')
                    expected_dirs.add(cp.parent)
                    add(cp, 'build/' + cp.relative_to(RAW).as_posix(), command['sha256'])
                    child = load(cp)
                    require(child['status'] == 'finished' and child['returncode'] == 0, 'failed stage child')
                    for stream in ['stdout', 'stderr']:
                        p = cp.parent / stream
                        add(p, 'build/' + p.relative_to(RAW).as_posix(), child[stream + '_sha256'])
                    require(set(p.name for p in cp.parent.iterdir()) == {'receipt.json', 'stdout', 'stderr'}, 'unexpected child file')
                require(set((directory / 'commands').iterdir()) == expected_dirs, 'unbound command directory')
                outer = DRIVER / '.work/experiments' / ('mono-production-' + stage + '-supervisor-01')
                status = load(outer / 'status.json')
                require(status['status'] == 'finished' and status['returncode'] == 0, 'unfinished outer')
                require(status['child_pid'] == data['supervisor_pid'] and status['supervisor_pid'] == data['parent_pid'], 'outer ownership')
                require(status['cwd'] == str(DRIVER), 'outer cwd')
                require(status['command'][-4:] == ['--stage', stage, '--attempt', stage + '-01'], 'outer stage argv')
                require(digest(outer / 'plan.json') == status['plan_sha256'], 'outer plan hash')
                require(digest(outer / 'command.log') == status['log_sha256'], 'outer log hash')
                require(set(p.name for p in outer.iterdir()) == {'plan.json', 'status.json', 'command.log', 'supervisor.log'}, 'unexpected outer file')
                for p in outer.iterdir():
                    add(p, 'supervisors/' + outer.name + '/' + p.name)
                if stage in ['native-controls', 'strip-controls']:
                    control_dir = directory / 'controls'
                    result = load(control_dir / 'result.json')
                    require(digest(control_dir / 'result.json') == data['control_result']['sha256'], 'control result hash')
                    require(result['status'] == 'passed' and result['partitioning_policy'] == 'stable-mono-cgu', 'control policy')
                    require(result['compiler_unchanged'] and result['package_files_unchanged'] == 6902, 'control package guard')
                    for i, command in enumerate(result['commands']):
                        require(command['returncode'] == 0, 'failed native command')
                        for stream in ['stdout', 'stderr']:
                            require(digest(control_dir / f'{i:02d}.{stream}') == command[stream + '_sha256'], 'native output hash')
                    for p in control_dir.iterdir():
                        if p.is_file() and p.suffix in {'.json', '.rs', '.stdout', '.stderr'}:
                            add(p, 'build/' + p.relative_to(RAW).as_posix())
                    require(len(result['commands']) == (30 if stage == 'native-controls' else 15), 'control command count')
                    require(len(result['histories']) == (15 if stage == 'native-controls' else 6), 'control history count')
                stages[stage] = {'status': 'passed', 'commands': len(data['commands']),
                                 'receipt_sha256': stage_sha, 'supervisor_pid': data['parent_pid'],
                                 'helper_pid': data['supervisor_pid'], 'started_at': data['started_at'],
                                 'admitted_at': data['admitted_at'], 'finished_at': data['finished_at']}
            package = load(RAW / 'package-01/receipt.json')
            require(len(package['files']) == 6902, 'package inventory count')
            for p in (RAW / 'package-01').iterdir():
                require(p.is_file(), 'unexpected package metadata directory')
                add(p, 'build/package-01/' + p.name)
            for i, command in enumerate(package['commands']):
                require(digest(RAW / 'package-01' / f'probe-{i:02d}.log') == command['log_sha256'], 'package probe hash')
            for stage, pattern in [('option-hash', '1 passed; 0 failed; 0 ignored; 0 measured; 17 filtered out'),
                                   ('stage2-controls', '15 passed; 0 failed; 0 ignored; 0 measured; 33 filtered out'),
                                   ('stage2-controls', '2 passed; 0 failed; 0 ignored; 0 measured; 528 filtered out')]:
                text = (RAW / 'stages' / (stage + '-01') / 'commands/006/stdout').read_text()
                require(pattern in text, 'expected focused test summary missing')
            source = load(RAW / 'source.json')
            require(source['source_commit'] == prior['source_commit'], 'compiler identity differs from stage1')
            add(Path(__file__), 'archive-runner.py')
            estimated = sum(v['size'] for v in entries.values())
            require(shutil.disk_usage(OWNER).free > 8 * 1024**3 + 2 * estimated, 'archive disk floor')
            save(OUT / 'members.json', entries)
            archive = OUT / 'evidence.tar.xz'
            with tarfile.open(archive, 'w:xz', preset=3) as tar:
                for name, entry in sorted(entries.items()):
                    p = Path(entry['source'])
                    info = tarfile.TarInfo(name)
                    info.size = entry['size']
                    info.mode = 0o644
                    info.mtime = 0
                    with p.open('rb') as stream:
                        tar.addfile(info, stream)
            seen = set()
            with tarfile.open(archive, 'r:xz') as tar:
                for member in tar:
                    require(member.isfile() and member.name in entries and member.name not in seen, 'bad archived member')
                    seen.add(member.name)
                    h = hashlib.sha256()
                    with tar.extractfile(member) as stream:
                        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                            h.update(chunk)
                    require(h.hexdigest() == entries[member.name]['sha256'] and member.size == entries[member.name]['size'], 'archive member changed')
            require(seen == set(entries), 'missing archive member')
            for entry in entries.values():
                require(digest(entry['source']) == entry['sha256'], 'source changed during archive')
            summary = {'status': 'passed', 'kind': 'production compiler stage2 through complete controls',
                       'source_commit': source['source_commit'], 'bootstrap_sha256': source['config_sha256'],
                       'original_plan_sha256': plan_sha, 'prior_stage1_archive_sha256': PRIOR_SHA,
                       'prior_stage1_summary_sha256': digest(PRIOR / 'summary.json'),
                       'archive': {'path': archive.name, 'sha256': digest(archive), 'bytes': archive.stat().st_size,
                                   'members': len(entries), 'uncompressed_bytes': estimated},
                       'stages': stages, 'option_hash_tests': {'passed': 1, 'filtered': 17},
                       'partition_tests': {'passed': 15, 'filtered': 33},
                       'run_make_tests': {'passed': 2, 'filtered': 528},
                       'native_control_states': 15, 'native_control_commands': 30,
                       'strip_variants': 6, 'strip_control_commands': 15,
                       'package_files': 6902, 'package_receipt_sha256': digest(RAW / 'package-01/receipt.json'),
                       'provenance_sha256': digest(RAW / 'package-01/provenance.json'),
                       'compiler_binaries_or_caches_archived': False, 'source_or_driver_modified_by_archival': False,
                       'all_members_and_sources_rechecked': True, 'frozen_plan_input_count': len(plan['inputs']),
                       'interpreter_integration_qualified': False, 'performance_claim': False, 'benchmark_commands': 0}
            save(OUT / 'summary.json', summary)
            receipt.update(status='passed', finished_at=time.time(), archive_sha256=summary['archive']['sha256'],
                           summary_sha256=digest(OUT / 'summary.json'), members=len(entries),
                           free_bytes_after=shutil.disk_usage(OWNER).free)
            save(receipt_path, receipt)
            print(json.dumps({'status': 'passed', 'pid': os.getpid(), 'archive': summary['archive']}), flush=True)
        except BaseException as error:
            receipt.update(status='failed', finished_at=time.time(), error=repr(error))
            save(receipt_path, receipt)
            raise

if __name__ == '__main__':
    main()
