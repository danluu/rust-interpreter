import gzip, hashlib, io, json, os, re, sys, tarfile, time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import write_json

sha = lambda data: hashlib.sha256(data).hexdigest()
specs = [
    ('host-library-publication', root, 'host-library-publication-tests-01',
     'host-library-publication-tests-supervisor-01', 17),
    ('custom-workspace', Path('/Users/danluu/dev/rust-interp-mono-post-driver-20260913'),
     'custom-workspace-check-tests-01', 'custom-workspace-check-tests-supervisor-01', 4),
]
with Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('r+') as lock:
    acquire_lock(lock, 600)
    admitted_at = time.time()
    payloads, attempts = {}, []
    for label, owner, run_id, supervisor_id, expected in specs:
        raw, supervisor = owner / '.work' / run_id, owner / '.work/experiments' / supervisor_id
        result = json.loads((raw / 'summary.json').read_bytes())
        child = json.loads((raw / 'process.json').read_bytes())
        outer = json.loads((supervisor / 'status.json').read_bytes())
        plan = json.loads((supervisor / 'plan.json').read_bytes())
        stderr = (raw / 'stderr').read_text()
        counts = re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$', stderr, re.M)
        assert result['status'] == 'passed' and result['reported_counts'] == [str(expected)]
        assert result['sources_unchanged'] and result['complete_expected_suite']
        assert result['returncode'] == child['returncode'] == outer['returncode'] == 0
        assert len(counts) == 1 and counts[0][0] == str(expected) and re.search(r'^OK$', stderr, re.M)
        assert child['status'] == outer['status'] == 'finished'
        assert child['pid'] == result['child_pid'] and child['parent_pid'] == result['pid']
        assert child['command'] == result['command'] and child['expected_tests'] == expected
        assert outer['child_pid'] == result['pid'] and outer['supervisor_pid'] == result['parent_pid']
        assert outer['plan_sha256'] == sha((supervisor / 'plan.json').read_bytes())
        assert outer['log_sha256'] == sha((supervisor / 'command.log').read_bytes())
        assert plan['supervisor_sha256'] == result['source_hashes'][str(owner / 'scripts/supervise_experiment.py')]
        for name, digest in result['source_hashes'].items():
            snapshot = raw / 'sources' / Path(name).relative_to(owner)
            assert not snapshot.is_symlink() and sha(snapshot.read_bytes()) == digest
        attempts.append(dict(label=label, owner=str(owner), tests=expected,
            source_revision=result['revision'], test_seconds=float(counts[0][1]),
            supervisor_pid=outer['supervisor_pid'], helper_pid=result['pid'], child_pid=child['pid'],
            source_snapshots=len(result['source_hashes']), summary_sha256=sha((raw/'summary.json').read_bytes())))
        for base in (raw, supervisor):
            for path in sorted(base.rglob('*')):
                assert not path.is_symlink()
                if path.is_file():payloads[label + '/' + str(path.relative_to(owner))] = path.read_bytes()
    payloads['archive-script.py'] = Path(__file__).read_bytes()
    manifest = {name: dict(bytes=len(data), sha256=sha(data)) for name, data in payloads.items()}
    out = root / 'results/host-library-and-custom-workspace-source-tests-01'
    out.mkdir(exist_ok=False)
    archive = out / 'evidence.tar.gz'
    with archive.open('xb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as writer:
            for name, data in sorted(payloads.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(data), 0o644
                writer.addfile(entry, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as reader:
        assert len(reader.getnames()) == len(manifest) and set(reader.getnames()) == set(manifest)
        for member in reader.getmembers():
            assert member.isfile()
            data = reader.extractfile(member).read()
            assert manifest[member.name] == dict(bytes=len(data), sha256=sha(data))
    write_json(out / 'manifest.json', manifest)
    summary = dict(status='passed', tests=21, attempts=attempts, compiler_commands=0, benchmarks=0,
        archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()), members=len(manifest)),
        verification=dict(pid=os.getpid(), parent_pid=os.getppid(), lock=str(Path(lock.name)),
                          admitted_at=admitted_at, finished_at=time.time(), all_member_hashes_verified=True))
    write_json(out / 'summary.json', summary)
    (out / 'README.md').write_text('The 17 shared public-tool publication contracts and four matched custom-workspace boundary tests passed without skips. These are separate source test executions; no compiler build or benchmark ran. Exact tested source snapshots, raw output and process/supervisor receipts are retained. Each archive member and snapshot hash was verified under the canonical workload lock. Actual host-library build/native histories and custom-compiler workspace execution remain separate gates.\n')
    print(json.dumps(summary))
