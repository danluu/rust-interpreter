import hashlib, json, os, re, subprocess, sys, time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from compare_saved_runtime import acquire_lock
from workflow_io import capture, write_json

work=root/'.work/custom-workspace-check-tests-01'
work.mkdir(exist_ok=False)
lock_path=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
record=dict(status='waiting',owner=str(root),pid=os.getpid(),parent_pid=os.getppid(),
            started_at=time.time(),canonical_lock=str(lock_path),lock_wait_seconds=600,
            expected_tests=4,compiler_commands=0,benchmarks=0)
write_json(work/'summary.json',record)
try:
    with lock_path.open('r+') as lock:
        acquire_lock(lock,600)
        record.update(status='running',admitted_at=time.time(),
            revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip())
        files=[root/name for name in ['experiments/stable-cgu/check-custom-workspace.py',
            'experiments/stable-cgu/POST-DRIVER-QUALIFICATION.md','tests/test_custom_workspace_check.py',
            'scripts/build_custom_tools.py','scripts/custom_compiler.py','scripts/interpreter.py',
            'scripts/workspace_cache.py','scripts/compare_saved_runtime.py','scripts/workflow_io.py',
            'scripts/supervise_experiment.py']]+[Path(__file__)]
        record['source_hashes']={}
        for path in files:
            if not path.is_file() or path.is_symlink():raise RuntimeError('invalid source input: '+str(path))
            data=path.read_bytes()
            record['source_hashes'][str(path)]=hashlib.sha256(data).hexdigest()
            saved=work/'sources'/path.relative_to(root)
            saved.parent.mkdir(parents=True,exist_ok=True)
            saved.write_bytes(data)
        write_json(work/'summary.json',record)
        command=[sys.executable,'-B','-m','unittest','-v','test_custom_workspace_check']
        env=dict(os.environ,PYTHONPATH=str(root/'tests'),PYTHONDONTWRITEBYTECODE='1')
        child,stdout,stderr=capture(command,cwd=root,env=env,receipt_path=work/'process.json',
                                   receipt=dict(expected_tests=4))
        (work/'stdout').write_text(stdout)
        (work/'stderr').write_text(stderr)
        counts=re.findall(r'^Ran (\d+) tests? in [\d.]+s$',stderr,re.M)
        passed=child.returncode==0 and counts==['4'] and re.search(r'^OK$',stderr,re.M) is not None
        unchanged=all(hashlib.sha256(p.read_bytes()).hexdigest()==record['source_hashes'][str(p)] for p in files)
        record.update(status='passed' if passed and unchanged else 'failed',returncode=child.returncode,
            child_pid=child.pid,command=command,reported_counts=counts,sources_unchanged=unchanged,
            complete_expected_suite=passed,finished_at=time.time())
        write_json(work/'summary.json',record)
        print(stderr)
        sys.exit(0 if passed and unchanged else child.returncode or 1)
except BaseException as error:
    if not isinstance(error,SystemExit):
        record.update(status='failed',error=repr(error),finished_at=time.time())
        write_json(work/'summary.json',record)
    raise
