"""Finite publication of the completed, independently verified parked screen."""
from pathlib import Path
import gzip,hashlib,io,json,os,stat,tarfile,time
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913');X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918');O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
H=ROOT/'experiments/proc-macro-arena-ruff-screen-04';E=ROOT/'results/proc-macro-arena-ruff-screen-04';W=ROOT/'.work/proc-macro-arena-ruff-screen-04'
P=ROOT/'results/proc-macro-arena-ruff-screen-04-publication';FIELDS=('dev','ino','mode','nlink','size','mtime_ns','ctime_ns')
def stamp(p):s=p.lstat();return {k:getattr(s,'st_'+k) for k in FIELDS}
def read(p):return json.loads(p.read_bytes())
def canonical(d):return json.dumps(d,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def row(p):
 assert p.is_absolute() and p.resolve(strict=True)==p;s=stamp(p);assert stat.S_ISREG(s['mode']) and s['size']<=(16 if p==P/'evidence.tar.gz' else 8)*2**20
 b=p.read_bytes();assert stamp(p)==s and len(b)==s['size'];return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),identity=s)
def save(p,d):
 b=(json.dumps(d,sort_keys=True,indent=2)+'\n').encode();assert len(b)<=4*2**20
 with p.open('xb') as f:f.write(b)
def ref(p):return dict(path=str(p),**row(p))
def tree(base):
 found=set()
 for root,dirs,files in os.walk(base,followlinks=False):
  for name in dirs:assert (Path(root)/name).resolve(strict=True)==Path(root)/name
  for name in files:found.add(Path(root)/name)
 return found
assert not P.exists()
plan=read(H/'plan.json');proof=X/'.work/proc-macro-arena-ruff-screen04-independent-readback-01.json';audit=read(proof)
assert row(proof)['sha256']=='dff7089c8a01e39dc17a71b022c6ae62ae9ee9816fff2a78aa8801478d7d184f'
assert audit['status']=='verified-native-frontend-screen' and audit['decision']=='park-allocator-performance-path'
assert audit['timed_calls']==36 and audit['warm_calls']==audit['restoration_calls']==12 and len(audit['pairs'])==18
assert audit['actual_setup_calls']=={'stock':325,'candidate':325} and audit['all_attempts_retained']==650
execution=read(E/'execution.json');result=read(E/'result.json')
assert row(E/'execution.json')['sha256']==audit['execution']['sha256']=='a7cbe575e83a0c2ca902a5a596a241a2bcf8b7c6d765e268c1d93aeccd5ccf68'
assert row(E/'result.json')['sha256']==audit['result']['sha256']=='ae9afc2c954565074d5fea0e3d483acb3ff39cdbc0a894606a0806ecae74d76b'
for key in ['decision','pairs','median_candidate_stock_ratio','max_absolute_AA_variation']:assert execution[key]==result[key]==audit[key]
assert execution['status']==result['status']=='passed' and execution['parent_pid']==53069 and execution['signals']==[] and execution['retries']==0
readback_dir=X/'.work/proc-macro-arena-ruff-screen04-readback-execution-01';reader_owner=read(readback_dir/'record.json')
assert row(readback_dir/'record.json')['sha256']=='e14fd67114855cf6ce845a358a6b50f14a23f8301c43ba020000e698af467a92'
assert reader_owner['status']=='closed' and reader_owner['returncode']==0 and reader_owner['parent_pid']==3845 and reader_owner['child_pid']==5281
trees={base:tree(base) for base in [H,E,readback_dir]};assert len(trees[E])==4140
evidence_rows={str(p.relative_to(E)):row(p) for p in sorted(trees[E])}
assert sum(r['bytes'] for r in evidence_rows.values())==audit['complete_evidence_bytes']==58244067
assert hashlib.sha256(canonical(evidence_rows)).hexdigest()==audit['complete_evidence_table_sha256']
selected=set().union(*trees.values())
selected.update([proof,X/'.work/verify_ruff_screen04_saved_01.py',X/'.work/verify_ruff_screen04_saved_01.from-unrun03.diff',X/'.work/proc-macro-arena-ruff-screen04-saved-reader-source-handoff-01.json',
 X/'.work/proc-macro-arena-ruff-screen04-source-handoff-01.json',X/'.work/proc-macro-arena-ruff-screen04-source-handoff-02.json',X/'.work/proc-macro-arena-ruff-screen04-source-handoff-02.from-handoff01.diff',
 X/'.work/check_ruff_screen04_json_messages_01.py',X/'.work/ruff-screen04-json-development-01.json',X/'.work/verify_ruff_screen03_saved_01.py',
 O/'.work/ruff-screen04-reader-JSON-independent-source-slice-01.json',O/'.work/ruff-screen03-json-contract-independent-review-01.json',
 ROOT/'.work/proc-macro-arena-ruff-screen04-root-review-01.json',ROOT/'.work/proc-macro-arena-ruff-screen-invocation-04.json',
 W/'contexts/stock.json',W/'contexts/candidate.json',Path(__file__).absolute(),Path(plan['source_inventory']['path']),
 X/'.work/proc-macro-arena-ruff-screen04-publication-plan-01.json',X/'.work/publish_ruff_screen04_01.from-screen03.diff'])
for r in [*plan['reference_sources'],*plan['probe_source_references'],*plan['probe_sources'].values(),*plan['json_contract_sources']]:
 p=Path(r['path']);assert row(p)['sha256']==r['sha256'];selected.add(p)
for previous in plan['failed_predecessors']:
 for key in ['execution','independent_readback','source']:
  r=previous[key];p=Path(r['path']);assert row(p)['sha256']==r['sha256'];selected.add(p)
for number in ['01','02','03']:
 for name in ['summary.json','READBACK.json']:selected.add(ROOT/f'results/proc-macro-arena-ruff-screen-{number}-publication'/name)
assert row(ROOT/'.work/proc-macro-arena-ruff-screen-invocation-04.json')['sha256']==audit['invocation_sha256']=='a2a533b0490b55d407cd3d239e99abe806b867514260e59db1f07cb94a3bd496'
assert row(H/'source-manifest.json')['sha256']==audit['source_manifest_sha256']=='2bd6a2f822d6a2dee2cdbf1afa39e344aea583571ca9fe9497db9f9230db5548'
assert row(X/'.work/verify_ruff_screen04_saved_01.py')['sha256']=='aebefb87a9c468ebb92f60ac6e833ed43927e3bd12e98f189991121abbe4085f'
assert row(O/'.work/ruff-screen04-reader-JSON-independent-source-slice-01.json')['sha256']=='69c0e50aed7fb78655c4bf6fa1b34ae93f6af899d094449e087cfa92b763a8fc'
assert all(not p.is_relative_to(W/'source') and not p.is_relative_to(W/'target') and not p.is_relative_to(W/'replays') for p in selected)
rows={str(p):row(p) for p in sorted(selected)};logical=sum(r['bytes'] for r in rows.values());assert len(rows)<=4500 and logical<=72*2**20
publication_plan=read(X/'.work/proc-macro-arena-ruff-screen04-publication-plan-01.json')
assert row(Path(__file__).absolute())['sha256']==publication_plan['publisher']['sha256']
without_plan={name:r for name,r in rows.items() if name!=str(X/'.work/proc-macro-arena-ruff-screen04-publication-plan-01.json')}
assert len(rows)==publication_plan['selected_file_count_including_plan'] and sum(r['bytes'] for r in without_plan.values())==publication_plan['logical_bytes_excluding_plan']
assert hashlib.sha256(canonical(sorted(without_plan))).hexdigest()==publication_plan['selected_paths_sha256_excluding_plan']
P.mkdir();archive=P/'evidence.tar.gz'
with archive.open('xb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w|') as tar:
   for name,r in rows.items():
    p=Path(name);assert row(p)==r;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256']
    item=tarfile.TarInfo(name.lstrip('/'));item.size=len(b);item.mode=stat.S_IMODE(r['identity']['mode']);item.mtime=r['identity']['mtime_ns']//10**9
    item.uid=0;item.gid=0;item.uname='';item.gname='';tar.addfile(item,io.BytesIO(b))
assert archive.stat().st_size<=16*2**20
uncompressed=0
with gzip.open(archive,'rb') as f:
 while block:=f.read(2**20):uncompressed+=len(block);assert uncompressed<=80*2**20
seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for item in tar:
  name='/'+item.name;assert item.isfile() and name in rows and name not in seen;seen.add(name)
  with tar.extractfile(item) as stream:b=stream.read(8*2**20+1)
  assert len(b)==rows[name]['bytes'] and hashlib.sha256(b).hexdigest()==rows[name]['sha256']
assert seen==set(rows)
for name,r in rows.items():assert row(Path(name))==r
for base,found in trees.items():assert tree(base)==found
manifest=dict(policy='portable-verified-Ruff-screen04-parked-result-v1',archive=ref(archive),member_count=len(rows),logical_bytes=logical,
 members={name.lstrip('/'):dict(original_path=name,**r) for name,r in rows.items()},
 external=dict(copied_Ruff_source=str(W/'source'),fresh_Cargo_targets=str(W/'target'),replay_artifact_outputs=str(W/'replays'),canonical_Ruff_source=plan['source_root'],
 source_and_binary_tree_payloads='excluded; complete source and captured input inventories retained as metadata; exact bounded reviewed source references retained',
 compiler_Cargo_and_overlay_binaries='excluded; exact invocation, complete independent EOF readback and prior passed N overlay provenance remain authoritative',
 original_WORK_and_providers='preserved unchanged; no retirement, reuse or subsequent execution authority'))
save(P/'manifest.json',manifest)
summary=dict(status='published-verified-native-frontend-screen-parked',observed_at=time.time(),source=str(H),actual_results=str(E),independent_readback=ref(proof),readback_execution=ref(readback_dir/'record.json'),
 actual_execution_sha256=audit['execution']['sha256'],actual_result_sha256=audit['result']['sha256'],parent_pid=53069,root_observed_parent_returncode=0,
 timed_calls=36,warm_calls=12,restoration_calls=12,pair_count=18,setup_calls=audit['actual_setup_calls'],all_attempts_retained=650,
 median_candidate_stock_ratio=audit['median_candidate_stock_ratio'],max_absolute_AA_variation=audit['max_absolute_AA_variation'],decision=audit['decision'],
 meaning='Fixed screening rule found no gain beyond same-run AA variation; allocator performance path parked without unchanged retry. This does not establish a full-workflow result or zero allocator effect.',
 full_ordered_selected_check_parity=True,application_tests_run=False,full_workflow_qualified=False,holdout_qualified=False,sub_half_second_claim=False,
 failed_predecessors=plan['failed_predecessors'],source_restored_by_completed_screen=True,payload_retirement=False,retries=0,
 archive=ref(archive),manifest=ref(P/'manifest.json'),preserved_originals=True)
save(P/'summary.json',summary)
save(P/'READBACK.json',dict(status='verified',full_gzip_EOF=True,all_members_read_to_EOF=True,all_member_hashes_match=True,
 current_selected_sources_raw_stamps_and_bytes_unchanged=True,closed_evidence_members=4140,source_and_evidence_tree_membership_unchanged=True,
 members=len(rows),logical_bytes=logical,gzip_bytes=archive.stat().st_size,uncompressed_tar_bytes=uncompressed,
 archive=ref(archive),manifest=ref(P/'manifest.json'),summary=ref(P/'summary.json')))
(P/'README.md').write_text('The fixed Ruff native frontend screen completed both 325-call Cargo setups,36 timed calls,12 warm calls and12 restoration checks. Independent saved readback verified every closure, all 650 wrapper attempts, the genuine edited test-metadata command, complete selected JSON records, dependency provenance, source restoration and the full input EOF checks.\n\nThe median candidate/stock wall ratio is 0.9941062147904625; largest same-run stock/stock variation is 0.03440974702224331. The precommitted decision is park-allocator-performance-path: the observed median difference does not exceed AA noise. No unchanged retry is authorized or performed. This is a native nonincremental frontend screen, not full edited-build/workflow/holdout or sub-half-second qualification. Setup and every sample remain separately recorded.\n\nAll 4140 closed raw/attempt/record/input-metadata files, exact bounded source/invocation, independent reader and review, actual readback closure and selected provenance are retained. Failed 01–03 remain failures with exact readbacks and prior-publication references. Their binary caches are not reused. Ruff/target/compiler/provider binary or source-tree payloads remain external and unchanged; no payload is retired. Archive stamps are historical original observations. Full gzip EOF, every member EOF/hash, current selected byte/stamp readback and exact tree membership were verified. No Git, compiler, Cargo, retry, cleanup or process control is performed by publication.\n')
print(json.dumps(dict(path=str(P),members=len(rows),logical_bytes=logical,gzip_bytes=archive.stat().st_size,readback_sha256=row(P/'READBACK.json')['sha256'],summary_sha256=row(P/'summary.json')['sha256'])))
