"""Independent saved readback. Do not invoke until the measured owner has closed."""
from pathlib import Path
import argparse,ast,fcntl,hashlib,json,math,os,re,stat,statistics,time
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
H=ROOT/'experiments/proc-macro-arena-ruff-screen-03';E=ROOT/'results/proc-macro-arena-ruff-screen-03';W=ROOT/'.work/proc-macro-arena-ruff-screen-03'
OUTPUT=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918/.work/proc-macro-arena-ruff-screen03-independent-readback-01.json')
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
INVOCATION_SHA='a2a03d90bd27e91a4600444b10958f07d989d41c9795b2f5a85d9c735f23f21b'
MANIFEST_SHA='538484bc340be6c7909c55bb2de3a2224a8eb0f6d853bed11b2d2609ea958626'
FIELDS=('dev','ino','mode','nlink','size','mtime_ns','ctime_ns');CHECKED={};JSONS={};READ_BYTES=0

def require(ok,msg):
 if not ok:raise RuntimeError(msg)
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def stamp(p):s=Path(p).lstat();return {k:getattr(s,'st_'+k) for k in FIELDS}
def file(p):
 global READ_BYTES
 p=Path(p);require(p.is_absolute() and p.resolve(strict=True)==p,'ordinary current file route')
 before=stamp(p);require(stat.S_ISREG(before['mode']) and before['size']<=512*2**20,'bounded regular file')
 if str(p) in CHECKED:
  require(CHECKED[str(p)]['identity']==before,'file changed after first complete read');return CHECKED[str(p)]
 h=hashlib.sha256();n=0
 with os.fdopen(os.open(p,os.O_RDONLY|os.O_NOFOLLOW),'rb') as stream:
  s=os.fstat(stream.fileno());require({k:getattr(s,'st_'+k) for k in FIELDS}==before,'opened file identity')
  while block:=stream.read(2**20):h.update(block);n+=len(block);READ_BYTES+=len(block);require(READ_BYTES<=8*2**30,'finite saved readback bytes')
  s=os.fstat(stream.fileno());require({k:getattr(s,'st_'+k) for k in FIELDS}==before,'file changed during EOF')
 require(stamp(p)==before and n==before['size'],'file replaced during EOF')
 row=dict(bytes=n,sha256=h.hexdigest(),identity=before);CHECKED[str(p)]=row;return row
def read(p,expected=None):
 p=Path(p);row=file(p);require(row['bytes']<=8*2**20 and (expected is None or row['sha256']==expected),'JSON source pin/size')
 if str(p) not in JSONS:JSONS[str(p)]=json.loads(p.read_bytes());require(stamp(p)==row['identity'],'JSON decode race')
 return JSONS[str(p)]
def pinned(ref):
 row=file(ref['path']);require(row['sha256']==ref['sha256'],'reference SHA')
 for key in ['bytes','identity']:
  if key in ref:require(row[key]==ref[key],'reference '+key)
 return read(ref['path'],ref['sha256'])
def option(args,key):
 found=[]
 for i,a in enumerate(args):
  if a==key:require(i+1<len(args),'missing option');found.append(args[i+1])
  elif a.startswith(key+'='):found.append(a.split('=',1)[1])
 require(len(found)<=1,'duplicate option');return found[0] if found else None
def crate_types(args):
 values=[]
 for i,a in enumerate(args):
  if a=='--crate-type':require(i+1<len(args),'crate type value');values.extend(args[i+1].split(','))
  elif a.startswith('--crate-type='):values.extend(a.split('=',1)[1].split(','))
 require(len(values)==len(set(values)) and set(values)<={'bin','lib','rlib','dylib','cdylib','staticlib','proc-macro'},'actual distinct crate type list')
 return values

def changed_output(args,destination):
 out=[];i=0
 while i<len(args):
  if args[i]=='--out-dir':out.extend([args[i],str(destination)]);i+=2
  elif args[i].startswith('--out-dir='):out.append('--out-dir='+str(destination));i+=1
  else:out.append(args[i]);i+=1
 return out

def process(directory,expected_code):
 r=read(directory/'record.json');require(r['status']=='closed' and r['may_be_live'] is False and r['returncode'] in expected_code,'exact process closure')
 require(type(r['pid']) is int and r['pid']>1 and type(r['parent_pid']) is int,'process identities')
 require(r['started_at']<=r['spawned_at']<=r['finished_at']<=r['observation_finished_at'],'process chronology')
 require(r['observation_errors']==[] and os.waitstatus_to_exitcode(r['wait_status'])==r['returncode'],'actual wait4 closure')
 for n in ['elapsed_seconds','cpu_user_seconds','cpu_system_seconds']:
  require(type(r[n]) in [int,float] and math.isfinite(r[n]) and r[n]>=0,'finite actual timing')
 require(r['elapsed_seconds']>0 and r['rusage_source']=='actual os.wait4 return for this child','blocking wait4 timing scope')
 for name in ['stdout','stderr','stdin']:
  if name in r:require(file(directory/name)==r[name],'actual full raw stream')
 return r

def table(ref):
 index=pinned(ref);rows={}
 require(type(index['rows']) is int and index['rows']<=70000,'finite input table')
 for ordinal,part in enumerate(index['parts']):
  require(Path(part['path']).name==f'part-{ordinal:03d}.json','ordered fixed table parts')
  values=pinned(part);require(len(values)==part['rows'] and 0<len(values)<=1000 and not(set(rows)&set(values)),'complete disjoint part')
  rows.update(values)
 require(len(rows)==index['rows'] and sha(canonical(rows))==index['canonical_sha256'],'complete canonical table digest')
 return rows

def current_rows(rows):
 for name,row in rows.items():
  if row.get('kind')=='symlink':require(stamp(name)==row['identity'] and os.readlink(name)==row['target'],'exact retained source alias')
  elif 'resolved' in row:
   require(str(Path(name).resolve(strict=True))==row['resolved'],'declared dependency resolution')
   require(file(row['resolved'])=={k:row[k] for k in ['bytes','sha256','identity']},'complete actual compiler input')
  else:require(file(name)==row,'complete current input table')

def depinfo(p,cwd):
 r=file(p);raw=Path(p).read_text();require(stamp(p)==r['identity'],'dep-info unchanged')
 first=next(x for x in raw.replace('\\\n','').splitlines() if x and not x.startswith('#'));require(': ' in first,'dep-info first target')
 rhs=first.split(': ',1)[1];words=[];word='';escape=False
 for char in rhs:
  if escape:word+=char;escape=False
  elif char=='\\':escape=True
  elif char.isspace():
   if word:words.append(word);word=''
  else:word+=char
 require(not escape,'complete dep-info escape')
 if word:words.append(word)
 paths=sorted({os.path.normpath(x if Path(x).is_absolute() else str(Path(cwd)/x)) for x in words})
 return raw,paths

def normalized(value):
 text=json.dumps(value,sort_keys=True)
 for arm in ['stock','candidate']:
  text=text.replace(str(W/'target'/arm),'<target>').replace(str(W/'tmp'/arm),'<tmp>').replace(str(Path(PLAN['overlay_work'])/arm/'sysroot'),'<sysroot>')
 return text

def jobserver_changed(old,new):
 require(set(old)==set(new),'replay environment keys preserved');observed={};pairs=set();original_pairs=set()
 for key in old:
  if key not in ['CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS']:require(old[key]==new[key],'non-jobserver environment value changed');continue
  pattern=r'--jobserver-(auth|fds)=([0-9]+),([0-9]+)';matches=list(re.finditer(pattern,old[key]));current=list(re.finditer(pattern,new[key]))
  require(len(matches)==len(current)<=2 and len({m.group(1) for m in matches})==len(matches) and old[key].count('--jobserver-')==len(matches),'jobserver tokens retained')
  require(re.sub(pattern,r'--jobserver-\1=<pair>',old[key])==re.sub(pattern,r'--jobserver-\1=<pair>',new[key]),'only pipe numbers substituted')
  if matches:
   original_pairs.update(m.group(2,3) for m in matches);pairs.update(m.group(2,3) for m in current);observed[key]=dict(before=old[key],after=new[key])
 require('CARGO_MAKEFLAGS' in observed and len(pairs)==len(original_pairs)==1,'one coherent original and owned replay jobserver pair')
 return observed

def transport(environment,observation):
 pairs=set();advertised={}
 for key in ['CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS']:
  if key not in environment:continue
  matches=list(re.finditer(r'--jobserver-(auth|fds)=([0-9]+),([0-9]+)',environment[key]))
  require(len(matches)<=2 and len({m.group(1) for m in matches})==len(matches) and environment[key].count('--jobserver-')==len(matches),'source-defined pipe transport')
  if matches:advertised[key]=environment[key];pairs.update((int(m.group(2)),int(m.group(3))) for m in matches)
 require(len(pairs)<=1 and observation['advertised']==advertised,'complete advertised transport')
 pair=next(iter(pairs)) if pairs else None
 require(observation['pair']==(list(pair) if pair is not None else None),'actual recorded pipe pair')
 endpoints=observation['observed_endpoints'];require(set(endpoints)==({str(x) for x in pair} if pair else set()),'complete observed pipe endpoints')
 if pair:
  require(pair[0]>2 and pair[1]>2 and pair[0]!=pair[1],'two distinct inherited pipe descriptors')
  for fd,mode in zip(pair,[os.O_RDONLY,os.O_WRONLY]):
   row=endpoints[str(fd)];require(stat.S_ISFIFO(row['identity']['mode']) and row['inheritable'] is True and row['flags']&os.O_ACCMODE==mode,'recorded live inheritable read/write pipe ends')

def environment_parity(environment):
 out=dict(environment)
 for key in ['CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS']:
  if key in out:out[key]=re.sub(r'--jobserver-(auth|fds)=([0-9]+),([0-9]+)',r'--jobserver-\1=1000001,1000002',out[key])
 return normalized(out)

def verify_dependency(proof,command,cwd,arm,is_macro):
 crate=option(command,'--crate-name');output=option(command,'--out-dir');suffix=[]
 for i,arg in enumerate(command):
  if arg=='-C' and i+1<len(command) and command[i+1].startswith('extra-filename='):suffix.append(command[i+1].split('=',1)[1])
  elif arg.startswith('-Cextra-filename='):suffix.append(arg.split('=',1)[1])
 require(crate is not None and output is not None and len(suffix)<=1,'actual Cargo dependency output key')
 if not suffix:require(crate=='build_script_build' and crate_types(command)==['bin'] and option(command,'--emit')=='dep-info,link','only normal Cargo build-script binary has no filename suffix')
 expected=Path(output)/(crate+(suffix[0] if suffix else '')+'.d')
 ref=proof['depinfo'];require(Path(ref['path'])==expected,'independent captured command to dep-info path association')
 require(file(ref['path'])=={k:ref[k] for k in ['bytes','sha256','identity']},'actual dependency proof file')
 raw,paths=depinfo(ref['path'],cwd);require(paths==proof['paths'],'complete independently decoded dep-info')
 other='candidate' if arm=='stock' else 'stock'
 require('/.rustup/toolchains/' not in raw and str(Path(PLAN['overlay_work'])/other/'sysroot') not in raw,'no T/opposite artifact fallback')
 require('libproc_macro-452900db9815e688.' not in raw and 'librustc_literal_escaper-f4f532eb55f87a02.' not in raw,'old client/literal absent')
 if is_macro:
  expected={name:row for name,row in OVERLAY['entries'].items() if row['kind']=='file' and Path(name).is_relative_to(Path(PLAN['overlay_work'])/arm/'sysroot')}
  require(len(expected)==4 and set(proof['selected'])==set(expected),'exact four arm-owned macro dependencies')
  for name,row in expected.items():require(name in paths and file(name)==proof['selected'][name]=={k:row[k] for k in ['bytes','sha256','identity']},'actual default selected macro artifact')
 else:require(proof['selected']=={},'no invented macro artifact claim')


def setup(arm,parent):
 directory=E/('cargo-'+arm);cargo=process(directory,{0});require(cargo['parent_pid']==parent,'Cargo parent owner')
 require(cargo['command']==[PLAN['cargo']]+[str(W/'target'/arm) if x=='<fresh-arm-target>' else x for x in PLAN['cargo_arguments']],'actual fixed Cargo command')
 environment=cargo['environment'];expected_environment=dict(PLAN['environment'],RUSTC=str(H/'rustc_capture.py'),RUSTC_WRAPPER='',RUSTC_WORKSPACE_WRAPPER='',TMPDIR=str(W/'tmp'/arm),ARENA_SCREEN_CONTEXT=str(W/'contexts'/(arm+'.json')),ARENA_SCREEN_CONTEXT_SHA=environment['ARENA_SCREEN_CONTEXT_SHA'],ARENA_SCREEN_LOCK_FD=environment['ARENA_SCREEN_LOCK_FD'])
 require(environment==expected_environment and environment['ARENA_SCREEN_LOCK_FD'].isdigit() and int(environment['ARENA_SCREEN_LOCK_FD'])>2,'exact producer-passed Cargo environment')
 require(cargo['cwd']==str(W/'source'),'actual owned source working directory')
 events=[json.loads(s) for s in (directory/'stdout').read_text().splitlines() if s.strip()]
 require(events[-1]=={'reason':'build-finished','success':True},'successful actual Cargo event')
 require(any(v.get('reason')=='compiler-artifact' and v['target']['name']=='ruff_linter' and v['profile']['test'] is True for v in events),'real Ruff library-test selection')
 saved=read(E/('setup-'+arm+'.json'));require(saved['record']==cargo,'same recorded setup')
 context=pinned(dict(path=cargo['environment']['ARENA_SCREEN_CONTEXT'],sha256=cargo['environment']['ARENA_SCREEN_CONTEXT_SHA']))
 require(context['arm']==arm and context['common_sha256']==MANIFEST['files']['common.py']['sha256'] and context['wrapper_sha256']==MANIFEST['files']['rustc_capture.py']['sha256'],'source-authenticated capture context')
 require(context['compiler']==PLAN['compiler'] and file(context['compiler'])==context['compiler_row'] and context['sysroot']==str(Path(PLAN['overlay_work'])/arm/'sysroot') and context['probe_sources']==PLAN['probe_sources'],'exact compiler/overlay/probe context')
 routes=[];probes=[];tops=[];macros=0;dependencies=set()
 for ref in saved['route_records']:
  route=pinned(ref);call=Path(route['call_directory']);require(call.parent==E/'capture'/arm,'owned native capture')
  attempt=read(Path(route['attempt']));require(attempt['status']=='returned-native-exit' and attempt['id']==call.name,'every wrapper returned a recorded native outcome')
  require(attempt['argv']==[str(H/'rustc_capture.py')]+route['original_arguments'] and attempt['wrapper_pid']==route['wrapper_pid'],'actual captured argv association')
  require(attempt['cwd']==route['cwd'] and attempt['received_environment']==route['received_environment'] and attempt['wrapper_parent_pid']==route['wrapper_parent_pid'] and route['context_sha256']==environment['ARENA_SCREEN_CONTEXT_SHA'],'actual wrapper observation association')
  classification=route['classification'];kind=classification['kind'];allowed={0,1} if kind in ['autocfg-probe','proc-macro2-probe','thiserror-probe','anyhow-probe','rustix-probe'] else {0}
  native=process(call,allowed);require(native['parent_pid']==route['wrapper_pid'] and attempt['returned_code']==native['returncode'],'owned native/parent closure')
  require(native['command']==route['forwarded_arguments'] and native['environment']==route['forwarded_environment'],'exact actual native command/environment')
  expected=[PLAN['compiler']]+route['original_arguments']+['--sysroot',str(Path(PLAN['overlay_work'])/arm/'sysroot')]
  if kind=='cargo-crate':expected+=['-Zbinary-dep-depinfo']
  require(native['command']==expected and route['is_compile']==(kind=='cargo-crate'),'host/probe overlay selection and unchanged Cargo argv')
  require(route['forwarded_environment']=={k:v for k,v in route['received_environment'].items() if k not in ['ARENA_SCREEN_CONTEXT','ARENA_SCREEN_CONTEXT_SHA','ARENA_SCREEN_LOCK_FD']},'only explicit wrapper transport fields removed')
  transport(route['forwarded_environment'],route['jobserver_transport'])
  require(cargo['spawned_at']<=attempt['started_at']<=native['started_at']<=native['finished_at']<=attempt['finished_at']<=cargo['finished_at'],'setup process chronology')
  require(file(call/'record.json')['sha256']==route['record']['sha256'],'route native record SHA')
  if kind=='cargo-crate':
   proof=read(call/'dependency-proof.json');is_macro='proc-macro' in crate_types(native['command']);verify_dependency(proof,native['command'],native['cwd'],arm,is_macro);macros+=int(is_macro);dependencies.update(proof['paths'])
   if option(native['command'],'--crate-name')=='ruff_linter' and '--test' in native['command']:tops.append(dict(route,dependency_proof=proof))
  elif kind in ['autocfg-probe','proc-macro2-probe','thiserror-probe','anyhow-probe','rustix-probe']:
   if 'source_row' in classification:
    source=classification['probe_source'];require(source in PLAN['probe_sources'] and file(source)==classification['source_row'] and file(source)['sha256']==PLAN['probe_sources'][source]['sha256'],'same exact pinned source-file capability probe')
   if kind=='rustix-probe':
    source=classification['callsite_source'];require(source['path']==str(Path(route['cwd'])/'build.rs') and source['path'] in PLAN['probe_sources'],'exact rustix stdin generator association')
    require(file(source['path'])=={k:source[k] for k in ['bytes','sha256','identity']} and source['sha256']==PLAN['probe_sources'][source['path']]['sha256'],'actual pinned rustix caller source')
   digest=native['stdin']['sha256'] if classification['probe_source']=='captured stdin' else classification['source_row']['sha256']
   probes.append(dict(kind=kind,cwd=route['cwd'],source_sha256=digest,returncode=native['returncode'],out_dir=route['forwarded_environment']['OUT_DIR']))
  else:require(kind=='query','only retained explicit query/probe/crate roles')
  routes.append(route)
 require(len(routes)==saved['compiler_calls'] and 0<len(routes)<=1024 and len(tops)==1 and macros>0,'complete fresh compiler graph and top target')
 require(tops[0]==saved['top'] and option(tops[0]['forwarded_arguments'],'--emit')=='dep-info,metadata','exact genuine top-level test metadata command')
 require({Path(x['path']).parent for x in saved['route_records']}==set((E/'capture'/arm).iterdir()),'complete native capture membership')
 require({x['path'] for x in saved['attempts']}=={r['attempt'] for r in routes},'every wrapper attempt retained')
 for ref in saved['attempts']:pinned(ref)
 closure=read(E/('native-closure-'+arm+'.json'));require(len(closure)==len(routes) and {x['path'] for x in closure}=={str(Path(r['call_directory'])/'record.json') for r in routes},'complete native closure census')
 for row in closure:
  native=read(row['path'],row['sha256']);require(row['native_closure_known'] is True and row['may_be_live'] is False and (row['status'],row['pid'],row['returncode'])==(native['status'],native['pid'],native['returncode']),'same actual native closure census')
 return dict(cargo=cargo,top=tops[0],routes=routes,probes=probes,dependencies=dependencies)


def verify_replay(item,setup_row,parent):
 ref=item['verification'];verified=pinned(ref);label=item['label'];directory=E/'replays'/label
 require(Path(ref['path'])==directory/'verification.json','owned replay proof')
 record=process(directory,{0});require(file(directory/'record.json')['sha256']==verified['record']['sha256'],'replay raw owner')
 require(record['parent_pid']==parent and record['command']==changed_output(setup_row['top']['forwarded_arguments'],W/'replays'/label),'only output path changed in genuine replay')
 require(record['cwd']==setup_row['top']['cwd'],'captured source working directory')
 require(jobserver_changed(setup_row['top']['forwarded_environment'],record['environment'])==verified['jobserver_substitution'],'exact recorded pipe substitution')
 transport(record['environment'],verified['jobserver_transport'])
 for field in ['wall_seconds','cpu_user_seconds','cpu_system_seconds']:
  original='elapsed_seconds' if field=='wall_seconds' else field
  require(item[field]==verified[field]==record[original],'raw-derived actual timing')
 require(verified['timed']==item['timed'] and verified['arm']==item['arm'] and verified['label']==label,'timed role/arm/label unchanged')
 verify_dependency(verified['dependency_proof'],record['command'],record['cwd'],item['arm'],False)
 require(str(W/'source'/PLAN['source_edit']['relative']) in verified['dependency_proof']['paths'],'edited production source used')
 values=[json.loads(s) for s in (directory/'stderr').read_text().splitlines()]
 require(all(v.get('$message_type') in ['diagnostic','artifact'] for v in values),'raw rustc message kinds')
 diagnostics=[v for v in values if v['$message_type']=='diagnostic'];require(all(v['level'] not in ['error','failure-note'] for v in diagnostics),'successful diagnostic semantics')
 require(diagnostics==verified['diagnostics'] and sha(normalized(diagnostics).encode())==item['normalized_diagnostics_sha256'],'complete paired diagnostics')
 require(record['stdout']['bytes']==0,'actual native stdout remains empty')
 return record


def verify(args):
 global PLAN,MANIFEST,OVERLAY
 require(not OUTPUT.exists(),'fresh independent readback output')
 invocation=read(ROOT/'.work/proc-macro-arena-ruff-screen-invocation-03.json',INVOCATION_SHA)
 MANIFEST=read(H/'source-manifest.json',MANIFEST_SHA);require(invocation['source_manifest_sha256']==MANIFEST_SHA,'actual exact source manifest')
 require(MANIFEST['policy']=='reviewed-Ruff-screen-source-v1' and set(MANIFEST['files'])=={'screen.py','common.py','rustc_capture.py','plan.json','registry-original.rs','registry-edited.rs'},'exact six source associations')
 for name,row in MANIFEST['files'].items():
  got=file(H/name);require((got['bytes'],got['sha256'])==(row['bytes'],row['sha256']),'unchanged exact source bytes')
 PLAN=read(H/'plan.json',MANIFEST['files']['plan.json']['sha256'])
 for state in ['original','edited']:
  ref=PLAN['source_edit'][state];require(file(ref['path'])['sha256']==ref['sha256'],'exact reviewed production states')
  raw=Path(ref['path']).read_bytes();require(sha(raw.split(PLAN['source_edit']['test_marker'].encode(),1)[1])==PLAN['source_edit']['tests_sha256'],'unchanged real test bodies in both states')
 summary=read(E/'execution.json',args.execution_sha256);result=read(E/'result.json',args.result_sha256)
 require(summary['status']==result['status']=='passed' and summary['parent_pid']==args.owner_pid,'actual successful screen03 owner')
 require(summary['invocation_sha256']==INVOCATION_SHA and summary['plan_sha256']==MANIFEST['files']['plan.json']['sha256'],'same actual plan/invocation')
 require(result['execution']==file(E/'execution.json'),'result binds exact closed execution')
 require(summary['started_at']<=summary['admitted_at']<=summary['finished_at']<=summary['parent_lock_closed_at'],'owner chronology')
 require(summary['signals']==[] and summary['retries']==0 and summary['application_tests_run'] is False and summary['full_workflow_qualified'] is False and summary['unchanged_retry_allowed'] is False,'screen scope unchanged')
 require(result['timed_calls']==36 and result['application_tests_run'] is False and result['full_workflow_qualified'] is False and result['sub_half_second_claim'] is False,'result scope unchanged')
 for previous in [PLAN['earlier_failed_predecessor'],PLAN['failed_predecessor']]:
  failure=pinned(previous['independent_readback']);failed=pinned(previous['execution'])
  require(failure['status']==previous['readback_status'] and failure['crate_compilations']==previous['crate_compilations'] and failure['timed_calls']==failure['source_edits']==0,'retain exact failed01 and02 scopes')
  require(failed['status']=='failed' and failed['samples']==failed['edits']==[] and failure['execution']['sha256']==previous['execution']['sha256'],'same unrewritten failed predecessor')
 require(invocation['policy']=='reviewed-passed-overlay-for-Ruff-screen-v1' and invocation['actual_success'] is True and set(invocation['overlay_proofs'])=={'result.json','execution.json','overlays-after.json','runtime-after.json'},'exact prior semantic proof inputs')
 prior_result=pinned(invocation['overlay_proofs']['result.json']);prior_execution=pinned(invocation['overlay_proofs']['execution.json']);prior_audit=pinned(invocation['overlay_independent_readback'])
 require(prior_result['status']=='passed' and prior_result['default_discovery_qualified'] is True and prior_result['execution_sha256']==invocation['overlay_proofs']['execution.json']['sha256'],'passed default-discovery result')
 require(prior_execution['status']=='passed' and prior_execution['children']==20 and prior_execution['canonical_released_at']>=prior_execution['finished_at'],'prior semantic owner closed')
 require(prior_audit['status']=='verified' and prior_audit['command_count']==20 and prior_audit['stable_caller_pairs']==9 and prior_audit['default_discovery_qualified'] is True,'independent same actual semantic prerequisite')
 require(prior_audit['result']==invocation['overlay_proofs']['result.json'] and prior_audit['execution']==invocation['overlay_proofs']['execution.json'] and invocation['overlay_independent_readback']==PLAN['overlay_independent_readback'] and prior_audit['result']['sha256']==PLAN['overlay_result_sha256'],'exact prerequisite associations')
 OVERLAY=pinned(invocation['overlay_proofs']['overlays-after.json']);runtime=pinned(invocation['overlay_proofs']['runtime-after.json'])
 for name,row in OVERLAY['entries'].items():
  require(stamp(name)==row['identity'],'complete overlay identity')
  if row['kind']=='file':require(file(name)=={k:row[k] for k in ['bytes','sha256','identity']},'complete own client/literal bytes')
  else:require(os.readlink(name)==row['target'] and str(Path(name).resolve(strict=True))==row['resolved'],'exact unchanged overlay alias')
 for name,row in OVERLAY['directories'].items():require(stamp(name)==row,'complete overlay membership unchanged')
 nr=Path(PLAN['compiler']).parent.parent
 for name,row in runtime['entries'].items():
  p=nr/name;require(stamp(p)==row['identity'],'complete N runtime identity')
  if row['kind']=='file':require(file(p)=={k:row[k] for k in ['bytes','sha256','identity']},'complete unchanged N bytes')
  else:require(os.readlink(p)==row['target'] and str(p.resolve(strict=True))==row['resolved'],'N alias unchanged')
 for name,row in runtime['directories'].items():require(stamp(nr/name)==row,'complete N membership')
 require(file(PLAN['cargo'])==invocation['cargo'],'actual installed Cargo bytes unchanged')
 configuration=read(E/'cargo-configurations.json')
 for name,row in configuration.items():
  if row is None:require(not os.path.lexists(name),'recorded absent Cargo configuration remains absent')
  else:require(file(name)==row,'exact passed Cargo configuration')
 setups={arm:setup(arm,summary['parent_pid']) for arm in ['stock','candidate']}
 require(setups[PLAN['setup_order'][0]]['cargo']['finished_at']<=setups[PLAN['setup_order'][1]]['cargo']['started_at'],'fixed sequential fresh setup order')
 left=sorted(normalized(r['forwarded_arguments']) for r in setups['stock']['routes'] if r['is_compile']);right=sorted(normalized(r['forwarded_arguments']) for r in setups['candidate']['routes'] if r['is_compile'])
 require(left==right,'same actual compile/profile/check vectors across arms')
 require(environment_parity(setups['stock']['top']['forwarded_environment'])==environment_parity(setups['candidate']['top']['forwarded_environment']),'top actual environments equal except declared arm paths and jobserver transport')
 require(sorted(normalized(p) for p in setups['stock']['probes'])==sorted(normalized(p) for p in setups['candidate']['probes']),'same actual capability inputs/outcomes')
 attempts={str(p) for p in (E/'wrapper-attempts').iterdir()};declared={r['attempt'] for s in setups.values() for r in s['routes']};require(attempts==declared,'no hidden wrapper refusal or attempt')
 for p in attempts:require(read(Path(p))['status']=='returned-native-exit','any wrapper refusal invalidates setup')
 require(len(summary['samples'])==36 and len(summary['warmups'])==len(summary['restorations'])==12 and len(summary['edits'])==12,'fixed finite protocol counts')
 table_refs=summary['retained_input_tables'];require(set(table_refs)=={'original_source','copied_source','cache_stock','cache_candidate','actual_compiler_inputs'},'complete five actual input tables');tables={k:table(v) for k,v in table_refs.items()}
 copied=tables['copied_source'];mutable=str(W/'source'/PLAN['source_edit']['relative']);last_end=max(s['cargo']['finished_at'] for s in setups.values());records={}
 require(set(tables['actual_compiler_inputs'])==(setups['stock']['dependencies']|setups['candidate']['dependencies'])-{mutable},'all actual compiler dependencies retained except separately observed mutable source')
 inventory=pinned(PLAN['source_inventory']);base=Path(PLAN['source_root']);expected_sources={str(base/name) for name in inventory}|{PLAN['historical_source_marker']['path']}
 require(set(tables['original_source'])==expected_sources and set(copied)=={str(W/'source'/Path(name).relative_to(base)) for name in expected_sources},'complete original and copied source tables')
 for relative,row in inventory.items():
  a=tables['original_source'][str(base/relative)];b=copied[str(W/'source'/relative)]
  if row['kind']=='file':require((a['bytes'],a['sha256'])==(b['bytes'],b['sha256'])==(row['bytes'],row['sha256']),'original acquisition and initial copy bytes')
  else:require(a['target']==b['target']==row['target'] and sha(a['target'].encode())==row['sha256'],'original acquisition and copied alias')
 for block in range(6):
  edit,restore=summary['edits'][2*block:2*block+2]
  for event,state in [(edit,'edited'),(restore,'original')]:
   require(event['path']==mutable and event['state']==state and event['row']['sha256']==PLAN['source_edit'][state]['sha256'],'exact actual production edit/restoration bytes')
  require(last_end<=edit['at']<restore['at'],'edit occurs only after preceding children close')
  samples=[x for x in summary['samples'] if x['block']==block];expected=[x for x in PLAN['schedule'] if x['block']==block]
  require([{k:x[k] for k in e} for x,e in zip(samples,expected)]==expected and len(samples)==6,'fixed chronological schedule')
  require(all(x['timed'] is True for x in samples),'exact fixed timed role')
  order=[x['arm'] for x in expected if x['kind']=='ab'][:2]
  group=[next(x for x in summary['warmups'] if x['label']==f'b{block}-warm-{arm}') for arm in order]+samples
  require(all(x['timed'] is False for x in group[:2]),'warmups explicitly outside sample set')
  for item in group:
   record=verify_replay(item,setups[item['arm']],summary['parent_pid']);require(max(last_end,edit['at'])<=record['started_at']<=record['finished_at']<=restore['at'],'warm/timed child while exact edit active');last_end=record['finished_at'];records[item['label']]=record
  for arm in reversed(order):
   item=next(x for x in summary['restorations'] if x['label']==f'b{block}-restored-{arm}');require(item['timed'] is False,'restoration outside timing');record=verify_replay(item,setups[arm],summary['parent_pid']);require(max(last_end,restore['at'])<=record['started_at'],'actual restoration precedes check');last_end=record['finished_at'];records[item['label']]=record
  copied[mutable]=restore['row']
 require(last_end<=summary['finished_at'] and len(records)==60,'all60 actual direct calls precede final owner close')
 require(set(records)=={p.name for p in (E/'replays').iterdir()}=={p.name for p in (W/'replays').iterdir()},'complete direct call membership')
 pairs=[]
 for pair in range(18):
  values=[x for x in summary['samples'] if x['pair']==pair];require(len(values)==2 and [x['position'] for x in values]==[0,1],'pair order')
  require(values[0]['normalized_diagnostics_sha256']==values[1]['normalized_diagnostics_sha256'],'paired checks/diagnostics unchanged')
  if values[0]['kind']=='aa':ratio=values[1]['wall_seconds']/values[0]['wall_seconds']
  else:ratio=next(x['wall_seconds'] for x in values if x['arm']=='candidate')/next(x['wall_seconds'] for x in values if x['arm']=='stock')
  pairs.append(dict(pair=pair,kind=values[0]['kind'],ratio=ratio))
 median=statistics.median(x['ratio'] for x in pairs if x['kind']=='ab');noise=max(abs(x['ratio']-1) for x in pairs if x['kind']=='aa');decision='screen-gain-exceeds-AA-noise' if 1-median>noise else 'park-allocator-performance-path'
 for obj in [summary,result]:require(obj['pairs']==pairs and obj['median_candidate_stock_ratio']==median and obj['max_absolute_AA_variation']==noise and obj['decision']==decision,'independently recomputed fixed screen decision')
 for rows in tables.values():current_rows(rows)
 for source in [base,W/'source']:
  if source==base:continue # Acquisition table defines canonical scope; unrelated canonical files are not owned.
  actual=set()
  for directory,dirs,files in os.walk(source,followlinks=False):
   for name in dirs+files:
    p=Path(directory)/name
    if not p.is_dir() or p.is_symlink():actual.add(str(p))
  require(actual==set(copied),'complete owned source membership')
 for arm in ['stock','candidate']:
  actual=set()
  for directory,dirs,files in os.walk(W/'target'/arm,followlinks=False):
   for name in dirs:require((Path(directory)/name).resolve(strict=True)==Path(directory)/name,'ordinary cache directory')
   actual.update(str(Path(directory)/name) for name in files)
  require(actual==set(tables['cache_'+arm]),'complete fresh cache membership')
 for ref in [*PLAN['probe_source_references'],*PLAN['probe_sources'].values()]:require(file(ref['path'])['sha256']==ref['sha256'],'current pinned probe sources')
 # Bind all closed output bytes, including every failure/raw stream and table part.
 closed={};total=0
 for directory,dirs,files in os.walk(E,followlinks=False):
  for name in dirs:require((Path(directory)/name).resolve(strict=True)==Path(directory)/name,'ordinary evidence directory')
  for name in files:
   p=Path(directory)/name;closed[str(p.relative_to(E))]=file(p);total+=p.stat().st_size;require(len(closed)<=70000 and total<=4*2**30,'finite complete evidence tree')
 for name,row in CHECKED.items():require(stamp(name)==row['identity'],'current input changed during independent readback')
 return dict(status='verified-native-frontend-screen',execution=dict(path=str(E/'execution.json'),sha256=args.execution_sha256),result=dict(path=str(E/'result.json'),sha256=args.result_sha256),invocation_sha256=INVOCATION_SHA,source_manifest_sha256=MANIFEST_SHA,
  timed_calls=36,warm_calls=12,restoration_calls=12,actual_setup_calls={a:len(s['routes']) for a,s in setups.items()},all_attempts_retained=len(attempts),pairs=pairs,median_candidate_stock_ratio=median,max_absolute_AA_variation=noise,decision=decision,
  all_samples=summary['samples'],warmups=summary['warmups'],restorations=summary['restorations'],setup={a:dict(record=dict(path=str(E/('cargo-'+a)/'record.json'),**file(E/('cargo-'+a)/'record.json')),wall_seconds=s['cargo']['elapsed_seconds'],cpu_user_seconds=s['cargo']['cpu_user_seconds'],cpu_system_seconds=s['cargo']['cpu_system_seconds'],compiler_calls=len(s['routes'])) for a,s in setups.items()},
  timing_scope='Actual blocking wait4 interval includes process spawn/reap and concurrent parent observer I/O; pre/post validation lies outside. Same observer applies to both arms.',
  input_tables=table_refs,checked_files=len(CHECKED),checked_file_rows_sha256=sha(canonical(CHECKED)),complete_evidence_files=len(closed),complete_evidence_bytes=total,complete_evidence_table_sha256=sha(canonical(closed)),full_payload_bytes_read=READ_BYTES,
  failed_predecessor_readbacks=[PLAN['earlier_failed_predecessor']['independent_readback'],PLAN['failed_predecessor']['independent_readback']],application_tests_run=False,full_workflow_qualified=False,holdout_qualified=False,sub_half_second_claim=False,no_retries_or_new_compiler_calls=True)

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--execution-sha256',required=True);parser.add_argument('--result-sha256',required=True);parser.add_argument('--owner-pid',type=int,required=True);args=parser.parse_args()
 require(all(re.fullmatch('[0-9a-f]{64}',x) for x in [args.execution_sha256,args.result_sha256]),'actual closed proof SHAs required');require(args.owner_pid>1,'actual root-observed closed owner PID required')
 started=time.time()
 with LOCK.open('r+') as lock:
  deadline=time.monotonic()+600
  while True:
   try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
   except BlockingIOError:require(time.monotonic()<deadline,'bounded independent admission wait');time.sleep(.25)
  admitted=time.time();report=verify(args)
 released=time.time();report.update(started_at=started,admitted_at=admitted,canonical_parent_lock_closed_at=released,finished_at=time.time(),parent_pid=os.getpid(),reader_source=dict(path=str(Path(__file__).absolute()),**file(Path(__file__).absolute())))
 payload=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();require(len(payload)<=2**20,'bounded concise readback result')
 with OUTPUT.open('xb') as stream:stream.write(payload)
 print(str(OUTPUT));print(hashlib.sha256(payload).hexdigest())
