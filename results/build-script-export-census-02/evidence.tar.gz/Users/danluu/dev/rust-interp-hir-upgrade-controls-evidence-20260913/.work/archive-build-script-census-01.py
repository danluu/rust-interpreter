#!/usr/bin/env python3
"""Retain two metadata plans and four actual compiler-only support observations."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import time

ROOT=Path('/Users/danluu/dev/rust-interp-hir-upgrade-controls-evidence-20260913')
WORK=ROOT/'.work/build-script-census-archive-01'
OUTPUT=ROOT/'results/build-script-export-census-02'
SOURCE=ROOT/'.work/census-build-script-export-02.py'
SOURCE_SHA='e4c18bb4157963b209f9fbb664a2e1068740d907140be461b5c4ff7f3de1a146'
PLAN_SHA='cb70041ada99117cb9b8f08e476347b2fbadaf3317ba4dbbd6bb22c034164587'
RUN_SHA='a990a468a3927d180aff522dc06ac69fde49e6087b34bbf88e573265f3e4fa52'
OLD=ROOT/'.work/build-script-export-census-01'
CURRENT=ROOT/'.work/build-script-export-census-02'
TERMINALS=[(OLD/'plan/receipt.json','1a3f2c748700e46a77062662ee03e1970c4ef74735e181ff66af76a8d35c5469','plan',1),
    (CURRENT/'plan/receipt.json','9abb5188b7ffdf06bbaa48c0c4562dc7c05f165cd448a1735a496f939015fa87','plan',2),
    (CURRENT/'run/receipt.json',RUN_SHA,'run',2)]

def digest(data):return hashlib.sha256(data).hexdigest()
if digest(SOURCE.read_bytes())!=SOURCE_SHA:raise RuntimeError('frozen census helper changed')
spec=importlib.util.spec_from_file_location('census_for_archival',SOURCE)
c=importlib.util.module_from_spec(spec);sys.modules[spec.name]=c;spec.loader.exec_module(c)
q=c.q
require,sha,write=c.require,c.sha,c.write

def main():
    WORK.mkdir(exist_ok=False)
    receipt=dict(status='waiting',owner=str(ROOT),pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),
        canonical_lock=str(q.owned.CANONICAL_LOCK),wait_seconds=600,compiler_or_test_commands=0,helper_sha256=sha(Path(__file__)))
    write(WORK/'receipt.json',receipt)
    try:
        with q.owned.workload_lock(q.owned.CANONICAL_LOCK,600):
            receipt.update(admitted_at=time.time(),status='archiving',free_bytes_before=q.owned.disk(ROOT));write(WORK/'receipt.json',receipt)
            selected={}
            def add(path,expected=None):
                path=c.ordinary(path);data=path.read_bytes();row=dict(source=str(path),sha256=digest(data),bytes=len(data))
                require(expected is None or row['sha256']==expected,'archive input changed: '+str(path))
                require(str(path) not in selected or selected[str(path)]==row,'archive input changed between reads')
                selected[str(path)]=row;return data
            def tree(path):
                for path in q.files(path):add(path)
            plan=json.loads(add(CURRENT/'plan.json',PLAN_SHA));run=json.loads(add(CURRENT/'run/receipt.json',RUN_SHA))
            require(run['status']=='passed' and run['compiler_commands']==4 and run['main_audits']==3
                and run['plan_sha256']==PLAN_SHA and run['guest_executions']==run['native_build_script_executions']==0
                and not run['performance_claim'] and len(run['commands'])==4,'actual census scope differs')
            require(plan['commands']==c.command_plan() and plan['configuration']==c.configuration()
                and plan['built_source_policy']=='complete-archived-qualified-sources-v1','frozen census recipe differs')
            require(not (OLD/'run').exists() and not (OLD/'fixture').exists(),'old metadata-only history was executed')
            for path,expected,stage,attempt in TERMINALS:
                row=json.loads(add(path,expected))
                require(row['status']==('planned' if stage=='plan' else 'passed')
                    and row['stage']==stage and row['owner']==str(ROOT),'terminal history changed')
                if stage=='plan':
                    require(row['commands']==[],'metadata history contains a child')
                    base=path.parent.parent;add(base/'plan.json',row['plan_sha256'])
                    index=json.loads(add(base/'plan/source-snapshots.json',row['snapshot_index_sha256']))
                    require(len(index)==(21 if attempt==1 else 224),'snapshot inventory cardinality differs')
                    for snapshot in index.values():
                        data=add(snapshot['snapshot'],snapshot['sha256']);require(len(data)==snapshot['bytes'],'snapshot size differs')
                outer=ROOT/'.work/experiments'/f'build-script-export-census-{stage}-supervisor-{attempt:02d}'
                status=json.loads(add(outer/'status.json'))
                require(status['status']=='finished' and status['returncode']==0 and status['child_pid']==row['pid']
                    and status['supervisor_pid']==row['parent_pid'] and status['started_at']<=row['started_at']
                    and row['finished_at']<=status['finished_at'],'actual supervisor association differs')
                add(outer/'plan.json',status['plan_sha256']);add(outer/'command.log',status['log_sha256']);add(outer/'supervisor.log')
            for i,ref in enumerate(run['commands']):
                path=Path(ref['path']);child=json.loads(add(path,ref['sha256']));expected=plan['commands'][i]
                require(path==CURRENT/'run/commands'/f'{i:03d}'/'receipt.json' and child['command']==expected['command']
                    and child['cwd']==expected['cwd'] and child['environment']==expected['environment']
                    and child['returncode']==0 and child['status']=='finished' and child['supervisor_pid']==run['pid']
                    and run['admitted_at']<=child['started_at']<=child['finished_at']<=run['finished_at'],'compiler child differs')
                for stream in ['stdout','stderr']:add(path.parent/stream,child[stream+'_sha256'])
            observations=json.loads(add(CURRENT/'run/observations.json',run['observations_sha256']))
            require([r['configuration'] for r in observations]==[name for name,_ in c.MODES],'audit configuration set differs')
            for i,row in enumerate(observations,start=1):
                report=Path(row['report']);data=add(report,row['sha256']);result=json.loads(data)
                child=json.loads(Path(run['commands'][i]['path']).read_bytes())
                require(row['result']==result and row['actual_compiler_child']==child['pid']
                    and row['child_receipt_sha256']==run['commands'][i]['sha256']
                    and result['kind']=='lowering-audit' and result['strict_frontend'] is True and result['executed'] is False
                    and result['requested']==result['blocked']==1 and result['lowered']==0
                    and result['entries'][0]['entry']=='main' and result['entries'][0]['status']=='blocked'
                    and result['entries'][0]['error']=='libc::unix::getcwd: MIR unavailable for libc::unix::getcwd',
                    'retained first blocker differs')
                require(add(report.parent/'metadata.rmeta.audit.json')==data,'audit sidecar differs')
            artifacts=json.loads(add(CURRENT/'run/artifacts.json',run['artifacts_sha256']))
            add(CURRENT/'helper/libibs_fixture_helper.rmeta',run['helper_metadata_sha256'])
            prior=c.load_prerequisites()
            require(prior['live_helpers']==plan['live_helpers'],'executing Python helper identity differs')
            def guard():
                require(c.configuration()==plan['configuration'],'census configuration changed')
                q.guard_records(prior['records']+artifacts,full=True)
                require(c.imported_paths()==prior['imported_paths'],'executing Python closure changed')
                require(q.std_proof(prior['qualified_plan']['versions']['rustc'])==prior['qualified_plan']['std'],'std changed')
                for root in [c.FIXTURE,c.COPIED]:
                    require({str(p.relative_to(root)):sha(p) for p in q.files(root)}==plan['fixture'],'fixture changed')
                for value in list(prior['qualified_plan']['closures'].values())+list(prior['tools']['closures'].values()):
                    require(q.loaders.library_state(value['identity'])==value['state'],'loader closure changed')
                for ref in c.ARCHIVES.values():
                    for key,name in [('archive','evidence.tar.gz'),('manifest','manifest.json'),('summary','summary.json')]:
                        require(sha(Path(ref['root'])/name)==ref[key],'qualified archive reference changed')
                for row in selected.values():require(sha(row['source'])==row['sha256'],'selected archive input changed')
                q.owned.disk(ROOT)
            for root in [OLD,CURRENT]:tree(root)
            for attempt in [1,2]:
                add(ROOT/'.work'/f'census-build-script-export-{attempt:02d}.py',
                    'ded5c202791bb46428c592b51e899e5465b3d19bef239bd99db39bd8dcde61eb' if attempt==1 else SOURCE_SHA)
                add(ROOT/'.work'/f'build-script-export-census-{attempt:02d}-review.json')
                for stage in (['plan'] if attempt==1 else ['plan','run']):
                    # Initial launcher stdout was not separately saved; its actual supervisor receipt is retained.
                    for suffix in (['.json'] if attempt==1 else ['.json','-result.json']):add(ROOT/'.work'/f'build-script-export-census-{stage}-launch-{attempt:02d}{suffix}')
            for p in [Path(__file__),ROOT/'scripts/supervise_experiment.py',*prior['own_sources']]:add(p)
            for row in prior['live_helpers']:add(row['path'],row['sha256'])
            for ref in c.ARCHIVES.values():
                for name in ['manifest.json','summary.json']:add(Path(ref['root'])/name)
            guard();OUTPUT.mkdir(parents=True,exist_ok=False)
            archive=OUTPUT/'evidence.tar.gz';manifest={};first={}
            with tarfile.open(archive,'w:gz',compresslevel=6) as bundle:
                for name,row in sorted(selected.items()):
                    data=Path(name).read_bytes();require(digest(data)==row['sha256'],'input changed during compression');q.owned.disk(ROOT)
                    member=name.lstrip('/');info=tarfile.TarInfo(member);info.mode=0o600;info.mtime=0;key=(row['sha256'],row['bytes'])
                    if key in first:info.type=tarfile.LNKTYPE;info.linkname=first[key];bundle.addfile(info)
                    else:info.size=len(data);bundle.addfile(info,io.BytesIO(data));first[key]=member
                    manifest[member]=row
            seen=set()
            with tarfile.open(archive,'r:gz') as bundle:
                for member in bundle:
                    require(member.name in manifest and member.name not in seen and (member.isfile() or member.islnk()),'archive membership differs')
                    stream=bundle.extractfile(member);require(stream is not None,'missing archive bytes')
                    with stream:data=stream.read()
                    expected=manifest[member.name];require(digest(data)==expected['sha256'] and len(data)==expected['bytes'],'archive readback differs');seen.add(member.name)
            require(seen==set(manifest),'archive incomplete');guard();write(OUTPUT/'manifest.json',manifest)
            summary=dict(status='passed',plan_sha256=PLAN_SHA,run_receipt_sha256=RUN_SHA,metadata_children=[0,0],compiler_children=4,
                audits=observations,guest_executions=0,native_build_script_executions=0,performance_claim=False,
                scope='First strict lowering blocker per configuration; later support unknown',qualified_archive_references=c.ARCHIVES,
                actual_binaries=plan['actual_binaries'],source_checkpoint=c.SOURCE,snapshots=[21,224],
                archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,archive_members=len(manifest),physical_members=len(first),
                all_member_hashes_verified=True,all_current_runtime_helper_std_fixture_guards_passed=True)
            write(OUTPUT/'summary.json',summary)
            receipt.update(status='passed',finished_at=time.time(),archive_sha256=summary['archive_sha256'],archive_members=len(manifest),free_bytes_after=q.owned.disk(ROOT))
            write(WORK/'receipt.json',receipt);write(OUTPUT/'archive-receipt.json',receipt);print(json.dumps(summary,sort_keys=True))
    except BaseException as error:
        receipt.update(status='failed',error=repr(error),finished_at=time.time());write(WORK/'receipt.json',receipt);raise

if __name__=='__main__':main()
