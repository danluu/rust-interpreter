#!/usr/bin/env python3
import gzip,hashlib,io,json,os,re,sys,tarfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
UP=Path('/Users/danluu/dev/rust-interp-hir-diagnostic-native-20260913')
RAW=UP/'.work/hir-diagnostic-native-controls-01'
SUP=UP/'.work/experiments/hir-diagnostic-native-controls-supervisor-01'
OUT=ROOT/'results/hir-diagnostic-native-controls-01'
WORK=ROOT/'.work/hir-diagnostic-native-controls-archive-01'
sys.path.insert(0,str(ROOT/'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK,disk,require,sha,workload_lock,write

def digest(data):return hashlib.sha256(data).hexdigest()
def main():
 WORK.mkdir(parents=True,exist_ok=False)
 r=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),canonical_lock=str(CANONICAL_LOCK),lock_wait_seconds=600)
 write(WORK/'summary.json',r)
 try:
  with workload_lock(CANONICAL_LOCK,600):
   r.update(status='running',admitted_at=time.time(),free_bytes_before=disk(ROOT));write(WORK/'summary.json',r)
   payloads={}
   def capture(path,expected=None):
    p=Path(path);require(p.is_absolute() and p.resolve(strict=True)==p and p.is_file() and not p.is_symlink(),'nonordinary evidence')
    data=p.read_bytes();require(expected is None or digest(data)==expected,'source changed: '+str(p))
    require(str(p) not in payloads or payloads[str(p)]==data,'changed during capture');payloads[str(p)]=data;return data
   test=json.loads(capture(RAW/'summary.json'))
   require(test['status']=='passed' and test['expected_controls']==5 and test['all_inputs_unchanged'] and len(test['inputs'])==39
           and test['source_revision']=='e90f6e9978863099eebf324ec91362309f6665c0','wrong control history')
   references=[]
   for path,expected in test['inputs'].items():
    snap=test['snapshots'][path]
    if snap.get('archive_reference'):
     require(sha(path)==expected==snap['sha256'],'historical archive changed')
     base=Path(path).parent;manifest=json.loads(capture(base/'manifest.json',test['inputs'][str(base/'manifest.json')]))
     summary=json.loads(capture(base/'summary.json',test['inputs'][str(base/'summary.json')]))
     require(summary['archive']['sha256']==expected,'reference summary association changed')
     seen=set()
     with tarfile.open(path,'r:gz') as tar:
      for member in tar:
       require(member.isfile() and member.name not in seen and member.name in manifest,'invalid reference member')
       seen.add(member.name);data=tar.extractfile(member).read();m=manifest[member.name]
       require(member.name==m['source'].lstrip('/') and len(data)==m['bytes'] and digest(data)==m['sha256'],'reference member changed')
     require(seen==set(manifest),'reference incomplete')
     references.append(dict(path=path,sha256=expected,members=len(seen),all_members_verified=True))
    else:
     data=capture(path,expected);require(capture(snap['path'],expected)==data and len(data)==snap['bytes'],'snapshot changed')
   child=json.loads(capture(RAW/'command/receipt.json',test['command_receipt_sha256']))
   require(child['returncode']==0 and child['status']=='finished' and child['cwd']==str(UP)
           and child['command'][1:]==['-B','-m','unittest','discover','-s','tests','-p','test_hir_diagnostic_native.py','-v'],'wrong test child')
   stderr=capture(RAW/'command/stderr',child['stderr_sha256']).decode();capture(RAW/'command/stdout',child['stdout_sha256'])
   require(len(re.findall(r'^test_[^\n]+ \.\.\. ok$',stderr,re.M))==5 and re.search(r'^Ran 5 tests in [0-9.]+s$',stderr,re.M)
           and stderr.rstrip().endswith('OK'),'five successes required')
   supervisor=json.loads(capture(SUP/'status.json'))
   require(supervisor['status']=='finished' and supervisor['returncode']==0 and supervisor['child_pid']==test['pid'],'supervisor mismatch')
   capture(SUP/'plan.json',supervisor['plan_sha256']);capture(SUP/'command.log',supervisor['log_sha256']);capture(SUP/'supervisor.log')
   for path in [Path(__file__),ROOT/'experiments/stable-cgu/owned_stage.py',ROOT/'scripts/supervise_experiment.py']:capture(path)
   OUT.mkdir(parents=True,exist_ok=False);archive=OUT/'evidence.tar.gz';manifest={}
   with archive.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
     with tarfile.open(fileobj=gz,mode='w') as tar:
      for source,data in sorted(payloads.items()):
       disk(ROOT);name=source.lstrip('/');m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o644;tar.addfile(m,io.BytesIO(data))
       manifest[name]=dict(source=source,bytes=len(data),sha256=digest(data))
   seen=set()
   with tarfile.open(archive,'r:gz') as tar:
    for m in tar:
     require(m.isfile() and m.name not in seen and m.name in manifest,'invalid archive member');seen.add(m.name)
     data=tar.extractfile(m).read();item=manifest[m.name];require(len(data)==item['bytes'] and digest(data)==item['sha256'],'archive readback differs')
   require(seen==set(manifest) and all(Path(p).read_bytes()==b for p,b in payloads.items()),'archive or input changed')
   require(all(sha(ref['path'])==ref['sha256'] for ref in references),'reference changed after readback')
   write(OUT/'manifest.json',manifest)
   summary=dict(status='passed',schema_version=1,source_revision=test['source_revision'],controls=5,skipped=0,
    test_pid=child['pid'],helper_pid=test['pid'],supervisor_pid=supervisor['supervisor_pid'],raw=str(RAW),supervisor=str(SUP),
    inputs=test['inputs'],all_39_inputs_unchanged=True,historical_archive_references=references,
    scope='five Python controls only; no compiler/source mutation/native hit or performance qualification',
    archive=dict(path=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(manifest),all_member_hashes_verified=True),manifest_sha256=sha(OUT/'manifest.json'))
   write(OUT/'summary.json',summary)
   (OUT/'README.md').write_text('# Diagnostic-native source controls\n\nAll five Python controls passed without skips at `e90f6e99` (0.027 seconds). They verify exact phase-report grammar, diagnostic-only outcomes, unchanged build/probe/capture and capacity contracts, required successful check/unit history, and separate predecessor archive references. No compiler or native execution ran as part of these controls.\n\nThe archive preserves the exact raw command and supervisor receipts plus 36 source snapshots. All 39 inputs remained unchanged; three earlier archive payloads remain separately verified references. Every new and referenced archive member was read back and hash checked.\n')
   r.update(status='passed',finished_at=time.time(),result=str(OUT),archive=summary['archive'],summary_sha256=sha(OUT/'summary.json'),free_bytes_after=disk(ROOT));write(WORK/'summary.json',r)
 except BaseException as e:
  r.update(status='failed',finished_at=time.time(),error=repr(e));write(WORK/'summary.json',r);raise
if __name__=='__main__':main()
