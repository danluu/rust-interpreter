#!/usr/bin/env python3
"""Supervise only the committed diagnostic-native Python controls."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / '.work/hir-diagnostic-native-controls-01'
TEST = ROOT / 'tests/test_hir_diagnostic_native.py'
DRIVER = ROOT / 'experiments/hir-diagnostic-native/check.py'
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, disk, require, run, sha, workload_lock, write


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--source-revision', required=True)
    parser.add_argument('--expected-controls', type=int, required=True)
    args = parser.parse_args()
    require(re.fullmatch('[0-9a-f]{40}', args.source_revision) and args.expected_controls > 0,
            'explicit final source revision and control count required')
    WORK.mkdir(parents=True, exist_ok=False)
    record = dict(status='waiting', started_at=time.time(), pid=os.getpid(), parent_pid=os.getppid(),
        canonical_lock=str(CANONICAL_LOCK), lock_wait_seconds=600,
        expected_source_revision=args.source_revision, expected_controls=args.expected_controls)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            source_revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
            require(source_revision == args.source_revision, 'author source revision changed before control admission')
            require(subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--'], cwd=ROOT).returncode == 0,
                    'tracked author source changed before control admission')
            spec = importlib.util.spec_from_file_location('diagnostic_control_source', DRIVER)
            driver = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = driver
            spec.loader.exec_module(driver)
            frozen = driver.inputs() | driver.old.frozen_plan()['inputs'] | {str(Path(__file__).resolve()): sha(Path(__file__))}
            tracked = [str(Path(p).relative_to(ROOT)) for p in frozen
                       if Path(p).is_relative_to(ROOT) and not Path(p).is_relative_to(ROOT / '.work')]
            subprocess.run(['git', 'ls-files', '--error-unmatch', '--', *tracked], cwd=ROOT,
                           check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            tree = ast.parse(TEST.read_bytes(), filename=str(TEST))
            names = sorted('test_hir_diagnostic_native.' + cls.name + '.' + method.name
                for cls in tree.body if isinstance(cls, ast.ClassDef)
                for method in cls.body if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef))
                and method.name.startswith('test_'))
            require(len(names) == len(set(names)) == args.expected_controls,
                    'author committed test definitions differ from the reviewed count')
            snapshots = {}
            for source, expected in frozen.items():
                path = Path(source)
                require(path.is_absolute() and path.resolve(strict=True) == path and path.is_file()
                        and not path.is_symlink(), 'nonordinary frozen control input')
                if path.name.endswith('.tar.gz'):
                    require(sha(path) == expected, 'referenced archive changed')
                    snapshots[source] = dict(sha256=expected, archive_reference=True)
                    continue
                data = path.read_bytes()
                require(hashlib.sha256(data).hexdigest() == expected, 'source changed during snapshot')
                target = WORK / 'sources' / source.lstrip('/')
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as output:
                    output.write(data)
                snapshots[source] = dict(path=str(target), sha256=expected, bytes=len(data))
            record.update(source_revision=source_revision, inputs=frozen, snapshots=snapshots, required_tests=names)
            write(WORK / 'summary.json', record)
            environment = {k: v for k, v in os.environ.items() if k in
                ['PATH', 'HOME', 'USER', 'LOGNAME', 'TMPDIR', 'LANG', 'LC_ALL', 'LC_CTYPE', 'SYSTEMROOT']}
            environment['PYTHONDONTWRITEBYTECODE'] = '1'
            command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests',
                       '-p', 'test_hir_diagnostic_native.py', '-v']
            try:
                run(command, cwd=ROOT, env=environment, out=WORK / 'command', capacity_root=ROOT)
            finally:
                unchanged = all(sha(path) == expected for path, expected in frozen.items())
                record['all_inputs_unchanged'] = unchanged
                if (WORK / 'command/receipt.json').exists():
                    record['command_receipt_sha256'] = sha(WORK / 'command/receipt.json')
                write(WORK / 'summary.json', record)
                require(unchanged, 'frozen control source changed during test execution')
            output = (WORK / 'command/stderr').read_text()
            actual = re.findall(r'^test_[^\n]* \(([^)]+)\) \.\.\. ok$', output, re.M)
            require(sorted(actual) == names and re.search(
                r'^Ran ' + str(args.expected_controls) + r' tests in [0-9.]+s$', output, re.M)
                and output.rstrip().endswith('OK'), 'exact passing test identities without skips required')
            record.update(status='passed', finished_at=time.time(), free_bytes_after=disk(ROOT),
                          actual_tests=actual, compiler_commands=0, source_mutations=0)
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
