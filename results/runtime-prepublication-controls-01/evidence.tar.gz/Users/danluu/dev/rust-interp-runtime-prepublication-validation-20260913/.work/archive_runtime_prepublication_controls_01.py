#!/usr/bin/env python3
"""Retain completed compiler-policy controls using the existing tar route."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time

ROOT = Path('/Users/danluu/dev/rust-interp-runtime-prepublication-validation-20260913')
RAW = ROOT / '.work/runtime-prepublication-controls-01'
SUPERVISOR = ROOT / '.work/experiments/runtime-prepublication-controls-supervisor-01'
LAUNCH = ROOT / '.work/runtime-prepublication-controls-launch-01.json'
OUT = ROOT / 'results/runtime-prepublication-controls-01'
WORK = ROOT / '.work/runtime-prepublication-controls-archive-01'
OWNED = ROOT / 'experiments/stable-cgu/owned_stage.py'
EXPECTED_SUMMARY = '672a3710cf67d7665c6f55b5a6b442c50d24c5c9fea0df93c1b7eb985d5e1192'
EXPECTED_CHILD = '50a819e4b240603098ebdabb4f3445eeedace671c2e9852d67d0f10363a40b3e'
REVISION = 'c466a7abfb6d36d53aea9dc87c9c145164f9feee'


def digest(data):
    return hashlib.sha256(data).hexdigest()


assert digest(OWNED.read_bytes()) == '7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e'
sys.path.insert(0, str(OWNED.parent))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--helper-sha', required=True)
    args = parser.parse_args()
    require(sys.dont_write_bytecode and not sys.flags.optimize and Path.cwd() == ROOT,
            'fixed cwd and Python -B required')
    require(Path(__file__).resolve() == ROOT / '.work/archive_runtime_prepublication_controls_01.py'
            and sha(__file__) == args.helper_sha, 'reviewed archive source changed')
    WORK.mkdir(exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(),
                  started_at=time.time(), helper_sha256=args.helper_sha,
                  lock=str(CANONICAL_LOCK), lock_wait_seconds=600)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            payloads = {}

            def capture(path, expected=None):
                path = Path(path)
                require(path.is_absolute() and path.resolve(strict=True) == path
                        and path.is_file() and not path.is_symlink(), 'nonordinary evidence path')
                data = path.read_bytes()
                require(expected is None or digest(data) == expected, 'evidence source changed: ' + str(path))
                if str(path) in payloads:
                    require(payloads[str(path)] == data, 'evidence changed during capture')
                payloads[str(path)] = data
                return data

            test = json.loads(capture(RAW / 'summary.json', EXPECTED_SUMMARY))
            require(test['status'] == 'passed' and test['base_commit'] == REVISION
                    and test['source_commit'] == 'a05f4e4f05858cd343261706f5eb579edb54c872'
                    and test['source_patch_sha256'] == 'f6cf94c53b17309b3b205a46731d1f6845f4dc04cbcd514c6da0caa20171d749'
                    and test['source_files'] == 37 and len(test['sources']) == 77
                    and test['all_inputs_unchanged'] and test['command_receipt_sha256'] == EXPECTED_CHILD
                    and test['real_archive_reads'] == test['real_compiler_input_reads'] == 0
                    and test['compiler_commands'] == 0 and not test['real_compiler_or_sysroot_inspected']
                    and test['production_policy_modules_imported_by_tests']
                    and test['synthetic_installations_exercised'],
                    'exact passing synthetic compiler-policy history required')
            for path, expected in test['sources'].items():
                capture(path, expected)
            for path, row in test['snapshots'].items():
                require(row['sha256'] == test['sources'][path], 'test snapshot association differs')
                require(len(capture(row['path'], row['sha256'])) == row['bytes'], 'snapshot size differs')
            require(set(test['snapshots']) == set(test['sources']), 'test source snapshots incomplete')
            child = json.loads(capture(RAW / 'command/receipt.json', EXPECTED_CHILD))
            require(child['status'] == 'finished' and child['returncode'] == 0
                    and child['cwd'] == test['command_cwd'] == str(ROOT / 'tests') and child['command'] == test['command']
                    and child['environment'] == test['environment'] and child['supervisor_pid'] == test['pid']
                    and child['parent_pid'] == test['parent_pid']
                    and test['admitted_at'] <= child['started_at'] <= child['finished_at'] <= test['finished_at'],
                    'completed test command/environment/process association differs')
            require(not capture(RAW / 'command/stdout', child['stdout_sha256']), 'unexpected test stdout')
            stderr = capture(RAW / 'command/stderr', child['stderr_sha256']).decode()
            actual = re.findall(r'^test_[^\n]* \((test_(?:custom_compiler|runtime_compiler|std_mir_source_paths)\.[^)]+)\) \.\.\. ok$', stderr, re.M)
            require(len(actual) == 51 and actual == test['actual_tests'] == test['required_tests']
                    and re.search(r'^Ran 51 tests in [0-9.]+s$', stderr, re.M)
                    and stderr.rstrip().endswith('OK') and 'skipped' not in stderr,
                    '51 actual unfiltered passing names required')
            outer = json.loads(capture(SUPERVISOR / 'status.json', '6bdc1fc93061e0957890b075b6c2d2766fad212ebfb0a70af2cd33e2cec65f41'))
            plan = json.loads(capture(SUPERVISOR / 'plan.json', outer['plan_sha256']))
            require(outer['status'] == 'finished' and outer['returncode'] == 0
                    and outer['child_pid'] == test['pid'] and outer['supervisor_pid'] == test['parent_pid']
                    and outer['started_at'] <= test['started_at'] <= test['finished_at'] <= outer['finished_at']
                    and outer['command'] == plan['command'] and outer['cwd'] == plan['owner'] == str(ROOT),
                    'outer supervisor association differs')
            capture(SUPERVISOR / 'command.log', outer['log_sha256'])
            capture(SUPERVISOR / 'supervisor.log')
            launch = json.loads(capture(LAUNCH, 'a0e337cafbbf39d2b6f4b9c9aa830f024d9ad857d6ccb256ad306bfcbf647b14'))
            admission = json.loads(capture(launch['admission'], launch['admission_sha256']))
            require(plan['command'] == launch['command'][launch['command'].index('--') + 1:]
                    and admission['helper_sha256'] == test['helper_sha256']
                    and launch['admission_sha256'] == test['admission_sha256']
                    and admission['source_freeze_sha256'] == test['source_freeze_sha256'],
                    'saved launch/admission/helper association differs')
            for suffix in ('.stdout', '.stderr'):
                capture(LAUNCH.with_suffix(suffix))
            execution = json.loads(capture(ROOT / '.work/runtime-prepublication-controls-launch-execution-01.json', '0b466375eae6f4a4c21f8677503d221c6d88257050d714190535fac98597cd3f'))
            require(execution['launcher_returncode'] == 0 and execution['argv'] == launch['command']
                    and execution['environment'] == launch['environment'] and execution['cwd'] == str(ROOT)
                    and execution['supervisor_admission']['supervisor_pid'] == outer['supervisor_pid']
                    and execution['launch_sha256'] == digest(capture(LAUNCH))
                    and execution['started_at'] <= outer['started_at'], 'actual control launch association differs')
            capture(LAUNCH.with_suffix('.stdout'), execution['stdout_sha256'])
            capture(LAUNCH.with_suffix('.stderr'), execution['stderr_sha256'])
            verified = json.loads(capture(ROOT / '.work/runtime-prepublication-controls-independent-verification-01.json', 'ff04d9f0fe8d952688b54eee90c96b6a49f10b7662452acc9ad9147515e516a3'))
            require(verified['status'] == 'passed' and verified['verified_tests'] == 51
                    and verified['summary_sha256'] == EXPECTED_SUMMARY and verified['command_receipt_sha256'] == EXPECTED_CHILD
                    and verified['test_pid'] == child['pid'] and verified['helper_pid'] == test['pid']
                    and verified['supervisor_pid'] == outer['supervisor_pid'], 'independent verification association differs')
            readme = capture(ROOT / '.work/runtime-prepublication-controls-archive-README-01.md',
                '37fa5f2d34b90bec69eb4f47e6ec0a5fc1555a6cdd0e46dff058629758c4851f')
            for path in [Path(__file__), ROOT / '.work/runtime-prepublication-controls-archive-launch-01.json']:
                capture(path)
            OUT.mkdir(parents=True, exist_ok=False)
            archive = OUT / 'evidence.tar.gz'
            manifest = {}
            with archive.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for source, data in sorted(payloads.items()):
                            disk(ROOT)
                            name = source.lstrip('/')
                            member = tarfile.TarInfo(name)
                            member.size, member.mode = len(data), 0o644
                            tar.addfile(member, io.BytesIO(data))
                            manifest[name] = dict(source=source, bytes=len(data), sha256=digest(data))
            seen = set()
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    disk(ROOT)
                    require(member.isfile() and member.name not in seen, 'invalid archive member')
                    seen.add(member.name)
                    item = manifest[member.name]
                    with tar.extractfile(member) as stream:
                        data = stream.read()
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback differs')
            require(seen == set(manifest), 'archive readback incomplete')
            require(all(capture(path) == data for path, data in list(payloads.items())), 'retained input changed')
            write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed', base_commit=REVISION, source_commit=test['source_commit'], source_patch_sha256=test['source_patch_sha256'], raw=str(RAW),
                supervisor=str(SUPERVISOR), controls=51, skipped=0, actual_tests=actual,
                test_pid=child['pid'], helper_pid=test['pid'], supervisor_pid=outer['supervisor_pid'],
                test_command=child['command'], test_seconds=child['finished_at'] - child['started_at'],
                actual_test_summary_sha256=EXPECTED_SUMMARY, actual_test_receipt_sha256=EXPECTED_CHILD,
                tested_sources=test['sources'], all_sources_unchanged=True,
                archive=dict(path=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
                             members=len(manifest), all_member_hashes_verified=True, gzip_mtime=0),
                manifest_sha256=sha(OUT / 'manifest.json'), archive_helper_sha256=args.helper_sha,
                archive_pid=os.getpid(), archive_parent_pid=os.getppid(), archive_admitted_at=record['admitted_at'],
                real_archive_reads=0, real_compiler_input_reads=0, assembly_performed=False,
                compiler_commands=0, runtime_qualification=False, performance_claim=False,
                scope='51 synthetic compiler-policy controls; no real compiler, Cargo or loader execution')
            write(OUT / 'summary.json', summary)
            (OUT / 'README.md').write_bytes(readme)
            record.update(status='passed', finished_at=time.time(), free_bytes_after=disk(ROOT),
                          result=str(OUT), archive=summary['archive'], summary_sha256=sha(OUT / 'summary.json'))
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
