import hashlib,importlib.util,json,re
from pathlib import Path
owner=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918');work=owner/'.work/oxc-native-compatibility-02';outer=owner/'.work/experiments/oxc-native-compatibility-supervisor-02'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=read(work/'receipt.json');o=read(outer/'status.json');plan=read(owner/'experiments/oxc-plugin-normalization/native-compatibility-plan-02.json');freeze=read(owner/'.work/oxc-native-compatibility-source-02/inputs.json');case=read(owner/'experiments/oxc-plugin-normalization/case.json')['case'];source=owner/'.work/sources/oxc';assert r['status']=='passed' and o['returncode']==0 and r['source_restored'] and len(r['children'])==64 and r['clean_native_performance_qualified'] and not r['native_warnings']
for p,d in freeze['files'].items():
 assert sha(p)==d,p
 assert sha(work/'inputs'/p.lstrip('/'))==d,p
assert sha(outer/'command.log')==o['log_sha256']
spec=importlib.util.spec_from_file_location('controls',owner/'scripts/workflow_controls.py');controls=importlib.util.module_from_spec(spec);spec.loader.exec_module(controls)
identity=read(owner/'.work/oxc-native-toolchain-composition-01/native-toolchain-identity.json')
env=controls.native_environment(plan['environment'],'repository',[],compiler=identity)
children={};warnings=[];dyld=set()
for row in r['children']:
 path=Path(row['path']);child=read(path/'receipt.json');assert child==row['receipt'] and child['status']=='finished';assert child['supervisor_pid']==r['pid'] and child['parent_pid']==r['parent_pid'];assert r['admitted_at']<=child['started_at']<=child['finished_at']<=r['finished_at'];assert child['returncode']==(101 if row['label']=='state--1' else 0)
 for channel in ['stdout','stderr']:assert sha(path/channel)==child[channel+'_sha256']
 label=row['label'];assert child['environment']==(controls.native_identity_environment(plan['environment']) if label.startswith('identity-') else env)
 if label in plan['commands']:assert child['command']==plan['commands'][label]['command'] and child['cwd']==plan['commands'][label]['cwd']
 elif label=='test-list':assert child['command']==[read(work/'discovery-artifact.json')['path'],'--list','--format','terse','--exact',*case['tests']] and child['cwd']==str(source)
 else:
  command=child['command'];assert '-loader-' in label and len(command)==5 and command[:3]==['/usr/bin/otool','-arch','arm64'] and command[3] in ['-L','-l'] and child['cwd']==str(source)
  file=Path(command[4]).resolve(strict=True);name=str(file.relative_to(owner/'.work/oxc-native-toolchain-composition-01/toolchain'));assert sha(file)==read(owner/'.work/oxc-native-toolchain-composition-01/toolchain-inventory.json')[name]['sha256']
 raw=(path/'stderr').read_text(); messages=re.findall(r'^warning(?:\[[^\]]+\])?: (.+)$',raw,re.M)
 assert not messages and not re.search(r'dyld\[|Library not loaded:|failed to execute rust-objcopy',raw)
 if messages:warnings.append(dict(label=row['label'],path=str(path/'stderr'),sha256=sha(path/'stderr'),warnings=messages))
 dyld.update(re.findall(r'dyld\[(\d+)\]',raw));children[row['label']]=child
assert [s['label'] for s in r['states']]==plan['state_labels'];assert len(r['states'])==6
states=[]
for row in r['states']:
 label=row['label'];wanted='FAILED' if label=='state--1' else 'ok';assert sorted(row['tests'])==sorted([[n,wanted] for n in case['tests']]);child=children[label];raw=(Path(row['child_path'])/'stdout').read_text();events=[]
 for line in raw.splitlines():
  if line.startswith('{'):
   event=json.loads(line);events.append(event)
   if event.get('reason')=='compiler-message':assert event['message']['level']!='warning'
   if event.get('reason')=='build-finished':assert event['success'];break
 artifacts=[e for e in events if e.get('reason')=='compiler-artifact' and e.get('executable') and e['profile'].get('test') and 'lib' in e['target']['kind']];assert len(artifacts)==1 and artifacts[0]==row['executable']['artifact'];assert artifacts[0]['package_id']==plan['package_id']
 if label!='state-0':assert not artifacts[0]['fresh']
 assert child['command']==plan['commands'][label]['command'] and child['cwd']==plan['commands'][label]['cwd']
 if label=='state--1':
  for name in case['tests']:
   match=re.search(r'^---- '+re.escape(name)+r' stdout ----\n(.*?)(?=^---- |^failures:|\Z)',raw,re.M|re.S);assert match and 'panicked at' in match[1] and 'assertion' in match[1]
 states.append(dict(label=label,source_sha256=row['source_sha256'],artifact_sha256=row['executable']['sha256'],artifact_fresh=artifacts[0]['fresh'],rebuilt_targets=[dict(name=e['target']['name'],kind=e['target']['kind'],test=e['profile'].get('test')) for e in events if e.get('reason')=='compiler-artifact' and not e['fresh']],tests=row['tests'],whole_child_seconds=child['finished_at']-child['started_at']))
assert states[0]['source_sha256']==states[-1]['source_sha256']==sha(source/case['file']);assert [s['source_sha256'] for s in states[:-1]]==plan['source_states'];assert sha(r['states'][-1]['executable']['path'])==states[-1]['artifact_sha256'];assert read(work/'initial-sdk.json')==read(work/'final-sdk.json');assert read(work/'initial-loaders.json')==read(work/'final-loaders.json')
result=dict(schema_version=1,status='six-state clean native history passed',clean_native_performance_qualified=True,benchmark=False,children=64,states=states,source_restored=True,warnings=warnings,unique_reported_dyld_pids=sorted(dyld,key=int),limitation='One correctness/compatibility history; whole-child times are diagnostic observations, not repeated performance distributions or interpreter/JIT speedups.',hashes={str(p.relative_to(owner)):sha(p) for p in [work/'receipt.json',outer/'status.json',outer/'command.log',work/'initial-sdk.json',work/'final-sdk.json',work/'initial-loaders.json',work/'final-loaders.json',owner/'.work/oxc-native-compatibility-source-02/inputs.json']})
output=owner/'.work/oxc-native-compatibility-verification-02.json'
with output.open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['warnings','states']},indent=2));print('states',[(s['label'],round(s['whole_child_seconds'],3),s['artifact_fresh']) for s in states]);print('warning_children',len(warnings));print('verification_sha256',sha(output))
