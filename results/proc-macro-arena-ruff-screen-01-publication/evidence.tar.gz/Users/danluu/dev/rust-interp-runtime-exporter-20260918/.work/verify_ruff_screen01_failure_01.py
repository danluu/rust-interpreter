from pathlib import Path
import hashlib,json,os,stat,time
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
H=ROOT/'experiments/proc-macro-arena-ruff-screen-01';OUT=ROOT/'results/proc-macro-arena-ruff-screen-01';WORK=ROOT/'.work/proc-macro-arena-ruff-screen-01'
DEST=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918/.work/proc-macro-arena-ruff-screen01-failure-independent-readback-01.json')
FIELDS=('dev','ino','mode','nlink','size','mtime_ns','ctime_ns');CHECKED={}
def stamp(p):s=p.lstat();return {k:getattr(s,'st_'+k) for k in FIELDS}
def file(p):
 p=Path(p);assert p.resolve(strict=True)==p;s=stamp(p);assert stat.S_ISREG(s['mode']) and s['size']<=64*2**20
 b=p.read_bytes();assert len(b)==s['size'] and stamp(p)==s
 r=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),identity=s)
 if str(p) in CHECKED:assert CHECKED[str(p)]==r
 CHECKED[str(p)]=r;return r
def read(p,sha=None):
 r=file(p);assert sha is None or r['sha256']==sha
 return json.loads(p.read_bytes())
def pinned(ref):return read(Path(ref['path']),ref['sha256'])
def raw(directory,record):
 for n in ['stdout','stderr']:
  assert file(directory/n)==record[n]
 if 'stdin' in record:assert file(directory/'stdin')==record['stdin']
execution=read(OUT/'execution.json','6108f328770d75c9167968a038b2b05aae9edf62771d883d3d0e15797053f409')
assert execution['status']=='failed' and execution['parent_pid']==70030
assert execution['error']=="RuntimeError('wrapper refusal cannot become a swallowed capability=false result')"
assert all(execution[n]==[] for n in ['samples','warmups','restorations','edits','signals']) and execution['retries']==0
assert execution['started_at']<=execution['admitted_at']<=execution['observation_finished_at']<=execution['parent_lock_closed_at']
assert not (OUT/'result.json').exists()
inv=read(ROOT/'.work/proc-macro-arena-ruff-screen-invocation-01.json','a8aa0d1adbfaecad2307bb36cd8039249bf9920473d865e5172d0fc93abf7aca')
manifest=read(H/'source-manifest.json',inv['source_manifest_sha256']);assert len(manifest['files'])==6
for n,r in manifest['files'].items():
 now=file(H/n);assert now['bytes']==r['bytes'] and now['sha256']==r['sha256']
plan=read(H/'plan.json',execution['plan_sha256'])
assert file(Path(plan['cargo']))==inv['cargo']
cargo=read(OUT/'cargo-stock/record.json','a1b1917af5b90b91cc09193496f5ce3201baa45c7b33ab2397d24684aef26742')
assert cargo['status']=='closed' and cargo['may_be_live'] is False and cargo['returncode']==101
assert cargo['parent_pid']==70030 and cargo['pid']==73891 and not cargo['observation_errors']
assert cargo['started_at']<=cargo['spawned_at']<=cargo['finished_at']<=cargo['observation_finished_at']<=execution['observation_finished_at']
assert cargo['command']==[plan['cargo']]+[str(WORK/'target/stock') if x=='<fresh-arm-target>' else x for x in plan['cargo_arguments']]
raw(OUT/'cargo-stock',cargo)
assert (OUT/'cargo-stock/stdout').read_text()=='{"reason":"build-finished","success":false}\n'
closure=read(OUT/'native-closure-stock.json','dae44d93c03aa4277e28eb91604ba5015b86d69776aab299f1446868ce4a8987')
assert len(closure)==3
attempts=[];native=[];refusals=[]
for p in sorted((OUT/'wrapper-attempts').iterdir()):
 assert p.suffix=='.json';attempt=read(p);assert attempt['wrapper_parent_pid']==cargo['pid']
 assert cargo['spawned_at']<=attempt['started_at']<=attempt['finished_at']<=cargo['finished_at']
 attempts.append(dict(path=str(p),**file(p)))
 call=OUT/'capture/stock'/attempt['id']
 if attempt['status']=='returned-native-exit':
  route=read(call/'route.json');record=pinned(route['record']);raw(call,record)
  assert record['status']=='closed' and not record['may_be_live'] and record['returncode']==0 and attempt['returned_code']==0
  assert record['parent_pid']==attempt['wrapper_pid'] and record['pid'] in [74421,74423,74425]
  assert route['attempt']==str(p) and route['wrapper_pid']==attempt['wrapper_pid'] and route['classification']['kind']=='query'
  assert route['original_arguments']==attempt['argv'][1:] and route['is_compile'] is False
  assert record['command']==[plan['compiler']]+attempt['argv'][1:]+['--sysroot',str(Path(plan['overlay_work'])/'stock/sysroot')]
  assert record['command']==route['forwarded_arguments'] and record['environment']==route['forwarded_environment']
  assert record['spawned_at']<=record['finished_at']<=attempt['finished_at'] and not record['observation_errors']
  assert next(x for x in closure if x['pid']==record['pid'])['sha256']==file(call/'record.json')['sha256']
  native.append(dict(wrapper_pid=attempt['wrapper_pid'],pid=record['pid'],returncode=0,route=dict(path=str(call/'route.json'),**file(call/'route.json'))))
 else:
  assert attempt['status']=='wrapper-refused' and attempt['wrapper_pid']==74426
  assert attempt['error']=="RuntimeError('unexpected Cargo unstable flag')" and not call.exists()
  args=attempt['argv'][1:];assert args[args.index('--crate-name')+1]=='unicode_ident'
  zs=[(i,x) for i,x in enumerate(args) if x.startswith('-Z')];assert len(zs)==1 and zs[0][1]=='-Z' and args[zs[0][0]+1]=='embed-metadata=no'
  out=Path(args[args.index('--out-dir')+1]);assert out==WORK/'target/stock/debug/build/unicode-ident/9baaff01dc4adfda/out'
  assert out.exists() and list(out.iterdir())==[]
  refusals.append(dict(path=str(p),**file(p),reason=attempt['error'],actual_arguments=args,compiler_spawned=False))
assert len(attempts)==4 and len(native)==3 and len(refusals)==1
assert len(list((OUT/'capture/stock').iterdir()))==3
for name in ['cargo-candidate','capture/candidate','replays','setup-stock.json','setup-candidate.json']:
 assert not (OUT/name).exists()
assert not (WORK/'target/candidate').exists() and not (WORK/'replays').exists()
reg=plan['source_edit']['relative'];expected=plan['source_edit']['original']['sha256']
assert file(WORK/'source'/reg)['sha256']==expected and file(Path(plan['source_root'])/reg)['sha256']==expected
# Closed evidence only: all output files are raw, source-table metadata or receipts.
closed=[];total=0
for directory,dirs,names in os.walk(OUT,followlinks=False):
 assert len(closed)<256
 for n in dirs:assert (Path(directory)/n).resolve(strict=True)==Path(directory)/n
 for n in names:
  p=Path(directory)/n;r=file(p);closed.append(dict(path=str(p),**r));total+=r['bytes'];assert total<=32*2**20
for name,row in CHECKED.items():assert stamp(Path(name))==row['identity']
report=dict(status='verified-failed-screen-before-crate-compilation',observed_at=time.time(),execution=dict(path=str(OUT/'execution.json'),**file(OUT/'execution.json')),
 invocation_sha256=execution['invocation_sha256'],source_manifest_sha256=inv['source_manifest_sha256'],parent_pid=70030,
 parent_exit_observed_by_root=dict(session=45385,exit_code=1),cargo_pid=73891,cargo_returncode=101,native_queries=native,wrapper_attempts=attempts,refusals=refusals,
 crate_compilations=0,timed_calls=0,source_edits=0,warmups=0,restorations=0,performance_decision=None,qualification_passed=False,
 expected_cargo_flag=dict(spelling=['-Z','embed-metadata=no'],role='normal split rlib/rmeta output',forwarded_by_failed_attempt=False),
 dependency_layout=dict(actual_out_dir=str(out),expected_depinfo=str(out/'unicode_ident-9baaff01dc4adfda.d'),basis='retained actual --crate-name, extra-filename, --out-dir; no output was produced'),
 closed_output_files=closed,closed_output_bytes=total,checked_files=CHECKED,
 scope='saved closure/raw/source readback; no source copy/cache/provider-tree replay and no new compiler/Cargo calls')
assert not DEST.exists();DEST.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(str(DEST));print(hashlib.sha256(DEST.read_bytes()).hexdigest());print('closed files',len(closed),'bytes',total,'checked',len(CHECKED))
