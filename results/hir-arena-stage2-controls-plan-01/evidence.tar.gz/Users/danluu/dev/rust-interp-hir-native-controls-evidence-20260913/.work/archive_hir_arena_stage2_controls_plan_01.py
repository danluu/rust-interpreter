#!/usr/bin/env python3
"""Archive completed eight stage2 controls and five metadata guards; no workloads."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[1]
OWNER = Path('/Users/danluu/dev/rust-interp-hir-arena-stage2-20260913')
CONTROLS = OWNER / '.work/hir-arena-stage2-controls-01'
PLAN_STAGE = OWNER / '.work/hir-stage2-package-01/stages/plan-01'
PLAN = OWNER / 'experiments/hir-stage2-package/planned-stage2-01.json'
PLAN_SHA = '2b8393472e57b9a8331aeed1817cabf7dd04a74fd2214f475d16c7e37ccb7425'
CONTROL_SHA = '7dd2c8726091f62c7ef4e05d98fb93a0a93dac60e3cf27595f85e035a39c9484'
PLAN_RECEIPT_SHA = 'b58ccfcbda285d867e61dfb3ad610fdf1f7b3ebacad12cdc5524512323b3b719'
SOURCE_COMMIT = '447d4054c9ffeefb23f594873647e2f7d0f74796'
PLAN_COMMIT = '4990cc33eef94e6c3c30f23cbe4bd4eefbf32b91'
REVIEWED_FILES = {
    '.work/hir-arena-stage2-control-inputs-01.json': '4e4822b96d5b66aad0c8f67201d8b3a8b792270a5f1fc1d09f9fb361e14bd320',
    '.work/hir-arena-stage2-controls-launch-01.json': '5f94a35fb6b36636ffdafe1e34a68f198fabe88db9e94de5fee859d02595dda6',
    '.work/hir-arena-stage2-plan-launch-01.json': '394b8a993f3fb5ea68b16272071cd24bbb7aefe8d1b7d0a4e1ca61e888c73804',
    '.work/hir-arena-stage2-plan-admission-01.json': '1fe3ef165ffec49d9e0e1230c61b353c8f8d0f2a05254b157c8d2b5d2f57e056',
}
WORK = ROOT / '.work/hir-arena-stage2-controls-plan-archive-01'
OUT = ROOT / 'results/hir-arena-stage2-controls-plan-01'
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, disk, require, sha, workload_lock, write


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    WORK.mkdir(parents=True, exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
                  canonical_lock=str(CANONICAL_LOCK), lock_wait_seconds=600)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            payloads, excluded, verified = {}, {}, []

            def capture(path, expected=None):
                path = Path(path)
                require(path.is_absolute() and path.is_file() and not path.is_symlink()
                        and path.resolve(strict=True) == path, 'nonordinary archive input')
                data = path.read_bytes()
                require(expected is None or digest(data) == expected, 'changed archive input: ' + str(path))
                require(str(path) not in payloads or payloads[str(path)] == data, 'changed capture bytes')
                payloads[str(path)] = data
                return data

            plan = json.loads(capture(PLAN, PLAN_SHA))
            require(plan['owner'] == str(OWNER) and plan['previous']['source']['revision'] ==
                    '7efc0d9484da82cd327deb3b48616f8ec81eaf8d' and len(plan['required_units']) == 27
                    and len(plan['inputs']) == 135 and len(plan['configurations']) == 48
                    and not any(plan['configurations'].values())
                    and len(plan['previous']['stage1']['files']) == 64
                    and len(plan['previous']['stage1']['source_links']) == 2,
                    'reviewed stage2 plan changed')
            reviewed = {name: json.loads(capture(OWNER / name, expected))
                        for name, expected in REVIEWED_FILES.items()}
            input_manifest = reviewed['.work/hir-arena-stage2-control-inputs-01.json']
            refs = [dict(paths=plan['archive_paths'], hashes=plan['archive_hashes'], required=plan['archive_required']),
                    *plan['previous']['historical_archives']]
            counts = [1012, 334, 322, 250, 324, 203, 314, 318]
            require(len(refs) == len(counts), 'native qualification and seven earlier archive proofs required')
            for ref, count in zip(refs, counts, strict=True):
                paths, hashes = ref['paths'], ref['hashes']
                archive = Path(paths['archive'])
                require(archive.is_file() and not archive.is_symlink() and archive.resolve(strict=True) == archive
                        and sha(archive) == hashes[str(archive)], 'referenced archive changed')
                manifest = json.loads(capture(paths['manifest'], hashes[paths['manifest']]))
                summary = json.loads(capture(paths['summary'], hashes[paths['summary']]))
                require(summary['archive']['sha256'] == hashes[str(archive)] and len(manifest) == count,
                        'referenced archive summary changed')
                pending, seen = dict(ref['required']), set()
                with tarfile.open(archive, 'r:gz') as tar:
                    for member in tar:
                        disk(ROOT)
                        require(member.isfile() and member.name not in seen and member.name in manifest,
                                'unexpected prior archive member')
                        item = manifest[member.name]; data = tar.extractfile(member).read(); source = item['source']
                        require(member.name == source.lstrip('/') and Path(source).is_absolute()
                                and '..' not in Path(member.name).parts and len(data) == item['bytes']
                                and digest(data) == item['sha256'], 'prior archive source or bytes changed')
                        if source in pending:
                            require(pending.pop(source) == item['sha256'], 'prior required source changed')
                        seen.add(member.name)
                require(not pending and seen == set(manifest), 'incomplete prior archive')
                excluded[str(archive)] = hashes[str(archive)]
                verified.append(dict(ref, members=count, all_member_hashes_verified=True, payload_not_duplicated=True))

            controls = json.loads(capture(CONTROLS / 'summary.json', CONTROL_SHA))
            require(controls['status'] == 'passed' and controls['expected_controls'] == 8
                    and controls['source_revision'] == SOURCE_COMMIT
                    and controls['all_inputs_unchanged'] and len(controls['inputs']) == 145
                    and len(controls['snapshots']) == 145 and len(controls['required_tests']) == 8,
                    'completed eight controls/source guards changed')
            require(input_manifest['owner'] == str(OWNER) and input_manifest['source_revision'] == SOURCE_COMMIT
                    and input_manifest['inputs'] == controls['inputs']
                    and input_manifest['required_tests'] == controls['required_tests'],
                    'reviewed input manifest differs from passing control source')
            capture(CONTROLS / 'reviewed-inputs.json', REVIEWED_FILES['.work/hir-arena-stage2-control-inputs-01.json'])
            require(all(controls['inputs'].get(p) == h for p, h in plan['inputs'].items()),
                    'plan inputs differ from actual passing test bytes')
            snapshot_count, archive_count = 0, 0
            for path, expected in controls['inputs'].items():
                snapshot = controls['snapshots'][path]
                require(snapshot['sha256'] == expected, 'snapshot identity changed')
                if path in excluded:
                    require(snapshot['archive_reference'] and excluded[path] == expected, 'archive input differs')
                    archive_count += 1
                else:
                    data = capture(path, expected)
                    require(capture(snapshot['path'], expected) == data and len(data) == snapshot['bytes'],
                            'original passing snapshot differs')
                    snapshot_count += 1
            require((snapshot_count, archive_count) == (145, 0), 'control snapshot scope changed')
            child = json.loads(capture(CONTROLS / 'command/receipt.json', controls['command_receipt_sha256']))
            require(child['status'] == 'finished' and child['returncode'] == 0 and child['cwd'] == str(OWNER)
                    and child['command'][1:] == ['-B', '-m', 'unittest', '-v',
                                                 'test_hir_stage2_package']
                    and child['environment']['PYTHONPATH'] == str(OWNER / 'tests')
                    and child['environment']['PYTHONDONTWRITEBYTECODE'] == '1'
                    and child['environment']['TMPDIR'] == str(CONTROLS / 'temporary'),
                    'actual control route changed')
            stderr = capture(CONTROLS / 'command/stderr', child['stderr_sha256']).decode()
            capture(CONTROLS / 'command/stdout', child['stdout_sha256'])
            actual = re.findall(r'^test_[^\n]* \(([^)]+)\) \.\.\. ok$', stderr, re.M)
            require(sorted(actual) == controls['required_tests'] == sorted(controls['actual_tests'])
                    and len(actual) == 8 and re.search(r'^Ran 8 tests in [0-9.]+s$', stderr, re.M)
                    and stderr.rstrip().endswith('OK'), 'exact eight passes without skips required')

            stage = json.loads(capture(PLAN_STAGE / 'receipt.json', PLAN_RECEIPT_SHA))
            require(stage['status'] == 'passed' and stage['stage'] == 'plan' and stage['owner'] == str(OWNER)
                    and stage['plan_sha256'] == PLAN_SHA and len(stage['commands']) == 5,
                    'successful five-command plan changed')
            source = Path(plan['source'])
            expected_commands = [['git', 'rev-parse', 'HEAD'], ['git', 'diff', 'HEAD', '--'],
                                 ['git', 'ls-files', '--stage', '-z'], ['git', 'rev-parse', 'HEAD'],
                                 ['git', 'ls-files', '--stage', '-z']]
            for i, ref in enumerate(stage['commands']):
                path = Path(ref['path'])
                require(path == PLAN_STAGE / 'commands' / f'{i:03d}' / 'receipt.json', 'unexpected planning child')
                row = json.loads(capture(path, ref['sha256']))
                require(row['status'] == 'finished' and row['returncode'] == 0
                        and row['command'] == ref['command'] == expected_commands[i]
                        and row['cwd'] == str(source if i < 3 else source / 'library/backtrace')
                        and row['environment'] == plan['previous']['old_plan']['environment'],
                        'planning command/route/environment changed')
                streams = {stream: capture(path.parent / stream, row[stream + '_sha256'])
                           for stream in ['stdout', 'stderr']}
                if i == 0:
                    require(streams['stdout'].decode().strip() == plan['previous']['source']['revision'],
                            'actual compiler source revision differs')
                if i == 1: require(not streams['stdout'], 'actual source diff was not empty')
                if i == 3:
                    require(streams['stdout'].decode().strip() == plan['previous']['old_plan']['backtrace'],
                            'actual backtrace source revision differs')
            for label, row in [('controls', controls), ('plan', stage)]:
                outer = OWNER / '.work/experiments' / {'controls': 'hir-arena-stage2-controls-supervisor-01',
                    'plan': 'hir-stage2-package-plan-supervisor-01'}[label]
                status = json.loads(capture(outer / 'status.json'))
                require(status['status'] == 'finished' and status['returncode'] == 0
                        and status['child_pid'] == row['pid'] and status['supervisor_pid'] == row['parent_pid'],
                        'completed supervisor association changed')
                outer_plan = json.loads(capture(outer / 'plan.json', status['plan_sha256']))
                launch = reviewed['.work/hir-arena-stage2-' + ('controls' if label == 'controls' else 'plan') + '-launch-01.json']
                expected = launch['command'][launch['command'].index('--') + 1:]
                require(status['owner'] == outer_plan['owner'] == str(OWNER)
                        and status['command'] == outer_plan['command'] == expected
                        and outer_plan['supervisor_sha256'] == controls['inputs'][str(OWNER / 'scripts/supervise_experiment.py')],
                        'actual supervisor invocation differs from reviewed launch')
                capture(outer / 'command.log', status['log_sha256'])
                capture(outer / 'supervisor.log')
            for path in [Path(__file__), ROOT / 'experiments/stable-cgu/owned_stage.py',
                         ROOT / 'scripts/supervise_experiment.py']: capture(path)

            OUT.mkdir(parents=True, exist_ok=False)
            target = OUT / 'evidence.tar.gz'; manifest = {}
            with target.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w') as tar:
                        for source, data in sorted(payloads.items()):
                            disk(ROOT)
                            name = source.lstrip('/'); member = tarfile.TarInfo(name)
                            member.size = len(data); member.mode = 0o444
                            tar.addfile(member, io.BytesIO(data))
                            manifest[name] = dict(source=source, bytes=len(data), sha256=digest(data))
            seen = set()
            with tarfile.open(target, 'r:gz') as tar:
                for member in tar:
                    require(member.isfile() and member.name not in seen and member.name in manifest,
                            'invalid new archive member')
                    item = manifest[member.name]; data = tar.extractfile(member).read()
                    require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'archive readback changed')
                    seen.add(member.name)
            require(seen == set(manifest) and all(Path(p).read_bytes() == b for p, b in payloads.items())
                    and all(sha(p) == h for p, h in excluded.items()), 'final archive/input guard failed')
            write(OUT / 'manifest.json', manifest)
            summary = dict(schema_version=1, status='passed controls and metadata plan archived', owner=str(OWNER),
                source_commit=SOURCE_COMMIT, plan_commit=PLAN_COMMIT,
                plan=dict(path=str(PLAN), sha256=PLAN_SHA), controls=8, skipped=0,
                test_pid=child['pid'], control_helper_pid=controls['pid'], control_supervisor_pid=controls['parent_pid'],
                plan_helper_pid=stage['pid'], plan_supervisor_pid=stage['parent_pid'], plan_commands=5,
                test_source_inputs=145, copied_test_snapshots=145, test_archive_references=0,
                compiler_source_revision=plan['previous']['source']['revision'], required_compiler_units=27,
                stage1_admission_inventory=plan['previous']['stage1'],
                control_summary_sha256=CONTROL_SHA, plan_receipt_sha256=PLAN_RECEIPT_SHA,
                historical_archives=verified, native_qualification_claim=False, stage2_qualification_claim=False,
                new_compiler_commands=0, new_source_guard_commands=0, performance_claim=False,
                archive=dict(path=target.name, sha256=sha(target), bytes=target.stat().st_size,
                    members=len(manifest), all_member_hashes_verified=True, gzip_mtime=0),
                manifest_sha256=sha(OUT / 'manifest.json'))
            write(OUT / 'summary.json', summary)
            (OUT / 'README.md').write_text(
                '# HIR stage2 continuation controls and metadata plan\n\n'
                'All eight Python controls passed without skips at source447d4054. '
                'The metadata plan2b839347 then passed all five source guards against '
                'compiler source7efc. The archive retains all145 exact frozen input '
                'files and copied snapshots, raw outputs, environments and child/outer '
                'receipts. The complete native qualification archive373719 and its '
                'seven earlier archives were verified in full and retained by reference; '
                'their tar payloads are not nested.\n\n'
                'The plan keeps all27 compiler units, exact stage2 bootstrap commands, '
                'complete direct native recipe, package/native15/strip6 scope and24/9/8 '
                'capacity policy. No compiler build, test, package or source mutation '
                'occurred during metadata planning or this archive. These controls '
                'do not establish stage2 qualification or a performance result. '
                'The original outer native attempt remains failed; its separate complete '
                'direct recipe pass is retained in the referenced native archive. '
                'Every new archive member and captured source was rechecked.\n')
            record.update(status='passed', finished_at=time.time(), free_bytes_after=disk(ROOT), result=str(OUT),
                archive=summary['archive'], summary_sha256=sha(OUT / 'summary.json'))
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', error=repr(error), finished_at=time.time())
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__': main()
