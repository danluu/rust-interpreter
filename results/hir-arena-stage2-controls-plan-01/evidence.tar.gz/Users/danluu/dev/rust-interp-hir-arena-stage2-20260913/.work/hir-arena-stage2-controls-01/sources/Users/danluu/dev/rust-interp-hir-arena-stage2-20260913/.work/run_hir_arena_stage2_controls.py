#!/usr/bin/env python3
"""Run only the eight reviewed stage2 continuation Python controls."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / '.work/hir-arena-stage2-controls-01'
MANIFEST = ROOT / '.work/hir-arena-stage2-control-inputs-01.json'
DRIVER = ROOT / 'experiments/hir-stage2-package/check.py'
TEST = ROOT / 'tests/test_hir_stage2_package.py'
OWNED = Path('/Users/danluu/dev/rust-interp-hir-arena-native-20260913/experiments/stable-cgu/owned_stage.py')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_frozen(inputs):
    for source, expected in inputs.items():
        path = Path(source)
        if (not path.is_absolute() or path.resolve(strict=True) != path
                or not path.is_file() or path.is_symlink() or digest(path.read_bytes()) != expected):
            raise RuntimeError('frozen control input changed: ' + source)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-revision', required=True)
    parser.add_argument('--inputs-sha256', required=True)
    parser.add_argument('--expected-controls', type=int, required=True)
    args = parser.parse_args()
    raw = MANIFEST.read_bytes()
    if not re.fullmatch('[0-9a-f]{64}', args.inputs_sha256) or digest(raw) != args.inputs_sha256:
        raise RuntimeError('reviewed control-input manifest changed')
    manifest = json.loads(raw)
    if (manifest['owner'] != str(ROOT) or manifest['source_revision'] != args.source_revision
            or not re.fullmatch('[0-9a-f]{40}', args.source_revision) or args.expected_controls != 8
            or manifest['expected_controls'] != 8 or manifest['work'] != str(WORK)):
        raise RuntimeError('fixed eight-control scope changed')
    frozen = manifest['inputs']
    read_frozen(frozen)
    sys.path.insert(0, str(OWNED.parent))
    import owned_stage
    if Path(owned_stage.__file__).resolve() != OWNED or str(OWNED) not in frozen:
        raise RuntimeError('unexpected owned control runner')
    sha, require, write = owned_stage.sha, owned_stage.require, owned_stage.write
    WORK.mkdir(parents=True, exist_ok=False)
    record = dict(status='waiting', started_at=time.time(), pid=os.getpid(), parent_pid=os.getppid(),
        canonical_lock=str(owned_stage.CANONICAL_LOCK), lock_wait_seconds=600,
        expected_source_revision=args.source_revision, expected_controls=8,
        reviewed_inputs_sha256=args.inputs_sha256, compiler_commands=0, source_mutations=0)
    write(WORK / 'summary.json', record)
    try:
        with owned_stage.workload_lock(owned_stage.CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=owned_stage.disk(ROOT))
            write(WORK / 'summary.json', record)
            require(sha(MANIFEST) == args.inputs_sha256, 'reviewed manifest changed before admission')
            read_frozen(frozen)
            revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
            require(revision == args.source_revision, 'source revision changed before admission')
            require(subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--'], cwd=ROOT).returncode == 0,
                    'tracked source changed before admission')
            spec = importlib.util.spec_from_file_location('stage2_control_source', DRIVER)
            driver = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = driver
            spec.loader.exec_module(driver)
            actual_inputs = driver.inputs() | driver.old.frozen_plan()['inputs']
            actual_inputs[str(Path(__file__).resolve())] = sha(Path(__file__).resolve())
            require(actual_inputs == frozen, 'current driver input closure differs from reviewed closure')
            loaded = {str(Path(module.__file__).resolve()) for module in list(sys.modules.values())
                if getattr(module, '__file__', None)
                and str(Path(module.__file__).resolve()).startswith('/Users/danluu/dev/')}
            require(loaded <= set(frozen), 'unfrozen local Python dependency was imported')
            tracked = [str(Path(p).relative_to(ROOT)) for p in frozen
                       if Path(p).is_relative_to(ROOT) and not Path(p).is_relative_to(ROOT / '.work')]
            subprocess.run(['git', 'ls-files', '--error-unmatch', '--', *tracked], cwd=ROOT,
                           check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            names = sorted(TEST.stem + '.' + cls.name + '.' + method.name
                for cls in ast.parse(TEST.read_bytes(), filename=str(TEST)).body
                if isinstance(cls, ast.ClassDef) for method in cls.body
                if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and method.name.startswith('test_'))
            require(names == manifest['required_tests'] and len(names) == len(set(names)) == 8,
                    'exact eight reviewed test definitions required')
            snapshots = {}
            for source, expected in frozen.items():
                data = Path(source).read_bytes()
                require(digest(data) == expected, 'source changed during snapshot')
                target = WORK / 'sources' / source.lstrip('/')
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as output:
                    output.write(data)
                snapshots[source] = dict(path=str(target), sha256=expected, bytes=len(data))
            (WORK / 'reviewed-inputs.json').write_bytes(raw)
            record.update(source_revision=revision, inputs=frozen, snapshots=snapshots, required_tests=names,
                          imported_local_sources=sorted(loaded))
            write(WORK / 'summary.json', record)
            temporary = WORK / 'temporary'
            temporary.mkdir(exist_ok=False)
            environment = {k: v for k, v in os.environ.items() if k in
                ['PATH', 'HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL', 'LC_CTYPE', 'SYSTEMROOT']}
            environment.update(PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT / 'tests'), TMPDIR=str(temporary))
            command = [sys.executable, '-B', '-m', 'unittest', '-v', TEST.stem]
            try:
                owned_stage.run(command, cwd=ROOT, env=environment, out=WORK / 'command', capacity_root=ROOT)
            finally:
                unchanged = all(sha(path) == expected for path, expected in frozen.items())
                unchanged = unchanged and sha(MANIFEST) == args.inputs_sha256
                record['all_inputs_unchanged'] = unchanged
                if (WORK / 'command/receipt.json').exists():
                    record['command_receipt_sha256'] = sha(WORK / 'command/receipt.json')
                write(WORK / 'summary.json', record)
                require(unchanged, 'frozen source changed during controls')
            output = (WORK / 'command/stderr').read_text()
            actual = re.findall(r'^test_[^\n]* \(([^)]+)\) \.\.\. ok$', output, re.M)
            require(sorted(actual) == names and re.search(r'^Ran 8 tests in [0-9.]+s$', output, re.M)
                    and output.rstrip().endswith('OK'), 'exact eight passing identities without skips required')
            require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == revision
                    and subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--'], cwd=ROOT).returncode == 0,
                    'author source changed during controls')
            record.update(status='passed', finished_at=time.time(), free_bytes_after=owned_stage.disk(ROOT),
                          actual_tests=actual)
            write(WORK / 'summary.json', record)
    except BaseException as error:
        record.update(status='failed', finished_at=time.time(), error=repr(error))
        write(WORK / 'summary.json', record)
        raise


if __name__ == '__main__':
    main()
