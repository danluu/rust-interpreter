#!/usr/bin/env python3
"""Archive the actual61 proof and its retained38-command transport failure."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import time

OWNER = Path('/Users/danluu/dev/rust-interp-source-observable-transport-20260913')
SOURCE_ROOT = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
LOCK = Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
sys.path.insert(0, str(SOURCE_ROOT / 'scripts'))
from compare_saved_runtime import acquire_lock
from std_source_observables import validate_source_observables
from workflow_io import write_json

def sha(data):
    return hashlib.sha256(data).hexdigest()

payloads = {}
def retain(name, path):
    assert path.resolve(strict=True) == path and path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    assert name not in payloads
    payloads[name] = data
    return data

def retain_tree(prefix, directory):
    assert directory.resolve(strict=True) == directory and directory.is_dir()
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            retain(prefix + '/' + str(path.relative_to(directory)), path)

with LOCK.open('r+') as lock:
    acquire_lock(lock, 600)
    admitted = time.time()
    passed = SOURCE_ROOT / '.work/mono-production-source-observables-02'
    failed = SOURCE_ROOT / '.work/mono-production-source-observables-01'
    result = json.loads(retain('passed02/result.json', passed / 'result.json'))
    assert result['status'] == 'passed' and result['commands'] == 61
    for name, expected in result['evidence_files'].items():
        assert sha(retain('passed02/' + name, passed / name)) == expected
    checked = validate_source_observables(passed / 'result.json', SOURCE_ROOT,
        result['compiler_key'], result['tool_key'], result['std_mir'],
        compiler_sysroot=result['compiler_sysroot'],
        read_bytes=lambda path: payloads['passed02/' + str(path.relative_to(passed))])
    assert checked['result'] == result
    failure = json.loads((failed / 'result.json').read_bytes())
    assert failure['status'] == 'failed' and failure['completed_commands'] == 38
    for path in sorted(failed.iterdir()):
        if path.is_file() and path.suffix in ['.json', '.rs', '.native', '.rbc']:
            retain('failed01/' + path.name, path)
    for name in ['compiler-argv', 'source-snapshots', 'application', 'source-histories', 'verified-standard-sources']:
        if (failed / name).exists():
            retain_tree('failed01/' + name, failed / name)
    rows = json.loads(payloads['failed01/commands.json'])
    assert len(rows) == 38 and rows[-1]['label'] == 'off-unmapped-exported' and rows[-1]['returncode'] == 1
    assert 'pthread_mutexattr_init' in rows[-1]['stderr']
    launch = [json.loads(line.removeprefix('rust-interp-launch: ')) for line in rows[-1]['stderr'].splitlines()
              if line.startswith('rust-interp-launch: ')]
    assert len(launch) == 1
    bindings = {}
    for field, destination in [('artifact_path', 'entry.rbc'), ('call_report_path', 'entry.calls.json')]:
        path = Path(launch[0][field])
        assert path.is_relative_to(failed / 'observable-cache')
        data = retain('failed01/referenced-artifacts/' + destination, path)
        if field == 'artifact_path':
            assert sha(data) == launch[0]['artifact_sha256']
        bindings[field] = dict(original=str(path), archive='failed01/referenced-artifacts/' + destination,
                               bytes=len(data), sha256=sha(data))
    payloads['failed01/referenced-artifacts.json'] = (json.dumps(bindings, indent=2) + '\n').encode()
    retain_tree('amended-inputs', SOURCE_ROOT / '.work/mono-production-source-observables-02-inputs')
    attempts = []
    for number, record in [('01', failure), ('02', result)]:
        directory = SOURCE_ROOT / '.work/experiments' / ('mono-production-source-observables-supervisor-' + number)
        status = json.loads((directory / 'status.json').read_bytes())
        plan = json.loads((directory / 'plan.json').read_bytes())
        assert status['status'] == 'finished' and status['returncode'] == (0 if number == '02' else 1)
        assert status['plan_sha256'] == sha((directory / 'plan.json').read_bytes())
        assert status['log_sha256'] == sha((directory / 'command.log').read_bytes())
        assert plan['command'] == status['command']
        retain_tree('supervisor' + number, directory)
        attempts.append(dict(run=number, status=record['status'],
            commands=record.get('commands', record.get('completed_commands')), supervisor_pid=status['supervisor_pid'],
            helper_pid=status['child_pid'], finished_at=status['finished_at']))
    for name in ['std_source_observables.py', 'source_observable_transport.py']:
        retain('archive-validator/' + name, SOURCE_ROOT / 'scripts' / name)
    payloads['archive-script.py'] = Path(__file__).read_bytes()
    manifest = {name: dict(bytes=len(data), sha256=sha(data)) for name, data in payloads.items()}
    output = OWNER / 'results/mono-production-source-observables-02'
    output.mkdir(exist_ok=False)
    archive = output / 'evidence.tar.gz'
    with archive.open('xb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as writer:
            for name, data in sorted(payloads.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode = len(data), 0o644
                writer.addfile(item, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as reader:
        assert len(reader.getnames()) == len(manifest) and set(reader.getnames()) == set(manifest)
        for member in reader.getmembers():
            assert member.isfile()
            data = reader.extractfile(member).read()
            assert manifest[member.name] == dict(bytes=len(data), sha256=sha(data))
    write_json(output / 'manifest.json', manifest)
    summary = dict(status='passed', policy=result['policy'], transport_policy=result['transport_policy'],
        compiler_key=result['compiler_key'], tool_key=result['tool_key'], std_mir=result['std_mir'],
        commands=61, source_restored=True, guest_negative_controls=4,
        result_sha256=sha(payloads['passed02/result.json']), attempts=attempts, benchmark=False,
        archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()), members=len(manifest)),
        verification=dict(pid=os.getpid(), parent_pid=os.getppid(), lock=str(LOCK), admitted_at=admitted,
                          finished_at=time.time(), typed_validator_from_archived_bytes=True, all_member_hashes_verified=True),
        excluded=['native compiler/sysroot trees', 'prepared std copies', 'Cargo target caches'])
    write_json(output / 'summary.json', summary)
    (output / 'README.md').write_text(
        'The fresh source-observable qualification passed all 61 commands and the shared archived-byte validator. '
        'Both modes returned 1023 for each normal phase, 1022 for the altered filename expectation and 767 for '
        'the altered line expectation, followed by restored success. Raw native observations, exact expectation '
        'tables/source, actual fixture bytecode/native artifacts, compiler argv, diagnostics and copy proofs are retained.\n\n'
        'The earlier 38-command failure is preserved: its exported fixture reached unsupported pthread stdout locking. '
        'The corrected fixture uses exact guest byte/coordinate comparisons and the existing integer-return ABI. '
        'Compiler, tool and std identities were unchanged; no diagnostic rewriting or comparison relaxation was used.\n\n'
        'This is correctness evidence, not a latency or holdout result. Large compiler/std copies and Cargo caches '
        'remain outside the archive; their complete declared identities are retained. All archive member hashes were '
        'verified under the canonical lock. The 27 Python controls are separately archived in '
        '../source-observable-transport-tests-01.\n')
    print(json.dumps(summary))
