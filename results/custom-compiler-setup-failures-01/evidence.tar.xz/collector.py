import hashlib,io,json,subprocess,tarfile,time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
primary=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
frontend=Path('/Users/danluu/dev/rust-interp-stable-cgu-20260913')
out=root/'results/custom-compiler-setup-failures-01';out.mkdir(parents=True,exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
members={};origins={}
def add(name,path):
 path=Path(path);assert path.is_file() and not path.is_symlink(),path
 data=path.read_bytes();assert name not in members;members[name]=data;origins[name]=str(path)
def add_tree(prefix,path):
 for p in sorted(path.rglob('*')):
  if p.is_file():add(prefix+'/'+str(p.relative_to(path)),p)
for label in ['loader','support']:
 path=root/('.work/custom-compiler-'+label+'-tests-01')
 add_tree('tests/'+label,path)
 receipt=json.loads((path/'result.json').read_text());assert receipt['status']=='passed' and receipt['returncode']==0
 revision={'loader':'4ed6162','support':'3fc77d6'}[label]
 for name,expected in receipt['inputs'].items():
  data=subprocess.check_output(['git','show',revision+':'+name],cwd=root);assert sha(data)==expected
  member='tests/'+label+'/source/'+name;members[member]=data;origins[member]='git:'+revision+':'+name
for label in ['01','02']:
 add_tree('pipeline-'+label,primary/('.work/custom-compiler-pipeline-'+label))
add_tree('tool-build-01',primary/'.work/custom-compiler-tools-01')
key='e48e40e180efbcad9366decdfef2f1152f0a54fb0e78fb865550a64056e84723'
add('installed-compiler/ready.json',primary/'.work/compilers'/key/'ready.json')
package=frontend/'.work/stable-cgu-compiler-build-01/package-05'
add('package-05/receipt.json',package/'receipt.json');add('package-05/provenance.json',package/'provenance.json')
record=json.loads((package/'receipt.json').read_text())
for index,command in enumerate(record['commands']):
 if command['argv'][-1].endswith('/libdarling_macro-335d02ec269ea4d6.dylib'):
  add('observed-macho/'+str(index)+'.log',package/f'probe-{index:02d}.log')
for revision,names in [('78729d1',['scripts/custom_compiler.py']),('a4f376a',['scripts/custom_compiler.py','scripts/build_custom_tools.py'])]:
 for name in names:
  member='pipeline-source/'+revision+'/'+name;members[member]=subprocess.check_output(['git','show',revision+':'+name],cwd=primary);origins[member]='git:'+revision+':'+name
add('collector.py',Path(__file__))
index={name:{'sha256':sha(data),'size':len(data),'origin':origins[name]} for name,data in sorted(members.items())}
manifest=(json.dumps(index,indent=2)+'\n').encode();members['MEMBERS.json']=manifest
archive=out/'evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:xz') as tar:
 assert set(tar.getnames())==set(members)
 for item in tar:
  assert item.isfile() and tar.extractfile(item).read()==members[item.name]
summary={'kind':'custom-compiler-setup-correctness-and-failures','benchmark':False,'created_at':time.time(),'archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'members':len(members),'archive_members_verified':True,'synthetic_tests':{'loader':{'passed':9,'child_pid':14385,'fix_commit':'4ed6162'},'support':{'passed':10,'child_pid':77541,'fix_commit':'3fc77d6'}},'installer_attempt01':'failed closed on LC_ID_DYLIB self-identity being treated as a dependency; retained copied prefix','installer_attempt02':'installed package05 with exact 6982-file equality; later found missing rust-objcopy during tool build','installed_compiler_key':key,'tool_build_attempt01':'failed at ordinary Darwin release build-script stripping because rust-objcopy is missing','toolsets_published':0,'qualifications_started':0,'workload_timings':0,'replacement_package_and_real_qualification':'pending','retained_raw_roots':[str(primary/'.work/custom-compiler-pipeline-01'),str(primary/'.work/custom-compiler-pipeline-02'),str(primary/'.work/custom-compiler-tools-01')],'retained_compiler_copy':str(primary/'.work/compilers/.install-8j_ugjr3'),'no_profile_strip_or_workload_changes':True}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'members.json').write_bytes(manifest)
(out/'README.md').write_text("""# Custom compiler setup failures and focused checks

This archive preserves two setup failures and their narrow importer fixes. It contains no benchmark or speedup result and does not qualify a compiler/tool pair for workload timing.

- Installer attempt01 rejected an absolute `LC_ID_DYLIB` self identity. The actual library load was the system library. The corrected importer distinguishes identity from actual ordinary, weak, reexport, upward and lazy load edges. Nine focused synthetic tests passed.
- Installer attempt02 published package05 after validating its complete recorded 6,982-file inventory. The first matching tool build then failed because that package omitted `rust-objcopy`, which normal Darwin release build-script stripping requires. No matching tools were published and real integration never started. The importer now requires and audits the executable support tool; ten focused synthetic tests passed.

The original compiler/package identities, failed copy, failed build target, plans, child receipts, logs and frozen input hashes are retained. No compiler artifact, strip setting, build profile, or workload source was changed to bypass either failure. The replacement package and its real qualification are separate later steps.

`evidence.tar.xz` contains exact tested source snapshots, both synthetic test receipts, setup plans and outputs, installed/compiler-package inventories, and the observed Mach-O records. `members.json` records each payload's source, size and SHA256; `summary.json` records the archive digest. Every archived member was reopened and compared with its captured bytes. Compiler/tool binaries are retained at their recorded owned paths and are not duplicated in this compact archive.
""")
print(json.dumps(summary,indent=2))
