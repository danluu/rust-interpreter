import hashlib, json, os, re, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
import owned_stage as owned
PLAN = ROOT / '.work/span-bridge-baseline-python-inputs-02.json'
WORK = ROOT / '.work/span-bridge-baseline-python-02'

def main():
    plan_bytes = PLAN.read_bytes()
    owned.require(owned.sha(PLAN) == sys.argv[1], 'control plan changed')
    plan = json.loads(plan_bytes)
    owned.require(plan['runner_sha256'] == owned.sha(Path(__file__)), 'control runner changed')
    WORK.mkdir(exist_ok=False)
    result = dict(status='waiting', started_at=time.time(), pid=os.getpid(), parent_pid=os.getppid(),
        owner=str(ROOT), source_commit=plan['source_commit'], fixture_commit=plan['fixture_commit'],
        plan_sha256=owned.sha(PLAN), benchmark=False, native_commands=0,
        canonical_lock=str(owned.CANONICAL_LOCK), lock_wait_seconds=600)
    owned.write(WORK / 'result.json', result)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK, 600):
            result.update(status='admitted', admitted_at=time.time(), free_bytes=owned.disk(ROOT))
            owned.write(WORK / 'result.json', result)
            def guard():
                owned.require(PLAN.read_bytes() == plan_bytes and owned.sha(Path(__file__)) == plan['runner_sha256'], 'control supervision changed')
                owned.require(all(owned.sha(ROOT / name) == h for name,h in plan['source_files'].items()), 'frozen control input changed')
                owned.require(owned.sha(Path(sys.executable).resolve()) == plan['python']['sha256'], 'control Python changed')
            guard()
            for name,h in plan['source_files'].items():
                target = WORK / 'source' / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((ROOT / name).read_bytes())
            (WORK / 'runner.py').write_bytes(Path(__file__).read_bytes())
            (WORK / 'plan.json').write_bytes(plan_bytes)
            (WORK / 'tmp').mkdir()
            env = dict(PATH='/usr/bin:/bin:/usr/sbin:/sbin', LANG='C', LC_ALL='C',
                PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(WORK / 'tmp'))
            if 'HOME' in os.environ: env['HOME'] = os.environ['HOME']
            command = [sys.executable, '-m', 'unittest', 'discover', '-s',
                str(ROOT / 'experiments/proc-macro-span-handles/integration'), '-p', 'test_baseline.py', '-v']
            row = owned.run(command, cwd=ROOT, env=env, out=WORK / 'command', capacity_root=ROOT)
            guard()
            stderr = (WORK / 'command/stderr').read_text()
            names = re.findall(r'^(test_[a-z0-9_]+) \([^\n]+\) \.\.\. ok$', stderr, re.MULTILINE)
            owned.require(sorted(names) == sorted(plan['tests']) and re.findall(r'^Ran (\d+) tests in .+$', stderr, re.MULTILINE) == ['4']
                and re.findall(r'^OK$', stderr, re.MULTILINE) == ['OK'], 'four exact pure tests did not pass')
            owned.require(all(owned.sha(WORK / 'source' / name) == h for name,h in plan['source_files'].items()), 'source snapshot changed')
            result.update(status='passed', finished_at=time.time(), passed=4, failed=0,
                source_unchanged=True, test_pid=row['pid'], tests=names,
                evidence_files={str(p.relative_to(WORK)):owned.sha(p) for p in sorted(WORK.rglob('*'))
                    if p.is_file() and p != WORK / 'result.json' and not p.is_relative_to(WORK / 'tmp')})
            owned.write(WORK / 'result.json', result)
            print(json.dumps(dict(status='passed', tests=4, native_commands=0, test_pid=row['pid'])), flush=True)
    except BaseException as error:
        result.update(status='failed', finished_at=time.time(), error=repr(error))
        owned.write(WORK / 'result.json', result)
        raise
if __name__ == '__main__': main()
