"""Archive completed stock-bridge qualification and the failed zero-test setup."""
import hashlib, io, json, os, re, sys, tarfile, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments/stable-cgu'))
sys.path.insert(0,str(ROOT/'scripts'))
import owned_stage as owned
import custom_compiler


def main():
    assert __debug__
    output=ROOT/'results/span-bridge-native-baseline-01'
    receipt=ROOT/'.work/span-bridge-baseline-archive-01.json'
    state=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),
        canonical_lock=str(owned.CANONICAL_LOCK),archive_runner_sha256=owned.sha(Path(__file__)),
        compiler_or_test_commands=0)
    owned.write(receipt,state)
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK,600):
            state.update(status='admitted',admitted_at=time.time());owned.write(receipt,state)
            sources=set()
            def add_tree(directory,excluded=()):
                for p in directory.rglob('*'):
                    assert not p.is_symlink()
                    if p.is_file() and not any(p.is_relative_to(directory/x) for x in excluded):sources.add(p)
            def supervisor(name,code):
                directory=ROOT/'.work/experiments'/name
                row=json.loads((directory/'status.json').read_bytes())
                assert row['status']=='finished' and row['returncode']==code
                assert owned.sha(directory/'plan.json')==row['plan_sha256']
                assert owned.sha(directory/'command.log')==row['log_sha256']
                sources.update(directory/n for n in ['plan.json','status.json','command.log','supervisor.log'])
                return row
            failed=ROOT/'.work/span-bridge-baseline-python-01'
            failed_row=json.loads((failed/'result.json').read_bytes())
            failed_sup=supervisor('span-bridge-baseline-python-supervisor-01',1)
            assert failed_row['status']=='failed' and failed_row['error']=="RuntimeError('control Python changed')"
            assert not (failed/'command').exists() and failed_sup['child_pid']==failed_row['pid']
            add_tree(failed)
            for number in ['01','02']:
                sources.update([ROOT/f'.work/run-span-bridge-baseline-python-{number}.py',
                                ROOT/f'.work/span-bridge-baseline-python-inputs-{number}.json'])
            tests=ROOT/'.work/span-bridge-baseline-python-02'
            tests_row=json.loads((tests/'result.json').read_bytes())
            test_sup=supervisor('span-bridge-baseline-python-supervisor-02',0)
            assert tests_row['status']=='passed' and tests_row['passed']==4 and tests_row['failed']==0
            assert tests_row['native_commands']==0 and tests_row['source_unchanged']
            test_command=json.loads((tests/'command/receipt.json').read_bytes())
            assert test_command['returncode']==0 and test_command['pid']==tests_row['test_pid']
            assert test_sup['child_pid']==tests_row['pid']==test_command['supervisor_pid']
            assert re.search(r'\nRan 4 tests in [0-9.]+s\n\nOK\n\Z',(tests/'command/stderr').read_text())
            assert all(owned.sha(tests/n)==h for n,h in tests_row['evidence_files'].items())
            old_plan=json.loads((ROOT/'.work/span-bridge-baseline-python-inputs-01.json').read_bytes())
            new_plan=json.loads((tests/'plan.json').read_bytes())
            assert old_plan['source_files']==new_plan['source_files']
            assert all(owned.sha(tests/'source'/n)==h for n,h in old_plan['source_files'].items())
            add_tree(tests,('tmp',))
            native=ROOT/'.work/span-bridge-baseline-01'
            native_row=json.loads((native/'result.json').read_bytes())
            native_sup=supervisor('span-bridge-baseline-supervisor-01',0)
            assert native_row['status']=='passed' and native_row['completed_commands']==2
            assert [native_row[k] for k in ['passed','failed','ignored','measured','filtered']]==[4,0,0,0,0]
            assert not native_row['benchmark'] and not native_row['patched_span_store']
            assert native_row['frozen_inputs_unchanged'] and native_sup['child_pid']==native_row['pid']
            assert all(owned.sha(native/n)==h for n,h in native_row['evidence_files'].items())
            plan=json.loads((native/'plan.json').read_bytes())
            commands=json.loads((native/'commands.json').read_bytes())
            assert len(commands)==2 and all(c['returncode']==0 for c in commands)
            assert [c['command'] for c in commands]==[p['argv'] for p in plan['commands']]
            for i,label in enumerate(['compile','tests']):
                command=commands[i];directory=native/'commands'/label
                assert command==json.loads((directory/'receipt.json').read_bytes())
                assert command['supervisor_pid']==native_row['pid'] and command['parent_pid']==native_sup['supervisor_pid']
                assert owned.sha(directory/'stdout')==command['stdout_sha256']
                assert owned.sha(directory/'stderr')==command['stderr_sha256']
            names=re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. ok$',(native/'commands/tests/stdout').read_text(),re.M)
            assert sorted(names)==sorted(plan['expected_tests']) and len(names)==4
            compiler=custom_compiler.load_compiler(Path(plan['compiler_owner']),plan['compiler_key'])
            assert compiler.key=='f9fb3e5f59b8567fffd32c936a9864d0baee77038574236710fbcec75a57d33f'
            ready=Path(plan['compiler_owner'])/'.work/compilers'/compiler.key/'ready.json'
            assert ready.read_bytes()==(native/'compiler-ready.json').read_bytes()
            assert all(owned.sha(compiler.sysroot/n)==h for n,h in plan['native_inputs'].items())
            sources.update(compiler.sysroot/n for n in plan['inputs']['native_source_files'])
            binary=native/'artifacts/span_bridge_baseline'
            assert owned.sha(binary)==native_row['artifact_sha256']
            add_tree(native,('tmp','artifacts/span_bridge_baseline'))
            sources.update([Path(__file__),ROOT/'experiments/stable-cgu/owned_stage.py',ROOT/'scripts/supervise_experiment.py'])
            files={}
            for path in sorted(sources):
                assert path.is_file() and not path.is_symlink()
                data=path.read_bytes();files[str(path).lstrip('/')]=dict(source=str(path),data=data)
            output.mkdir(parents=True,exist_ok=False)
            archive=output/'evidence.tar.gz'
            with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
                for name,item in sorted(files.items()):
                    info=tarfile.TarInfo(name);info.size=len(item['data']);info.mode=0o644;info.mtime=0
                    tar.addfile(info,io.BytesIO(item['data']))
            with tarfile.open(archive,'r:gz') as tar:
                members=tar.getmembers();assert len(members)==len(files)
                assert all(m.isfile() and m.name in files and tar.extractfile(m).read()==files[m.name]['data'] for m in members)
            assert all(path.read_bytes()==files[str(path).lstrip('/')]['data'] for path in sources)
            assert custom_compiler.load_compiler(Path(plan['compiler_owner']),compiler.key)==compiler
            manifest={name:dict(source=v['source'],bytes=len(v['data']),sha256=hashlib.sha256(v['data']).hexdigest()) for name,v in sorted(files.items())}
            owned.write(output/'manifest.json',manifest)
            summary=dict(status='baseline stock-span real bridge controls passed',source_commit='63f70679756b15517ab122a6be9124cd4838aa4c',
                fixture_commit=plan['fixture_commit'],compiler_key=compiler.key,compiler_source_commit=compiler.identity['provenance']['source_commit'],
                span_patch_sha256=plan['inputs']['files']['experiments/proc-macro-span-handles/span-handles.patch'],
                pure_tests=dict(passed=4,supervisor=test_sup['supervisor_pid'],helper=tests_row['pid'],child=tests_row['test_pid'],result=tests_row),
                failed_pure_setup=dict(supervisor=failed_sup['supervisor_pid'],helper=failed_row['pid'],tests_run=0,result=failed_row,
                    explanation='Plan bound macOS /usr/bin/python3 launcher instead of real Xcode interpreter. Exact guard rejected before test spawn; fresh02 changed only supervisor/plan Python identity and run paths.'),
                native_tests=dict(passed=4,failed=0,ignored=0,filtered=0,commands=2,supervisor=native_sup['supervisor_pid'],helper=native_row['pid'],
                    compile_pid=commands[0]['pid'],test_pid=commands[1]['pid'],admitted_at=native_row['admitted_at'],finished_at=native_row['finished_at'],exact_names=names),
                binary=dict(path=str(binary),sha256=native_row['artifact_sha256'],bytes=binary.stat().st_size,retained_locally=True,archived=False),
                benchmark=False,patched_span_store=False,compiler_rebuilt=False,frozen_inputs_unchanged=True,
                warnings='Original proc_macro_internals internal_features compiler warning retained; expected client/server/stale-handle panic stderr retained verbatim.',
                archive=dict(path='evidence.tar.gz',sha256=owned.sha(archive),bytes=archive.stat().st_size,members=len(files),all_member_bytes_verified=True))
            owned.write(output/'summary.json',summary)
            state.update(status='passed',finished_at=time.time(),archive=summary['archive'])
            owned.write(receipt,state);owned.write(output/'archive-receipt.json',state)
            print(json.dumps(state),flush=True)
    except BaseException as error:
        state.update(status='failed',finished_at=time.time(),error=repr(error));owned.write(receipt,state);raise

if __name__=='__main__':main()
