/Users/danluu/dev/rust-interp-span-bridge-baseline-20260913/.work/span-bridge-baseline-01/artifacts/bridge.d: /Users/danluu/dev/rust-interp-span-bridge-baseline-20260913/.work/span-bridge-baseline-01/source/experiments/proc-macro-span-handles/integration/bridge.rs

/Users/danluu/dev/rust-interp-span-bridge-baseline-20260913/.work/span-bridge-baseline-01/artifacts/span_bridge_baseline: /Users/danluu/dev/rust-interp-span-bridge-baseline-20260913/.work/span-bridge-baseline-01/source/experiments/proc-macro-span-handles/integration/bridge.rs

/Users/danluu/dev/rust-interp-span-bridge-baseline-20260913/.work/span-bridge-baseline-01/source/experiments/proc-macro-span-handles/integration/bridge.rs:
