import hashlib,json,re,time
from pathlib import Path
A=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
H=A/'experiments/hir-options-hash-beta-controls-01';W=A/'.work/hir-options-hash-beta-controls-01'
O=A/'.work/experiments/hir-options-hash-beta-controls-supervisor-01';L=A/'.work/beta-controls-launch-execution-01'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stamp(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink]
f=read(H/'inputs.json');launch=read(H/'launch.json');outer=read(L/'record.json');saved=read(L/'stdout');status=read(O/'status.json');plan=read(O/'plan.json');terminal=read(W/'receipt.json');child=read(W/'command/receipt.json');result=read(W/'result.json')
assert sha(H/'launch.json')==outer['launch_sha256']=='80cc3dce25b811956a6376c35cbde4e1dba58533768193ee9d3de41c7e916be0'
assert sha(H/'inputs.json')==launch['inputs_sha256']==terminal['inputs_sha256']=='f1442f5a776a6331d29f6d084a2eced1d03c4a2ee95a5df026fe62fbd75d0f73'
assert sha(Path(outer['launcher_source_path']))==outer['launcher_source_sha256']
assert outer['status']=='finished' and outer['returncode']==0 and outer['command']==launch['command'] and outer['cwd']==launch['owner']==str(A) and outer['environment']==launch['environment']==f['environment']
assert sha(L/'stdout')==outer['stdout_sha256'] and sha(L/'stderr')==outer['stderr_sha256'] and not (L/'stderr').read_bytes()
assert saved['supervisor_pid']==status['supervisor_pid'] and saved['directory']==str(O)
line=saved['identity'].splitlines()[1].split();assert list(map(int,line[:2]))==[status['supervisor_pid'],outer['pid']]
assert status['status']=='finished' and status['returncode']==0 and status['owner']==status['cwd']==str(A)
assert sha(O/'plan.json')==status['plan_sha256'] and sha(O/'command.log')==status['log_sha256']
assert plan['command']==status['command']==launch['command'][launch['command'].index('--')+1:] and plan['owner']==str(A)
assert sha(A/'scripts/supervise_experiment.py')==plan['supervisor_sha256']
assert terminal['status']=='passed' and terminal['controls_passed']==49 and all(terminal[k]==0 for k in ['compiler_calls','provider_probes','B3_compositions'])
assert status['child_pid']==terminal['pid'] and status['supervisor_pid']==terminal['parent_pid']
assert outer['started_at']<=status['started_at']<=status['child_started_at']<=terminal['started_at']<=terminal['admitted_at']<=child['started_at']<=child['finished_at']<=terminal['finished_at']<=status['finished_at']
assert child['status']=='finished' and child['returncode']==0 and child['command']==f['command'] and child['cwd']==str(A/'experiments/hir-options-hash-beta-composition-02')
assert child['environment']==f['environment']|{'TMPDIR':str(W/'tmp')}
assert child['supervisor_pid']==terminal['pid'] and child['parent_pid']==terminal['parent_pid']
assert terminal['commands']==[dict(path=str(W/'command/receipt.json'),sha256=sha(W/'command/receipt.json'),pid=child['pid'])]
identity=child['identity'];assert identity['ps_returncode']==identity['cwd_returncode']==0
parts=identity['ps'].split();assert list(map(int,parts[:3]))==[child['pid'],terminal['pid'],child['pid']]
assert identity['ps'].endswith(' '.join(child['command'])) and 'n'+child['cwd']+'\n' in identity['cwd']
for stream in ['stdout','stderr']:assert sha(W/'command'/stream)==child[stream+'_sha256']
assert not (W/'command/stdout').read_bytes()
raw=(W/'command/stderr').read_text();names=re.findall(r'^test_[A-Za-z0-9_]+ \(([^)]+)\) \.\.\. ok$',raw,re.M)
assert sorted(names)==f['expected_names']==result['expected_names'] and len(names)==len(set(names))==49
assert re.search(r'^Ran 49 tests in [0-9.]+s\n\nOK\n$',raw,re.M)
assert result['status']=='passed' and result['tests_run']==49 and sha(W/'result.json')==terminal['result_sha256']
assert all(result[k]==0 for k in ['failures','errors','skipped','expected_failures','unexpected_successes','child_processes','compiler_calls'])
assert result['writable_names']<=256 and result['directories']<=2048 and result['maximum_file_bytes']==256*1024
assert not list((W/'tmp').iterdir()) and terminal['retained_file_bytes']<=2*1024*1024
for name,row in f['files'].items():
 p=Path(name);assert p.resolve(strict=True)==p and stamp(p)==row['stamp'] and sha(p)==row['sha256'] and stamp(p)==row['stamp'],name
for name,resolved in f['routes'].items():assert str(Path(name).resolve(strict=True))==resolved,name
report=dict(status='verified',receipt_sha256=sha(W/'receipt.json'),freeze_sha256=sha(H/'inputs.json'),launch_sha256=sha(H/'launch.json'),inputs=len(f['files']),input_bytes=sum(row['stamp'][3] for row in f['files'].values()),controls=49,actual_children=1,actual_compiler_calls=0,actual_provider_probes=0,source_inputs_unchanged=True,complete_raw_and_process_association=True,verifier_sha256=sha(Path(__file__)),finished_at=time.time())
p=A/'.work/beta-controls-independent-verification-01.json';assert not p.exists();p.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report,indent=2))
