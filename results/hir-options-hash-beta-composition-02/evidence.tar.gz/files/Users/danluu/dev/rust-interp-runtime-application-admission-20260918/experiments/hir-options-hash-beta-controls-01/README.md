This packet runs 49 synthetic controls for B3 successor02 in one Python child.
It does not run a compiler, provider probe, B3 composition, application or
benchmark. The compositor controls create small fake inputs under the new
owned temporary directory. One ancestor control reads the frozen real build02,
acquisition and original workspace-control catalogs plus both parent manifest
versions, without inspecting compiler outputs. Draft01 remains unchanged.

The exact resolved Python, scripts, all candidate and predecessor sources,
source references, manifest/catalog bytes, process-identity executors and
environment are frozen. The helper uses the existing supervisor and canonical
lock with a 600-second wait, 16 GiB entry, 9 GiB stop and 8 GiB floor. Its single
test child inherits the held canonical descriptor. Schedule only when doing so
does not delay an admitted compiler; a timeout is retained, never retried here.

The test child rejects subprocess and network-connect audit events, has a
120-second alarm and 60-second CPU limit, caps every file at 256 KiB, and caps
cumulative writable names at 256 and directory names at 2,048. Test write-open
and directory-creation routes must remain in its owned namespace. Together with
the two inherited raw streams, this bounds child file payload to 64.5 MiB even
when fixtures are removed. This is not a filesystem-allocation guarantee or a
general security sandbox. The existing parent's five-second capacity checks
and exact owned-process proof still apply. Retained stage files must total at
most 2 MiB; expected actual output is much smaller. Fixture cleanup, complete
test IDs, zero skips/expected failures, raw stdout/stderr, child result and all
frozen inputs are checked after the run. Any failure remains under its fresh
output path. Existing supervision cannot promise to reap an uninterruptible
kernel task; inherited exclusion remains with a live child.

`prepare.py` performs source hashing and creates the concrete freeze/launch.
It does not execute controls. `run.py` requires the reviewed freeze hash.
