"""One bounded read-only hash proposal preparation after all four actual audits."""
import argparse, hashlib, json, os, shutil, subprocess, sys, time
from pathlib import Path
ROOT=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
A=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
HERE=ROOT/'experiments/hir-options-hash-driver-stage-03'
WORK=ROOT/'.work/hash-driver-preparation-execution-04'
PREREQUISITES=ROOT/'.work/hash-driver-preparation-predecessors-03.json'
AUDIT=A/'.work/native-reconciliation-independent-verification-01.json'
RECEIPT=A/'.work/hir-options-hash-native-controls-reconciliation-01/receipt.json'
MAXIMUM_OBSERVATION_SECONDS=1800
EXPECTED_CONTROLS_AUDIT='7d17277c1551a40faa717ed06056184d156519cee4b2002a83e69f7d3424265a'  # Bound to actual66 independent audit.
# Bind only after independent source review and the actual focused tests.
SOURCES=None  # Exact final stage03 source map after O/X/ROOT review; unbound drafts cannot prepare.
FILE_TABLE_AUDIT_SHA256='6742d9a6199381d77f424f35d3b03e2ea99950ec307b399e4955716894986e2e'
READER_AUDIT_SHA256='ea8ba76b848318affd0f2d76f4f5e4b6711731d15250e0eb17ec5d1362408b2b'
CONTINUATION_AUDIT_SHA256=None  # Require actual70 passed independent audit; never anticipate it.
FAILED_AUDIT=ROOT/'.work/hir-options-hash-driver-failure-verification-01.json'
FAILED_AUDIT_SHA256='ee81a129d5d1742074619ea31b75ad06512abd110dd102dc0ac8bec8c3eda8b3'
FAILED_SOURCE=ROOT/'experiments/hir-options-hash-driver-stage-02'
FAILED_WORK=ROOT/'.work/hir-options-hash-driver-01'
NEXT_WORK=ROOT/'.work/hir-options-hash-driver-02'
NEXT_ARTIFACTS=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918/.work/hir-options-hash-compiler-01/hash-driver-02')

def sha(p):
 with Path(p).open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def save(record):
 staged=WORK/'record.staged';assert not staged.exists()
 with staged.open('x') as s:json.dump(record,s,sort_keys=True,indent=2);s.write('\n');s.flush();os.fsync(s.fileno())
 staged.replace(WORK/'record.json')
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--native-audit-sha256',required=True);args=parser.parse_args()
 assert Path.cwd()==ROOT and sys.dont_write_bytecode and not sys.flags.optimize
 assert type(SOURCES) is dict and SOURCES and all(len(value)==64 for value in SOURCES.values()),'unbound stage source inventory'
 assert type(CONTINUATION_AUDIT_SHA256) is str and len(CONTINUATION_AUDIT_SHA256)==64,'unbound actual70 continuation qualification'
 assert type(FILE_TABLE_AUDIT_SHA256) is str and len(FILE_TABLE_AUDIT_SHA256)==64,'unbound file-table controls'
 assert type(READER_AUDIT_SHA256) is str and len(READER_AUDIT_SHA256)==64,'unbound independent-reader controls'
 assert type(EXPECTED_CONTROLS_AUDIT) is str and len(EXPECTED_CONTROLS_AUDIT)==64,'unbound actual66 controls qualification'
 assert len(args.native_audit_sha256)==64 and all(c in '0123456789abcdef' for c in args.native_audit_sha256)
 assert sha(PREREQUISITES)=='0fd7de818ec1efa748078c9e9605c7849131a3751280cd2d0ddd7c7dbcc559a4'
 prior=read(PREREQUISITES)
 assert sha(prior['previous_preparation']['record'])==prior['previous_preparation']['sha256']
 for name,row in prior['previous_preparation']['partial_catalogs'].items():assert sha(name)==row['sha256'] and Path(name).stat().st_size==row['size']
 for key in ['record','stdout','stderr']:
  row=prior['previous_preparation02'][key];assert sha(row['path'])==row['sha256'] and Path(row['path']).stat().st_size==row['size']
 for row in prior['previous_preparation02']['sources']+prior['previous_preparation02']['partial_packet']:
  assert sha(row['path'])==row['sha256'] and Path(row['path']).stat().st_size==row['size']
 for row in prior['audits'].values():
  assert sha(row['path'])==row['sha256'] and sha(row['receipt'])==row['receipt_sha256']
  assert read(row['path'])['status']=='verified' and read(row['receipt'])['status']=='passed'
 assert sha(AUDIT)==args.native_audit_sha256
 audit=read(AUDIT);receipt=read(RECEIPT)
 assert audit['status']=='verified' and audit['receipt_sha256']==sha(RECEIPT) and receipt['status']=='passed'
 assert audit['read_only_reconciliation'] is True and audit['actual_workload_children']==0 and audit['qualified_native_children']==20
 assert audit['original_failed_receipt_sha256']=='76fe70afd8eb6486b445e39366de2dd1ffd52ed9578e63203dc7cf74a679a272'
 assert sha(ROOT/'.work/hir-options-hash-prerequisite-controls-independent-verification-05.json')==EXPECTED_CONTROLS_AUDIT
 for namespace,digest in [('frozen-file-table-delta-controls',FILE_TABLE_AUDIT_SHA256),('hash-file-table-reader-controls',READER_AUDIT_SHA256),('hash-continuation-controls',CONTINUATION_AUDIT_SHA256)]:
  audit_path=ROOT/('.work/'+namespace+'-independent-verification-01.json')
  assert sha(audit_path)==digest
  proof=read(audit_path);assert proof['status']=='verified'
  evidence=ROOT/('.work/'+namespace+'-01');terminal=read(evidence/'receipt.json')
  assert terminal['status']=='passed' and proof['receipt_sha256']==sha(evidence/'receipt.json')
  assert proof['result_sha256']==terminal['result_sha256']==sha(evidence/'result.json')
  if namespace=='hash-continuation-controls':
   result=read(evidence/'result.json')
   assert proof['controls']==terminal['controls_passed']==result['tests_run']==70 and result['status']=='passed'
  inputs_path=ROOT/('experiments/'+namespace+'-01/inputs.json')
  assert sha(inputs_path)==terminal['inputs_sha256']
  inputs=read(inputs_path)
  for name,row in inputs['files'].items():
   p=Path(name);info=p.lstat();stamp=[getattr(info,'st_'+key) for key in ['dev','ino','mode','size','mtime_ns','ctime_ns','nlink']]
   assert p.resolve(strict=True)==p and stamp==row['stamp'] and sha(p)==row['sha256']
 assert sha(FAILED_AUDIT)==FAILED_AUDIT_SHA256
 failure=read(FAILED_AUDIT);failed=read(FAILED_WORK/'receipt.json')
 assert failure['status']=='verified-retained-failure' and failure['owner_status']==failed['status']=='failed'
 assert failure['source']==str(FAILED_SOURCE) and failure['evidence']==str(FAILED_WORK)
 assert failure['receipt_sha256']==sha(FAILED_WORK/'receipt.json')
 for field,path in [('inputs_sha256',FAILED_SOURCE/'inputs.json'),('plan_sha256',FAILED_SOURCE/'plan.json'),
                    ('snapshot_plan_sha256',FAILED_SOURCE/'snapshot-plan.json'),('source_snapshots_sha256',FAILED_WORK/'source-snapshots.json')]:
  assert failure[field]==sha(path)
 assert failure['inputs_sha256']==failed['inputs_sha256'] and failure['snapshot_plan_sha256']==failed['snapshot_plan_sha256']
 assert failure['source_snapshots_sha256']==failed['source_snapshots_sha256']
 assert failure['actual_children']==failure['actual_compiler_children']==1
 assert failure['actual_driver_processes']==failure['qualified_hash_driver_processes']==0
 assert all(failure[key] is True for key in ['complete_failed_raw_history','full_snapshot_selection','full_frozen_byte_rehash','retained_snapshot_owner_only'])
 assert failure['compressed_snapshots']['full_gzip_eof_crc'] is True and failure['compressed_snapshots']['full_logical_hashes'] is True
 outer=ROOT/'.work/experiments/hir-options-hash-driver-supervisor-01/status.json'
 launcher=ROOT/'.work/hash-driver-launch-execution-01/record.json'
 assert failure['closure']['actual_outer_closed'] is failure['closure']['actual_wrapper_closed'] is True
 assert failure['closure']['outer_sha256']==sha(outer) and failure['closure']['launcher_record_sha256']==sha(launcher)
 assert read(outer)['status']=='finished' and read(outer)['returncode']==1
 assert read(launcher)['status']=='terminal-observed' and read(launcher)['returncode']==1
 assert all(not Path(name).exists() and not Path(name).is_symlink() for name in failure['absent_outputs'])
 for name,h in SOURCES.items():assert sha(HERE/name)==h,name
 assert not WORK.exists() and not WORK.is_symlink()
 for name in ['plan.json','inputs.json','snapshot-plan.json','launch.json','metadata-preflight.json','catalogs-02']:
  assert not (HERE/name).exists() and not (HERE/name).is_symlink(),name
 assert not NEXT_WORK.exists() and not NEXT_WORK.is_symlink()
 assert not NEXT_ARTIFACTS.exists() and not NEXT_ARTIFACTS.is_symlink()
 free=shutil.disk_usage(ROOT).free;assert free>=16*2**30,'fresh16GiB readonly preparation entry required'
 argv=list(prior['partial_argv_not_runnable'])
 assert argv[:3]==[str(Path('/opt/homebrew/bin/python3').resolve()),'-B',str(FAILED_SOURCE/'prepare.py')]
 argv[2]=str(HERE/'prepare.py')
 argv+=['--native-audit',str(AUDIT),'--native-audit-sha256',args.native_audit_sha256]
 env=dict(HOME='/Users/danluu',LANG='C',LC_ALL='C',LOGNAME='danluu',PATH='/usr/bin:/bin:/usr/sbin:/sbin',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',TZ='UTC',USER='danluu')
 WORK.mkdir();(WORK/'source').mkdir()
 for name,h in SOURCES.items():
  data=(HERE/name).read_bytes();assert hashlib.sha256(data).hexdigest()==h
  with (WORK/'source'/name).open('xb') as s:s.write(data)
 record=dict(status='starting',command=argv,cwd=str(ROOT),environment=env,parent_pid=os.getpid(),started_at=time.time(),entry_free_bytes=free,
  sources_sha256=SOURCES,native_audit_sha256=args.native_audit_sha256,runner_source=str(Path(__file__).resolve()),runner_sha256=sha(__file__),
  file_table_controls_audit_sha256=FILE_TABLE_AUDIT_SHA256,reader_controls_audit_sha256=READER_AUDIT_SHA256,
  continuation_controls_audit_sha256=CONTINUATION_AUDIT_SHA256,failed_driver_audit_sha256=FAILED_AUDIT_SHA256,
  prior_preparation_reference=dict(path=str(PREREQUISITES),sha256=sha(PREREQUISITES)),
  scope='Read-only prerequisite and provider bytes; writes fresh proposal only, no compiler/provider commands or WORK controller.',
  identity_limitation='Popen PID, parent, launch command/directory and times; no contemporaneous ps/cwd probes.',workload_children=0)
 save(record)
 with (WORK/'stdout').open('xb') as out,(WORK/'stderr').open('xb') as err:
  child=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  record.update(status='running',pid=child.pid,maximum_observation_seconds=MAXIMUM_OBSERVATION_SECONDS)
  try:
   try:save(record)
   except BaseException as error:record['initial_child_publication_error']=repr(error)
   try:
    code=child.wait(timeout=MAXIMUM_OBSERVATION_SECONDS)
   except subprocess.TimeoutExpired:
    code=None;record.update(status='observation-expired-task-not-signaled',may_be_live=True)
  finally:
   record.update(returncode=child.returncode,observation_finished_at=time.time(),stdout_sha256=sha(WORK/'stdout'),stderr_sha256=sha(WORK/'stderr'))
   if child.returncode is not None:record.update(status='finished',finished_at=time.time())
   else:record.update(status='unclosed-task-not-signaled',may_be_live=True)
   try:save(record)
   except BaseException as error:
    print(json.dumps(dict(status='publication-failed',error=repr(error),observed_record=record)),flush=True)
    raise
 print(json.dumps(dict(record=str(WORK/'record.json'),sha256=sha(WORK/'record.json'),pid=child.pid,returncode=code)))
 if code is None:raise RuntimeError('Preparation may still be live; no signal or retry authorized by this observation')
 if code:raise SystemExit(code)
 if 'initial_child_publication_error' in record:raise RuntimeError('Preparation completed but initial child record publication failed; inspect retained evidence')
 for name,h in SOURCES.items():assert sha(HERE/name)==h,name
 assert not NEXT_WORK.exists() and not NEXT_WORK.is_symlink()
 assert not NEXT_ARTIFACTS.exists() and not NEXT_ARTIFACTS.is_symlink()
if __name__=='__main__':main()
