"""Unrun draft for one independently reviewed saved-evidence audit.

Supply the actual adapter qualification and four closure digests only after
their respective completed controls and original driver have closed.
No compiler, driver, provider probe, retry, or process signal is performed here.
"""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import stat
import subprocess
import sys
import time

ROOT = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
X = Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
HERE = ROOT/'experiments/hir-options-hash-driver-stage-03'
SELF = ROOT/'.work/execute_hash_driver_saved_evidence_audit_02.py'
WORK = ROOT/'.work/hir-options-hash-driver-02'
OUTER = ROOT/'.work/experiments/hir-options-hash-driver-supervisor-02'
LAUNCHER = ROOT/'.work/hash-driver-launch-execution-02'
E = ROOT/'.work/hash-driver-independent-verification-execution-02'
REPORT = ROOT/'.work/hir-options-hash-driver-independent-verification-02.json'
PYTHON = Path('/opt/homebrew/Cellar/python@3.14/3.14.7/Frameworks/Python.framework/Versions/3.14/bin/python3.14')
PYTHON_SHA256 = '87d4df53fd91304be5bac391fb204643c36b7df2023c04a0953bcbc7d4fdf634'
OWNED = X/'experiments/stable-cgu/owned_stage.py'
OWNED_SHA256 = '7021a15d3b806ab908f03276051d9d9ca9c9e208bbf8933a60229c9fb35bb68e'
# The successor is a separately reviewed auditor, never an old workload input.
AUDITOR = HERE/'verify.py'
AUDITOR_SHA256 = '1e269c13aa473bbb3602a42793cecf4524b8d8223b185ceb4b9009cf72c46416'
QUALIFIED_AUDITOR = ROOT/'experiments/hir-options-hash-driver-audit-02/verify.py'
QUALIFIED_AUDITOR_SHA256 = '9e3e3291d168f3ac69d4bba4bf047212d53eb2eb485218df4b5f819f1601daf0'
ORIGINAL_VERIFIER = ROOT/'experiments/hir-options-hash-driver-stage-02/verify.py'
ORIGINAL_VERIFIER_SHA256 = 'cbff690675b8697855bb87b0e09d9b77495fc0b8968855301e1a88612ec62a3f'
ADAPTER_TEST = QUALIFIED_AUDITOR.with_name('test_inherited_records.py')
ADAPTER_TEST_SHA256 = '694cc68445209b82a7d5e59af0d94302661e1717deb58f0206fa6c6577052b9e'
CONTROL_SOURCE = ROOT/'experiments/hash-inherited-record-controls-01'
CONTROL_WORK = ROOT/'.work/hash-inherited-record-controls-01'
CONTROL_AUDIT = ROOT/'.work/hash-inherited-record-controls-independent-verification-01.json'
CONTINUATION_SOURCE = ROOT/'experiments/hash-continuation-controls-01'
CONTINUATION_WORK = ROOT/'.work/hash-continuation-controls-01'
CONTINUATION_AUDIT = ROOT/'.work/hash-continuation-controls-independent-verification-01.json'
CONTINUATION_AUDIT_SHA256 = 'c0d5f127f802d9369ebcfb53f3658fda143aa35e7df641792ab483cb3f6b6a41'
FAILED_AUDIT = ROOT/'.work/hir-options-hash-driver-failure-verification-01.json'
FAILED_AUDIT_SHA256 = 'ee81a129d5d1742074619ea31b75ad06512abd110dd102dc0ac8bec8c3eda8b3'
FAILED_SOURCE = ROOT/'experiments/hir-options-hash-driver-stage-02'
FAILED_WORK = ROOT/'.work/hir-options-hash-driver-01'
PACKET_AUDIT = X/'.work/hash-driver-packet-verification-06.json'
PACKET_AUDIT_SHA256 = '575ba8744b332c3fc1df0eb2653b20a541aefca58bd69a8edc92170f5ec6d01d'
PACKET_EXECUTION = X/'.work/hash-driver-packet-review-execution-06/record.json'
PACKET_EXECUTION_SHA256 = '7ffede503881d2b66e6205905bcbd45e4cd3cba793b8250cbee738bc616607b8'
PACKET = {'launch.json': '64989ae26d8824704150c76b3a3de8bc28f19a0c2e913fe019f7748e08abaf99', 'inputs.json': 'c06e016829f0c98e579aace635ded04858ac8890ebe43bb6014d1f4df52aa010', 'plan.json': '24faa0611eacda26748727e443bef844c695c3ed362cda75b5aa60223e4d6055', 'snapshot-plan.json': 'cee68b8a0a51c25fca1040819ff330b887ea841636606e7a4c4fce74381cbad9', 'verify.py': '1e269c13aa473bbb3602a42793cecf4524b8d8223b185ceb4b9009cf72c46416', 'launch.py': '67754c8e39377ceec8cbb31d8f3079e82f369842582641de5d597afa52e84d20'}
MAXIMUM_OBSERVATION_SECONDS = 1800
MAXIMUM_CPU_SECONDS = 900
MAXIMUM_OUTPUT_FILE_BYTES = 16*2**20


def require(value, message):
    if not value:
        raise RuntimeError(message)


def stamp(path):
    value = Path(path).lstat()
    return tuple(getattr(value, 'st_'+key) for key in
                 ['dev', 'ino', 'mode', 'nlink', 'size', 'mtime_ns', 'ctime_ns'])


def data(path, maximum=64*2**20):
    path = Path(path); before = stamp(path)
    require(path.resolve(strict=True) == path and stat.S_ISREG(before[2])
            and before[4] <= maximum, 'bounded ordinary input required: '+str(path))
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), 'rb') as stream:
        opened = os.fstat(stream.fileno())
        require((opened.st_dev, opened.st_ino) == before[:2], 'opened input changed')
        value = stream.read(maximum+1)
    require(len(value) == before[4] and len(value) <= maximum and stamp(path) == before,
            'read input changed or exceeded bound')
    return value


def sha(path):
    return hashlib.sha256(data(path)).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def read(path):
    return json.loads(data(path), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def qualification(expected_audit):
    require(sha(CONTROL_AUDIT) == expected_audit, 'exact accepted adapter qualification audit required')
    audit = read(CONTROL_AUDIT); freeze = read(CONTROL_SOURCE/'inputs.json')
    receipt = read(CONTROL_WORK/'receipt.json'); result = read(CONTROL_WORK/'result.json')
    require(type(freeze['files']) is dict and len(freeze['files']) <= 64
            and sum(row['stamp'][3] for row in freeze['files'].values()) <= 16*2**20,
            'bounded complete pure-control input closure required')
    for name, row in freeze['files'].items():
        path = Path(name); before = stamp(path)
        require(list(before[i] for i in [0, 1, 2, 4, 5, 6, 3]) == row['stamp']
                and sha(path) == row['sha256'] and stamp(path) == before,
                'qualified adapter input changed')
    for name, resolved in freeze['routes'].items():
        require(str(Path(name).resolve(strict=True)) == resolved, 'adapter input route changed')
    for path, digest in [(QUALIFIED_AUDITOR, QUALIFIED_AUDITOR_SHA256), (ADAPTER_TEST, ADAPTER_TEST_SHA256)]:
        require(freeze['files'][str(path)]['sha256'] == digest == sha(path), 'actual tested adapter bytes differ')
    names = []
    for node in ast.parse(data(ADAPTER_TEST), filename=str(ADAPTER_TEST)).body:
        if isinstance(node, ast.ClassDef):
            names.extend(ADAPTER_TEST.stem+'.'+node.name+'.'+item.name for item in node.body
                         if isinstance(item, ast.FunctionDef) and item.name.startswith('test_'))
    require(len(names) == len(set(names)) == 22 and sorted(names) == freeze['expected_names'] == result['expected_names']
            and sorted(names) == sorted(audit['exact_names']), 'exact actual adapter22 names required')
    require(receipt['status'] == result['status'] == 'passed' and receipt['controls_passed'] == result['tests_run'] == 22
            and audit['status'] == 'verified' and audit['controls'] == 22
            and receipt['inputs_sha256'] == sha(CONTROL_SOURCE/'inputs.json')
            and receipt['result_sha256'] == audit['result_sha256'] == sha(CONTROL_WORK/'result.json')
            and audit['receipt_sha256'] == sha(CONTROL_WORK/'receipt.json')
            and all(result[key] == 0 for key in ['failures', 'errors', 'skipped', 'expected_failures',
                                               'unexpected_successes', 'child_processes', 'compiler_calls']),
            'passed independently audited adapter controls required')
    child_path = CONTROL_WORK/'command/receipt.json'; child = read(child_path)
    require(receipt['commands'] == [dict(path=str(child_path), pid=child['pid'], sha256=sha(child_path))]
            and child['status'] == 'finished' and child['returncode'] == 0
            and child['command'] == freeze['command'] and child['environment'] == freeze['environment']
            and child['cwd'] == str(QUALIFIED_AUDITOR.parent) and child['supervisor_pid'] == receipt['pid'],
            'actual adapter child owner/recipe differs')
    for stream in ['stdout', 'stderr']:
        require(child[stream+'_sha256'] == audit['raw_sha256'][stream] == sha(CONTROL_WORK/'command'/stream),
                'actual adapter raw differs')
    return dict(audit=dict(path=str(CONTROL_AUDIT), sha256=expected_audit), controls=22,
                receipt_sha256=audit['receipt_sha256'], result_sha256=audit['result_sha256'],
                inputs_sha256=receipt['inputs_sha256'], tested_reader=dict(path=str(QUALIFIED_AUDITOR), sha256=QUALIFIED_AUDITOR_SHA256))


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)+'\n').encode()


def auditor_association():
    require(sha(AUDITOR) == AUDITOR_SHA256 and sha(QUALIFIED_AUDITOR) == QUALIFIED_AUDITOR_SHA256
            and sha(ORIGINAL_VERIFIER) == ORIGINAL_VERIFIER_SHA256, 'exact separate auditor source associations')
    functions = lambda p: {node.name: ast.dump(node, include_attributes=False)
        for node in ast.parse(data(p), filename=str(p)).body if isinstance(node, ast.FunctionDef)}
    original, qualified, current = map(functions, [ORIGINAL_VERIFIER, QUALIFIED_AUDITOR, AUDITOR])
    require(set(qualified)-set(original) == {'canonical_inherited_record'} and set(original) <= set(qualified)
            and {name for name in original if original[name] != qualified[name]} == {'inherited_inputs', 'main'},
            'original strict inherited22 correction association')
    require(set(current)-set(qualified) == {'complete_plan', 'continuation_qualification', 'driver_derivation',
                'failed_owner_history', 'historical_commands', 'retained_failed_snapshots', 'verify_original_snapshot_catalog'}
            and set(qualified) <= set(current)
            and {name for name in qualified if qualified[name] != current[name]} == {'main', 'verify_snapshot_catalog'},
            'reviewed continuation-only auditor change')
    require(original['complete_file_table'] == current['complete_file_table']
            and qualified['canonical_inherited_record'] == current['canonical_inherited_record']
            and qualified['inherited_inputs'] == current['inherited_inputs'], 'unchanged actually tested reader functions')
    return dict(current=dict(path=str(AUDITOR), sha256=AUDITOR_SHA256),
        qualified_reader=dict(path=str(QUALIFIED_AUDITOR), sha256=QUALIFIED_AUDITOR_SHA256),
        original=dict(path=str(ORIGINAL_VERIFIER), sha256=ORIGINAL_VERIFIER_SHA256),
        unchanged_reader_functions=['complete_file_table', 'canonical_inherited_record', 'inherited_inputs'])


def continuation_proofs():
    require(sha(CONTINUATION_AUDIT) == CONTINUATION_AUDIT_SHA256, 'actual70 audit changed')
    inputs = read(CONTINUATION_SOURCE/'inputs.json'); launch = read(CONTINUATION_SOURCE/'launch.json')
    terminal = read(CONTINUATION_WORK/'receipt.json'); result = read(CONTINUATION_WORK/'result.json')
    audit = read(CONTINUATION_AUDIT); child = read(CONTINUATION_WORK/'command/receipt.json')
    require(len(inputs['files']) == 45 and sum(row['stamp'][3] for row in inputs['files'].values()) == 1012724,
            'complete actual70 bounded input closure')
    for name, row in inputs['files'].items():
        before = stamp(name)
        require([before[i] for i in [0, 1, 2, 4, 5, 6, 3]] == row['stamp']
                and sha(name) == row['sha256'] and stamp(name) == before, 'actual70 input bytes/identity changed')
    for name, target in inputs['routes'].items():
        require(str(Path(name).resolve(strict=True)) == target and target in inputs['files'], 'actual70 executable route')
    catalog = ROOT/'experiments/completed-proof-snapshot-catalog-02/catalog.py'
    reference = HERE/'plan_reference.py'
    tests = [catalog.with_name('test_catalog.py'), catalog.with_name('test_failed_catalog.py'), reference.with_name('test_plan_reference.py')]
    names = []
    for test in tests:
        for cls in ast.parse(data(test), filename=str(test)).body:
            if isinstance(cls, ast.ClassDef):
                names.extend(test.stem+'.'+cls.name+'.'+method.name for method in cls.body
                             if isinstance(method, ast.FunctionDef) and method.name.startswith('test_'))
    names = sorted(names)
    require(len(names) == len(set(names)) == 70 and names == inputs['expected_names'] == result['expected_names']
            == sorted(audit['exact_names']), 'all70 actual source-derived identities')
    require(terminal['status'] == result['status'] == 'passed' and audit['status'] == 'verified'
            and all(type(n) is int and n == 70 for n in [terminal['controls_passed'], result['tests_run'], audit['controls'], launch['controls']])
            and terminal['inputs_sha256'] == launch['inputs_sha256'] == sha(CONTINUATION_SOURCE/'inputs.json')
            and terminal['result_sha256'] == audit['result_sha256'] == sha(CONTINUATION_WORK/'result.json')
            and audit['receipt_sha256'] == sha(CONTINUATION_WORK/'receipt.json'), 'closed actual70 qualification')
    require(all(type(result[k]) is int and result[k] == 0 for k in ['failures', 'errors', 'skipped', 'expected_failures',
                'unexpected_successes', 'child_processes', 'compiler_calls']), 'no omitted pure controls')
    require(terminal['commands'] == [dict(path=str(CONTINUATION_WORK/'command/receipt.json'), pid=child['pid'],
                sha256=sha(CONTINUATION_WORK/'command/receipt.json'))]
            and child['status'] == 'finished' and child['returncode'] == 0 and child['command'] == inputs['command']
            and child['environment'] == inputs['environment'] and child['cwd'] == str(catalog.parent)
            and child['supervisor_pid'] == terminal['pid'] and child['parent_pid'] == terminal['parent_pid']
            and terminal['admitted_at'] <= child['started_at'] <= child['finished_at'] <= terminal['finished_at'],
            'actual70 child/raw history association')
    for stream in ['stdout', 'stderr']:
        require(sha(CONTINUATION_WORK/'command'/stream) == child[stream+'_sha256'] == audit['raw_sha256'][stream], 'actual70 raw')
    stderr = data(CONTINUATION_WORK/'command/stderr').decode('utf-8')
    actual = re.findall(r'^test_[A-Za-z0-9_]+ \(([^)]+)\) \.\.\. ok$', stderr, re.M)
    require(not data(CONTINUATION_WORK/'command/stdout') and sorted(actual) == names
            and re.search(r'^Ran 70 tests in [0-9.]+s\n\nOK\n$', stderr, re.M), 'all actual70 raw outcomes')
    proof = dict(controls=70, audit=dict(path=str(CONTINUATION_AUDIT), sha256=CONTINUATION_AUDIT_SHA256),
        inputs=dict(path=str(CONTINUATION_SOURCE/'inputs.json'), sha256=sha(CONTINUATION_SOURCE/'inputs.json')),
        receipt=dict(path=str(CONTINUATION_WORK/'receipt.json'), sha256=sha(CONTINUATION_WORK/'receipt.json')),
        result=dict(path=str(CONTINUATION_WORK/'result.json'), sha256=sha(CONTINUATION_WORK/'result.json')),
        sources={str(p): sha(p) for p in [catalog, reference, *tests]})
    require(sha(FAILED_AUDIT) == FAILED_AUDIT_SHA256, 'retained driver01 failure audit changed')
    failure = read(FAILED_AUDIT); failed = read(FAILED_WORK/'receipt.json')
    require(failure['status'] == 'verified-retained-failure' and failure['owner_status'] == failed['status'] == 'failed'
            and failure['source'] == str(FAILED_SOURCE) and failure['evidence'] == str(FAILED_WORK)
            and failure['receipt_sha256'] == sha(FAILED_WORK/'receipt.json')
            and failure['actual_compiler_children'] == failure['actual_children'] == 1
            and failure['actual_driver_processes'] == failure['qualified_hash_driver_processes'] == 0,
            'original failed workload remains unqualified')
    owner = dict(role='failed-hash-driver-01', source=str(FAILED_SOURCE), evidence=str(FAILED_WORK),
                 audit=dict(path=str(FAILED_AUDIT), sha256=FAILED_AUDIT_SHA256))
    require(type(PACKET_AUDIT_SHA256) is str and re.fullmatch('[a-f0-9]{64}', PACKET_AUDIT_SHA256)
            and sha(PACKET_AUDIT) == PACKET_AUDIT_SHA256 and sha(PACKET_EXECUTION) == PACKET_EXECUTION_SHA256,
            'actual independent prepared-packet06 audit required')
    packet = read(PACKET_AUDIT); execution = read(PACKET_EXECUTION)
    require(packet['status'] == 'verified-prepared-unrun' and packet['workload_children'] == 0
            and execution['status'] == 'finished' and execution['returncode'] == 0
            and execution['result_sha256'] == PACKET_AUDIT_SHA256
            and execution['pid'] == packet['pid'] == 41705 and execution['parent_pid'] == packet['parent_pid'] == 40992
            and execution['finished_at'] <= execution['canonical_released_at']
            and packet['continuation_verifier'] == dict(path=str(AUDITOR), sha256=AUDITOR_SHA256),
            'actual packet06 identity and closure')
    for name, key in [('launch.json', 'launch_sha256'), ('inputs.json', 'inputs_sha256'),
                      ('plan.json', 'plan_sha256'), ('snapshot-plan.json', 'snapshot_plan_sha256')]:
        require(packet[key] == PACKET[name], 'packet06 exactly qualifies current prepared input')
    for stream in ['stdout', 'stderr']:
        require(sha(PACKET_EXECUTION.parent/stream) == execution[stream+'_sha256'], 'packet06 execution raw changed')
    require(encoded(packet['continuation_controls']) == encoded(proof)
            and packet['failed_predecessor'] == dict(owner=owner, receipt_sha256=sha(FAILED_WORK/'receipt.json'),
                actual_children=1, qualified_children=0), 'packet06 retained continuation and failure associations')
    return dict(continuation_controls=proof, failed_owner=owner,
        failed_receipt_sha256=sha(FAILED_WORK/'receipt.json'),
        packet_audit=dict(path=str(PACKET_AUDIT), sha256=PACKET_AUDIT_SHA256),
        packet_execution=dict(path=str(PACKET_EXECUTION), sha256=PACKET_EXECUTION_SHA256))


def closure(expected):
    for name, digest in PACKET.items():
        require(sha(HERE/name) == digest, 'reviewed packet/source changed: '+name)
    for path, digest in expected.items():
        require(sha(path) == digest, 'actual saved closure changed: '+str(path))
    require(sha(AUDITOR) == AUDITOR_SHA256 and sha(OWNED) == OWNED_SHA256,
            'reviewed auditor or admission helper changed')
    auditor_association(); proofs = continuation_proofs()
    proposal = read(HERE/'launch.json'); terminal = read(WORK/'receipt.json')
    result = read(WORK/'result.json'); outer = read(OUTER/'status.json')
    launch = read(LAUNCHER/'record.json')
    wire_plan = read(HERE/'plan.json')
    require(wire_plan['policy'] == 'external-json-member-v1' and wire_plan['member'] == 'metadata_plan'
            and all(encoded(value['continuation_controls']) == encoded(proofs['continuation_controls'])
                and encoded(value['failed_driver']) == encoded(proofs['failed_owner'])
                for value in [wire_plan['remainder'], terminal, result]), 'actual continuation plan/terminal/result associations')
    require(terminal['status'] == 'passed-awaiting-independent-audit'
            and result['status'] == 'hash-driver-observations-passed-awaiting-independent-audit'
            and terminal['result_sha256'] == expected[WORK/'result.json']
            and terminal['inputs_sha256'] == proposal['inputs_sha256'] == PACKET['inputs.json']
            and terminal['snapshot_plan_sha256'] == proposal['snapshot_plan_sha256'] == PACKET['snapshot-plan.json']
            and proposal['plan_sha256'] == PACKET['plan.json']
            and proposal['expected_children'] == 3 and proposal['driver_processes'] == 2
            and proposal['contexts_per_process'] == 8, 'passed exact three-child stage required')
    require(outer['status'] == 'finished' and type(outer['returncode']) is int and outer['returncode'] == 0
            and outer['child_pid'] == terminal['pid'] and outer['supervisor_pid'] == terminal['parent_pid']
            and outer['command'] == proposal['command'][6:] and outer['cwd'] == str(ROOT)
            and outer['plan_sha256'] == sha(OUTER/'plan.json')
            and outer['log_sha256'] == sha(OUTER/'command.log'), 'actual outer closure required')
    require(outer['child_started_at'] <= terminal['started_at'] <= terminal['admitted_at']
            <= terminal['finished_at'] <= outer['finished_at'], 'original owner timing differs')
    require(launch['status'] == 'terminal-observed'
            and type(launch['returncode']) is int and launch['returncode'] == 0
            and type(launch['launcher_returncode']) is int and launch['launcher_returncode'] == 0
            and launch['outer_sha256'] == expected[OUTER/'status.json']
            and launch['launch_sha256'] == PACKET['launch.json']
            and launch['command'] == proposal['command'] and launch['cwd'] == str(ROOT)
            and launch['environment'] == proposal['environment']
            and launch['launcher_source_path'] == str(HERE/'launch.py')
            and launch['launcher_source_sha256'] == PACKET['launch.py']
            and launch['started_at'] <= launch['launcher_finished_at'] <= launch['finished_at']
            and outer['finished_at'] <= launch['terminal_observed_at'] <= launch['finished_at'],
            'explicit successful launcher closure required')
    for stream in ['stdout', 'stderr']:
        require(sha(LAUNCHER/stream) == launch[stream+'_sha256'], 'launcher raw changed')
    handoff = read(LAUNCHER/'stdout')
    require(handoff == launch['supervisor_handoff'] and handoff['directory'] == str(OUTER)
            and handoff['supervisor_pid'] == outer['supervisor_pid'] == launch['supervisor_pid']
            and launch['controller_pid'] == terminal['pid'], 'actual launcher handoff differs')
    return proposal


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--adapter-audit-sha256', required=True)
    for name in ['receipt', 'result', 'outer', 'launcher-record']:
        parser.add_argument('--'+name+'-sha256', required=True)
    args = parser.parse_args()
    require(isinstance(AUDITOR, Path) and AUDITOR.is_absolute()
            and type(AUDITOR_SHA256) is str and re.fullmatch('[a-f0-9]{64}', AUDITOR_SHA256),
            'unbound draft: a reviewed saved-audit successor must be pinned first')
    require(Path.cwd() == ROOT and Path(__file__) == SELF and sys.argv[0] == str(SELF)
            and sys.dont_write_bytecode and not sys.flags.optimize
            and Path(sys.executable).resolve(strict=True) == PYTHON and sha(PYTHON) == PYTHON_SHA256,
            'exact explicit wrapper/interpreter invocation required')
    expected = {WORK/'receipt.json': args.receipt_sha256, WORK/'result.json': args.result_sha256,
                OUTER/'status.json': args.outer_sha256, LAUNCHER/'record.json': args.launcher_record_sha256}
    require(all(re.fullmatch('[a-f0-9]{64}', value) for value in expected.values()),
            'four explicit observed actual closure digests required')
    require(re.fullmatch('[a-f0-9]{64}', args.adapter_audit_sha256), 'explicit actual adapter qualification digest required')
    adapter = qualification(args.adapter_audit_sha256)
    association = auditor_association(); proofs = continuation_proofs()
    proposal = closure(expected)
    require(all(not path.exists() and not path.is_symlink() for path in [E, REPORT]),
            'fresh audit execution/report namespaces required')
    require(E.parent.resolve(strict=True) == E.parent and shutil.disk_usage(ROOT).free >= 16*2**30,
            'fresh ordinary owner and 16 GiB required before audit evidence creation')
    spec = importlib.util.spec_from_file_location('hash_saved_audit_owned', OWNED)
    owned = importlib.util.module_from_spec(spec); spec.loader.exec_module(owned)
    E.mkdir(mode=0o700)
    for name, path in [('auditor.py', AUDITOR), ('execution.py', SELF), ('owned_stage.py', OWNED),
                       ('qualified-reader.py', QUALIFIED_AUDITOR), ('original-verifier.py', ORIGINAL_VERIFIER),
                       ('continuation70-audit.json', CONTINUATION_AUDIT), ('failed-driver-audit.json', FAILED_AUDIT),
                       ('packet06-audit.json', PACKET_AUDIT), ('packet06-execution.json', PACKET_EXECUTION)]:
        with (E/name).open('xb') as stream:
            stream.write(data(path)); stream.flush(); os.fsync(stream.fileno())
        require(sha(E/name) == sha(path), 'retained execution source differs')
    command = [str(PYTHON), '-B', str(AUDITOR), '--launch-sha256', PACKET['launch.json'],
               '--launcher-record', str(LAUNCHER/'record.json')]
    record = dict(status='waiting', started_at=time.time(), parent_pid=os.getpid(),
        supervisor_parent_pid=os.getppid(), command=command, cwd=str(ROOT), environment=proposal['environment'],
        actual_closure={str(path): digest for path, digest in expected.items()}, packet_sha256=PACKET,
        adapter_qualification=adapter, auditor_source_association=association, continuation_proofs=proofs,
        source_path=str(AUDITOR), source_sha256=AUDITOR_SHA256, execution_source_sha256=sha(SELF),
        owned_source_sha256=OWNED_SHA256, canonical_lock=str(owned.CANONICAL_LOCK), wait_seconds=600,
        maximum_observation_seconds=MAXIMUM_OBSERVATION_SECONDS, maximum_cpu_seconds=MAXIMUM_CPU_SECONDS,
        maximum_output_file_bytes=MAXIMUM_OUTPUT_FILE_BYTES, capacity=dict(entry_gib=16, stop_gib=9, floor_gib=8),
        parent_identity=dict(source='in-process observation', pid=os.getpid(), parent_pid=os.getppid(),
                             pgid=os.getpgrp(), cwd=os.getcwd(), argv=sys.argv),
        identity_limitation='Popen PID and in-process parent retained; no separate child ps/cwd probes or signals.',
        mode='one saved-evidence auditor child; zero compiler, provider-probe or driver workload children', disk_samples=[])

    def save():
        owned.write(E/'record.json', record)

    save()
    try:
        with owned.workload_lock(owned.CANONICAL_LOCK, 600) as fd:
            record.update(admitted_at=time.time(), free_bytes_before=owned.disk(ROOT, 16)); save()
            require(qualification(args.adapter_audit_sha256) == adapter, 'adapter qualification changed before child')
            closure(expected)
            require(sha(SELF) == sha(E/'execution.py') and sha(AUDITOR) == sha(E/'auditor.py')
                    and not REPORT.exists() and not REPORT.is_symlink(), 'audit source/report changed before child')
            resource.setrlimit(resource.RLIMIT_CPU, (MAXIMUM_CPU_SECONDS, MAXIMUM_CPU_SECONDS))
            resource.setrlimit(resource.RLIMIT_FSIZE, (MAXIMUM_OUTPUT_FILE_BYTES, MAXIMUM_OUTPUT_FILE_BYTES))
            with (E/'stdout').open('xb') as stdout, (E/'stderr').open('xb') as stderr:
                child = subprocess.Popen(command, cwd=ROOT, env=proposal['environment'], stdin=subprocess.DEVNULL,
                                         stdout=stdout, stderr=stderr, pass_fds=(fd,))
                record.update(status='running', pid=child.pid, child_started_at=time.time())
                publication_errors = []
                def observe():
                    try:
                        save()
                    except BaseException as error:
                        publication_errors.append(repr(error))
                observe(); deadline = time.monotonic()+MAXIMUM_OBSERVATION_SECONDS
                while True:
                    try:
                        code = child.wait(timeout=min(1, max(.001, deadline-time.monotonic()))); break
                    except subprocess.TimeoutExpired:
                        record['disk_samples'].append(dict(time=time.time(), free_bytes=shutil.disk_usage(ROOT).free))
                        observe()
                        if time.monotonic() >= deadline:
                            record.update(status='unresolved-live-child-not-signaled', observation_finished_at=time.time(),
                                          publication_errors=publication_errors)
                            save(); raise
            record.update(status='finished', returncode=code, finished_at=time.time(), publication_errors=publication_errors,
                          stdout_sha256=sha(E/'stdout'), stderr_sha256=sha(E/'stderr'),
                          free_bytes_after=shutil.disk_usage(ROOT).free)
            save()
            require(code == 0 and not data(E/'stderr') and not publication_errors, 'auditor did not close cleanly')
            require(record['free_bytes_after'] >= 9*2**30
                    and all(row['free_bytes'] >= 9*2**30 for row in record['disk_samples']), 'audit live capacity was breached')
            closure(expected)
            require(qualification(args.adapter_audit_sha256) == adapter, 'adapter qualification changed during audit')
            require(sha(SELF) == sha(E/'execution.py') and sha(AUDITOR) == sha(E/'auditor.py'), 'audit source changed')
            result = read(REPORT); output = read(E/'stdout')
            require(result['status'] == 'verified' and result['receipt_sha256'] == args.receipt_sha256
                    and result['result_sha256'] == args.result_sha256 and result['launch_sha256'] == PACKET['launch.json']
                    and result['verifier_sha256'] == AUDITOR_SHA256 and result['actual_children'] == 3
                    and result['original_verifier'] == dict(path=str(ORIGINAL_VERIFIER), sha256=ORIGINAL_VERIFIER_SHA256)
                    and result['historical_failed_compiler_children'] == 1 and result['total_actual_hash_children'] == 4
                    and encoded(result['continuation_controls']) == encoded(proofs['continuation_controls'])
                    and result['failed_predecessor'] == dict(owner=proofs['failed_owner'],
                        receipt_sha256=proofs['failed_receipt_sha256'], actual_children=1, qualified_children=0)
                    and result['metadata_plan_reference'] == read(HERE/'plan.json')['reference']
                    and result['contexts_per_process'] == 8 and result['hash_driver_qualified'] is True
                    and result['application_qualified'] is False and result['performance_measurement'] is False
                    and output == dict(path=str(REPORT), sha256=sha(REPORT), actual_children=3, contexts_per_process=8),
                    'complete independent report/output association required')
            record.update(verified_output=output, report_sha256=sha(REPORT)); save()
        record['canonical_released_at'] = time.time(); save()
        print(json.dumps(record, sort_keys=True))
    except BaseException as error:
        record['execution_error'] = repr(error); save(); raise


if __name__ == '__main__':
    main()
