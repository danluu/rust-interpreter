"""One bounded read-only packet audit; explicit wait, no signals or workloads."""
import hashlib, importlib.util, json, os, shutil, subprocess, sys, time
from pathlib import Path
O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
R=Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
P=Path('/opt/homebrew/Cellar/python@3.14/3.14.7/Frameworks/Python.framework/Versions/3.14/bin/python3.14')
AUDITOR=X/'.work/verify_hash_driver_packet_06.py'
E=X/'.work/hash-driver-packet-review-execution-06'
RESULT=X/'.work/hash-driver-packet-verification-06.json'
H=R/'experiments/hir-options-hash-driver-stage-03'
OLD_H=R/'experiments/hir-options-hash-driver-stage-02'
OWNED=X/'experiments/stable-cgu/owned_stage.py'
CORRECTED=R/'experiments/hir-options-hash-driver-audit-02/verify.py'
QUALIFICATION=R/'.work/hash-inherited-record-controls-independent-verification-01.json'
CONTINUATION=R/'.work/hash-continuation-controls-independent-verification-01.json'
FAILURE=R/'.work/hir-options-hash-driver-failure-verification-01.json'
EXPECTED=None  # Bind exact auditor, packet, preparation and reviewed sources after source review.
def require(ok,message):
 if not ok:raise RuntimeError(message)
def sha(path):
 path=Path(path);before=path.stat();require(path.resolve(strict=True)==path and path.is_file() and before.st_size<=64*2**20,'bounded ordinary wrapper input')
 with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 after=path.stat();require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),'wrapper input changed')
 return digest
def sources():
 require(type(EXPECTED) is dict and EXPECTED and all(type(digest) is str and len(digest)==64 for digest in EXPECTED.values()),'unbound exact audit wrapper inputs')
 for path,digest in EXPECTED.items():require(sha(path)==digest,'reviewed exact wrapper input: '+str(path))
require(Path.cwd()==X and sys.dont_write_bytecode and not sys.flags.optimize and Path(sys.executable).resolve()==P,'fixed Python/owner')
require(not E.exists() and not E.is_symlink() and not RESULT.exists() and not RESULT.is_symlink(),'fresh audit evidence/result')
sources();entry=shutil.disk_usage(X).free;require(entry>=16*2**30,'fresh16GiB before audit evidence/child')
spec=importlib.util.spec_from_file_location('_packet06_owned',OWNED);owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
E.mkdir(mode=0o700);(E/'source').mkdir(mode=0o700)
for source,name in [(AUDITOR,'audit.py'),(CORRECTED,'corrected-verify.py'),(QUALIFICATION,'inherited22-audit.json'),(OLD_H/'verify.py','original-verify.py'),(H/'verify.py','continuation-verify.py'),(CONTINUATION,'continuation70-audit.json'),(FAILURE,'failed-driver-audit.json'),(OWNED,'owned_stage.py'),(Path(__file__).resolve(),'execution.py')]:
 before=sha(source);data=source.read_bytes();require(hashlib.sha256(data).hexdigest()==before,'retained wrapper source differs')
 with (E/'source'/name).open('xb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
 require(sha(source)==before==sha(E/'source'/name),'stable exact retained source')
env=dict(HOME='/Users/danluu',USER='danluu',LOGNAME='danluu',LANG='C',LC_ALL='C',TZ='UTC',PATH='/usr/bin:/bin:/usr/sbin:/sbin',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
r=dict(status='waiting',started_at=time.time(),parent_pid=os.getpid(),parent_parent_pid=os.getppid(),cwd=str(X),environment=env,
 canonical_lock=str(owned.CANONICAL_LOCK),wait_seconds=600,capacity=dict(entry_gib=16,stop_gib=9,floor_gib=8),
 maximum_child_cpu_seconds=900,maximum_child_read_seconds=1200,maximum_observation_seconds=1250,maximum_file_bytes=4*2**20,
 source_hashes={str(k):v for k,v in EXPECTED.items()},execution_source_sha256=sha(__file__),entry_free_bytes=entry,disk_samples=[],
 scope='One read-only prepared packet review; zero compiler/provider/controller/workload calls.',
 identity_limitation='In-process parent identity plus Popen PID/argv/environment/cwd/times; no external ps/cwd probes and no signals.')
def save():owned.write(E/'record.json',r)
save()
try:
 with owned.workload_lock(owned.CANONICAL_LOCK,600) as fd:
  sources();r.update(admitted_at=time.time(),free_bytes_before=owned.disk(X,16));save()
  command=[str(P),'-B',str(AUDITOR),'--canonical-fd',str(fd)];r['command']=command;save()
  with (E/'stdout').open('xb') as stdout,(E/'stderr').open('xb') as stderr:
   child=subprocess.Popen(command,cwd=X,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,pass_fds=(fd,))
   r.update(status='running',pid=child.pid,child_started_at=time.time());deadline=time.monotonic()+1250
   try:
    try:save()
    except BaseException as error:r['initial_child_publication_error']=repr(error)
    while True:
     try:code=child.wait(timeout=min(5,max(.001,deadline-time.monotonic())));break
     except subprocess.TimeoutExpired:
      r['disk_samples'].append(dict(time=time.time(),free_bytes=shutil.disk_usage(X).free))
      if time.monotonic()>=deadline:
       r.update(status='observation-expired-task-not-signaled',may_be_live=True);code=None;break
   finally:
    r.update(returncode=child.returncode,observation_finished_at=time.time(),stdout_sha256=sha(E/'stdout'),stderr_sha256=sha(E/'stderr'))
    if child.returncode is not None:r.update(status='finished',finished_at=time.time())
    else:r.update(status='unclosed-task-not-signaled',may_be_live=True)
    try:save()
    except BaseException as error:
     print(json.dumps(dict(status='publication-failed',error=repr(error),observed_record=r)),flush=True);raise
  require(code is not None,'audit may still be live; no signal or retry')
  require(code==0,'actual packet audit failed; preserve evidence')
  require(not (E/'stderr').read_bytes(),'audit emitted stderr')
  require('initial_child_publication_error' not in r,'audit initial record publication failed')
  sources();r.update(result_sha256=sha(RESULT),free_bytes_after=owned.disk(X,9));save()
  require(all(row['free_bytes']>=9*2**30 for row in r['disk_samples']),'observed live-floor violation')
 r['canonical_released_at']=time.time();save()
 print(json.dumps(dict(record=str(E/'record.json'),record_sha256=sha(E/'record.json'),result=str(RESULT),result_sha256=r['result_sha256'],pid=r['pid'],returncode=0)),flush=True)
except BaseException as error:
 r['execution_error']=repr(error);save();raise
