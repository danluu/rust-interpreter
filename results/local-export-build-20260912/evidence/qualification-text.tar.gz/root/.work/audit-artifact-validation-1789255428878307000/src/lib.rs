fn value()->u64 { if cfg!(feature="other") {23} else {13} }
#[cfg(test)] mod tests {
    static STATE: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(9);
    #[test] fn good() { assert_eq!(super::value(),13); }
    #[test] fn panic_body() { panic!("RETAINED_PANIC_BODY"); }
    #[test] fn result_ok()->Result<(),u64> { Ok(()) }
    #[test] fn result_err()->Result<(),u64> { Err(17) }
    #[test] fn mutable_first() { assert_eq!(STATE.fetch_add(1,std::sync::atomic::Ordering::Relaxed),9); }
    #[test] fn mutable_second() { assert_eq!(STATE.load(std::sync::atomic::Ordering::Relaxed),10); }
    #[test] #[ignore = "fixture skip"] fn ignored_named() { panic!("IGNORED_FIXTURE"); }
    #[test] #[should_panic] fn expected_panic() { panic!("EXPECTED_FIXTURE"); }
    #[test] #[should_panic(expected = "NAMED_FIXTURE")] fn expected_named_panic() { panic!("NAMED_FIXTURE"); }
    #[test] #[cfg_attr(feature="other", ignore = "conditional skip")] fn conditional_ignore() {}
    #[test] #[cfg_attr(feature="other", should_panic(expected = "conditional"))] fn conditional_panic() { panic!("conditional"); }
    fn plain() {}
    #[test] fn unsupported() { unsafe extern "C" { fn getpid()->i32; } unsafe { let _=getpid(); } }
}
