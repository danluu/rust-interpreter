pub fn entry() -> u64 { 1 }
fn unused() { let mut x=1; let a=&mut x; let b=&mut x; *a+=*b; }
