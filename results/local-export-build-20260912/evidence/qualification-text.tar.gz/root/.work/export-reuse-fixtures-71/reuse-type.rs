pub fn entry() -> u64 { 1 }
fn unused() { let _: u64 = "wrong"; }
