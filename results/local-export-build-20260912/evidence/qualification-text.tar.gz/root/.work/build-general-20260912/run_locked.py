import fcntl, json, os, subprocess, sys, time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
work=Path(__file__).resolve().parent
label=sys.argv[1]
lock=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock').open('a')
deadline=time.monotonic()+300
while True:
 try:
  fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
  break
 except BlockingIOError:
  if time.monotonic()>=deadline:
   raise RuntimeError('benchmark lock unavailable after bounded wait; no other process controlled')
  time.sleep(1)
env=os.environ.copy()
for name in list(env):
 if name.startswith(('RUST_INTERP_', 'RUSTDEV_', 'CARGO_PROFILE_')) or name in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_INCREMENTAL','CARGO_TARGET_DIR','CARGO_BUILD_TARGET']:
  env.pop(name)
env.update(CARGO_INCREMENTAL='0', CARGO_TERM_COLOR='never')
command=sys.argv[2:]
record=dict(owner='build-general-20260912', cwd=str(root), command=command, controller_pid=os.getpid(), controller_ppid=os.getppid(), started_at=time.time())
with (work/(label+'.log')).open('x') as log:
 child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
 record['child_pid']=child.pid
 (work/(label+'.json')).write_text(json.dumps(record,indent=2))
 print(json.dumps(record),flush=True)
 code=child.wait()
record.update(returncode=code,finished_at=time.time())
(work/(label+'.json')).write_text(json.dumps(record,indent=2))
print('finished',label,code,flush=True)
sys.exit(code)
