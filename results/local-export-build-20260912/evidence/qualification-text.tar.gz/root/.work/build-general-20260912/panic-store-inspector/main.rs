//! Read and validate a retained fixture artifact for structural inspection.
//! Printing its operations is evidence, not by itself a data-flow proof.
use bincode::Options;
use rust_interp_bytecode::{Program, validate};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().skip(1).collect();
    if args.len() != 1 {
        return Err("usage: panic-store-inspector PROGRAM.rbc".into());
    }
    let bytes = std::fs::read(&args[0])?;
    if bytes.len() > 64 * 1024 * 1024 {
        return Err("fixture artifact exceeds inspection limit".into());
    }
    let program: Program = bincode::DefaultOptions::new()
        .with_fixint_encoding()
        .with_limit(64 * 1024 * 1024)
        .reject_trailing_bytes()
        .deserialize(&bytes)?;
    validate(&program)?;
    println!("{}", serde_json::to_string_pretty(&program)?);
    Ok(())
}
