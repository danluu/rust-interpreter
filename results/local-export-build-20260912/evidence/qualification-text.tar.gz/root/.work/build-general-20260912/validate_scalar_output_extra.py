from pathlib import Path
import hashlib, importlib.util, json, os, sys, time

root = Path(__file__).resolve().parents[2]
b = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ['audit', 'inline']
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
expected = json.loads((b / 'scalar-output-extra-inputs.json').read_text())
for name, digest in expected['files'].items(): assert sha(root / name) == digest, name
tools = json.loads((b / 'scalar-output-tools.json').read_text())
assert tools['tool_key'] == expected['candidate_tool_key']
baseline = json.loads((b / 'owned-analysis-tools.json').read_text())
assert baseline['tool_key'] == expected['baseline_tool_key']
for group in [tools, baseline]:
    for name, digest in group['binaries'].items(): assert sha(Path(group['directory']) / name) == digest, name
for name in ['rust-interp-vm', 'rust-interp-rustc-wrapper']: assert tools['binaries'][name] == baseline['binaries'][name]
name = {'audit': 'validate_audit_artifacts.py', 'inline': 'validate_leaf_inlining.py'}[mode]
sys.path.insert(0, str(root / 'scripts'))
spec = importlib.util.spec_from_file_location('scalar_output_extra_' + mode, root / 'scripts' / name)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.checked_tools = lambda: (Path(tools['directory']), tools['tool_key'])
path = b / ('scalar-output-' + mode + '-validation.json')
receipt = dict(mode=mode, script=name, source_sha256=sha(root / 'scripts' / name),
               tool_key=tools['tool_key'], binaries=tools['binaries'],
               controller_pid=os.getpid(), started_at=time.time())
with path.open('x') as f: json.dump(receipt, f, indent=2)
top = root / 'results/audit-artifact-validation.json'
saved = top.read_bytes() if mode == 'audit' and top.exists() else None
try:
    module.main()
    receipt.update(status='passed', finished_at=time.time())
    if mode == 'audit':
        summary = json.loads(top.read_text())
        assert summary['tool_key'] == tools['tool_key'] and summary['source_restored']
        (b / 'scalar-output-audit-top-level-validation.json').write_bytes(top.read_bytes())
        receipt['summary'] = summary
except BaseException as error:
    receipt.update(status='failed', error=repr(error), finished_at=time.time())
    raise
finally:
    if mode == 'audit':
        if saved is not None: top.write_bytes(saved)
        elif top.exists(): top.unlink()
    path.write_text(json.dumps(receipt, indent=2) + '\n')
