# Additional audit and inlining qualification before diagnostics

The core differential suite checks audit policy rejection. Because this candidate
also removes the immediate duplicate validation in the successful audit path,
run the existing complete audit-artifact and leaf-inline launcher validations
with the frozen candidate exporter and selected baseline VM/wrapper before any
diagnostic or adoption measurement. Both scripts and their assertions remain
unchanged; the task adapter only binds checked_tools to the installed candidate.
Keep all native comparisons, mixed lowered/blocked entries, metadata checks,
retained-body limits/provenance, fresh/cached/source/configuration/selection
transitions, strict frontend checks, inlining on/off and both execution engines.

Retain the script's full command archive and final receipt, plus the exact input
hashes and selected tool hashes. Preserve any existing top-level audit summary;
copy this run's summary to its own candidate evidence directory before restoring
the original bytes. A failure is terminal for this attempt and is preserved.
Do not alter tests to make a failure pass or substitute old successful receipts.

Run a further small paired audit export check of the existing Result fixture
with the candidate3 and candidate4 exporters: inlining off/on, retained bodies
off/on, the same source/selection and exact compiler options. Exclude only audit
elapsed times and generated pack directory names from report comparison. Require
all other fields and every retained corresponding bytecode artifact to match.
This checks audit metadata/result classification and packing directly across the
changed caller, while the existing audit validator supplies independent native
and runtime results. No audit body is executed by this parity check itself.

These are correctness checks, with no performance claim. Shared benchmark lock,
task-owned paths, bounded waiting and existing profile settings apply. No other
session's process, source, artifacts or cache is changed.
