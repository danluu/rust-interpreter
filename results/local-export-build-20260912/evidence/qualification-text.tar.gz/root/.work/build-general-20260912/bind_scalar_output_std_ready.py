"""Bind local standard-MIR readiness without changing copy provenance."""
from pathlib import Path
import hashlib, json, time

root = Path(__file__).resolve().parents[2]
b = Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
copy_path = b / 'std-mir-copy.json'
copy = json.loads(copy_path.read_text())
directory = root / '.work/std-mir' / Path(copy['source']).name
ready_path = directory / 'ready.json'
assert directory.resolve(strict=True) == directory and ready_path.resolve(strict=True) == ready_path
ready = json.loads(ready_path.read_text())
assert ready['owner'] == copy['owner'] == str(root)
assert ready['copied_immutable_metadata_from'] == copy['source']
assert set(ready['artifacts']) == set(copy['artifacts']) and len(copy['artifacts']) == 26
for name, row in copy['artifacts'].items():
    path = directory / name
    assert path.resolve(strict=True) == path and path.is_file()
    assert sha(path) == row['sha256'] == ready['artifacts'][name]['sha256'], name
    info = path.stat()
    assert info.st_size == row['bytes'], name
    assert list((info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)) == ready['artifacts'][name]['stamp'], name
receipt = dict(copy, local_ready_path=str(ready_path), local_ready_sha256=sha(ready_path),
               copy_receipt={'path': str(copy_path), 'sha256': sha(copy_path)},
               local_binding_script={'path': str(Path(__file__).resolve()), 'sha256': sha(Path(__file__))},
               recorded_at=time.time(), artifacts_rehashed=26,
               explanation='source_ready_sha256 remains the original checkout copy provenance; local_ready_sha256 binds this owned copied cache metadata.')
with (b / 'std-mir-diagnostic-local-ready.json').open('x') as output:
    json.dump(receipt, output, indent=2); output.write('\n')
print(json.dumps({'status':'passed', 'artifacts_rehashed':26, 'metadata_bytes':sum(row['bytes'] for row in copy['artifacts'].values()),
                  'local_ready_sha256':receipt['local_ready_sha256'], 'source_ready_sha256':copy['source_ready_sha256']}, indent=2))
