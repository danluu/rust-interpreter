#[inline(never)]
fn leaf(a:u64)->u64 {
    if a==9 { panic!("INLINE_COLD_FAILURE"); }
    if a & 1 == 0 { a.wrapping_mul(3) } else { a.wrapping_add(7) }
}
pub fn entry(a:u64)->u64 { leaf(a).wrapping_add(leaf(a.wrapping_add(2))) }
#[cfg(test)] mod tests {
    #[test] fn results() { assert_eq!(super::entry(2),18); assert_eq!(super::entry(3),22); }
}
