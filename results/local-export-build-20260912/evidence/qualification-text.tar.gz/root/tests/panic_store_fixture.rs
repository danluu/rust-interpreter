// Qualification must inspect the actual MIR and exported Store-before-Trap
// data flow; the source shape and helper name alone do not prove coverage.
#[inline(never)]
fn store_then_panic(destination: &mut u64, value: u64) -> ! {
    *destination = value;
    panic!("panic-store fixture");
}

#[inline(never)]
fn store_and_return(destination: &mut u64, value: u64) {
    *destination = value;
}

pub fn rust_interp_entry(mode: u64, value: u64) -> u64 {
    let mut destination = !value;
    if mode == 0 {
        store_and_return(&mut destination, value);
        destination
    } else {
        store_then_panic(&mut destination, value)
    }
}

fn main() {
    let mut args = std::env::args().skip(1);
    let mode = args.next().expect("mode or observe");
    let value: u64 = args.next().expect("value").parse().unwrap();
    assert!(args.next().is_none(), "unexpected argument");
    if mode == "observe" {
        // This native-only adapter observes the store despite unwinding. It is
        // unreachable from the selected interpreter entry above.
        let mut destination = !value;
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            store_then_panic(&mut destination, value);
        }));
        assert!(result.is_err(), "helper did not panic");
        assert_eq!(destination, value, "store before panic was lost");
        println!("{destination}");
    } else {
        // Panic mode is intentionally uncaught here for the failure oracle.
        println!("{}", rust_interp_entry(mode.parse().unwrap(), value));
    }
}
