#![feature(panic_internals)]
#![allow(internal_features)]

// A separate prospective fixture: the original panic_store_fixture's Copy and
// intervening formatting call remain preserved as failed structural coverage.
// Actual MIR and argument-directed Unary/Store-before-Trap evidence is required.
#[inline(never)]
fn store_then_panic(destination: &mut u64, value: u64) -> ! {
    *destination = !value;
    core::panicking::panic("panic-store late fixture");
}

#[inline(never)]
fn store_and_return(destination: &mut u64, value: u64) {
    *destination = !value;
}

pub fn rust_interp_entry(mode: u64, value: u64) -> u64 {
    let mut destination = value;
    if mode == 0 {
        store_and_return(&mut destination, value);
        destination
    } else {
        store_then_panic(&mut destination, value)
    }
}

fn main() {
    let mut args = std::env::args().skip(1);
    let mode = args.next().expect("mode or observe");
    let value: u64 = args.next().expect("value").parse().unwrap();
    assert!(args.next().is_none(), "unexpected argument");
    if mode == "observe" {
        let mut destination = value;
        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            store_then_panic(&mut destination, value);
        }));
        assert!(result.is_err(), "helper did not panic");
        assert_eq!(destination, u64::MAX - value, "store before panic was lost");
        println!("{destination}");
    } else {
        println!("{}", rust_interp_entry(mode.parse().unwrap(), value));
    }
}
