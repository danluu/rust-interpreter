"""Archive original compilation/tests and separate saved-output validation."""
import fcntl,gzip,hashlib,json,os,shutil,sys,tarfile,time
from pathlib import Path
ROOT=Path('/Users/danluu/dev/rust-interp-proc-macro-bridge-20260913')
RAW=ROOT/'.work/proc-macro-span-handle-controls-01'
VALIDATION=ROOT/'.work/proc-macro-span-handle-validation-02'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
OUT=ROOT/'results/proc-macro-span-handle-controls-01'
def require(ok,message):
    if not ok:raise RuntimeError(message)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def main():
    OUT.mkdir(parents=True,exist_ok=False)
    record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),argv=sys.argv,cwd=str(Path.cwd()),
        canonical_lock=str(LOCK),wait_seconds=600,compiler_children=0,test_children=0,benchmark_children=0,script_sha256=sha(__file__))
    write(OUT/'packaging-receipt.json',record)
    try:
        with LOCK.open('r+') as lock:
            deadline=time.monotonic()+600
            while True:
                try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);break
                except BlockingIOError:
                    require(time.monotonic()<deadline,'canonical admission expired');time.sleep(.25)
            record.update(status='archiving',admitted_at=time.time(),free_bytes_before=shutil.disk_usage(ROOT).free)
            write(OUT/'packaging-receipt.json',record)
            original=read(RAW/'summary.json');validation=read(VALIDATION/'summary.json');result=read(VALIDATION/'validated-controls.json')
            require(original['status']=='failed' and validation['status']==result['status']=='passed','control status')
            require(result['tests_passed']==4 and result['tests_failed']==result['tests_ignored']==0,'control counts')
            require(result['original_receipt_sha256']==sha(RAW/'summary.json')==validation['original_receipt_sha256'],'original failure identity')
            require(validation['result_sha256']==sha(VALIDATION/'validated-controls.json'),'saved validation identity')
            for group in ['source_guards','compiler_inputs','compiled_sources']:
                for path,item in result[group].items():
                    require(sha(path)==item['sha256'] and Path(path).stat().st_size==item['bytes'],'source/compiler changed')
            require(sha(RAW/'span-handle-controls')==result['binary_sha256_at_continued_validation'],'test binary changed')
            entries={}
            def add(p,name):
                require(p.is_file() and not p.is_symlink() and name not in entries,'archive path')
                entries[name]=dict(source=str(p),bytes=p.stat().st_size,sha256=sha(p))
            for directory,prefix in [(RAW,'controls01'),(VALIDATION,'validation02')]:
                for p in sorted(directory.rglob('*')):
                    require(not p.is_symlink(),'unexpected symlink')
                    if p.is_file() and p!=RAW/'span-handle-controls':add(p,prefix+'/'+p.relative_to(directory).as_posix())
            for run,code in [('span-handle-controls-supervisor-01',1),('span-handle-validation-supervisor-02',0)]:
                directory=ROOT/'.work/experiments'/run;outer=read(directory/'status.json')
                require(outer['status']=='finished' and outer['returncode']==code,'unfinished outer supervisor')
                require(sha(directory/'command.log')==outer['log_sha256'] and sha(directory/'plan.json')==outer['plan_sha256'],'supervisor hashes')
                for p in directory.iterdir():add(p,'supervisors/'+run+'/'+p.name)
            for name in ['run-span-handle-controls-01.py','validate-span-handle-controls-02.py','archive-span-handle-controls-01.py']:
                add(ROOT/'.work'/name,'runners/'+name)
            size=sum(i['bytes'] for i in entries.values())
            require(shutil.disk_usage(ROOT).free>=8*1024**3+2*size,'archive disk floor')
            write(OUT/'members.json',entries)
            archive=OUT/'evidence.tar.gz'
            with archive.open('xb') as f:
                with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed,mode='w|') as tar:
                        for name,item in sorted(entries.items()):
                            ti=tarfile.TarInfo(name);ti.mode=0o444;ti.mtime=0;ti.size=item['bytes']
                            with Path(item['source']).open('rb') as source:tar.addfile(ti,source)
            seen=set()
            with tarfile.open(archive,'r:gz') as tar:
                for member in tar:
                    require(member.isfile() and member.name in entries and member.name not in seen,'archive member')
                    b=tar.extractfile(member).read();item=entries[member.name]
                    require(len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256'],'archive member digest');seen.add(member.name)
            require(seen==set(entries),'archive members missing')
            for item in entries.values():require(sha(item['source'])==item['sha256'],'archive source changed')
            summary=dict(status='passed',policy=result['policy'],tests_passed=4,tests_failed=0,tests_ignored=0,
                original_compile_pid=result['original_compile_pid'],original_test_pid=result['original_test_pid'],
                original_supervisor_status=result['original_supervisor_status'],original_receipt_sha256=sha(RAW/'summary.json'),
                saved_validation_receipt_sha256=sha(VALIDATION/'summary.json'),saved_validation_result_sha256=sha(VALIDATION/'validated-controls.json'),
                compiler_version=result['compiler_version'],patch_sha256=result['patch_sha256'],compiled_sources=result['compiled_sources'],
                original_source_sha256='cd7e0b6c7940f7ae9baad9c463e4bc3a77dd5db29922a2e988dfeef4230d5bde',
                tests=result['test_outcomes'],source_and_compiler_guards_unchanged=True,full_compiler_builds=0,
                bridge_integration=False,microbenchmarks=0,performance_claim=False,compiler_and_test_repeated=False,
                archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(entries),
                    uncompressed_bytes=size,all_members_and_sources_verified=True),originals_preserved=True)
            write(OUT/'summary.json',summary)
            (OUT/'README.md').write_text('''# Standalone proc-macro span-handle controls

The exact candidate handle.rs compiled with public rustc cea272fa3 and passed all four container tests: ordered-store equivalence with repeated values and counter gaps; cross-store/stale-handle rejection; zero-counter rejection; and overflow rejection. The pinned sibling fxhash.rs was unchanged. The harness imports the standard macros at crate root so its cfg_select invocation remains the original source.

Compilation used Rust2024, opt-level0, debug assertions and overflow checks enabled, and two backend jobs. The test binary ran once with one test thread. Compiler/source snapshots and hashes, exact argv/environment, raw compiler/test output and process receipts are retained. These are container invariants, not a bridge integration test or performance result. No full compiler build or microbenchmark ran.

The first supervisor failed after the four tests had passed: its output parser omitted libtest's ` - should panic` suffix. That exact failed receipt is retained. Separate validation02 checked the saved four outcomes and all original source/compiler hashes under the canonical lock. It launched no compiler or tests and did not replace the failed receipt. Both completed supervisors are archived. The test binary hash was collected during continued validation; the binary itself is excluded.

Every archive member and source was checked after packaging. Original evidence and the private test binary remain unchanged.
''')
            record.update(status='passed',finished_at=time.time(),archive=summary['archive'],summary_sha256=sha(OUT/'summary.json'),free_bytes_after=shutil.disk_usage(ROOT).free)
            write(OUT/'packaging-receipt.json',record);print(json.dumps(record),flush=True)
    except BaseException as error:
        record.update(status='failed',error=repr(error),finished_at=time.time());write(OUT/'packaging-receipt.json',record);raise
if __name__=='__main__':main()
