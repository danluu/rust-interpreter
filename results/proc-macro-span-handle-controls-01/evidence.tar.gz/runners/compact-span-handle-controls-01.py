"""Preserve first archive privately and omit generated dSYM payloads from publication."""
import fcntl,gzip,hashlib,io,json,os,shutil,sys,tarfile,time
from pathlib import Path
ROOT=Path('/Users/danluu/dev/rust-interp-proc-macro-bridge-20260913')
OUT=ROOT/'results/proc-macro-span-handle-controls-01'
PRIOR=ROOT/'.work/proc-macro-span-handle-archive-with-symbols-01'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def require(v,m):
    if not v:raise RuntimeError(m)
record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),canonical_lock=str(LOCK),wait_seconds=600,
    compiler_children=0,test_children=0,benchmark_children=0,argv=sys.argv,cwd=str(Path.cwd()))
receipt=ROOT/'.work/compact-span-handle-controls-01.json';write(receipt,record)
try:
 with LOCK.open('r+') as lock:
    end=time.monotonic()+600
    while True:
        try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);break
        except BlockingIOError:
            require(time.monotonic()<end,'canonical admission expired');time.sleep(.25)
    record.update(status='compacting',admitted_at=time.time());write(receipt,record)
    summary=json.loads((OUT/'summary.json').read_bytes());members=json.loads((OUT/'members.json').read_bytes())
    require(summary['status']=='passed' and sha(OUT/'evidence.tar.gz')==summary['archive']['sha256'],'prior archive changed')
    require(not PRIOR.exists(),'private prior exists');OUT.rename(PRIOR);OUT.mkdir()
    files={};excluded={}
    with tarfile.open(PRIOR/'evidence.tar.gz','r:gz') as tar:
        for m in tar:
            require(m.isfile() and m.name in members,'prior member')
            data=tar.extractfile(m).read();require(hashlib.sha256(data).hexdigest()==members[m.name]['sha256'],'prior member hash')
            if m.name.startswith('controls01/span-handle-controls.dSYM/'):
                excluded[m.name]=members[m.name]
            else:files[m.name]=data
    require(len(excluded)==3 and sum(x['bytes'] for x in excluded.values())>6_000_000,'unexpected symbol companion scope')
    for name in ['summary.json','members.json','packaging-receipt.json']:
        files['initial-packaging/'+name]=(PRIOR/name).read_bytes()
    files['runners/compact-span-handle-controls-01.py']=Path(__file__).read_bytes()
    final_members={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in files.items()}
    archive=OUT/'evidence.tar.gz'
    with archive.open('xb') as f:
      with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz:
       with tarfile.open(fileobj=gz,mode='w|') as tar:
        for name,data in sorted(files.items()):
            m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o444;m.mtime=0;tar.addfile(m,io.BytesIO(data))
    seen=set()
    with tarfile.open(archive,'r:gz') as tar:
        for m in tar:
            data=tar.extractfile(m).read();require(m.name not in seen and data==files[m.name],'repacked member mismatch');seen.add(m.name)
    require(seen==set(files),'missing repacked member')
    for name,old in members.items():require(sha(old['source'])==old['sha256'],'original source changed')
    summary.update(initial_packaging_archive=summary['archive'],generated_debug_companion_files_excluded=excluded)
    summary['archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(files),
        uncompressed_bytes=sum(len(v) for v in files.values()),all_members_and_sources_verified=True)
    write(OUT/'members.json',final_members);write(OUT/'summary.json',summary)
    (OUT/'README.md').write_bytes((PRIOR/'README.md').read_bytes()+b'\nThe initial verified archive included the generated dSYM companion. Compact publication excludes its three files, retaining their hashes and the initial packaging receipts. The original archive remains privately preserved.\n')
    record.update(status='passed',finished_at=time.time(),archive=summary['archive'],initial_archive=summary['initial_packaging_archive'],
        preserved_initial_directory=str(PRIOR),script_sha256=sha(__file__),free_bytes_after=shutil.disk_usage(ROOT).free)
    write(receipt,record);write(OUT/'packaging-receipt.json',record);print(json.dumps(record),flush=True)
except BaseException as e:
 record.update(status='failed',error=repr(e),finished_at=time.time());write(receipt,record);raise
