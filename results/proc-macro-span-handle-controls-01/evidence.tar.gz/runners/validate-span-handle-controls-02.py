"""Validate the already-passed exact four tests; no new compiler or test child."""
import fcntl,hashlib,json,os,re,shutil,sys,time
from pathlib import Path
ROOT=Path('/Users/danluu/dev/rust-interp-proc-macro-bridge-20260913')
RAW=ROOT/'.work/proc-macro-span-handle-controls-01'
OUT=ROOT/'.work/proc-macro-span-handle-validation-02'
OUTER=ROOT/'.work/experiments/span-handle-controls-supervisor-01'
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'scripts'))
from workflow_io import write_json

def require(ok,message):
    if not ok:raise RuntimeError(message)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def check_rows(rows):
    for path,item in rows.items():
        require(Path(path).is_file() and sha(path)==item['sha256'] and Path(path).stat().st_size==item['bytes'],'input changed: '+path)
def main():
    OUT.mkdir(exist_ok=False)
    record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),argv=sys.argv,cwd=str(Path.cwd()),started_at=time.time(),
        canonical_lock=str(LOCK),wait_seconds=600,compiler_children=0,test_children=0,benchmark_children=0,
        original_receipt_sha256=sha(RAW/'summary.json'),validation_script_sha256=sha(__file__))
    write_json(OUT/'summary.json',record)
    try:
        with LOCK.open('r+') as lock:
            deadline=time.monotonic()+600
            while True:
                try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);break
                except BlockingIOError:
                    require(time.monotonic()<deadline,'canonical admission expired');time.sleep(.25)
            record.update(status='validating-saved-controls',lock_acquired_at=time.time(),free_bytes_before=shutil.disk_usage(ROOT).free)
            write_json(OUT/'summary.json',record)
            original=read(RAW/'summary.json');outer=read(OUTER/'status.json')
            require(original['status']=='failed' and original['error']=="RuntimeError('missing test outcome: interned_handles_reject_zero_counter')",'unexpected original failure')
            require(outer['status']=='finished' and outer['returncode']==1 and outer['child_pid']==original['pid'],'original supervisor identity')
            sources=read(RAW/'source-guard-before.json');compiler=read(RAW/'compiler-inputs-before.json');compiled=read(RAW/'compiled-sources.json')
            check_rows(sources);check_rows(compiler);check_rows(compiled)
            commands=read(RAW/'commands.json')
            require([r['label'] for r in commands]==['public-version','public-sysroot','apply-exact-patch','compile','four-container-controls'],'original command sequence')
            for row in commands:
                receipt=read(RAW/(row['label']+'.process.json'))
                require(receipt['status']=='finished' and receipt['returncode']==row['returncode']==0 and receipt['pid']==row['pid']
                    and receipt['parent_pid']==original['pid'] and receipt['command']==row['argv'] and receipt['cwd']==row['cwd'],'child identity/status')
                for kind in ['stdout','stderr']:require(sha(RAW/(row['label']+'.'+kind))==row[kind+'_sha256'],'child stream changed')
            output=(RAW/'four-container-controls.stdout').read_text()
            outcomes=re.findall(r'^test handle::tests::([a-z_]+)( - should panic)? \.\.\. (ok)$',output,re.MULTILINE)
            expected={'interned_handles_match_ordered_store_with_counter_gaps':False,
                'interned_handles_reject_other_and_previous_stores':False,
                'interned_handles_reject_zero_counter':True,'interned_handles_keep_overflow_check':True}
            require(len(outcomes)==4 and {name:bool(panic) for name,panic,status in outcomes}==expected,'exact four test outcomes')
            require('test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in output,'actual summary differs')
            patch=ROOT/'experiments/proc-macro-span-handles/span-handles.patch'
            require(sha(patch)=='05aeea42bf6e3cd3aa9c1ec3adfdad65e6846e11e0419dca5490b253c4a922ff','patch changed')
            fx=RAW/'source/library/proc_macro/src/bridge/fxhash.rs'
            require(sha(fx)=='43c95da90564aa359a25b5a567cb5da351f40092caa260c29d009b7e25c68647','fxhash edited')
            result=dict(status='passed',policy='standalone-proc-macro-span-handle-controls-v1',source_and_compiler_guards_unchanged=True,
                tests_passed=4,tests_failed=0,tests_ignored=0,test_outcomes=[dict(name=n,should_panic=bool(p),status=s) for n,p,s in outcomes],
                original_supervisor_status='failed-postprocessing-after-four-passed-tests',original_test_pid=commands[-1]['pid'],
                original_compile_pid=commands[-2]['pid'],original_receipt_sha256=sha(RAW/'summary.json'),
                compiler_version=(RAW/'public-version.stdout').read_text(),compiler_inputs=compiler,
                source_guards=sources,compiled_sources=compiled,patch_sha256=sha(patch),
                binary_sha256_at_continued_validation=sha(RAW/'span-handle-controls'),
                bridge_integration=False,performance_claim=False,new_compiler_children=0,new_test_children=0,
                original_compiler_and_test_runs=1,finished_at=time.time())
            write_json(OUT/'validated-controls.json',result)
            check_rows(sources);check_rows(compiler);check_rows(compiled)
            record.update(status='passed',finished_at=time.time(),result_sha256=sha(OUT/'validated-controls.json'),free_bytes_after=shutil.disk_usage(ROOT).free)
            write_json(OUT/'summary.json',record);print(json.dumps({k:record[k] for k in ['status','pid','finished_at','result_sha256']}),flush=True)
    except BaseException as error:
        record.update(status='failed',error=repr(error),finished_at=time.time());write_json(OUT/'summary.json',record);raise
if __name__=='__main__':main()
