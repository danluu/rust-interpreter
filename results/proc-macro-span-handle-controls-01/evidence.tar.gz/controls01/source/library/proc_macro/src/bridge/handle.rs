//! Server-side handles and storage for per-handle data.

use std::collections::BTreeMap;
use std::hash::Hash;
use std::num::NonZero;
use std::ops::Index;
use std::sync::atomic::{AtomicU32, Ordering};

use super::fxhash::FxHashMap;

pub(super) type Handle = NonZero<u32>;

/// A store that associates values of type `T` with numeric handles. A value can
/// be looked up using its handle.
pub(super) struct OwnedStore<T: 'static> {
    counter: &'static AtomicU32,
    data: BTreeMap<Handle, T>,
}

impl<T> OwnedStore<T> {
    pub(super) fn new(counter: &'static AtomicU32) -> Self {
        // Ensure the handle counter isn't 0, which would panic later,
        // when `NonZero::new` (aka `Handle::new`) is called in `alloc`.
        assert_ne!(counter.load(Ordering::Relaxed), 0);

        OwnedStore { counter, data: BTreeMap::new() }
    }
}

impl<T> OwnedStore<T> {
    pub(super) fn alloc(&mut self, x: T) -> Handle {
        let counter = self.counter.fetch_add(1, Ordering::Relaxed);
        let handle = Handle::new(counter).expect("`proc_macro` handle counter overflowed");
        assert!(self.data.insert(handle, x).is_none());
        handle
    }

    pub(super) fn take(&mut self, h: Handle) -> T {
        self.data.remove(&h).expect("use-after-free in `proc_macro` handle")
    }
}

impl<T> Index<Handle> for OwnedStore<T> {
    type Output = T;
    fn index(&self, h: Handle) -> &T {
        self.data.get(&h).expect("use-after-free in `proc_macro` handle")
    }
}

/// Like `OwnedStore`, but avoids storing any value more than once.
pub(super) struct InternedStore<T: 'static> {
    counter: &'static AtomicU32,
    data: FxHashMap<Handle, T>,
    interner: FxHashMap<T, Handle>,
}

impl<T: Copy + Eq + Hash> InternedStore<T> {
    pub(super) fn new(counter: &'static AtomicU32) -> Self {
        // Keep the same global, nonzero handle allocation as OwnedStore.
        assert_ne!(counter.load(Ordering::Relaxed), 0);
        InternedStore {
            counter,
            data: FxHashMap::default(),
            interner: FxHashMap::default(),
        }
    }

    pub(super) fn alloc(&mut self, x: T) -> Handle {
        let Self { counter, data, interner } = self;
        *interner.entry(x).or_insert_with(|| {
            let counter = counter.fetch_add(1, Ordering::Relaxed);
            let handle = Handle::new(counter).expect("`proc_macro` handle counter overflowed");
            assert!(data.insert(handle, x).is_none());
            handle
        })
    }

    pub(super) fn copy(&mut self, h: Handle) -> T {
        *self.data.get(&h).expect("use-after-free in `proc_macro` handle")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn interned_handles_match_ordered_store_with_counter_gaps() {
        static ACTUAL: AtomicU32 = AtomicU32::new(1);
        static EXPECTED: AtomicU32 = AtomicU32::new(1);
        let mut actual = InternedStore::new(&ACTUAL);
        let mut ordered = OwnedStore::new(&EXPECTED);
        let mut interned = FxHashMap::default();
        let mut handles = Vec::new();
        for i in 0..4096u32 {
            if i % 13 == 0 {
                ACTUAL.fetch_add(31, Ordering::Relaxed);
                EXPECTED.fetch_add(31, Ordering::Relaxed);
            }
            let value = i.wrapping_mul(149) % 257;
            let expected = *interned.entry(value).or_insert_with(|| ordered.alloc(value));
            let got = actual.alloc(value);
            assert_eq!(got, expected);
            assert_eq!(actual.copy(got), ordered[expected]);
            handles.push((got, value));
        }
        for (handle, value) in handles.into_iter().rev() {
            assert_eq!(actual.copy(handle), value);
        }
        assert_eq!(ACTUAL.load(Ordering::Relaxed), EXPECTED.load(Ordering::Relaxed));
    }

    #[test]
    fn interned_handles_reject_other_and_previous_stores() {
        static COUNTER: AtomicU32 = AtomicU32::new(1);
        let old = {
            let mut first = InternedStore::new(&COUNTER);
            let mut second = InternedStore::new(&COUNTER);
            let a = first.alloc(7u32);
            let b = second.alloc(7u32);
            assert_ne!(a, b);
            assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| first.copy(b))).is_err());
            assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| second.copy(a))).is_err());
            assert_eq!(first.copy(a), 7);
            assert_eq!(second.copy(b), 7);
            a
        };
        let mut later = InternedStore::new(&COUNTER);
        let current = later.alloc(7u32);
        assert_ne!(old, current);
        assert!(std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| later.copy(old))).is_err());
        assert_eq!(later.copy(current), 7);
    }

    #[test]
    #[should_panic]
    fn interned_handles_reject_zero_counter() {
        static COUNTER: AtomicU32 = AtomicU32::new(0);
        let _ = InternedStore::<u32>::new(&COUNTER);
    }

    #[test]
    #[should_panic(expected = "`proc_macro` handle counter overflowed")]
    fn interned_handles_keep_overflow_check() {
        static COUNTER: AtomicU32 = AtomicU32::new(u32::MAX);
        let mut store = InternedStore::new(&COUNTER);
        let last = store.alloc(1u32);
        assert_eq!(last.get(), u32::MAX);
        assert_eq!(store.alloc(1), last);
        let _ = store.alloc(2);
    }
}
