#![allow(dead_code)]
#[macro_use]
extern crate std;
#[path = "library/proc_macro/src/bridge/fxhash.rs"]
mod fxhash;
#[path = "library/proc_macro/src/bridge/handle.rs"]
mod handle;
