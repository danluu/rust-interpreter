"""Standalone exact source container controls; no compiler/bridge integration build."""
import fcntl, hashlib, json, os, shutil, sys, time
from pathlib import Path
ROOT=Path('/Users/danluu/dev/rust-interp-proc-macro-bridge-20260913')
SOURCE=Path('/Users/danluu/dev/rustc-stable-mono-production-20260913')
PUBLIC=Path('/Users/danluu/.rustup/toolchains/nightly-2026-09-08-aarch64-apple-darwin')
LOCK=Path('/Users/danluu/dev/rust-interp/.work/benchmark.lock')
WORK=ROOT/'.work/proc-macro-span-handle-controls-01'
PROPOSAL=ROOT/'experiments/proc-macro-span-handles'
COMMIT='cea272fa356e94bd2ee2cadf376630aa0683867a'
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'scripts'))
from workflow_io import capture,write_json,require_space

def require(ok,message):
    if not ok:raise RuntimeError(message)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def files_guard(paths):return {str(p):dict(sha256=sha(p),bytes=p.stat().st_size) for p in paths}

def main():
    WORK.mkdir(exist_ok=False)
    record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),
        canonical_lock=str(LOCK),wait_seconds=600,argv=sys.argv,cwd=str(Path.cwd()),
        compiler_builds=0,bridge_integration=False,benchmarks=0,source_revision='6aff5a8ae11216a70abf35f3f58859282d735cb7')
    write_json(WORK/'summary.json',record)
    try:
        with LOCK.open('r+') as lock:
            deadline=time.monotonic()+600
            while True:
                try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);break
                except BlockingIOError:
                    require(time.monotonic()<deadline,'canonical admission expired');time.sleep(.25)
            record.update(status='running',lock_acquired_at=time.time(),free_bytes_before=shutil.disk_usage(ROOT).free)
            write_json(WORK/'summary.json',record);require_space(ROOT,8)
            bad=[k for k,v in os.environ.items() if v and (k.startswith(('DYLD_','LD_','CARGO_PROFILE_')) or k in
                ['RUSTFLAGS','RUSTC_BOOTSTRAP','RUSTC_FORCE_RUSTC_VERSION','RUSTC_OVERRIDE_VERSION_STRING','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'])]
            require(not bad,'ambient compiler overrides: '+str(bad))
            keep={'PATH','HOME','USER','LOGNAME','TMPDIR','LANG','LC_ALL','SHELL','SDKROOT','DEVELOPER_DIR','MACOSX_DEPLOYMENT_TARGET'}
            env={k:v for k,v in os.environ.items() if k in keep};write_json(WORK/'environment.json',env)
            reviewed=json.loads((PROPOSAL/'source-review.json').read_bytes())
            require(sha(PROPOSAL/'span-handles.patch')==reviewed['patch_sha256']=='05aeea42bf6e3cd3aa9c1ec3adfdad65e6846e11e0419dca5490b253c4a922ff','patch identity')
            rels=['library/proc_macro/src/bridge/handle.rs','library/proc_macro/src/bridge/fxhash.rs']
            frozen=[Path(__file__),ROOT/'scripts/workflow_io.py',ROOT/'scripts/supervise_experiment.py',
                    *[PROPOSAL/n for n in ['span-handles.patch','source-review.json','README.md']],*[SOURCE/r for r in rels]]
            freeze=files_guard(frozen);write_json(WORK/'source-guard-before.json',freeze)
            snapshots=WORK/'sources';snapshots.mkdir()
            for p in frozen:
                name=('pinned/'+str(p.relative_to(SOURCE))) if p.is_relative_to(SOURCE) else str(p.relative_to(ROOT))
                target=snapshots/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
            source=WORK/'source';source.mkdir()
            for r in rels:
                require(sha(SOURCE/r)==reviewed['reviewed_files'][r]['sha256'],'pinned input identity')
                target=source/r;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/r,target)
            public_inputs=[PUBLIC/'bin/rustc',*[p for p in (PUBLIC/'lib').glob('*.dylib') if p.is_file()],
                *[p for p in (PUBLIC/'lib/rustlib/aarch64-apple-darwin/lib').iterdir() if p.suffix in ['.rlib','.dylib','.rmeta']]]
            compiler=files_guard(public_inputs);write_json(WORK/'compiler-inputs-before.json',compiler)
            operations=[]
            def run(label,argv,cwd=source):
                require(files_guard(frozen)==freeze,'source changed before command');require_space(ROOT,8)
                argv=list(map(str,argv));child,stdout,stderr=capture(argv,cwd=cwd,env=env,
                    receipt_path=WORK/(label+'.process.json'),receipt=dict(label=label,environment=env))
                (WORK/(label+'.stdout')).write_text(stdout);(WORK/(label+'.stderr')).write_text(stderr)
                operations.append(dict(label=label,argv=argv,cwd=str(cwd),pid=child.pid,returncode=child.returncode,
                    stdout_sha256=sha(WORK/(label+'.stdout')),stderr_sha256=sha(WORK/(label+'.stderr'))))
                write_json(WORK/'commands.json',operations)
                require(child.returncode==0,label+' failed');require(files_guard(frozen)==freeze,'source changed after command')
                return stdout
            version=run('public-version',[PUBLIC/'bin/rustc','-vV'])
            require('commit-hash: '+COMMIT in version and 'host: aarch64-apple-darwin' in version,'public compiler version')
            require(run('public-sysroot',[PUBLIC/'bin/rustc','--print','sysroot']).strip()==str(PUBLIC),'public compiler sysroot')
            run('apply-exact-patch',['/usr/bin/patch','-p1','-F','0','-t','-N','-i',PROPOSAL/'span-handles.patch'])
            require(sha(source/rels[1])==reviewed['reviewed_files'][rels[1]]['sha256'],'fxhash snapshot was edited')
            harness=source/'harness.rs'
            harness.write_text('''#![allow(dead_code)]
#[macro_use]
extern crate std;
#[path = "library/proc_macro/src/bridge/fxhash.rs"]
mod fxhash;
#[path = "library/proc_macro/src/bridge/handle.rs"]
mod handle;
''')
            compiled_sources=files_guard([harness,*[source/r for r in rels]])
            write_json(WORK/'compiled-sources.json',compiled_sources)
            binary=WORK/'span-handle-controls'
            run('compile',[PUBLIC/'bin/rustc','--edition=2024','--test','--crate-name','proc_macro_span_handle_controls',
                harness,'-Copt-level=0','-Cdebuginfo=1','-Cdebug-assertions=yes','-Coverflow-checks=yes',
                '-Zunstable-options','--jobs-backend=2','-o',binary])
            output=run('four-container-controls',[binary,'--test-threads=1','--nocapture'])
            names=['interned_handles_match_ordered_store_with_counter_gaps','interned_handles_reject_other_and_previous_stores',
                   'interned_handles_reject_zero_counter','interned_handles_keep_overflow_check']
            for name in names:
                require('test handle::tests::'+name+' ...' in output,'missing test outcome: '+name)
            require('test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in output,'test result count')
            require(files_guard([harness,*[source/r for r in rels]])==compiled_sources,'compiled source changed')
            require(files_guard(frozen)==freeze,'frozen source changed');write_json(WORK/'source-guard-after.json',freeze)
            require(files_guard(public_inputs)==compiler,'public compiler input changed');write_json(WORK/'compiler-inputs-after.json',compiler)
            record.update(status='passed',finished_at=time.time(),compiler=version,compiler_sha256=compiler[str(PUBLIC/'bin/rustc')]['sha256'],
                original_handle_sha256=reviewed['reviewed_files'][rels[0]]['sha256'],patched_handle_sha256=sha(source/rels[0]),
                fxhash_sha256=sha(source/rels[1]),harness_sha256=sha(harness),test_binary_sha256=sha(binary),
                tests_passed=4,tests_failed=0,tests_ignored=0,commands=len(operations),
                source_and_compiler_guards_unchanged=True,free_bytes_after=shutil.disk_usage(ROOT).free)
            write_json(WORK/'summary.json',record);print(json.dumps(record),flush=True)
    except BaseException as error:
        record.update(status='failed',error=repr(error),finished_at=time.time());write_json(WORK/'summary.json',record);raise
if __name__=='__main__':main()
