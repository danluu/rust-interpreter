import datetime,hashlib,json,re,shlex
from pathlib import Path
O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918');S=X/'.work/hir-options-hash-compiler-01/source';W=X/'.work/hir-options-hash-compiler-build-02';H=X/'experiments/hir-options-hash/compiler-build-02';OUTER=X/'.work/experiments/hir-options-hash-compiler-build-supervisor-02'
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=read(W/'receipt.json');outer=read(OUTER/'status.json');plan=read(H/'plan.json');tests=read(H/'expected-tests.json');freeze=read(H/'inputs.json')
assert r['status']=='failed' and r['compiler_stages_completed']==2 and len(r['commands'])==16
assert r['application_qualified']==r['hash_driver_qualified']==r['native_recipe_qualified']==False
assert outer['status']=='finished' and outer['returncode']==1 and r['pid']==outer['child_pid']==40058 and r['parent_pid']==outer['supervisor_pid']==40055
assert outer['started_at']<=r['started_at']<=r['admitted_at']<=r['finished_at']<=outer['finished_at']
assert sha(OUTER/'command.log')==outer['log_sha256']
assert plan['tests']==tests and len(plan['children'])==25
assert sha(H/'plan.json')==freeze['files'][str(H/'plan.json')]['sha256']
assert sha(H/'expected-tests.json')==freeze['files'][str(H/'expected-tests.json')]['sha256']
children=[];previous=r['admitted_at']
for i,item in enumerate(r['commands']):
 p=W/'commands'/f'{i:03}'/'receipt.json';child=read(p);expected=plan['children'][i]
 assert str(p)==item['path'] and sha(p)==item['sha256']
 assert child['command']==item['command']==expected['argv'] and child['cwd']==expected.get('cwd',str(S))==str(S)
 assert child['environment']==expected['environment'] and child['status']=='finished' and child['returncode']==0
 assert child['pid']==item['pid'] and child['supervisor_pid']==r['pid'] and child['parent_pid']==r['parent_pid']
 assert previous<=child['started_at']<=child['finished_at']<=r['finished_at'];previous=child['finished_at']
 identity=child['identity'];assert identity['ps_returncode']==0
 assert identity['cwd_returncode'] in [0,1]
 words=identity['ps'].split(None,9);assert [int(x) for x in words[:3]]==[child['pid'],r['pid'],child['pid']] and words[8]=='??'
 argv=shlex.split(words[9]);wanted=(['/bin/sh'] if child['command'][0]=='./x' else [])+child['command'];assert argv==wanted
 start=datetime.datetime.strptime(' '.join(words[3:8]),'%a %b %d %H:%M:%S %Y').replace(tzinfo=datetime.timezone.utc).timestamp()
 assert child['started_at']-1<=start<=child['finished_at']
 if identity['cwd_returncode']==0:assert identity['cwd'].splitlines()==[f"p{child['pid']}",'fcwd','n'+str(S)]
 else:assert identity['cwd']=='' and i in [0,*range(3,15)]
 for stream in ['stdout','stderr']:assert sha(p.parent/stream)==child[stream+'_sha256']
 children.append(dict(index=i,contemporaneous_cwd_observed=identity['cwd_returncode']==0,pid=child['pid'],receipt_sha256=sha(p),stdout_sha256=child['stdout_sha256'],stderr_sha256=child['stderr_sha256'],started_at=child['started_at'],finished_at=child['finished_at']))
assert (W/'commands/000/stdout').read_text().strip()==plan['candidate_revision']=='4de35bdacef0e3cd18a66bc30b5459c19e09b118'
assert (W/'commands/001/stdout').read_bytes()==b'' and (W/'commands/001/stderr').read_bytes()==b''
check=(W/'commands/002/stdout').read_text()+(W/'commands/002/stderr').read_text()
assert re.search(r'(?m)^running: .*cargo.*"check".*rustc_ast_lowering',check)
raw=(W/'commands/015/stdout').read_text();err=(W/'commands/015/stderr').read_text()
actual=re.findall(r'^test (\S+) \.\.\. ok$',raw,re.M);assert len(actual)==len(set(actual))==27
assert len(re.findall(r'^test result: ok\. 27 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in [^\n]+$',raw,re.M))==1
assert not re.search(r'^test \S+ \.\.\. (?!ok$)',raw,re.M)
old=tests['lowering']['names'];changed={name:name.replace('body_cache::effects::tests::','body_cache::effects::replay_tests::') for name in old if name.startswith('body_cache::effects::tests::')}
assert len(changed)==3 and set(actual)==set(changed.get(n,n) for n in old)
assert len(set(actual)&set(old))==24 and r['error'].startswith('AssertionError((') and 'effects::replay_tests::' in r['error'] and 'effects::tests::' in r['error']
body=S/'compiler/rustc_ast_lowering/src/body_cache';mod=(body/'mod.rs').read_text();prepared=(body/'prepared.rs').read_text()
assert '#[path = "prepared_audit.rs"]\nmod cold;' in prepared and 'mod effects;' in mod
mapping={'mod.rs':'body_cache::tests','effects.rs':'body_cache::effects::replay_tests','entry.rs':'body_cache::entry::tests','journal.rs':'body_cache::journal::tests','prepared.rs':'body_cache::prepared::tests','prepared_audit.rs':'body_cache::prepared::cold::tests','storage.rs':'body_cache::storage::tests','validate.rs':'body_cache::validate::tests','wire.rs':'body_cache::wire::tests'}
source_names=[];source_proof={}
for filename,prefix in mapping.items():
 p=body/filename;text=p.read_text();module=prefix.rsplit('::',1)[1]
 assert len(re.findall(r'(?m)^(?:pub\(super\) )?mod '+module+r' \{',text))==1
 functions=re.findall(r'#\[test\]\s+fn ([A-Za-z_][A-Za-z_0-9]*)\(',text)
 assert functions and all(text.index('fn '+name+'(')>text.index('mod '+module+' {') for name in functions)
 source_names.extend(prefix+'::'+name for name in functions)
 assert sha(p)==tests['source_files'][str(p)]
 source_proof[str(p)]=dict(sha256=sha(p),module=prefix,test_functions=functions)
assert len(source_names)==len(set(source_names))==27 and set(source_names)==set(actual)
# The complete expected-source packet remains unchanged; this is not a new build.
for name,digest in tests['source_files'].items():assert sha(Path(name))==digest
running=[shlex.split(line.strip()[9:-1]) for line in err.splitlines() if line.strip().startswith('Running `') and line.strip().endswith('`')]
executions=[argv for argv in running if argv[-4:]==['-Z','unstable-options','--format','json']]
assert len(executions)==1 and len(executions[0])==5
exe=Path(executions[0][0]);assert exe.is_relative_to(S/'build/aarch64-apple-darwin/stage1-rustc') and exe.name.startswith('rustc_ast_lowering-')
assert exe.stat().st_ctime<=r['finished_at']
report=dict(status='verified-retained-failure',receipt_sha256=sha(W/'receipt.json'),outer_sha256=sha(OUTER/'status.json'),plan_sha256=sha(H/'plan.json'),expected_tests_sha256=sha(H/'expected-tests.json'),children=children,child_count=16,all_actual_children_returned_zero=True,actual_lowering_tests=actual,source_tests=source_proof,corrected_name_map=changed,unchanged_names=24,whole_suite_passed=27,source_packet_unchanged=True,current_observed_test_executable=dict(path=str(exe),bytes=exe.stat().st_size,sha256=sha(exe)),original_failure_preserved=True,compiler_complete=False,remaining_original_children=9,limitation='Read-only replay of saved16 actual children and current pinned test declarations. Thirteen fast Git/otool children have empty/rc1 contemporaneous cwd probes; only their recorded Popen cwd is bound, while all16 have exact ps identities. No full100k source/provider closure audit, compilation, probe, test rerun or current executable contemporaneous-launch hash is claimed.')
p=O/'.work/options-hash-build02-failure-independent-verification.json'
with p.open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(dict(path=str(p),sha256=sha(p),child_count=16,passed_tests=27,only_corrected_prefixes=changed),indent=2))
