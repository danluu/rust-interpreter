import hashlib,json,re
from pathlib import Path
O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918');H=O/'experiments/hir-options-hash-intermediate-retirement';C=H/'controls-01';W=O/'.work/hir-options-hash-intermediate-retirement-controls-01';E=O/'.work/experiments/hir-options-hash-intermediate-retirement-controls-supervisor-01'
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
f=read(C/'inputs.json');l=read(C/'launch.json');t=read(W/'receipt.json');c=read(W/'command/receipt.json');e=read(E/'status.json');v=read(W/'result.json')
assert sha(C/'launch.json')=='cbf0023e45e5c7592695cc3913f12884afef9acbd1c9a73011626e45e60f83f0'
assert sha(C/'inputs.json')==l['inputs_sha256']==t['inputs_sha256']=='b7750ff45ecb842e81956678c8783ccbdbb8d80a998b8822b90d2a7b9f853b5e'
for n,r in f['files'].items():
 p=Path(n);s=p.lstat();assert p.resolve()==p and [s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink]==r['stamp'] and sha(p)==r['sha256']
assert e['status']=='finished' and e['returncode']==0 and e['child_pid']==t['pid']==c['supervisor_pid'] and e['supervisor_pid']==t['parent_pid']==c['parent_pid']
assert e['command']==l['command'][6:] and e['cwd']==str(O)
assert e['started_at']<=t['started_at']<=t['admitted_at']<=c['started_at']<=c['finished_at']<=t['finished_at']<=e['finished_at']
assert t['status']=='passed' and t['controls_passed']==6 and t['commands']==[dict(path=str(W/'command/receipt.json'),sha256=sha(W/'command/receipt.json'),pid=c['pid'])]
assert c['status']=='finished' and c['returncode']==0 and c['command']==f['command'] and c['cwd']==str(H) and c['environment']==f['environment']
assert c['identity']['ps'].split()[:3]==[str(c['pid']),str(t['pid']),str(c['pid'])]
assert 'n'+str(H)+'\n' in c['identity']['cwd'] and c['identity']['ps_returncode']==c['identity']['cwd_returncode']==0
for stream in ['stdout','stderr']:assert sha(W/'command'/stream)==c[stream+'_sha256']
assert not (W/'command/stdout').read_bytes()
s=(W/'command/stderr').read_text();assert sorted(re.findall(r'^test_[A-Za-z0-9_]+ \(([^)]+)\) \.\.\. ok$',s,re.M))==f['expected_names'];assert re.search(r'Ran 6 tests in [0-9.]+s\n\nOK\n$',s)
assert v['status']=='passed' and v['tests_run']==6 and v['expected_names']==f['expected_names'] and sha(W/'result.json')==t['result_sha256']
assert all(v[k]==0 for k in ['failures','errors','skipped','expected_failures','unexpected_successes','child_processes','compiler_calls']) and not list((W/'tmp').iterdir())
a=read(O/'.work/hir-options-hash-intermediate-retirement-controls-launch-01.actual.json');assert a['command']==l['command'] and a['environment']==l['environment'] and a['cwd']==str(O) and a['returncode']==0
for stream in ['stdout','stderr']:assert sha(O/('.work/hir-options-hash-intermediate-retirement-controls-launch-01.'+stream))==a[stream+'_sha256']
assert read(E/'plan.json')['command']==e['command'] and sha(E/'plan.json')==e['plan_sha256'] and sha(E/'command.log')==e['log_sha256']
report=dict(status='verified',controls=6,receipt_sha256=sha(W/'receipt.json'),result_sha256=sha(W/'result.json'),outer_sha256=sha(E/'status.json'),child_sha256=sha(W/'command/receipt.json'),inputs_sha256=sha(C/'inputs.json'),frozen_files=len(f['files']),actual_compiler_calls=0,actual_N_mutations=0,verifier_sha256=sha(Path(__file__)))
p=O/'.work/hir-options-hash-intermediate-retirement-controls-verification-01.json';p.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,indent=2));print(sha(p))
