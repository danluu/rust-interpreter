"""Read-only reconciliation after the single approved retirement partially failed."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import time

O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
P=O/'experiments/hir-options-hash-intermediate-retirement/plan-01'
W=O/'.work/hir-options-hash-intermediate-retirement-01'
OUTER=O/'.work/experiments/hir-options-hash-intermediate-retirement-supervisor-01'
PREFIX=O/'.work/hir-options-hash-intermediate-retirement-launch-01'
REPORT=O/'.work/hir-options-hash-intermediate-retirement-failure-verification-01.json'
INVENTORY=O/'.work/hir-options-hash-intermediate-retirement-partial-inventory-01.json'
FIELDS=['dev','ino','mode','nlink','size','mtime_ns','ctime_ns']
def read(path):return json.loads(path.read_bytes())
def ident(path):
    st=path.lstat();return {k:getattr(st,'st_'+k) for k in FIELDS}
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def record(path):
    before=ident(path);assert stat.S_ISREG(before['mode']) and path.resolve(strict=True)==path
    digest=sha(path);assert ident(path)==before
    return dict(identity=before,sha256=digest)
def scan(root):
    assert root.resolve(strict=True)==root and root.is_dir()
    rows={'.':dict(kind='directory',identity=ident(root))}
    for base,dirs,files in os.walk(root,followlinks=False):
        for name in sorted(dirs+files):
            path=Path(base)/name;value=ident(path);key=str(path.relative_to(root))
            if stat.S_ISREG(value['mode']):row=dict(kind='file',**record(path))
            elif stat.S_ISDIR(value['mode']):row=dict(kind='directory',identity=value)
            else:
                assert stat.S_ISLNK(value['mode']);row=dict(kind='link',identity=value,target=os.readlink(path),resolved=str(path.resolve(strict=True)))
            assert ident(path)==value;rows[key]=row
    return rows
started=time.time();a=read(P/'assessment.json');plan=read(P/'plan.json');freeze=read(P/'inputs.json')
terminal=read(W/'receipt.json');outer=read(OUTER/'status.json');launch=read(P/'launch.json');launcher=read(Path(str(PREFIX)+'.actual.json'))
assert terminal['status']=='failed' and terminal['error']=="RuntimeError('directory identity changed during unlink')"
assert terminal['deleted']==[] and not (W/'deleted.jsonl').exists()
assert outer['status']=='finished' and outer['returncode']==1 and outer['child_pid']==terminal['pid'] and outer['supervisor_pid']==terminal['parent_pid']
assert outer['command']==launch['command'][6:] and outer['cwd']==launch['cwd']
assert outer['plan_sha256']==sha(OUTER/'plan.json') and outer['log_sha256']==sha(OUTER/'command.log')
assert launcher['status']=='finished' and launcher['returncode']==0 and launcher['command']==launch['command'] and launcher['environment']==launch['environment'] and launcher['cwd']==launch['cwd']
for stream in ['stdout','stderr']:assert launcher[stream+'_sha256']==sha(Path(str(PREFIX)+'.'+stream))
assert read(Path(str(PREFIX)+'.stdout'))['supervisor_pid']==outer['supervisor_pid']
assert outer['child_started_at']<=terminal['started_at']<=terminal['admitted_at']<=terminal['finished_at']<=outer['finished_at']
previous=terminal['admitted_at'];probes=[]
for ref,spec in zip(terminal['children'],plan['commands'],strict=True):
    directory=W/'commands'/spec['label'];child=read(directory/'receipt.json')
    assert ref==dict(label=spec['label'],path=str(directory/'receipt.json'),sha256=sha(directory/'receipt.json'))
    assert child['command']==spec['argv'] and child['cwd']==str(O) and child['environment']==plan['environment']
    assert child['status']=='finished' and child['returncode'] in spec['expected'] and child['supervisor_pid']==terminal['pid'] and child['parent_pid']==outer['supervisor_pid']
    assert previous<=child['started_at']<=child['finished_at']<=terminal['finished_at'];previous=child['finished_at']
    for stream in ['stdout','stderr']:assert sha(directory/stream)==child[stream+'_sha256']
    assert not (directory/'stderr').read_bytes()
    raw=(directory/'stdout').read_text()
    if spec['label'].startswith('open-handles'):assert child['returncode']==1 and not raw
    else:
        for line in raw.splitlines():
            words=line.split();assert len(words)>=9 and words[3:8]!=plan['owned_start_times'].get(words[0])
    probes.append(dict(path=str(directory/'receipt.json'),sha256=sha(directory/'receipt.json'),pid=child['pid'],returncode=child['returncode']))
for name,expected in freeze['files'].items():assert record(Path(name))==expected,name
root=Path(a['root']);current=scan(root);old=a['entries'];missing=sorted(set(old)-set(current));added=sorted(set(current)-set(old))
first=sorted(a['selected'])[0];assert missing==[first] and not added
parent=str(Path(first).parent);changed={name:dict(before=old[name],after=current[name]) for name in current if current[name]!=old[name]}
assert set(changed)=={parent}
before=old[parent]['identity'];after=current[parent]['identity']
assert all(before[k]==after[k] for k in ['dev','ino','mode'])
before_children=sorted(name for name in old if name!='.' and str(Path(name).parent)==parent)
after_children=sorted(name for name in current if name!='.' and str(Path(name).parent)==parent)
assert set(before_children)-set(after_children)=={first}
assert before['nlink']==6 and after['nlink']==5 and before['size']==192 and after['size']==160
assert len(before_children)==4 and len(after_children)==3
assert a['selected'][first]['identity']['size']==9152
for name,expected in a['protected_roots'].items():assert scan(Path(name))==expected,name
for name,expected in a['protected_files'].items():assert record(Path(name))==expected,name
for name,row in a['stamp_files'].items():assert sha(W/'retained'/Path(name).name)==row['sha256']==sha(Path(name))
assert read(W/'transition.json')==a['transition']
for name in a['transition']['consumer']['absent_before_retirement']:assert not Path(name).exists() and not Path(name).is_symlink()
assert read(W/'admitted-inventory.json')['entries']==old
with INVENTORY.open('x') as output:json.dump(dict(status='observed-after-partial-failure',root=str(root),entries=current),output,indent=2,sort_keys=True);output.write('\n')
proof=dict(status='verified-partial-failure',started_at=started,finished_at=time.time(),
    terminal_sha256=sha(W/'receipt.json'),outer_sha256=sha(OUTER/'status.json'),launcher_sha256=sha(Path(str(PREFIX)+'.actual.json')),
    frozen_inputs=len(freeze['files']),probes=probes,missing_files=[dict(path=str(root/first),original=a['selected'][first])],
    unexpected_added_entries=added,changed_parent_directories=changed,removed_files=1,remaining_selected_files=4645,
    missing_deletion_ledger=True,terminal_deleted_array_is_not_mutation_count=True,
    diagnosis='Source calls unlink before checking parent dev/ino/mode/nlink. Actual ordinary parent retained dev/ino/mode but nlink fell6to5 and size192to160 when its fourth child entry was removed; this triggered the failure before ledger append. No universal directory-link-count rule is inferred.',
    before_parent_children=before_children,after_parent_children=after_children,
    protected_trees=len(a['protected_roots']),protected_tree_entries=sum(map(len,a['protected_roots'].values())),protected_files=len(a['protected_files']),
    all_remaining_target_bytes_and_other_identities_unchanged=True,all_protected_bytes_and_identities_unchanged=True,
    complete_current_inventory=dict(path=str(INVENTORY),sha256=sha(INVENTORY)),free_bytes_after_audit=shutil.disk_usage(O).free,
    no_retry_or_further_mutation=True,verifier_sha256=sha(Path(__file__)))
with REPORT.open('x') as output:json.dump(proof,output,indent=2,sort_keys=True);output.write('\n')
print(json.dumps(dict(report=str(REPORT),sha256=sha(REPORT),removed_files=1,remaining_selected_files=4645,
    protected_unchanged=True,free_bytes_after_audit=proof['free_bytes_after_audit'],outer_finished_at=outer['finished_at']),indent=2))
