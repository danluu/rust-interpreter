"""Hash explicit candidate intermediates and bind retained producer commands.

Read-only analysis of completed outputs. No cleanup, compiler invocation,
consumer qualification or byte-identical reconstruction promise.
"""
import hashlib
import json
from pathlib import Path
import re
import shlex
import time

O = Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
X = Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
N = X/'.work/hir-options-hash-compiler-01'
S = N/'source'
T = S/'build/aarch64-apple-darwin/stage1-rustc'
ASSESSMENT = O/'.work/hir-options-hash-intermediate-eligibility-01.json'
OUT = O/'.work/hir-options-hash-intermediate-content-01.json'


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    state = path.lstat()
    return {key: getattr(state, 'st_' + key) for key in
            ['dev', 'ino', 'mode', 'size', 'mtime_ns', 'ctime_ns', 'nlink']}


def option(argv, name):
    values = [argv[i+1] for i, word in enumerate(argv[:-1]) if word == name]
    values += [word[len(name)+1:] for word in argv if word.startswith(name+'=')]
    assert len(values) == 1, (name, values)
    return values[0]


def main():
    started = time.time()
    assessment = read(ASSESSMENT)
    assert sha(ASSESSMENT) == '568b45b09fa774691b3bb59f591f28792fe44a2ac30e01b8bd9f313680e9e7fd'
    commands, histories, by_directory = [], [], {}
    for name, expected in [('hir-options-hash-compiler-build-02', 16),
                           ('hir-options-hash-compiler-build-continuation-01', 7)]:
        work = X/'.work'/name
        terminal = read(work/'receipt.json')
        assert terminal['status'] == 'failed' and len(terminal['commands']) == expected
        history = dict(path=str(work/'receipt.json'), sha256=sha(work/'receipt.json'), children=[])
        for ref in terminal['commands']:
            receipt_path = Path(ref['path'])
            assert sha(receipt_path) == ref['sha256']
            child = read(receipt_path)
            assert child['status'] in ['finished', 'failed']
            retained = dict(path=str(receipt_path), sha256=sha(receipt_path), returncode=child['returncode'], streams={})
            for stream_name in ['stdout', 'stderr']:
                path = receipt_path.parent/stream_name
                assert path.stat().st_size < 128*2**20
                raw = path.read_bytes()
                assert hashlib.sha256(raw).hexdigest() == child[stream_name+'_sha256']
                retained['streams'][stream_name] = dict(path=str(path), sha256=child[stream_name+'_sha256'], bytes=len(raw))
                for number, line in enumerate(raw.splitlines(keepends=True), 1):
                    match = re.fullmatch(rb'\s*Running `(.+)`\r?\n?', line)
                    if match is None:
                        continue
                    argv = shlex.split(match[1].decode())
                    environment = {}
                    while argv and re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*=.*', argv[0], re.S):
                        key, value = argv.pop(0).split('=', 1)
                        assert key not in environment
                        environment[key] = value
                    if '--crate-name' not in argv or '--out-dir' not in argv:
                        continue
                    directory = Path(option(argv, '--out-dir'))
                    if not directory.is_absolute():
                        directory = Path(child['cwd'])/directory
                    if not directory.is_relative_to(T):
                        continue
                    # Failed support routing produced no compiler invocation;
                    # each bound native producer belongs to a successful child.
                    assert child['returncode'] == 0
                    crate = option(argv, '--crate-name')
                    extra = [word.split('=', 1)[1] for word in argv if word.startswith('extra-filename=')]
                    assert len(extra) <= 1
                    record = dict(child_receipt=str(receipt_path), child_receipt_sha256=sha(receipt_path),
                        stream=stream_name, stream_sha256=child[stream_name+'_sha256'], line=number,
                        line_sha256=hashlib.sha256(line).hexdigest(), argv=argv, printed_environment=environment,
                        inherited_child_environment=child['environment'], crate=crate,
                        out_dir=str(directory), extra_filename=extra[0] if extra else '')
                    index = len(commands); commands.append(record)
                    by_directory.setdefault(str(directory), []).append(index)
            history['children'].append(retained)
        histories.append(history)
    candidates, unmatched = {}, []
    for filename, row in assessment['candidates'].items():
        path = Path(filename)
        assert path.resolve(strict=True) == path and identity(path) == row['identity']
        digest = sha(path)
        assert identity(path) == row['identity']
        matches = []
        for index in by_directory.get(str(path.parent), []):
            command = commands[index]
            if row['kind'] == 'rcgu.o':
                matched = path.name.startswith(command['crate']+'.') and path.name.endswith('.rcgu.o')
            else:
                matched = path.name == 'lib'+command['crate']+command['extra_filename']+'.'+row['kind']
            if matched:
                matches.append(index)
        if not matches:
            unmatched.append(filename)
        candidates[filename] = dict(row, sha256=digest, observed_producer_commands=matches)
    for filename, row in assessment['candidates'].items():
        assert identity(Path(filename)) == row['identity']
    for history in histories:
        assert sha(Path(history['path'])) == history['sha256']
    for record in assessment['stamps'].values():
        assert sha(Path(record['path'])) == record['sha256']
    sources = [S/'bootstrap.toml', S/'src/bootstrap/src/core/build_steps/compile.rs',
        S/'src/bootstrap/src/core/build_steps/test.rs', S/'src/bootstrap/src/core/build_steps/tool.rs',
        X/'experiments/hir-options-hash/compiler-build-02/plan.json',
        X/'experiments/hir-options-hash/compiler-build-continuation-01/plan.json',
        X/'experiments/hir-options-hash/compiler-metadata-03/inputs.json']
    result = dict(status='read-only-content-and-reconstruction-reference-assessment',
        started_at=started, finished_at=time.time(), candidates=candidates,
        producer_commands=commands, histories=histories,
        source_references={str(p): dict(sha256=sha(p), bytes=p.stat().st_size) for p in sources},
        eligibility_sha256=sha(ASSESSMENT), unmatched_candidates=unmatched,
        content_hashed_bytes=sum(row['identity']['size'] for row in candidates.values()),
        no_byte_identical_rebuild_promise=True,
        limitations=['Command association records observed producer routes; it is not a new compiler execution or complete effective-environment replay.',
                     'All private stamp members, admitted providers, hardlink aliases and retained evidence must remain protected.',
                     'No open-handle check, retirement authorization or mutation.'])
    with OUT.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True); stream.write('\n')
    print(json.dumps(dict(path=str(OUT), sha256=sha(OUT), candidates=len(candidates),
        content_hashed_bytes=result['content_hashed_bytes'], observed_producers=len(commands),
        unmatched=len(unmatched), first_unmatched=unmatched[:10]), sort_keys=True))


if __name__ == '__main__':
    main()
