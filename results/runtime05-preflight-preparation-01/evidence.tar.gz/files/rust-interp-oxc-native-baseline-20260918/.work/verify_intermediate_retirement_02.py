"""Read-only reconciliation of the separate remaining-file retirement."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import time

O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
P=O/'experiments/hir-options-hash-intermediate-retirement/plan-02'
W=O/'.work/hir-options-hash-intermediate-retirement-02'
OUTER=O/'.work/experiments/hir-options-hash-intermediate-retirement-supervisor-02'
PREFIX=O/'.work/hir-options-hash-intermediate-retirement-launch-02'
REPORT=O/'.work/hir-options-hash-intermediate-retirement-verification-02.json'
FIELDS=['dev','ino','mode','nlink','size','mtime_ns','ctime_ns']
def read(path):return json.loads(path.read_bytes())
def ident(path):
    st=path.lstat();return {k:getattr(st,'st_'+k) for k in FIELDS}
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def record(path):
    before=ident(path);assert stat.S_ISREG(before['mode']) and path.resolve(strict=True)==path
    digest=sha(path);assert ident(path)==before
    return dict(identity=before,sha256=digest)
def scan(root):
    assert root.resolve(strict=True)==root and root.is_dir()
    rows={'.':dict(kind='directory',identity=ident(root))}
    for base,dirs,files in os.walk(root,followlinks=False):
        for name in sorted(dirs+files):
            path=Path(base)/name;value=ident(path);key=str(path.relative_to(root))
            if stat.S_ISREG(value['mode']):row=dict(kind='file',**record(path))
            elif stat.S_ISDIR(value['mode']):row=dict(kind='directory',identity=value)
            else:
                assert stat.S_ISLNK(value['mode']);row=dict(kind='link',identity=value,target=os.readlink(path),resolved=str(path.resolve(strict=True)))
            assert ident(path)==value;rows[key]=row
    return rows
started=time.time();a=read(P/'assessment.json');plan=read(P/'plan.json');freeze=read(P/'inputs.json')
terminal=read(W/'receipt.json');outer=read(OUTER/'status.json');launch=read(P/'launch.json');launcher=read(Path(str(PREFIX)+'.actual.json'))
assert terminal['status']=='passed' and terminal['retired_files']==4645 and terminal['prior_partial_retired_files']==1 and terminal['combined_retired_files']==4646
assert terminal['validated_deletions']==4645 and not terminal['uncertain_unlink_intents'] and 'ledger_readback_error' not in terminal
assert outer['status']=='finished' and outer['returncode']==0 and outer['child_pid']==terminal['pid'] and outer['supervisor_pid']==terminal['parent_pid']
assert outer['command']==launch['command'][6:] and outer['cwd']==launch['cwd']
assert outer['plan_sha256']==sha(OUTER/'plan.json') and outer['log_sha256']==sha(OUTER/'command.log')
assert launcher['status']=='finished' and launcher['returncode']==0 and launcher['command']==launch['command'] and launcher['environment']==launch['environment'] and launcher['cwd']==launch['cwd']
assert launcher['launch_sha256']==sha(P/'launch.json') and launcher['launcher_sha256']==sha(O/'.work/launch_intermediate_retirement_02.py')
for stream in ['stdout','stderr']:assert launcher[stream+'_sha256']==sha(Path(str(PREFIX)+'.'+stream))
assert read(Path(str(PREFIX)+'.stdout'))['supervisor_pid']==outer['supervisor_pid']
assert outer['child_started_at']<=terminal['started_at']<=terminal['admitted_at']<=terminal['finished_at']<=outer['finished_at']
previous=terminal['admitted_at'];probes=[]
for ref,spec in zip(terminal['children'],plan['commands'],strict=True):
    directory=W/'commands'/spec['label'];child=read(directory/'receipt.json')
    assert ref==dict(label=spec['label'],path=str(directory/'receipt.json'),sha256=sha(directory/'receipt.json'))
    assert child['command']==spec['argv'] and child['cwd']==str(O) and child['environment']==plan['environment']
    assert child['status']=='finished' and child['returncode'] in spec['expected'] and child['supervisor_pid']==terminal['pid'] and child['parent_pid']==outer['supervisor_pid']
    assert previous<=child['started_at']<=child['finished_at']<=terminal['finished_at'];previous=child['finished_at']
    for stream in ['stdout','stderr']:assert sha(directory/stream)==child[stream+'_sha256']
    assert not (directory/'stderr').read_bytes()
    raw=(directory/'stdout').read_text()
    if spec['label'].startswith('open-handles'):assert child['returncode']==1 and not raw
    else:
        for line in raw.splitlines():
            words=line.split();assert len(words)>=9 and words[3:8]!=plan['owned_start_times'].get(words[0])
    probes.append(dict(path=str(directory/'receipt.json'),sha256=sha(directory/'receipt.json'),pid=child['pid'],returncode=child['returncode']))
for name,expected in freeze['files'].items():assert record(Path(name))==expected,name
root=Path(a['root']);current=scan(root);old=a['entries'];missing=sorted(set(old)-set(current));added=sorted(set(current)-set(old))
assert missing==sorted(a['selected']) and not added and len(missing)==4645
rows=[json.loads(line) for line in (W/'deleted.jsonl').read_text().splitlines()]
assert len(rows)==3*4645 and sha(W/'deleted.jsonl')==terminal['deleted_ledger_sha256']
expected=json.loads(json.dumps(old));completed=[];previous=terminal['admitted_at']
for index,name in enumerate(sorted(a['selected'])):
    intent,unlinked,validated=rows[index*3:index*3+3]
    assert [row['event'] for row in [intent,unlinked,validated]]==['intent','unlinked','validated']
    assert all(row['relative']==name and row['path']==str(root/name) for row in [intent,unlinked,validated])
    assert {k:v for k,v in intent.items() if k not in ['event','time']}=={k:v for k,v in unlinked.items() if k not in ['event','time']}
    parent=str(Path(name).parent);before=expected[name]['identity'];pb=expected[parent]['identity']
    assert intent['before']==before and before['nlink']==1 and intent['sha256']==expected[name]['sha256'] and intent['parent_before']==pb
    after=validated['after'];pa=validated['parent_after']
    assert all(after[k]==before[k] for k in ['dev','ino','mode','size','mtime_ns']) and after['nlink']==0
    assert all(pa[k]==pb[k] for k in ['dev','ino','mode'])
    assert previous<=intent['time']<=unlinked['time']<=validated['time']<=terminal['finished_at'];previous=validated['time']
    del expected[name];expected[parent]['identity']=pa;completed.append(str(root/name))
assert expected==current and terminal['deleted']==completed
assert read(W/'remaining-inventory.json')['entries']==current and sha(W/'remaining-inventory.json')==terminal['remaining_inventory_sha256']
prior=a['prior_partial'];assert terminal['prior_partial']==prior
assert not Path(prior['removed_path']).exists() and not Path(prior['removed_path']).is_symlink()
assert sha(Path(prior['audit']['path']))==prior['audit']['sha256'] and sha(Path(prior['terminal']['path']))==prior['terminal']['sha256']
original=read(P.parent/'plan-01/assessment.json')
assert {str(root/name) for name in original['selected']}==set(completed)|{prior['removed_path']}
for name,expected in a['protected_roots'].items():assert scan(Path(name))==expected,name
for name,expected in a['protected_files'].items():assert record(Path(name))==expected,name
for name,row in a['stamp_files'].items():assert sha(W/'retained'/Path(name).name)==row['sha256']==sha(Path(name))
assert read(W/'transition.json')==a['transition']
for name in a['transition']['consumer']['absent_before_retirement']:assert not Path(name).exists() and not Path(name).is_symlink()
assert read(W/'admitted-inventory.json')['entries']==old
proof=dict(status='verified',started_at=started,finished_at=time.time(),terminal_sha256=sha(W/'receipt.json'),
    outer_sha256=sha(OUTER/'status.json'),launcher_sha256=sha(Path(str(PREFIX)+'.actual.json')),frozen_inputs=len(freeze['files']),probes=probes,
    successor_retired_files=4645,prior_partial_retired_files=1,combined_retired_files=4646,removed_directories=0,
    ledger_rows=len(rows),deleted_ledger_sha256=sha(W/'deleted.jsonl'),remaining_inventory_sha256=sha(W/'remaining-inventory.json'),
    transition_sha256=sha(W/'transition.json'),prior_partial=prior,protected_trees=len(a['protected_roots']),
    protected_tree_entries=sum(map(len,a['protected_roots'].values())),protected_files=len(a['protected_files']),
    all_remaining_membership_bytes_and_identities_match_ledger=True,all_protected_bytes_and_identities_unchanged=True,
    free_bytes_after_audit=shutil.disk_usage(O).free,verifier_sha256=sha(Path(__file__)))
with REPORT.open('x') as output:json.dump(proof,output,indent=2,sort_keys=True);output.write('\n')
print(json.dumps(dict(report=str(REPORT),sha256=sha(REPORT),retired_files=4645,combined_retired_files=4646,
    protected_unchanged=True,free_bytes_after_audit=proof['free_bytes_after_audit'],outer_finished_at=outer['finished_at']),indent=2))
