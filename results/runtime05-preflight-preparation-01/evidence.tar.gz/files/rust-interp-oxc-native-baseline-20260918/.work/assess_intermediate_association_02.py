"""Complete saved command association using rustc's extra-filename stem.

Preserve the first conservative association result and all full content hashes.
This is read-only analysis; no compiler or retirement runs.
"""
import hashlib
import json
from pathlib import Path

O = Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
S = Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918/.work/hir-options-hash-compiler-01/source')
P = O/'.work/hir-options-hash-intermediate-content-01.json'
raw = P.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'ea9260a72ac01a540dd24ea1f839fd68015179474e66cfe248bfd50a8f9960a5'
previous = json.loads(raw)
commands = previous['producer_commands']
by_directory = {}
for index, command in enumerate(commands):
    by_directory.setdefault(command['out_dir'], []).append(index)
bindings = {}
for filename, row in previous['candidates'].items():
    path = Path(filename)
    state = path.lstat()
    assert {name: getattr(state, 'st_'+name) for name in row['identity']} == row['identity']
    matches = []
    for index in by_directory.get(str(path.parent), []):
        command = commands[index]
        stem = command['crate'] + command['extra_filename']
        matched = (path.name.startswith(stem+'.') and path.name.endswith('.rcgu.o')) if row['kind'] == 'rcgu.o' else path.name == 'lib'+stem+'.'+row['kind']
        if matched:
            matches.append(index)
    assert matches, filename
    bindings[filename] = matches
source = {}
for relative in ['compiler/rustc_session/src/config.rs', 'compiler/rustc_codegen_ssa/src/back/write.rs']:
    path = S/relative
    payload = path.read_bytes()
    source[str(path)] = dict(bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())
result = dict(status='all-candidate-command-references-associated',
    content_assessment=dict(path=str(P), sha256=hashlib.sha256(raw).hexdigest()),
    bindings=bindings, source=source,
    rule='Exact retained Running out-dir plus crate/extra-filename stem; OutputFilenames::new/with_directory_and_extension/temp_path_ext_for_cgu bound by source.',
    old_assessment_preserved=True, no_byte_identical_rebuild_promise=True,
    limitation='Retained actual commands and full hashes identify reconstruction inputs; effective compiler environment and runtime qualification remain in original reviewed histories. No new producer execution or deletion.')
out = O/'.work/hir-options-hash-intermediate-association-02.json'
with out.open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True); stream.write('\n')
print(out, hashlib.sha256(out.read_bytes()).hexdigest(), len(bindings))
