"""Execute the single root-reviewed retirement launcher and retain its bytes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
P=O/'experiments/hir-options-hash-intermediate-retirement/plan-01'
PREFIX=O/'.work/hir-options-hash-intermediate-retirement-launch-01'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(P/'launch.json')=='d7cf30d6be1727fb03b149b6cdf9b7720e580eb03af1a5ae3ca288f672d81cf2'
assert sha(P/'inputs.json')=='4413647169a87a8a0e841ad5b79af7bbb9f813bdcbd6c44da1d036ab7afe8828'
assert sha(P/'plan.json')=='d32d25a5d155c9b0499a9ee183c8cb6d606712e78d27a7f21b9adb3ca4366f14'
launch=json.loads((P/'launch.json').read_bytes())
for name,row in json.loads((P/'inputs.json').read_bytes())['files'].items():
    path=Path(name);info=path.lstat()
    assert path.resolve(strict=True)==path and {key:getattr(info,'st_'+key) for key in row['identity']}==row['identity']
    assert sha(path)==row['sha256']
record=dict(command=launch['command'],cwd=launch['cwd'],environment=launch['environment'],
    pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),launch_sha256=sha(P/'launch.json'),launcher_sha256=sha(Path(__file__)))
with Path(str(PREFIX)+'.stdout').open('xb') as out,Path(str(PREFIX)+'.stderr').open('xb') as err:
    result=subprocess.run(launch['command'],cwd=launch['cwd'],env=launch['environment'],stdout=out,stderr=err)
record.update(status='finished',returncode=result.returncode,finished_at=time.time(),
    stdout_sha256=sha(Path(str(PREFIX)+'.stdout')),stderr_sha256=sha(Path(str(PREFIX)+'.stderr')))
with Path(str(PREFIX)+'.actual.json').open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps(record,indent=2))
print(Path(str(PREFIX)+'.stdout').read_text())
assert result.returncode==0
