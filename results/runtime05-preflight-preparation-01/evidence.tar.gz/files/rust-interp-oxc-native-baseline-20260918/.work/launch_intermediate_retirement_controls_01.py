"""Execute the single root-reviewed retirement launcher and retain its bytes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
P=O/'experiments/hir-options-hash-intermediate-retirement/controls-01'
PREFIX=O/'.work/hir-options-hash-intermediate-retirement-controls-launch-01'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(P/'launch.json')=='cbf0023e45e5c7592695cc3913f12884afef9acbd1c9a73011626e45e60f83f0'
assert sha(P/'inputs.json')=='b7750ff45ecb842e81956678c8783ccbdbb8d80a998b8822b90d2a7b9f853b5e'
launch=json.loads((P/'launch.json').read_bytes())
for name,row in json.loads((P/'inputs.json').read_bytes())['files'].items():
    path=Path(name);info=path.lstat()
    assert path.resolve(strict=True)==path and [info.st_dev,info.st_ino,info.st_mode,info.st_size,info.st_mtime_ns,info.st_ctime_ns,info.st_nlink]==row['stamp']
    assert sha(path)==row['sha256']
record=dict(command=launch['command'],cwd=launch['owner'],environment=launch['environment'],
    pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),launch_sha256=sha(P/'launch.json'),launcher_sha256=sha(Path(__file__)))
with Path(str(PREFIX)+'.stdout').open('xb') as out,Path(str(PREFIX)+'.stderr').open('xb') as err:
    result=subprocess.run(launch['command'],cwd=launch['owner'],env=launch['environment'],stdout=out,stderr=err)
record.update(status='finished',returncode=result.returncode,finished_at=time.time(),
    stdout_sha256=sha(Path(str(PREFIX)+'.stdout')),stderr_sha256=sha(Path(str(PREFIX)+'.stderr')))
with Path(str(PREFIX)+'.actual.json').open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps(record,indent=2))
print(Path(str(PREFIX)+'.stdout').read_text())
assert result.returncode==0
