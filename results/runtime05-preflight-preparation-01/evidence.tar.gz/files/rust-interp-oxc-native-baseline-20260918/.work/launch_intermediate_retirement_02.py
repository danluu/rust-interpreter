"""Execute the single root-reviewed retirement launcher and retain its bytes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import shutil
import time

O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
P=O/'experiments/hir-options-hash-intermediate-retirement/plan-02'
PREFIX=O/'.work/hir-options-hash-intermediate-retirement-launch-02'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(P/'launch.json')=='77afdcff5679d34a2a1719a1f57274f651a4847ba3d2660f1e525be73ad26ccf'
assert sha(P/'inputs.json')=='bf3ce3c879cda62d396f112f262437338a4a144a366cf6005e2d15ff866c7340'
assert sha(P/'plan.json')=='abb90dcd30397e84f932e63491ef8790914fd9260c6c3f566a3020bb89da5021'
launch=json.loads((P/'launch.json').read_bytes())
for name,row in json.loads((P/'inputs.json').read_bytes())['files'].items():
    path=Path(name);info=path.lstat()
    assert path.resolve(strict=True)==path and {key:getattr(info,'st_'+key) for key in row['identity']}==row['identity']
    assert sha(path)==row['sha256']
assert shutil.disk_usage(O).free >= 9*2**30, 'cleanup admission below9GiB'
record=dict(command=launch['command'],cwd=launch['cwd'],environment=launch['environment'],
    pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),launch_sha256=sha(P/'launch.json'),launcher_sha256=sha(Path(__file__)))
with Path(str(PREFIX)+'.stdout').open('xb') as out,Path(str(PREFIX)+'.stderr').open('xb') as err:
    result=subprocess.run(launch['command'],cwd=launch['cwd'],env=launch['environment'],stdout=out,stderr=err)
record.update(status='finished',returncode=result.returncode,finished_at=time.time(),
    stdout_sha256=sha(Path(str(PREFIX)+'.stdout')),stderr_sha256=sha(Path(str(PREFIX)+'.stderr')))
with Path(str(PREFIX)+'.actual.json').open('x') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps(record,indent=2))
print(Path(str(PREFIX)+'.stdout').read_text())
assert result.returncode==0
