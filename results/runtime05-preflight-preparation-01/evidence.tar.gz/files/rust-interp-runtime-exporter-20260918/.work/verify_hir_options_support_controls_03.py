"""Read-only full association audit of the seven actual bounded support controls."""
import hashlib,json,re,stat,time
from pathlib import Path
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
H=X/'experiments/hir-options-hash/compiler-build-continuation-02/support-controls-03'
W=X/'.work/hir-options-hash-support-controls-03'
O=X/'.work/experiments/hir-options-hash-support-controls-supervisor-03'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
f=read(H/'inputs.json');l=read(H/'launch.json');r=read(W/'receipt.json');o=read(O/'status.json');p=read(O/'plan.json');c=read(W/'command/receipt.json');a=read(X/'.work/hir-options-hash-support-controls-launch-03.actual.json');result=read(W/'result.json')
assert sha(H/'launch.json')=='10c6aba9cb0cca85a09b42951f3e7cc681f6e67eaa04955797e25497c7e23ada'
assert sha(H/'inputs.json')==l['inputs_sha256']==r['inputs_sha256']=='f6463ce8ad090e59033ea54071ef8d77bb5fe400d8de84121fc8e6129f741e10'
for name,row in f['files'].items():
 q=Path(name);s=q.lstat();stamp=[s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink]
 assert stat.S_ISREG(s.st_mode) and q.resolve(strict=True)==q and stamp==row['stamp'] and sha(q)==row['sha256'],name
for name,route in f['routes'].items():assert str(Path(name).resolve(strict=True))==route
for name in f['unrun_prior_outputs']:assert not Path(name).exists() and not Path(name).is_symlink()
assert a['status']=='launcher-finished' and a['launcher_returncode']==0 and a['command']==l['command'] and a['environment']==l['environment'] and a['cwd']==str(X)
assert a['launch_sha256']==sha(H/'launch.json')
assert r['status']=='passed' and r['controls_passed']==7 and len(r['commands'])==1
assert r['commands']==[dict(path=str(W/'command/receipt.json'),sha256=sha(W/'command/receipt.json'),pid=c['pid'])]
assert o['status']=='finished' and o['returncode']==0 and o['child_pid']==r['pid'] and o['supervisor_pid']==r['parent_pid']
assert o['command']==l['command'][6:] and p['command']==o['command'] and p['owner']==o['owner']==str(X) and p['supervisor_sha256']==sha(X/'scripts/supervise_experiment.py')
assert sha(O/'plan.json')==o['plan_sha256'] and sha(O/'command.log')==o['log_sha256']
assert a['started_at']<=o['started_at']<=o['child_started_at']<=r['started_at']<=r['admitted_at']<=c['started_at']<=c['finished_at']<=r['finished_at']<=o['finished_at']
assert c['status']=='finished' and c['returncode']==0 and c['supervisor_pid']==r['pid'] and c['parent_pid']==r['parent_pid']
assert c['command']==f['command'] and c['cwd']==str(H.parent) and c['environment']==f['environment']
identity=c['identity'];assert identity['ps_returncode']==identity['cwd_returncode']==0
ps=identity['ps'].splitlines();assert len(ps)==1 and ps[0].split()[:3]==[str(c['pid']),str(r['pid']),str(c['pid'])] and ps[0].endswith(' '.join(c['command']))
assert identity['cwd'].splitlines()==['p'+str(c['pid']),'fcwd','n'+str(H.parent)]
for stream in ['stdout','stderr']:assert sha(W/'command'/stream)==c[stream+'_sha256']
assert not (W/'command/stdout').read_bytes()
raw=(W/'command/stderr').read_text();names=re.findall(r'^test_[A-Za-z0-9_]+ \(([^)]+)\) \.\.\. ok$',raw,re.M)
assert sorted(names)==f['expected_names'] and len(names)==7
assert re.search(r'^Ran 7 tests in [0-9.]+s\n\nOK\n$',raw,re.M)
assert sha(W/'result.json')==r['result_sha256'] and result['status']=='passed' and result['tests_run']==7 and result['expected_names']==f['expected_names']
assert all(result[k]==0 for k in ['failures','errors','skipped','expected_failures','unexpected_successes','child_processes','compiler_calls'])
assert all(r[k]==0 for k in ['compiler_calls','provider_probes','B3_compositions'])
assert r['free_bytes_before']>=16*2**30 and r['free_bytes_after']>=9*2**30
report=dict(status='verified',verified_at=time.time(),receipt_sha256=sha(W/'receipt.json'),outer_sha256=sha(O/'status.json'),child_sha256=sha(W/'command/receipt.json'),result_sha256=sha(W/'result.json'),inputs_sha256=sha(H/'inputs.json'),launch_sha256=sha(H/'launch.json'),verifier_sha256=sha(Path(__file__)),files=len(f['files']),bytes=sum(z['stamp'][3] for z in f['files'].values()),actual_children=1,controls_passed=7,pid=c['pid'],helper_pid=r['pid'],supervisor_pid=r['parent_pid'],compiler_calls=0,provider_probes=0,prior02='launcher exit unobserved; no admission or test evidence; original files unchanged',prior01='unrun wrapper proposal; original files unchanged')
out=X/'.work/hir-options-hash-support-controls-verification-03.json'
with out.open('x') as s:json.dump(report,s,indent=2,sort_keys=True);s.write('\n')
print(json.dumps(report,indent=2));print('report_sha256',sha(out))
