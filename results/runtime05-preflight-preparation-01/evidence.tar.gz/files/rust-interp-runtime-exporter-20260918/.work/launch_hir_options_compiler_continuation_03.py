"""Launch the reviewed support continuation once and retain launcher completion."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

OWNER = Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
HERE = OWNER / 'experiments/hir-options-hash/compiler-build-continuation-03'
WORK = OWNER / '.work/hir-options-hash-compiler-build-continuation-03'
OUTER = OWNER / '.work/experiments/hir-options-hash-compiler-build-continuation-supervisor-03'
PREFIX = OWNER / '.work/hir-options-hash-compiler-continuation-launch-03'

def read(path):
    return json.loads(path.read_bytes())

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(path, value):
    temporary = Path(str(path) + '.tmp')
    with temporary.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--launch-sha256', required=True)
    args = parser.parse_args()
    assert Path.cwd() == OWNER and sys.dont_write_bytecode and not sys.flags.optimize
    launch_path = HERE / 'launch.json'
    assert sha(launch_path) == args.launch_sha256
    launch = read(launch_path)
    assert sha(HERE / 'inputs.json') == launch['inputs_sha256']
    frozen = read(HERE / 'inputs.json')
    assert sha(HERE / 'plan.json') == frozen['plan_sha256'] == launch['plan_sha256']
    for name, row in frozen['files'].items():
        path = Path(name)
        info = path.lstat()
        stamp = [info.st_dev, info.st_ino, info.st_mode, info.st_size,
                 info.st_mtime_ns, info.st_ctime_ns, info.st_nlink]
        assert stamp == row['stamp'] and sha(path) == row['sha256'], name
    for path in [WORK, OUTER, *[Path(str(PREFIX) + suffix)
                              for suffix in ['.actual.json', '.stdout', '.stderr']]]:
        assert not path.exists() and not path.is_symlink(), str(path)
    free = shutil.disk_usage(OWNER).free
    assert free >= 24 * 2**30, ('prelaunch capacity below 24 GiB', free)
    stdout = Path(str(PREFIX) + '.stdout')
    stderr = Path(str(PREFIX) + '.stderr')
    record = Path(str(PREFIX) + '.actual.json')
    actual = dict(status='starting', started_at=time.time(), launcher_pid=os.getpid(),
                  command=launch['command'], environment=launch['environment'], cwd=str(OWNER),
                  launch=str(launch_path), launch_sha256=args.launch_sha256,
                  stdout=str(stdout), stderr=str(stderr),
                  prelaunch_free_bytes=free, prelaunch_frozen_files_verified=len(frozen['files']),
                  launcher_wait_seconds=30, dispatcher_sha256=sha(Path(__file__).resolve()))
    with record.open('x') as stream:
        json.dump(actual, stream, sort_keys=True, indent=2)
        stream.write('\n')
    with stdout.open('xb') as out, stderr.open('xb') as err:
        process = subprocess.Popen(launch['command'], cwd=OWNER, env=launch['environment'],
                                   stdin=subprocess.DEVNULL, stdout=out, stderr=err)
        actual.update(status='launcher-running', supervisor_launcher_pid=process.pid)
        write(record, actual)
        try:
            code = process.wait(timeout=30)
            actual.update(status='launcher-finished', launcher_returncode=code,
                          launcher_finished_at=time.time())
        except subprocess.TimeoutExpired:
            actual.update(status='launcher-wait-expired', launcher_wait_expired_at=time.time())
        finally:
            write(record, actual)
    print(json.dumps(actual, indent=2))
    assert actual['status'] == 'launcher-finished' and actual['launcher_returncode'] == 0

if __name__ == '__main__':
    main()
