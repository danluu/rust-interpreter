"""Bounded read-only capacity wait; never launches or controls workloads."""
import json,os,time
from pathlib import Path
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
OUT=X/'.work/hir-options-hash-compiler-build-capacity-wait-02.json'
assert not OUT.exists()
start=time.time();deadline=time.monotonic()+600
record=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=start,deadline_seconds=600,interval_seconds=15,required_bytes=24*2**30,samples=[],workloads_started=0)
def save():
 tmp=OUT.with_suffix('.json.tmp')
 with tmp.open('w') as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n')
 os.replace(tmp,OUT)
while True:
 now=time.time();v=os.statvfs(X);free=v.f_bavail*v.f_frsize
 record['samples'].append(dict(timestamp=now,free_bytes=free));save()
 if free>=record['required_bytes']:
  record['status']='capacity-observed';break
 remaining=deadline-time.monotonic()
 if remaining<=0:record['status']='expired';break
 time.sleep(min(15,remaining))
record.update(finished_at=time.time(),minimum_free_bytes=min(x['free_bytes'] for x in record['samples']),maximum_free_bytes=max(x['free_bytes'] for x in record['samples']),latest_free_bytes=record['samples'][-1]['free_bytes']);save()
print(json.dumps(record,indent=2))
