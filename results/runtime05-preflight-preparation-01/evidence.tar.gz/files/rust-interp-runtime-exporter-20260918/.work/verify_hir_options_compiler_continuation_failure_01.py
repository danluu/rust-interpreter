"""Independent completed-build evidence and immutable-output reconciliation."""
import hashlib,json,os,re,stat,time,tomllib
from pathlib import Path
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
H=X/'experiments/hir-options-hash/compiler-build-continuation-01'
OLDH=X/'experiments/hir-options-hash/compiler-build-02'
M=X/'experiments/hir-options-hash/compiler-metadata-03'
W=X/'.work/hir-options-hash-compiler-build-continuation-01'
OLDW=X/'.work/hir-options-hash-compiler-build-02'
N=X/'.work/hir-options-hash-compiler-01'
O=X/'.work/experiments/hir-options-hash-compiler-build-continuation-supervisor-01'
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def stamp(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink]
r=read(W/'receipt.json');p=read(H/'plan.json');f=read(H/'inputs.json');mf=read(M/'inputs.json');o=read(O/'status.json')
launch=read(H/'launch.json')
assert sha(H/'launch.json')=='27b7902a9fda604dc8a234b403d04f4791bdd3c139ab2176b6251fc6e4e4bb02'
assert sha(H/'inputs.json')==launch['inputs_sha256'] and sha(H/'plan.json')==launch['plan_sha256']==f['plan_sha256']
assert sha(H/'continue.py')==launch['helper_sha256']
assert r['prior_failed_build_sha256']==p['saved']['receipt_sha256']==sha(OLDW/'receipt.json')
assert read(X/'.work/hir-options-hash-compiler-build-01/receipt.json')['status']=='failed'
assert sha(X/'.work/hir-options-hash-workspace-controls-01/receipt.json')==p['workspace_controls']['receipt_sha256']
assert read(X/'.work/hir-options-hash-workspace-controls-01/receipt.json')['controls_passed']==6
assert sha(X/'Cargo.toml')==p['ancestor_workspace']['after_sha256']
before=tomllib.loads((OLDH/'ancestor-Cargo.before.toml').read_text());before['workspace']['exclude']=['.work']
assert before==tomllib.loads((X/'Cargo.toml').read_text())
for name,row in p['ancestor_manifests'].items():
 path=Path(name);assert not path.is_symlink()
 if row is None:assert not path.exists(),name
 else:assert path.resolve(strict=True)==path and stamp(path)==row['stamp'] and sha(path)==row['sha256'],name
assert r['status']=='failed' and r['compiler_stages_completed']==7 and len(r['commands'])==7 and len(p['children'])==25 and r['saved_children']==16 and r['new_compiler_stages_completed']==5
assert r['error']=="AssertionError('unexpected compiler-stage return code')"
assert not (W/'compiled.json').exists() and not (W/'run-make-support-inventory.json').exists()
assert not any(r[field] for field in ['application_qualified','hash_driver_qualified','native_recipe_qualified'])
assert o['status']=='finished' and o['returncode']==1 and o['child_pid']==r['pid'] and o['supervisor_pid']==r['parent_pid']
assert sha(O/'plan.json')==o['plan_sha256'] and sha(O/'command.log')==o['log_sha256']
assert o['started_at']<=r['started_at']<=r['admitted_at']<=r['finished_at']<=o['finished_at']
old=read(OLDW/'receipt.json');assert old['status']=='failed' and len(old['commands'])==16
assert p['original_plan']==read(OLDH/'plan.json') and p['remaining_children']==p['children'][16:]
history=old['commands']+r['commands']
assert len(history)==23
for name,membership in p['saved']['membership'].items():
 assert sorted(str(path.relative_to(name)) for path in Path(name).rglob('*') if path.is_file())==membership
previous=old['admitted_at'];unavailable_cwd=[];sample_count=0;minimum_free=None;max_namespace=0;max_evidence=0;race_samples=0
for index,(ref,row) in enumerate(zip(history,p['children'][:23],strict=True)):
 if index==16:previous=r['admitted_at']
 terminal=old if index<16 else r
 directory=(OLDW/'commands'/f'{index:03}') if index<16 else (W/'commands'/f'{index-16:03}')
 child=read(directory/'receipt.json')
 assert ref==dict(path=str(directory/'receipt.json'),sha256=sha(directory/'receipt.json'),pid=child['pid'],command=row['argv'])
 assert child['expected']==[0]
 if index==22:
  assert child['status']=='failed' and child['returncode']==1 and child['error']==r['error']
 else:assert child['status']=='finished' and child['returncode']==0
 assert child['command']==row['argv'] and child['cwd']==row['cwd'] and child['environment']==row['environment']
 assert child['supervisor_pid']==terminal['pid'] and child['parent_pid']==terminal['parent_pid']
 assert previous<=child['started_at']<=child['finished_at']<=terminal['finished_at'];previous=child['finished_at']
 identity=child['identity'];ps=identity['ps'].splitlines()
 assert identity['ps_returncode']==0 and len(ps)==1 and ps[0].split()[:3]==[str(child['pid']),str(terminal['pid']),str(child['pid'])]
 assert ps[0].endswith(' '.join(row['argv']))
 if identity['cwd_returncode']!=0 or not identity['cwd']:
  assert identity['cwd_returncode']==1 and not identity['cwd'];unavailable_cwd.append(index)
 else:assert 'n'+row['cwd'] in identity['cwd'].splitlines()
 assert child['samples'] and not any((directory/name).exists() for name in ['owned-stop.json','budget-reason.json'])
 for sample in child['samples']:
  sample_count+=1
  assert sample['free_bytes']>=9*2**30 and sample['namespace_allocated_bytes']<=14*2**30 and sample['evidence_allocated_bytes']<=256*2**20
  assert not sample['allocation_errors']
  if index>=16:
   roots=sample['evidence_allocation_sample']['roots']
   assert set(roots)=={str(X/'.work/hir-options-hash-compiler-build-01'),str(OLDW),str(W)}
   assert sample['evidence_allocated_bytes']==sum(value['bytes'] for value in roots.values())
  minimum_free=sample['free_bytes'] if minimum_free is None else min(minimum_free,sample['free_bytes'])
  max_namespace=max(max_namespace,sample['namespace_allocated_bytes']);max_evidence=max(max_evidence,sample['evidence_allocated_bytes'])
  race_samples+=bool(sample['namespace_allocation_sample']['raced_entries'] or sample['evidence_allocation_sample']['raced_entries'])
 for stream in ['stdout','stderr']:
  assert sha(directory/stream)==child[stream+'_sha256']
  if stream in row:assert (directory/stream).read_bytes()==row[stream].encode()
 assert not re.search(rb'(?im)^\s*(?:downloading https?://|Building LLVM(?:\s|$)|Building GCC(?:\s|$)|HIR compiler experiment: bootstrap network)',(directory/'stdout').read_bytes()+b'\n'+(directory/'stderr').read_bytes())
assert [index for index in unavailable_cwd if index<16]==p['saved']['unavailable_contemporaneous_cwd_children']
for directory,role in [(OLDW/'commands/015','lowering'),(W/'commands/005','interface')]:
 raw=(directory/'stdout').read_text()+(directory/'stderr').read_text()
 names=re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. ok$',raw,re.M)
 assert len(names)==len(set(names))==p['tests'][role]['count'] and set(names)==set(p['tests'][role]['names'])
 assert f"test result: ok. {len(names)} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;" in raw
check_raw=(OLDW/'commands/002/stdout').read_bytes()+(OLDW/'commands/002/stderr').read_bytes()
assert re.search(rb'(?m)^running: .*cargo.*\"check\".*rustc_ast_lowering',check_raw)
build_raw=(W/'commands/000/stdout').read_text()+(W/'commands/000/stderr').read_text()
for key,value in p['tests']['assertions']['build_compiler_std']['compiler_commit_environment'].items():assert key+'=\"'+value+'\"' in build_raw
for key,value in [('CFG_VIRTUAL_RUSTC_DEV_SOURCE_BASE_DIR','/rustc-dev/'+p['candidate_revision']),('CFG_VIRTUAL_RUST_SOURCE_BASE_DIR','/rustc/'+p['candidate_revision'])]:assert key+'=\"'+value+'\"' in build_raw
version=(W/'commands/001/stdout').read_text()
assert not (W/'commands/001/stderr').read_bytes() and (W/'commands/002/stdout').read_text()==version
for line in p['tests']['assertions']['rustc_version']['required_lines']+['LLVM version: '+p['llvm_version']]:assert line in version.splitlines()
assert (W/'commands/003/stdout').read_text()==str(N/'source/build/aarch64-apple-darwin/stage1')+'\n'
options=set(re.findall(r'(?m)^\s*(?:-Z\s+)?([a-z][a-z0-9-]+)\s*=',(W/'commands/004/stdout').read_text()))
assert set(p['tests']['assertions']['rustc_unstable_help']['required_option_names'])<=options
support_stderr=(W/'commands/006/stderr').read_text()
assert 'ERROR: no `build` rules matched ["src/tools/run-make-support"]' in support_stderr
assert 'Fresh bootstrap v0.0.0' in support_stderr
files={**mf['files'],**f['files']};input_bytes=0
for name,row in files.items():
 path=Path(name);assert path.resolve(strict=True)==path and stat.S_ISREG(path.lstat().st_mode)
 assert stamp(path)==row['stamp'] and sha(path)==row['sha256'],name
 input_bytes+=path.stat().st_size
for name,row in mf['links'].items():
 path=Path(name);assert path.is_symlink() and stamp(path)==row['stamp'] and os.readlink(path)==row['target'] and str(path.resolve(strict=True))==row['resolved']
for name,row in p['metadata_plan']['configuration'].items():
 path=Path(name);assert not path.is_symlink() and (sha(path) if path.is_file() else None)==row,name
for name,target in p['metadata_plan']['routes'].items():assert str(Path(name).resolve(strict=True))==target
sdk_route=p['metadata_plan']['build_environment']['SDKROOT']
sdk=Path(p['metadata_plan']['routes'][sdk_route]);assert str(Path(sdk_route).resolve(strict=True))==str(sdk)
sdk_members={''}
for parent,dirs,names in os.walk(sdk,followlinks=False):sdk_members.update(str((Path(parent)/name).relative_to(sdk)) for name in dirs+names)
assert sdk_members==set(p['metadata_plan']['sdk_inventory'])
for name,row in p['metadata_plan']['sdk_inventory'].items():
 path=sdk/name;assert stamp(path)==row['stamp']
 if row['kind']=='directory':assert stat.S_ISDIR(path.lstat().st_mode)
 elif row['kind']=='link':assert path.is_symlink() and os.readlink(path)==row['target'] and str(path.resolve(strict=True))==row['resolved']
 else:assert row['kind']=='file' and files[str(path)]['sha256']==row['sha256']
initial=read(W/'stage1-inventory.json');loader=read(W/'stage1-native-loader.json')
allowed={str(N/'source/build/aarch64-apple-darwin/stage1/bin/rustc'),*[row['resolved'] for row in initial['closure']['identity']['libraries']]}
raw=(W/'commands/002/stderr').read_bytes();pid=read(W/'commands/002/receipt.json')['pid'];seen=set();basenames={}
for number,line in enumerate(raw.decode().splitlines(),1):
 match=re.fullmatch(rf'dyld\[{pid}\]: (?:<[0-9A-Fa-f-]{{36}}>\s+)?(/.+)',line)
 delay=re.fullmatch(rf'dyld\[{pid}\]: move loaded to delayed: ([^/\r\n]+)',line)
 if match:
  name=match[1];assert str(Path(name))==name and '..' not in Path(name).parts
  basenames.setdefault(Path(name).name,set()).add(name)
  if not name.startswith(('/usr/lib/','/System/Library/')):assert name in allowed;seen.add(name)
 elif delay:
  matches=basenames.get(delay[1],set());assert len(matches)==1 and all(name.startswith(('/usr/lib/','/System/Library/')) for name in matches)
 else:raise AssertionError(('unknown loader line',line))
 assert loader['lines'][number-1]==dict(line=number,raw=line)
assert seen==allowed and loader['loaded_non_system']==sorted(allowed) and loader['raw_sha256']==hashlib.sha256(raw).hexdigest()
assert len(loader['lines'])==len(raw.decode().splitlines())
# This failure audit records actual completed history and immutable inputs. Final
# native/support output qualification remains deliberately incomplete.
target=X/'.work/hir-options-hash-compiler-continuation-failure-verification-01.json'
with target.open('x') as stream:
 json.dump(dict(status='verified-retained-failure',time=time.time(),script_sha256=sha(Path(__file__)),receipt_sha256=sha(W/'receipt.json'),outer_sha256=sha(O/'status.json'),children=7,saved_children=16,combined_children=23,successful_children=6,failed_support_child=6,unavailable_contemporaneous_cwd_children=unavailable_cwd,compiler_stages=7,lowering_tests=27,interface_tests=18,input_files=len(files),input_bytes=input_bytes,samples=sample_count,minimum_observed_free_bytes=minimum_free,maximum_observed_namespace_allocation=max_namespace,maximum_observed_evidence_allocation=max_evidence,raced_allocation_samples=race_samples,allocation_limitation='Observed non-atomic samples, not a hard reservation or proof of every instantaneous peak.',pending=['source-correct support build','final two Git guards','final full output/postguards'],native_recipe_qualified=False,hash_driver_qualified=False,application_qualified=False),stream,indent=2,sort_keys=True);stream.write('\n')
print(target,sha(target))
