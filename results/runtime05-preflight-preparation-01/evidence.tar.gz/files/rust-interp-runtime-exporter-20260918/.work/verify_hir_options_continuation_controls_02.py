"""Read only verification of the second, exact thirteen-control attempt."""
from pathlib import Path
import ast,hashlib,json,re,time
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
H=X/'experiments/hir-options-hash/compiler-build-continuation-01'
W=X/'.work/hir-options-hash-build-continuation-controls-02'
O=X/'.work/experiments/hir-options-hash-build-continuation-controls-supervisor-02'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
l=read(H/'control-launch-02.json');f=read(H/'control-inputs-02.json');r=read(W/'receipt.json');o=read(O/'status.json');c=read(W/'command/receipt.json')
assert sha(H/'control-launch-02.json')=='7d0e0486be447618c19a7f9b06dcbf6b5447f633690b38bc905ee61ed9a27c52'
assert sha(H/'control-inputs-02.json')==l['inputs_sha256']
for n,row in f['files'].items():assert sha(Path(n))==row['sha256'] and Path(n).stat().st_size==row['bytes']
assert r['status']=='passed' and r['controls_passed']==13
assert r['commands']==[dict(path=str(W/'command/receipt.json'),pid=c['pid'],sha256=sha(W/'command/receipt.json'))]
assert o['status']=='finished' and o['returncode']==0 and o['child_pid']==r['pid'] and o['supervisor_pid']==r['parent_pid']
assert sha(O/'plan.json')==o['plan_sha256'] and sha(O/'command.log')==o['log_sha256']
assert o['started_at']<=r['started_at']<=r['admitted_at']<=c['started_at']<=c['finished_at']<=r['finished_at']<=o['finished_at']
assert c['status']=='finished' and c['returncode']==0 and c['command']==f['command'] and c['cwd']==str(H)
assert c['environment']==dict(f['environment'],TMPDIR=str(W/'tmp'))
assert c['supervisor_pid']==r['pid'] and c['parent_pid']==r['parent_pid']
for stream in ['stdout','stderr']:assert sha(W/'command'/stream)==c[stream+'_sha256']
assert not (W/'command/stdout').read_bytes()
expected=set()
for filename in ['test_monitor.py','test_drain.py']:
 for node in ast.walk(ast.parse((H/filename).read_bytes())):
  if isinstance(node,ast.FunctionDef) and node.name.startswith('test_'):expected.add(node.name)
raw=(W/'command/stderr').read_text()
actual=re.findall(r'^(test_[A-Za-z0-9_]+) \([^\n]+\) \.\.\. ok$',raw,re.M)
assert len(actual)==len(set(actual))==13 and set(actual)==expected
assert re.search(r'^Ran 13 tests in [0-9.]+s\n\nOK\n$',raw,re.M)
identity=c['identity'];assert identity['ps_returncode']==0 and identity['ps'].split()[:3]==[str(c['pid']),str(r['pid']),str(c['pid'])]
assert identity['ps'].endswith(' '.join(c['command']))
cwd_observed=identity['cwd_returncode']==0 and 'n'+str(H) in identity['cwd'].splitlines()
if not cwd_observed:assert identity['cwd_returncode']==1 and not identity['cwd']
old=X/'.work/experiments/hir-options-hash-build-continuation-controls-supervisor-01'
assert read(old/'status.json')['returncode']==1 and not (X/'.work/hir-options-hash-build-continuation-controls-01').exists()
assert b"assert dict(os.environ)==frozen['environment']" in (old/'command.log').read_bytes()
result=dict(status='verified',time=time.time(),script_sha256=sha(Path(__file__)),receipt_sha256=sha(W/'receipt.json'),outer_sha256=sha(O/'status.json'),child_sha256=sha(W/'command/receipt.json'),controls=13,actual_children=1,actual_helper_environment=r['actual_helper_environment'],contemporaneous_child_cwd_observed=cwd_observed,prior_pre_admission_failure_preserved=True,compiler_calls=0)
p=X/'.work/hir-options-hash-build-continuation-controls-verification-02.json'
with p.open('x') as stream:json.dump(result,stream,indent=2,sort_keys=True);stream.write('\n')
print(p,sha(p))
