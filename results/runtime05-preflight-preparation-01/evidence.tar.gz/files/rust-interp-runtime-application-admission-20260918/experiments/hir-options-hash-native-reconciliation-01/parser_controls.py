"""Read-only binding of eleven actual saved wrong-beta parser controls."""
import hashlib
import json
from pathlib import Path

A=Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
CONTROL=A/'experiments/native-wrong-beta-controls-01'
WORK=A/'.work/native-wrong-beta-controls-01'
OUTER=A/'.work/experiments/native-wrong-beta-controls-supervisor-01'
LAUNCHER=A/'.work/native-wrong-beta-controls-launch-execution-01'
AUDIT=A/'.work/native-wrong-beta-controls-independent-verification-01.json'
AUDIT_SHA='b8d689dd8573ac4676ae4e43b0266d0af84fd10ac265854dfc00fa90a2f0d835'
INPUTS_SHA='33a9d5f4a0eeefc578d5279283cda98b525094fd1ef19df62e7ce7081e8c2f2f'
LAUNCH_SHA='404bc697334ecf4de0d6da902e12190d3273426b349b6c3ab1ae8687b7aa4030'


def require(ok,message):
    if not ok:raise ValueError(message)


def validate(check,files):
    def read(path,expected=None):
        path=Path(check(Path(path)));require(path.stat().st_size<=2*2**20,'bounded wrong-beta-control proof')
        raw=path.read_bytes();require(expected is None or hashlib.sha256(raw).hexdigest()==expected,'wrong-beta control proof digest differs')
        return json.loads(raw)
    audit=read(AUDIT,AUDIT_SHA);freeze=read(CONTROL/'inputs.json',INPUTS_SHA);launch=read(CONTROL/'launch.json',LAUNCH_SHA)
    require(audit['status']=='verified' and audit['controls']==11 and audit['input_files']==24,'actual eleven-control audit required')
    for name,row in freeze['files'].items():
        check(Path(name));current=files[name]
        stamp=[current['identity'][key] for key in ['dev','ino','mode','size','mtime_ns','ctime_ns','nlink']]
        require(stamp==row['stamp'] and current['sha256']==row['sha256'],'tested wrong-beta source/fixture/runner changed')
    members=[]
    execution_root=A/'.work/native-wrong-beta-controls-verification-execution-01'
    for root in [WORK,OUTER,LAUNCHER,execution_root]:
        for path in sorted(root.rglob('*')):
            require(not path.is_symlink() and (path.is_file() or path.is_dir()),'indirect closed wrong-beta control evidence')
            if path.is_file():check(path);members.append(str(path))
    require(len(members)<=64,'bounded wrong-beta-control evidence membership')
    launcher=A/'.work/launch_native_wrong_beta_controls_01.py';verifier=A/'.work/verify_native_wrong_beta_controls_01.py'
    for path in [launcher,verifier]:check(path)
    terminal=read(WORK/'receipt.json',audit['receipt_sha256']);result=read(WORK/'result.json',audit['result_sha256'])
    outer=read(OUTER/'status.json');dispatcher=read(LAUNCHER/'record.json');execution=read(execution_root/'record.json')
    require(terminal['status']==result['status']=='passed' and terminal['controls_passed']==result['tests_run']==11
        and terminal['inputs_sha256']==INPUTS_SHA and terminal['result_sha256']==audit['result_sha256']
        and len(terminal['commands'])==1 and result['expected_names']==freeze['expected_names']==audit['exact_names'],'actual eleven-control result differs')
    require(all(result[k]==0 for k in ['failures','errors','skipped','expected_failures','unexpected_successes','child_processes','compiler_calls']),
        'eleven controls not completely passed')
    child_path=WORK/'command/receipt.json';child=read(child_path);ref=terminal['commands'][0]
    require(ref==dict(path=str(child_path),pid=child['pid'],sha256=files[str(child_path)]['sha256'])
        and child['status']=='finished' and child['returncode']==0 and child['command']==freeze['command']
        and child['environment']==freeze['environment'] and child['supervisor_pid']==terminal['pid']
        and child['parent_pid']==terminal['parent_pid'],'actual wrong-beta test-child association differs')
    require(outer['status']=='finished' and outer['returncode']==0 and outer['command']==launch['command'][6:]
        and outer['child_pid']==terminal['pid'] and outer['supervisor_pid']==terminal['parent_pid']
        and outer['child_started_at']<=terminal['started_at']<=terminal['admitted_at']<=child['started_at']
        <=child['finished_at']<=terminal['finished_at']<=outer['finished_at'],'actual wrong-beta-control outer differs')
    require(dispatcher['status']=='terminal-observed' and dispatcher['returncode']==0 and dispatcher['launcher_returncode']==0
        and dispatcher['outer_status']=='finished' and dispatcher['outer_sha256']==files[str(OUTER/'status.json')]['sha256']
        and dispatcher['command']==launch['command'] and dispatcher['environment']==launch['environment']
        and dispatcher['launch_sha256']==LAUNCH_SHA and dispatcher['launcher_source_sha256']==files[str(launcher)]['sha256']
        and dispatcher['controller_pid']==terminal['pid'] and dispatcher['supervisor_pid']==outer['supervisor_pid']
        and outer['finished_at']<=dispatcher['terminal_observed_at']==dispatcher['finished_at'],'actual bounded wrong-beta-control launcher differs')
    require(execution['returncode']==0 and execution['source_sha256']==audit['verifier_sha256']==files[str(verifier)]['sha256'],
        'wrong-beta-control audit execution differs')
    for stream in ['stdout','stderr']:
        require(files[str(WORK/'command'/stream)]['sha256']==child[stream+'_sha256']==audit['raw_sha256'][stream]
            and files[str(LAUNCHER/stream)]['sha256']==dispatcher[stream+'_sha256'],'actual wrong-beta-control raw differs')
    require(not list((WORK/'tmp').iterdir()),'wrong-beta-control fixtures remain')
    return dict(source=str(CONTROL),evidence=str(WORK),
        receipt_sha256=audit['receipt_sha256'],result_sha256=audit['result_sha256'],
        audit=dict(path=str(AUDIT),sha256=AUDIT_SHA),controls=11)
