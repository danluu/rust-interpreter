"""Read-only failed native02 audit; six actual return-zero rows remain unqualified.

Requires the exact failed terminal and finished outer supervisor. Reads actual retained
streams, complete frozen sources/providers and compressed snapshots. No command,
controller, compiler, provider probe or signal is invoked. Pure observation
modules are loaded only from already rehashed source bytes.
"""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import time
from types import ModuleType

A = Path('/Users/danluu/dev/rust-interp-runtime-application-admission-20260918')
X = Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
ROOT = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
HERE = A/'experiments/hir-options-hash-native-controls-02'
WORK = A/'.work/hir-options-hash-native-controls-02'
OUTER = A/'.work/experiments/hir-options-hash-native-controls-supervisor-02'
LAUNCHER = A/'.work/native-controls-launch-execution-02'
OUT = A/'.work/native-controls-failure-verification-02.json'
BETA_SOURCE = A/'experiments/hir-options-hash-beta-composition-08'
BETA_WORK = A/'.work/hir-options-hash-beta-composition-08'
N = X/'.work/hir-options-hash-compiler-01'
S = N/'source'
EXPECTED_LAUNCH = 'c3ff62de1f2ea130461feddbdef4438c8ce461933f9d749967ba5c19bae1d812'
EXPECTED_INPUTS = '33958301017e8d2107ee94dbe431fb4402deabd1d4a1fa8b2298038e4a2b1b0c'
EXPECTED_PLAN = 'a4cf3862479fc357a75a0577fdf3b60bb2b8ba0ced57434a31cd02c9e343c2c4'
EXPECTED_PROJECTION = 'acadb255f1b59060801c2af8302c54f456e73b7a570b9abd0bc327602c9fe339'
FIELDS = ('dev', 'ino', 'mode', 'nlink', 'size', 'mtime_ns', 'ctime_ns')
checked = {}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def unique(pairs):
    value = {}
    for name, row in pairs:
        require(name not in value, 'duplicate JSON key')
        value[name] = row
    return value


def read(path):
    path = Path(path)
    require(path.stat().st_size <= 64*2**20, 'bounded JSON input required')
    return json.loads(path.read_bytes(), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'))+'\n').encode()


def identity(path):
    info = Path(path).lstat()
    return {key:getattr(info, 'st_'+key) for key in FIELDS}


def stamp(path):
    s = identity(path)
    return [s[k] for k in ('dev', 'ino', 'mode', 'size', 'mtime_ns', 'ctime_ns', 'nlink')]


def sha(path):
    path = Path(path); before = identity(path)
    require(path.resolve(strict=True) == path and stat.S_ISREG(before['mode']), 'ordinary input required: '+str(path))
    if str(path) in checked and checked[str(path)]['identity'] == before:
        return checked[str(path)]['sha256']
    require(before['size'] <= 2*2**30, 'finite ordinary file bound')
    fd = os.open(path, os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        require({k:getattr(os.fstat(stream.fileno()), 'st_'+k) for k in FIELDS} == before, 'open identity differs')
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
        require({k:getattr(os.fstat(stream.fileno()), 'st_'+k) for k in FIELDS} == before, 'read identity changed')
    require(identity(path) == before, 'input changed while hashed')
    checked[str(path)] = dict(identity=before, sha256=value)
    return value


def frozen(path, freeze):
    path = Path(path); row = freeze['files'][str(path)]
    require(identity(path) == row['identity'] and sha(path) == row['sha256']
            and path.stat().st_size == row['size'], 'frozen input changed: '+str(path))
    return path


def names(root):
    root = Path(root); require(root.resolve(strict=True) == root and root.is_dir(), 'ordinary tree root required')
    found = {}
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in dirs+files:
            path = Path(parent)/name; info = path.lstat()
            require(stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode), 'special tree entry')
            found[str(path.relative_to(root))] = path
            require(len(found) <= 150000, 'bounded inventory required')
    return found


def verify_snapshots(freeze, receipt, projection_plan):
    projection = projection_plan['projection']; manifest = read(WORK/'source-snapshots.json')
    require(sha(WORK/'source-snapshots.json') == receipt['source_snapshots_sha256']
            and sha(WORK/'snapshot-plan.json') == receipt['snapshot_plan_sha256'] == sha(HERE/'snapshot-plan.json'), 'snapshot manifest/projection binding differs')
    require(manifest['policy'] == projection['policy'] == 'bounded-gzip-proof-snapshots-v1'
            and manifest['projection_sha256'] == hashlib.sha256(encoded(projection)).hexdigest()
            and manifest['blobs'] == projection['blobs']
            and manifest['full_logical_readback'] is True and manifest['full_gzip_eof'] is True, 'snapshot policy/projection differs')
    expected_names = set(freeze['snapshot_inputs']) | {str(HERE/'inputs.json')}
    require(set(projection['files']) == set(manifest['files']) == expected_names, 'snapshot logical member set differs')
    root = WORK/'source-snapshots'
    require(set(p.name for p in root.iterdir()) == {row['filename'] for row in projection['blobs'].values()}, 'snapshot physical membership differs')
    compressed_total = 0
    for digest, row in projection['blobs'].items():
        require(row['filename'] == digest+'.gz' and row['logical_sha256'] == digest, 'snapshot blob route differs')
        path = root/row['filename']; before = identity(path)
        require(before['nlink'] == 1 and before['size'] == row['compressed_bytes'] and sha(path) == row['sha256'], 'snapshot compressed bytes differ')
        total = 0; h = hashlib.sha256()
        with gzip.open(path, 'rb') as stream:
            while chunk := stream.read(min(2**20, row['logical_bytes']-total+1)):
                total += len(chunk); require(total <= row['logical_bytes'], 'snapshot expansion exceeded exact bound'); h.update(chunk)
        require(total == row['logical_bytes'] and h.hexdigest() == digest and identity(path) == before, 'full snapshot logical/gzipEOF readback differs')
        compressed_total += before['size']
    for name, row in projection['files'].items():
        require(sha(name) == row['sha256'] and identity(name) == row['identity'] and Path(name).stat().st_size == row['size'], 'snapshot original changed')
        require(manifest['files'][name] == dict(path=str(root/(row['sha256']+'.gz')), sha256=row['sha256'], size=row['size'], encoding='gzip'), 'logical snapshot route differs')
    require(compressed_total == projection['compressed_bytes'] == manifest['compressed_bytes'], 'snapshot compressed total differs')
    return dict(logical_files=len(expected_names), physical_blobs=len(projection['blobs']), compressed_bytes=compressed_total,
                full_logical_hashes=True, full_gzip_eof_crc=True, exact_projection=True)


def pure_module(name, path, freeze, dependencies=None):
    """Execute only the admitted parser/recipe source, avoiding stale pyc bytes."""
    path = frozen(path, freeze)
    require(path.stat().st_size <= 2*2**20, 'bounded pure source required')
    raw = path.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == freeze['files'][str(path)]['sha256'], 'pure source changed')
    module = ModuleType(name); module.__file__ = str(path); module.__package__ = None
    missing = object(); replacements = dict(dependencies or {}, **{name: module})
    old = {key:sys.modules.get(key, missing) for key in replacements}; old_path = list(sys.path)
    try:
        sys.modules.update(replacements)
        exec(compile(raw, str(path), 'exec'), module.__dict__)
    finally:
        sys.path[:] = old_path
        for key, value in old.items():
            if value is missing: sys.modules.pop(key, None)
            else: sys.modules[key] = value
    return module


def exact_file(row):
    path = Path(row['path'])
    require(identity(path) == row['identity'] and path.stat().st_size == row['size']
            and sha(path) == row['sha256'], 'actual artifact identity or bytes differ')
    return path


def b3_prerequisite(plan, freeze):
    reference = plan['assembly']
    require(reference['source'] == str(BETA_SOURCE) and reference['evidence'] == str(BETA_WORK), 'wrong actual B308 route')
    terminal = read(frozen(BETA_WORK/'receipt.json', freeze))
    audit_ref = reference['audit']; audit = read(frozen(audit_ref['path'], freeze))
    require(terminal['status'] == 'passed' and terminal['assembly_and_auxiliary_strip_qualified'] is True
            and len(terminal['commands']) == 19 and sha(BETA_WORK/'receipt.json') == reference['receipt_sha256'],
            'successful actual B3 prerequisite required')
    require(audit['status'] == 'verified' and audit['receipt_sha256'] == reference['receipt_sha256']
            and sha(audit_ref['path']) == audit_ref['sha256'], 'actual independent B3 audit differs')
    beta_freeze = read(frozen(BETA_SOURCE/'inputs.json', freeze))
    beta_plan = read(frozen(BETA_SOURCE/'plan.json', freeze))
    require(sha(BETA_SOURCE/'inputs.json') == reference['inputs_sha256'] == terminal['inputs_sha256']
            and sha(BETA_SOURCE/'plan.json') == beta_freeze['plan_sha256'], 'B3 plan/freeze differs')
    require(all(freeze['files'].get(name) == row for name, row in beta_freeze['files'].items())
            and all(freeze['links'].get(name) == row for name, row in beta_freeze['links'].items())
            and set(beta_freeze['absent_paths']) <= set(freeze['absent_paths']), 'complete B3 closure omitted')
    require(sha(frozen(BETA_SOURCE/'snapshot-plan.json', freeze))
            == sha(frozen(BETA_WORK/'snapshot-plan.json', freeze)) == terminal['snapshot_plan_sha256']
            and sha(frozen(BETA_WORK/'source-snapshots.json', freeze)) == terminal['source_snapshots_sha256'],
            'qualified B3 compressed proof binding differs')
    previous = terminal['admitted_at']
    for index, (ref, wanted) in enumerate(zip(terminal['commands'], beta_plan['children'], strict=True)):
        path = BETA_WORK/'commands'/f'{index:03}'/'receipt.json'
        child = read(frozen(path, freeze))
        require(ref['path'] == str(path) and sha(path) == ref['sha256'] and ref['pid'] == child['pid']
                and child['status'] == 'finished' and child['returncode'] == 0 and child['expected'] == [0]
                and child['command'] == ref['command'] == wanted['argv']
                and child['environment'] == wanted['environment'] and child['cwd'] == wanted['cwd'] == str(S)
                and child['supervisor_pid'] == terminal['pid'] and child['parent_pid'] == terminal['parent_pid']
                and previous <= child['started_at'] <= child['finished_at'] <= terminal['finished_at'],
                'B3 actual child association differs')
        previous = child['finished_at']
        for stream in ['stdout', 'stderr']:
            require(sha(frozen(path.parent/stream, freeze)) == child[stream+'_sha256'], 'B3 retained raw differs')
    inventory = read(frozen(BETA_WORK/'assembly/output-inventory.json', freeze))
    require(sha(BETA_WORK/'assembly/output-inventory.json') == terminal['assembly']['output_inventory_sha256'], 'B3 inventory hash differs')
    current = {name:path for name, path in names(N/'beta-sysroot').items() if not path.is_dir() or path.is_symlink()}
    require(set(current) == set(inventory) and len(inventory) == 335, 'complete B3 payload membership differs')
    for name, row in inventory.items():
        path = current[name]
        require(not path.is_symlink() and identity(path) == row['identity'] and sha(path) == row['sha256']
                and path.stat().st_size == row['size'] and stat.S_IMODE(path.stat().st_mode) == row['mode'], 'B3 payload changed')
    require(plan['ordered_driver_destinations'] == terminal['producer_proof']['ordered_driver_destinations']
            and plan['compiler'] == beta_plan['actual_build']
            and sha(frozen(BETA_WORK/'strip-proof.json', freeze)) == terminal['strip_proof_sha256'], 'B3 role/provenance/strip proof differs')
    compiled = read(frozen(Path(plan['compiler']['evidence'])/'compiled.json', freeze))
    compiler_audit = read(frozen(plan['compiler']['audit']['path'], freeze))
    require(compiled['source_identity'] == plan['source_identity']
            and compiled['candidate_revision'] == plan['candidate_revision']
            and compiler_audit['status'] == 'verified'
            and sha(plan['compiler']['audit']['path']) == plan['compiler']['audit']['sha256']
            and compiler_audit['compiled_sha256'] == sha(Path(plan['compiler']['evidence'])/'compiled.json'),
            'actual compiler prerequisite differs')
    require([compiler_audit[key] for key in ['children','saved_children','saved_actual_children',
                'combined_children','combined_actual_children']] == [3,22,23,25,26], 'compiler failure/success scope differs')
    return dict(receipt_sha256=sha(BETA_WORK/'receipt.json'), independent_audit=audit_ref,
                current_B3_files=len(inventory), actual_B3_children=19, compiler_logical_children=25,
                compiler_actual_children=26)



def successor_proof(plan, freeze, receipt, paths):
    control_module = pure_module('_native02_audit_stock_controls', HERE/'stock_controls.py', freeze)
    controls = control_module.validate(lambda path: frozen(path, freeze), freeze['files'])
    require(controls == plan['stock_source_controls'] and controls['controls'] == 4,
            'exact actual private-source derivation controls differ')
    prior_module = pure_module('_native02_audit_previous_attempt', HERE/'previous_attempt.py', freeze)
    prior = prior_module.validate(lambda path: frozen(path, freeze), freeze['files'])
    require(prior == plan['prior_failed_attempt']
            and prior['actual_children'] == 5 and prior['qualified_children'] == 0,
            'old failed-five attempt was changed or relabeled')
    old_root = N/'native-controls'
    require(set(old_root.iterdir()) == {old_root/'smoke-rustc'}
            and exact_file(prior['unqualified_stock']) == old_root/'smoke-rustc'
            and prior['unqualified_stock']['qualified'] is False,
            'old failed root/stock changed')
    old_audit = read(frozen(prior['audit']['path'], freeze))
    source = frozen(S/'compiler/rustc/src/main.rs', freeze)
    derive = pure_module('_native02_audit_stock_source', HERE/'stock_source.py', freeze)
    derived, proof = derive.derive(source.read_bytes(), source, paths['stock_source'])
    require(proof == plan['stock_source_derivation'] == receipt['stock_source_derivation'] and proof['removed_line'] == 4
            and proof['original_sha256'] == 'bfa21d3eced1a7ae4de80cb17e7f8840be640bfdfa96bff32fd6c63282d2c2ab'
            and proof['derived_sha256'] == '2830149bab94db375ec164229320f060096bd5c1ba2576045148bfc090fdcd68',
            'exact remove-only Cargo expectation derivation differs')
    source_path = exact_file(receipt['stock_source'])
    require(source_path == paths['stock_source']
            and source_path.read_bytes() == derived and identity(source_path)['nlink'] == 1
            and (identity(source_path)['dev'],identity(source_path)['ino']) != (identity(source)['dev'],identity(source)['ino']),
            'independent private stock source changed')
    return dict(prior_failed_attempt=prior, stock_source_controls=controls, historical_failed_children=5, qualified_children=0,
                total_actual_children=11, exact_old_root_membership=['smoke-rustc'], stock_source_derivation=proof,
                stock_source=receipt['stock_source'], historical_missing_cwd=old_audit['unavailable_contemporaneous_cwd'])


def main():
    require(all(isinstance(value,str) and re.fullmatch(r'[a-f0-9]{64}',value) for value in [EXPECTED_LAUNCH,EXPECTED_INPUTS,EXPECTED_PLAN,EXPECTED_PROJECTION]), 'unbound source-only verifier; exact reviewed native02 packet required')
    require(sys.dont_write_bytecode and not sys.flags.optimize, 'explicit unoptimized Python -B required')
    require(not OUT.exists() and not OUT.is_symlink(), 'actual audit output already exists')
    started = time.time()
    launch = read(HERE/'launch.json'); freeze = read(HERE/'inputs.json'); plan = read(HERE/'plan.json')
    receipt = read(WORK/'receipt.json'); outer = read(OUTER/'status.json')
    require(sha(HERE/'launch.json') == EXPECTED_LAUNCH
            and sha(HERE/'inputs.json') == EXPECTED_INPUTS == launch['inputs_sha256'] == receipt['inputs_sha256']
            and sha(HERE/'plan.json') == EXPECTED_PLAN == freeze['plan_sha256']
            and sha(HERE/'snapshot-plan.json') == EXPECTED_PROJECTION == launch['snapshot_plan_sha256'] == receipt['snapshot_plan_sha256'],
            'exact reviewed native launch/freeze/plan/projection required')
    require(receipt['status']=='failed' and receipt['error']=="ValueError('stock direct private edge is outside exact E2 closure')", 'exact preserved static-validation failure required')
    require(receipt['source_restored'] is False and all(receipt[k]==[] for k in ['fixture_compilations','native_executions','hits']), 'fixture execution unexpectedly began')
    require(all(receipt[k] is False for k in ['hash_driver_qualified','application_qualified','runtime_installation','benchmark']), 'failed attempt qualified a later stage')
    require(not (WORK/'native-controls.json').exists() and 'actual_loader' not in receipt and 'static_loader' not in receipt, 'unreached qualification evidence present')
    require(outer['status'] == 'finished' and outer['returncode'] == 1
            and outer['child_pid'] == receipt['pid'] and outer['supervisor_pid'] == receipt['parent_pid']
            and outer['cwd'] == str(A) and outer['command'] == launch['command'][6:]
            and outer['log_sha256'] == sha(OUTER/'command.log') and outer['plan_sha256'] == sha(OUTER/'plan.json')
            and outer['started_at'] <= outer['child_started_at'] <= receipt['started_at'] <= receipt['admitted_at']
                <= receipt['finished_at'] <= outer['finished_at'], 'actual native outer association differs')
    dispatch = read(LAUNCHER/'record.json')
    require(dispatch['status'] == 'terminal-observed' and dispatch['returncode'] == 1
            and dispatch['outer_status'] == 'finished' and dispatch['launcher_returncode'] == 0
            and dispatch['command'] == launch['command'] and dispatch['cwd'] == launch['owner'] == str(A)
            and dispatch['environment'] == launch['environment'] and dispatch['launch_sha256'] == EXPECTED_LAUNCH
            and dispatch['started_at'] <= outer['started_at']
            and outer['finished_at'] <= dispatch['terminal_observed_at'] == dispatch['finished_at']
            and dispatch['started_at'] <= dispatch['launcher_finished_at'] <= dispatch['terminal_observed_at']
            and dispatch['outer_sha256'] == sha(OUTER/'status.json')
            and dispatch['controller_pid'] == receipt['pid'] and dispatch['supervisor_pid'] == outer['supervisor_pid']
            and Path(dispatch['launcher_source_path']) == A/'.work/launch_native_controls_02.py'
            and sha(dispatch['launcher_source_path']) == dispatch['launcher_source_sha256']
                == '1eea5e675d051cc93d4c8273d87691aebb59471fe7187bf3134861b024eec927',
            'explicit bounded native launcher differs')
    require(dispatch['entry_free_bytes'] >= 24*2**30 and dispatch['maximum_wrapper_seconds'] == 30
            and dispatch['maximum_observation_seconds'] == 1800
            and dispatch['wrapper_identity_limitation'] == 'Popen PID retained; no separate contemporaneous wrapper ps/cwd probe.'
            and dispatch['launcher_identity']['source'] == 'in-process observation'
            and dispatch['launcher_identity']['pid'] == dispatch['launcher_pid']
            and dispatch['launcher_identity']['parent_pid'] == dispatch['launcher_parent_pid']
            and dispatch['launcher_identity']['cwd'] == str(A), 'launcher admission/observation contract differs')
    for stream in ['stdout','stderr']:
        require(sha(LAUNCHER/stream) == dispatch[stream+'_sha256'], 'launcher raw differs')
    handoff = read(LAUNCHER/'stdout')
    require(handoff == dispatch['supervisor_handoff'] and handoff['supervisor_pid'] == outer['supervisor_pid'] and handoff['directory'] == str(OUTER), 'launcher supervisor handoff differs')
    outer_plan = read(OUTER/'plan.json')
    require(outer_plan['owner'] == str(A) and outer_plan['command'] == launch['command'][6:]
            and outer_plan['supervisor_sha256'] == sha(frozen(A/'scripts/supervise_experiment.py',freeze)),
            'actual outer source/command binding differs')
    require(plan['capacity'] == dict(entry_gib=24,stop_gib=9,floor_gib=8,
        namespace_bytes=14*2**30,evidence_bytes=256*2**20), 'native capacity contract differs')
    for name in freeze['files']: frozen(name, freeze)
    for name, row in freeze['links'].items():
        path = Path(name)
        require(path.is_symlink() and stamp(path) == row['stamp'] and os.readlink(path) == row['target']
                and str(path.resolve(strict=True)) == row['resolved'], 'frozen provider route differs')
    for name in freeze['absent_paths']:
        require(not Path(name).exists() and not Path(name).is_symlink(), 'frozen absence changed')
    for name, resolved in plan['executor_routes'].items():
        require(str(Path(name).resolve(strict=True)) == resolved, 'native executor route differs')
    recipe = pure_module('_native_audit_recipe', HERE/'recipe.py', freeze)
    observed = pure_module('_native_audit_observations', HERE/'observations.py', freeze)
    require(plan['children'] == recipe.desired_commands(plan), 'native exact twenty-call recipe differs')
    paths = recipe.paths(N)
    successor = successor_proof(plan,freeze,receipt,paths)
    rows = []; previous = receipt['admitted_at']; missing_cwd = []
    require(len(receipt['commands']) == 6 and len(plan['children']) == 20, 'exact failed six / intended twenty required')
    for index, (ref, wanted) in enumerate(zip(receipt['commands'], plan['children'][:6], strict=True)):
        path = WORK/'commands'/f'{index:03}'/'receipt.json'; child = read(path)
        require(ref['path'] == str(path) and sha(path) == ref['sha256'] and ref['pid'] == child['pid']
                and ref['command'] == child['command'] == wanted['argv'] and ref['role'] == wanted['role']
                and child['status'] == 'finished' and child['returncode'] == 0 and wanted['expected']==[0]
                and child['expected'] == wanted['expected'] and child['environment'] == wanted['environment']
                and child['cwd'] == wanted['cwd'] == str(S), 'actual native child argv/environment/role/return differs')
        require(child['supervisor_pid'] == receipt['pid'] and child['parent_pid'] == receipt['parent_pid']
                and previous <= child['started_at'] <= child['finished_at'] <= receipt['finished_at'], 'native parent/time association differs')
        previous = child['finished_at']; obs = child['identity']
        require(obs['ps_returncode'] == 0 and obs['ps'].strip(), 'missing actual native PS observation')
        fields = obs['ps'].split()
        require(list(map(int,fields[:3])) == [child['pid'],receipt['pid'],child['pid']]
                and len(fields) > 9 and fields[8] == '??' and obs['ps'].endswith(' '.join(wanted['argv'])), 'native actual PID/parent/group/start/command differs')
        time.strptime(' '.join(fields[3:8]), '%a %b %d %H:%M:%S %Y')
        if obs['cwd_returncode'] == 0:
            require(obs['cwd'] == 'p'+str(child['pid'])+'\nfcwd\nn'+str(S)+'\n', 'native contemporaneous cwd differs')
        else:
            require(obs['cwd_returncode'] == 1 and obs['cwd'] == '', 'unexpected native cwd probe failure')
            missing_cwd.append(dict(index=index,pid=child['pid'],requested_cwd=str(S),
                limitation='Contemporaneous cwd unavailable for fast child; requested/recorded cwd retained, no success inferred.'))
        for stream in ['stdout','stderr']:
            require((path.parent/stream).stat().st_size <= 8*2**20
                    and sha(path.parent/stream) == child[stream+'_sha256'], 'bounded native raw stream differs')
        rows.append(dict(child=child,stdout=(path.parent/'stdout').read_bytes(),stderr=(path.parent/'stderr').read_bytes()))
    require(len({row['child']['pid'] for row in rows}) == 6, 'distinct native child identities required')
    for index, expected in enumerate([plan['build_version'],str(paths['build'])+'\n',plan['runtime_version'],str(paths['runtime'])+'\n']):
        require(rows[index]['stdout'].decode() == expected and not rows[index]['stderr'], 'native compiler version/sysroot observation differs')
    require(not rows[4]['stderr'] and not rows[5]['stderr'], 'stock compile and static probe emitted diagnostics')
    stock=exact_file(receipt['stock']);require(stock==paths['stock'], 'unqualified stock binding differs')
    linker=observed.link_command(rows[4]['stdout'],clang=plan['clang'],output=stock,runtime_lib=paths['runtime']/'lib')
    require(linker==receipt['linker'],'actual printed linker differs')
    try:
        observed.stock_macho(stock.read_bytes(),rows[5]['stdout'],stock=stock,driver=plan['runtime_driver']['path'],
            runtime_lib=paths['runtime']/'lib',qualified_private={row['logical']:row['resolved'] for row in plan['runtime_closure']['libraries']})
    except ValueError as error:
        require(repr(error)==receipt['error'],'preserved parser rejection differs')
        reproduced_error=repr(error)
    else:raise RuntimeError('frozen parser did not reproduce recorded failure')
    require(set(p.name for p in (WORK/'commands').iterdir())=={f'{i:03}' for i in range(6)}, 'failed command membership differs')
    for index in range(6):
        require(set(p.name for p in (WORK/'commands'/f'{index:03}').iterdir())=={'receipt.json','stdout','stderr'},'unexpected command evidence')
    require(set(p.name for p in paths['root'].iterdir())=={'smoke-rustc','stock-main.rs'}, 'unreached fixture root was created')
    require(not list((WORK/'artifacts').iterdir()),'failed attempt retained executed fixture programs')
    for path in [paths['fixture'].parent,paths['wrong_source'].parent,*[WORK/(name+'.rs') for name in ['original','error','restored']]]:
        require(not path.exists() and not path.is_symlink(),'unreached fixture source exists')
    stock_record=dict(receipt['stock'],qualified=False)
    require(stock_record['identity']['nlink']==1,'unqualified stock must be ordinary owned output')
    beta = b3_prerequisite(plan,freeze)
    projection_plan = read(HERE/'snapshot-plan.json')
    require(projection_plan['inputs_sha256'] == EXPECTED_INPUTS
            and projection_plan['evidence_cap_bytes'] == 256*2**20
            and projection_plan['remaining_evidence_reservation_bytes'] == 32*2**20
            and projection_plan['limits'] == dict(maximum_files=1024,maximum_file_bytes=64*2**20,
                maximum_logical_bytes=512*2**20,maximum_compressed_bytes=128*2**20,maximum_manifest_bytes=4*2**20)
            and projection_plan['helper'] == dict(path=str(ROOT/'experiments/bounded-proof-snapshots/proof_snapshots.py'),
                sha256=freeze['files'][str(ROOT/'experiments/bounded-proof-snapshots/proof_snapshots.py')]['sha256']),
            'snapshot admission policy differs')
    snapshots = verify_snapshots(freeze,receipt,projection_plan)
    reserve = projection_plan['projection']['compressed_bytes']+4096*len(projection_plan['projection']['files'])+8*2**20+32*2**20
    require(projection_plan['projected_reservation_bytes'] == reserve
            and receipt['snapshot_admission']['projected_reservation_bytes'] == reserve
            and receipt['snapshot_admission']['evidence_cap_bytes'] == 256*2**20
            and receipt['snapshot_admission']['existing_evidence_bytes']+reserve <= 256*2**20, 'actual compressed evidence reservation differs')
    for path, row in checked.items(): require(identity(path) == row['identity'], 'audited input changed before completion')
    evidence={}
    for root in [WORK,OUTER,LAUNCHER]:
        for name,path in names(root).items():
            require(not path.is_symlink(),'indirect actual evidence')
            if path.is_file():evidence[str(path)]=dict(identity=identity(path),size=path.stat().st_size,sha256=sha(path))
    report=dict(status='verified-retained-failure',receipt_sha256=sha(WORK/'receipt.json'),outer_sha256=sha(OUTER/'status.json'),
        launch_sha256=EXPECTED_LAUNCH,inputs_sha256=EXPECTED_INPUTS,plan_sha256=EXPECTED_PLAN,snapshot_plan_sha256=EXPECTED_PROJECTION,
        children=6,intended_children=20,unexecuted_indices=list(range(6,20)),all_child_returncodes_zero=True,
        historical_failed_children=5,total_actual_native_children=11,qualified_native_children=0,
        successor=successor,error=receipt['error'],frozen_parser_reproduced_error=reproduced_error,
        static_stdout_sha256=hashlib.sha256(rows[5]['stdout']).hexdigest(),stock_compile_stderr_empty=True,static_probe_stderr_empty=True,
        fixture_never_created=True,source_restored_flag=False,source_restored_flag_explanation='Initialized false; fixture creation occurs only after row006, which never ran.',
        original_source=plan['stock_source_derivation'],private_stock_source=receipt['stock_source'],unqualified_stock=stock_record,printed_linker=linker,
        evidence_files=evidence,unavailable_contemporaneous_cwd=missing_cwd,wrapper_identity_limitation=dispatch['wrapper_identity_limitation'],B3=beta,snapshots=snapshots,
        frozen_files=len(freeze['files']),frozen_bytes=sum(row['size'] for row in freeze['files'].values()),frozen_links=len(freeze['links']),
        full_current_input_hashes=True,native_roles_and_behavior_qualified=False,hash_driver_qualified=False,application_qualified=False,
        admitted_at=receipt['admitted_at'],released_at=outer['finished_at'],started_at=started,finished_at=time.time(),
        verifier_sha256=sha(Path(__file__).resolve()),execution='Read-only actual/current byte audit and exact frozen pure parser reproduction; no controller/provider/process calls.')
    for path,row in checked.items():require(identity(path)==row['identity'],'input changed before audit publication')
    with OUT.open('x') as stream:json.dump(report,stream,sort_keys=True,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    print(json.dumps(dict(path=str(OUT),sha256=sha(OUT),children=6,snapshots=snapshots)))

if __name__=='__main__':main()
