"""One-time source-manifest binding from actual closed retry33 evidence.

No imported project modules, subprocesses, locks, provider calls or deletions.
Historical qualification manifests remain unchanged.
"""
import hashlib
import json
import os
from pathlib import Path
import stat

ROOT = Path('/Users/danluu/dev/rust-interp-semantic-reuse-20260913')
SOURCE = ROOT/'experiments/runtime-preflight-retry-05'
CONTROL = ROOT/'experiments/runtime-preflight-retry-controls-05'
WORK = ROOT/'.work/runtime-preflight-retry-controls-05'
FIELDS = ('dev', 'ino', 'mode', 'nlink', 'size', 'mtime_ns', 'ctime_ns')


def raw(path):
    path = Path(path)
    before = path.lstat()
    assert path.is_absolute() and path.resolve(strict=True) == path
    assert stat.S_ISREG(before.st_mode) and before.st_size <= 16*2**20
    identity = {key: getattr(before, 'st_'+key) for key in FIELDS}
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        assert {key: getattr(os.fstat(stream.fileno()), 'st_'+key) for key in FIELDS} == identity
        data = stream.read(16*2**20+1)
        assert {key: getattr(os.fstat(stream.fileno()), 'st_'+key) for key in FIELDS} == identity
    assert {key: getattr(path.lstat(), 'st_'+key) for key in FIELDS} == identity
    assert len(data) == before.st_size
    return data, dict(identity=identity, size=len(data), sha256=hashlib.sha256(data).hexdigest())


def document(path, expected=None):
    data, row = raw(path)
    assert expected is None or row['sha256'] == expected
    return json.loads(data)


def ref(path):
    return dict(path=str(path), sha256=raw(path)[1]['sha256'])


def write(path, value):
    data = (json.dumps(value, sort_keys=True, indent=2)+'\n').encode()
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    assert raw(path)[0] == data


assert Path.cwd() == ROOT
audit_path = ROOT/'.work/runtime-preflight-retry-controls-independent-verification-05.json'
audit = document(audit_path, '65c10f5917dde90d0d03d7abd951e33c09ba076b401c6d0b00d9fbc046ff19a9')
assert audit['status'] == 'verified' and audit['controls'] == 33
execution_path = ROOT/'.work/runtime-preflight-retry-controls-verification-execution-05/record.json'
execution = document(execution_path, 'd3e9f4bb9393b3bf314c5cd5ad0525b1b632de32a43c9d66f6611547414895f9')
assert execution['status'] == 'finished' and execution['returncode'] == 0
assert execution['verified_output']['sha256'] == ref(audit_path)['sha256']
for name in ['stdout', 'stderr']:
    assert ref(execution_path.parent/name)['sha256'] == execution[name+'_sha256']
    assert ref(WORK/'command'/name)['sha256'] == audit['raw_sha256'][name]
assert ref(WORK/'receipt.json')['sha256'] == audit['receipt_sha256']
assert ref(WORK/'result.json')['sha256'] == audit['result_sha256']

inputs = document(CONTROL/'inputs.json', '671e7d0c7625bf576315a971ed165f92e3cdbf993918d0655a79639a0a0ff40f')
for name, expected in inputs['files'].items():
    row = raw(name)[1]
    assert row['sha256'] == expected['sha256'] and row['size'] == expected['stamp'][3]
    assert [row['identity'][key] for key in ['dev','ino','mode','size','mtime_ns','ctime_ns','nlink']] == expected['stamp']
for name, target in inputs['routes'].items():
    assert str(Path(name).resolve(strict=True)) == target

old_path = ROOT/'.work/runtime04-startup-qualified-source-manifest-02.json'
old = document(old_path, '79e71ee98aa413bef8862dffcc9bd40ad0631ab849e0c9ffc604cf3dfcfbd594')
old_adapter = ROOT/'experiments/runtime04-environment-adapter-01'
keep_noncode = {str(old_adapter/name) for name in ['README.md','source-bindings.json']}
keep_noncode.add(str(ROOT/'.work/runtime-startup-environment-controls-independent-verification-01.json'))
files = {name: row for name, row in old['files'].items() if name.endswith('.py') or name in keep_noncode}
assert len(files) == 30
for name, row in files.items():
    assert raw(name)[1] == row
new_names = [SOURCE/name for name in ['entry.py','controller.py','audit_owner.py','routes.json',
    'prepare.py','prepare_once.py','launch.py','test_retry.py']]
new_names += [CONTROL/name for name in ['run.py','child.py','prepare.py']]
new_names += [ROOT/'.work'/name for name in ['prepare_runtime_preflight_retry_controls_05_once.py',
    'launch_runtime_preflight_retry_controls_05_bounded.py', 'verify_runtime_preflight_retry_controls_05.py',
    'execute_runtime_preflight_retry_controls_audit_05.py']]
new_names += [audit_path, execution_path, execution_path.parent/'stdout', execution_path.parent/'stderr',
    ROOT/'.work/runtime-preflight-retry-controls-preparation-execution-05/record.json']
for path in new_names:
    row = raw(path)[1]
    assert str(path) not in files or files[str(path)] == row
    files[str(path)] = row

old_invocation_path = ROOT/'.work/runtime04-preflight-preparation-invocation-01.json'
invocation = document(old_invocation_path, 'fa2244b0e8d9913c553802bc104e27772f0af225752fff6f98501a2ffac8d94d')
wire = document(invocation['rehearsal_inputs']['path'], invocation['rehearsal_inputs']['sha256'])
base = document(wire['file_table_base']['path'], wire['file_table_base']['sha256'])
assert not set(base['files']) & set(wire['files'])
historical = set(document(invocation['retirement']['path'], invocation['retirement']['sha256'])['selected_paths'])
assert not set(files) & (historical | set(wire['absent_paths']))
full = dict(base['files'], **wire['files'])
union = {name: row for name, row in full.items() if name.startswith('/Users/danluu/dev/') and name.endswith('.py')}
for name, row in files.items():
    assert name not in full or full[name] == row
    assert name not in union or union[name] == row
    union[name] = row
assert len(union)+1 <= 512
assert sum(row['size'] for row in union.values()) + 256*1024 <= 8*2**20

manifest_path = ROOT/'.work/runtime05-startup-qualified-source-manifest-01.json'
invocation_path = ROOT/'.work/runtime05-preflight-preparation-invocation-01.json'
review_path = ROOT/'.work/runtime05-preparation-source-binding-review-01.json'
assert all(not os.path.lexists(path) for path in [manifest_path, invocation_path, review_path])
manifest = dict(status='reviewed-runtime-preflight05-startup-source-closure', files=files)
write(manifest_path, manifest)
union[str(manifest_path)] = raw(manifest_path)[1]
for name, row in union.items():
    assert raw(name)[1] == row
invocation['status'] = 'reviewed-runtime-preflight05-preparation'
invocation['adapter'] = dict(preparer=ref(SOURCE/'prepare.py'), source_manifest=ref(manifest_path),
    startup_controls=invocation['adapter']['startup_controls'], retry_controls=ref(audit_path))
write(invocation_path, invocation)
write(review_path, dict(status='bound-from-actual-closed-retry33', old_manifest=ref(old_path),
    source_manifest=ref(manifest_path), invocation=ref(invocation_path), retry_audit=ref(audit_path),
    retry_audit_execution=ref(execution_path), retained_old_manifest_rows=30,
    omitted_from_preimport_only=sorted(set(old['files'])-set(files)),
    omitted_files_deleted=False, reason='Retain all imported Python; raw old39 proof is independently added by the qualified preparer.',
    manifest_files=len(files), full_preimport_files=len(union),
    full_preimport_bytes=sum(row['size'] for row in union.values()),
    compiler_calls=0, provider_calls=0, runtime_preparation_executed=False))
print(json.dumps(dict(manifest=ref(manifest_path), invocation=ref(invocation_path), review=ref(review_path),
    preimport_files=len(union), preimport_bytes=sum(row['size'] for row in union.values()))))
