#!/usr/bin/env python3
"""Preserve the actual failed ReadyHit native attempt without changing its source."""
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import time
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
NATIVE = Path('/Users/danluu/dev/rust-interp-hir-native-correctness-20260913')
SOURCE = Path('/Users/danluu/dev/rustc-hir-capture-check-20260913')
RAW = NATIVE / '.work/hir-native-correctness-01'
PLAN = NATIVE / 'experiments/hir-native-correctness/planned-native-01.json'
PLAN_SHA = '27977dafa0f59c7f9ee891b2e27ad3e75acfb8606411dd4ef2f0104e2e6cab81'
REVISION = '3d7ad8282c5695196f4a4dcfd0bdceacac3f79b9'
PARENT = '9d21c2bae5edcfd6cae6e96f38731a740b7acc9e'
WORK = ROOT / '.work/hir-native-failed-history-archive-01'
OUT = ROOT / 'results/hir-native-correctness-failed-01'
sys.path.insert(0, str(ROOT / 'experiments/stable-cgu'))
from owned_stage import CANONICAL_LOCK, disk, require, run, sha, workload_lock, write, inventory

def digest(data): return hashlib.sha256(data).hexdigest()

def main():
    WORK.mkdir(parents=True, exist_ok=False)
    record = dict(status='waiting', pid=os.getpid(), parent_pid=os.getppid(), started_at=time.time(),
                  lock=str(CANONICAL_LOCK), lock_wait_seconds=600, source_mutations=0, compiler_commands=0)
    write(WORK / 'summary.json', record)
    try:
        with workload_lock(CANONICAL_LOCK, 600):
            record.update(status='running', admitted_at=time.time(), free_bytes_before=disk(ROOT))
            write(WORK / 'summary.json', record)
            payloads = {}
            def retain(path, expected=None):
                path = Path(path)
                require(path.is_absolute() and path.resolve(strict=True) == path and path.is_file()
                        and not path.is_symlink(), 'nonordinary evidence: ' + str(path))
                data = path.read_bytes()
                require(expected is None or digest(data) == expected, 'changed evidence: ' + str(path))
                require(str(path) not in payloads or payloads[str(path)] == data, 'changed captured evidence')
                payloads[str(path)] = data
                return data
            plan = json.loads(retain(PLAN, PLAN_SHA))
            for p,h in plan['inputs'].items(): retain(p,h)
            spec = importlib.util.spec_from_file_location('frozen_native', NATIVE/'experiments/hir-native-correctness/check.py')
            native = importlib.util.module_from_spec(spec); sys.modules[spec.name]=native; spec.loader.exec_module(native)
            old = native.old
            prior = plan['previous']; state = prior['source']; old_plan = prior['old_plan']
            require(native.inputs() == plan['inputs'] and native.extra_configurations() == plan['configurations']
                    and old.frozen_plan() == old_plan and state['revision'] == REVISION and state['parent'] == PARENT
                    and len(state['files']) == 62708 and len(state['backtrace_files']) == 102,
                    'native source/recipe identity changed')
            for p,h in old_plan['inputs'].items(): retain(p,h)
            for p in [Path(__file__), ROOT/'experiments/stable-cgu/owned_stage.py', ROOT/'scripts/supervise_experiment.py']:
                retain(p)
            for p,h in prior['files'].items(): require(sha(p)==h, 'ReadyHit source history changed')
            state_path = native.READY_WORK / 'source.json'
            require(json.loads(retain(state_path)) == state, 'ReadyHit source record changed')
            references = [dict(paths=plan['archive_paths'], hashes=plan['archive_hashes'], required=plan['archive_required']),
                          *prior['historical_archives']]
            verified=[]
            for ref, expected, count in zip(references, [
                    '6c390653214092e920b6b3fb9e3b3e33ebf41521870170f7a0fff515511b5b14',
                    '55061f25443157ef7ea125a1cad8920ce18d895f9c6f9a99d480df804b188f73',
                    '53a8fa2fab9504a8dbef7a44fbe26bf094a254bf8443f0cda43c9fe35eacaf54'],[324,314,318],strict=True):
                paths=ref['paths']; require(all(sha(p)==h for p,h in ref['hashes'].items()), 'prior archive changed')
                summary=json.loads(retain(paths['summary'])); manifest=json.loads(retain(paths['manifest']))
                require(sha(paths['archive'])==summary['archive']['sha256']==expected, 'wrong historical archive')
                seen=set()
                with tarfile.open(paths['archive'],'r:gz') as tar:
                    for member in tar:
                        require(member.isfile() and member.name not in seen,'bad prior member')
                        item=manifest[member.name]; data=tar.extractfile(member).read()
                        require(member.name==item['source'].lstrip('/') and len(data)==item['bytes']
                                and digest(data)==item['sha256'],'prior member changed')
                        seen.add(member.name)
                require(seen==set(manifest) and len(seen)==count,'prior archive incomplete')
                require(all(manifest[p.lstrip('/')]['sha256']==h for p,h in ref['required'].items()), 'prior proof missing')
                verified.append(dict(**ref,members=count,all_members_verified=True,payload_not_duplicated=True))
            commands=[]
            def command(argv,cwd=SOURCE):
                require(native.inputs()==plan['inputs'] and native.extra_configurations()==plan['configurations']
                        and old.frozen_plan()==old_plan,'frozen archive input changed')
                directory=WORK/'verification-commands'/f'{len(commands):03d}'
                child=run(argv,cwd=cwd,env=old_plan['environment'],out=directory,capacity_root=ROOT)
                commands.append(dict(command=argv,cwd=str(cwd),pid=child['pid'],receipt=str(directory/'receipt.json'),
                                     sha256=sha(directory/'receipt.json')))
                write(WORK/'verification-commands.json',commands)
                return dict(child,stdout=(directory/'stdout').read_text(),stderr=(directory/'stderr').read_text())
            def source_guard():
                native.engine.source_guard(state,command,sha(prior['old_plan_path']))
                require(command(['git','rev-parse','HEAD^'])['stdout'].strip()==PARENT
                        and not (SOURCE/'.git/objects/info/alternates').exists()
                        and not (SOURCE/'library/backtrace/.git/objects/info/alternates').exists(),'source lineage changed')
                old.verify_archives(old.ARCHIVES); old.verify_copied_archives()
                require(old.frozen_plan()==old_plan and native.extra_configurations()==plan['configurations'],'config changed')
            source_guard()
            retain(SOURCE/'.rust-interp-owned.json'); retain(SOURCE/'bootstrap.toml')
            command(['git','cat-file','-p',REVISION]); command(['git','cat-file','-p',PARENT])
            command(['git','diff','--binary',PARENT,REVISION,'--'])
            command(['git','diff','--binary',old.BASE,REVISION,'--'])
            patched={}
            manifest=native.checkpoint()[0]
            for name,row in manifest['files'].items():
                data=retain(SOURCE/name,row['after_sha256'])
                patched[name]=dict(path=str(SOURCE/name),sha256=digest(data),bytes=len(data))
            stages=[]; texts={}; last_finish=0
            for label,folder,status,expected_count,super_name in [
                ('plan','plan-01','passed',5,'plan'),('run','native-01','failed',21,'run')]:
                path=RAW/'stages'/folder/'receipt.json'; row=json.loads(retain(path))
                require(row['status']==status and row['stage']==label and len(row['commands'])==expected_count
                        and row.get('plan_sha256',row.get('expected_plan_sha256'))==PLAN_SHA
                        and row['started_at']<=row['admitted_at']<=row['finished_at']
                        and row['admitted_at']>=last_finish,'native terminal/order differs')
                last_finish=row['finished_at']
                for i,ref in enumerate(row['commands']):
                    cp=Path(ref['path']); child=json.loads(retain(cp,ref['sha256']))
                    require(cp==path.parent/'commands'/f'{i:03d}'/'receipt.json'
                            and child['status']=='finished' and child['command']==ref['command']
                            and child['returncode']==(1 if label=='run' and i==20 else 0),'native child changed')
                    text=retain(cp.parent/'stdout',child['stdout_sha256']).decode()+retain(cp.parent/'stderr',child['stderr_sha256']).decode()
                    if label=='run': texts[i]=text
                sp=NATIVE/'.work/experiments'/('hir-native-correctness-'+super_name+'-supervisor-01')
                outer=json.loads(retain(sp/'status.json'))
                require(outer['status']=='finished' and outer['returncode']==(0 if status=='passed' else 1)
                        and outer['child_pid']==row['pid'],'native supervisor changed')
                retain(sp/'plan.json',outer['plan_sha256']); retain(sp/'command.log',outer['log_sha256']); retain(sp/'supervisor.log')
                stages.append(dict(stage=label,path=str(path),sha256=sha(path),status=status,commands=expected_count))
            require('commit-hash: '+REVISION in texts[11] and texts[12].strip()==str(native.SYSROOT)
                    and all(re.search(r'(?m)^\s*-Z\s+'+opt+'=',texts[13]) for opt in
                            ['hir-body-cache-capture','hir-body-cache-reuse']),'actual stage1 probes changed')
            native.checked_option(texts[14])
            require('hir-body-cache-capture/rmake.rs:30:5' in texts[20]
                    and '0 passed; 1 failed; 0 ignored; 0 measured; 530 filtered out' in texts[20]
                    and not re.search(r'(?m)^\[hir-body-(?:capture|reuse)\]',texts[20]),'actual native failure differs')
            built=json.loads(retain(RAW/'stages/native-01/built-artifacts.json'))
            current=native.artifacts()
            require(all(current['files'].get(p)==v for p,v in built['files'].items())
                    and current['source_links']==built['source_links'],'original built stage1 runtime changed')
            write(WORK/'postfailure-stage1-artifacts.json',current)
            additions=sorted(set(current['files'])-set(built['files']))
            fixture=SOURCE/'build'/old.HOST/'test/run-make/hir-body-cache-capture'
            require(f'cd "{fixture}/rmake_out"' in texts[20] and fixture.resolve(strict=True)==fixture,'fixture route not proven')
            fixture_inventory=inventory(fixture)
            write(WORK/'postfailure-fixture-inventory.json',dict(root=str(fixture),files=fixture_inventory,
                association='actual retained rmake cwd and exact tracked recipe; binaries/caches hash-only'))
            for name,item in fixture_inventory.items():
                if Path(name).suffix in ['.rs','.json','.txt','.log','.stdout','.stderr','.out','.err']:
                    retain(fixture/name,item['sha256'])
            source_fixture=SOURCE/'tests/run-make/hir-body-cache-capture'
            fixture_sources={}
            for path in sorted(source_fixture.rglob('*')):
                if path.is_file():
                    name=str(path.relative_to(SOURCE)); require(state['files'][name]['kind']=='file','untracked fixture input')
                    data=retain(path,state['files'][name]['sha256']); fixture_sources[name]=digest(data)
                    if path.name!='rmake.rs':
                        copy=fixture/'rmake_out'/path.relative_to(source_fixture)
                        require(retain(copy)==data,'copied run-make input differs')
            write(WORK/'historical-references.json',dict(references=verified))
            source_guard()
            require(native.artifacts()==current and inventory(fixture)==fixture_inventory,'postfailure artifact changed during archive')
            guard=dict(status='passed',source=str(SOURCE),revision=REVISION,parent=PARENT,
                source_files=62708,backtrace_files=102,all_tracked_content_verified_twice=True,
                independent_postfailure_check=True,configuration_and_absences_verified=True,
                original_and_copied_seed_archives_verified=True,source_mutations=0,finished_at=time.time())
            write(WORK/'source-postguard.json',guard)
            for path in WORK.rglob('*'):
                if path.is_file() and path!=WORK/'summary.json': retain(path)
            require(all(Path(p).read_bytes()==data for p,data in payloads.items()),'captured bytes changed')
            OUT.mkdir(parents=True,exist_ok=False); archive=OUT/'evidence.tar.gz'; members={}
            with archive.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
                    with tarfile.open(fileobj=gz,mode='w') as tar:
                        for source,data in sorted(payloads.items()):
                            disk(ROOT); name=source.lstrip('/'); member=tarfile.TarInfo(name); member.size=len(data); member.mode=0o444
                            tar.addfile(member,io.BytesIO(data)); members[name]=dict(source=source,bytes=len(data),sha256=digest(data))
            seen=set()
            with tarfile.open(archive,'r:gz') as tar:
                for member in tar:
                    require(member.isfile() and member.name not in seen,'bad new archive member')
                    data=tar.extractfile(member).read(); item=members[member.name]
                    require(len(data)==item['bytes'] and digest(data)==item['sha256'],'archive readback differs'); seen.add(member.name)
            require(seen==set(members),'archive incomplete'); write(OUT/'manifest.json',members)
            summary=dict(schema_version=1,status='failed native history archived; source unchanged',owner=str(NATIVE),
                driver_revision='8b83ddd79b1e5cd7c185b33d8bfc88466da90b1f',checkpoint=native.CHECKPOINT,
                source=str(SOURCE),source_revision=REVISION,parent_revision=PARENT,
                plan=dict(path=str(PLAN),sha256=PLAN_SHA),stages=stages,total_original_commands=26,
                plan_commands=5,native_stage_commands=21,bootstrap_build_passed=True,identity_probes_passed=3,
                option_test=dict(passed=1,failed=0,ignored=0,filtered_out=17),
                native_runmake=dict(passed=0,failed=1,ignored=0,filtered_out=530,
                    failure='rmake.rs:30 initial capture assertion; no capture or reuse report lines'),
                capture_report_lines=0,verified_cache_hit_lines=0,native_hit_qualified=False,performance_claim=False,
                built_artifact_sha256=sha(RAW/'stages/native-01/built-artifacts.json'),
                postfailure_stage1_artifacts=dict(path=str(WORK/'postfailure-stage1-artifacts.json'),
                    sha256=sha(WORK/'postfailure-stage1-artifacts.json'),files=len(current['files']),additions=additions),
                fixture_inventory=dict(path=str(WORK/'postfailure-fixture-inventory.json'),sha256=sha(WORK/'postfailure-fixture-inventory.json'),
                    files=len(fixture_inventory),source_files=fixture_sources),
                historical_archives=verified,source_postguard=guard,patched_source_files=patched,
                archive=dict(path=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=len(members),
                    all_member_hashes_verified=True,gzip_mtime=0),manifest_sha256=sha(OUT/'manifest.json'),finished_at=time.time())
            write(OUT/'summary.json',summary)
            (OUT/'README.md').write_text('# Failed native HIR capture qualification\n\n'
                'The exact ReadyHit stage1 compiler build, three identity probes and tracked-option unit test passed. '
                'The native run-make failed its first capture assertion at rmake.rs:30; it produced no capture reports '
                'or verified cache-hit reports. Native cache-hit correctness and performance remain unqualified.\n\n'
                'This archive retains the five planning and 21 native-stage command receipts and raw outputs, both '
                'supervisors, exact frozen inputs, all 25 patched source files, built/current stage1 inventories and '
                'run-make source/output evidence. Compiler/runtime/cache binaries remain hash-only in their owned paths. '
                'All 62,708 source and 102 backtrace entries were independently verified twice after failure, including '
                'ownership, parent/HEAD, configuration absences and seed archives. The 324/314/318-member prior archives '
                'were independently verified and retained by reference. All new archive members passed readback.\n')
            record.update(status='passed',finished_at=time.time(),result=str(OUT),archive=summary['archive'],
                summary_sha256=sha(OUT/'summary.json'),source_postguard_sha256=sha(WORK/'source-postguard.json'),free_bytes_after=disk(ROOT))
            write(WORK/'summary.json',record)
    except BaseException as error:
        record.update(status='failed',finished_at=time.time(),error=repr(error)); write(WORK/'summary.json',record); raise
if __name__=='__main__': main()
