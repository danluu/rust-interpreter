//! Lowers the AST to the HIR.
//!
//! Since the AST and HIR are fairly similar, this is mostly a simple procedure,
//! much like a fold. Where lowering involves a bit more work things get more
//! interesting and there are some invariants you should know about. These mostly
//! concern spans and IDs.
//!
//! Spans are assigned to AST nodes during parsing and then are modified during
//! expansion to indicate the origin of a node and the process it went through
//! being expanded. IDs are assigned to AST nodes just before lowering.
//!
//! For the simpler lowering steps, IDs and spans should be preserved. Unlike
//! expansion we do not preserve the process of lowering in the spans, so spans
//! should not be modified here. When creating a new node (as opposed to
//! "folding" an existing one), create a new ID using `next_id()`.
//!
//! You must ensure that IDs are unique. That means that you should only use the
//! ID from an AST node in a single HIR node (you can assume that AST node-IDs
//! are unique). Every new node must have a unique ID. Avoid cloning HIR nodes.
//! If you do, you must then set the new node's ID to a fresh one.
//!
//! Spans are used for error messages and for tools to map semantics back to
//! source code. It is therefore not as important with spans as IDs to be strict
//! about use (you can't break the compiler by screwing up a span). Obviously, a
//! HIR node can only have a single span. But multiple nodes can have the same
//! span and spans don't need to be kept in order, etc. Where code is preserved
//! by lowering, it should have the same span as in the AST. Where HIR nodes are
//! new it is probably best to give a span for the whole AST node being lowered.
//! All nodes should have real spans; don't use dummy spans. Tools are likely to
//! get confused if the spans from leaf AST nodes occur in multiple places
//! in the HIR, especially for multiple identifiers.

// tidy-alphabetical-start
#![feature(const_default)]
#![feature(const_trait_impl)]
#![feature(default_field_values)]
#![feature(deref_patterns)]
#![recursion_limit = "256"]
// tidy-alphabetical-end

use std::mem;
use std::sync::Arc;

use rustc_ast::mut_visit::{self, MutVisitor};
use rustc_ast::node_id::NodeMap;
use rustc_ast::visit::{self, Visitor};
use rustc_ast::{self as ast, *};
use rustc_attr_parsing::{AttributeParser, Recovery, ShouldEmit};
use rustc_data_structures::fx::FxIndexMap;
use rustc_data_structures::sorted_map::SortedMap;
use rustc_data_structures::stable_hash::{StableHash, StableHasher};
use rustc_data_structures::steal::Steal;
use rustc_data_structures::tagged_ptr::TaggedRef;
use rustc_data_structures::unord::ExtendUnord;
use rustc_errors::codes::*;
use rustc_errors::{DiagArgFromDisplay, DiagCtxtHandle, ErrorGuaranteed};
use rustc_hir::attrs::lang_items::LangItem;
use rustc_hir::def::{DefKind, Namespace, PerNS, Res};
use rustc_hir::def_id::{DefId, LOCAL_CRATE, LocalDefId, LocalDefIdMap};
use rustc_hir::definitions::PerParentDisambiguatorState;
use rustc_hir::lints::DelayedLint;
use rustc_hir::{
    self as hir, AngleBrackets, ConstArg, GenericArg, HirId, ItemLocalMap, LifetimeSource,
    LifetimeSyntax, MissingLifetimeKind, ParamName, Target, TraitCandidate, find_attr,
};
use rustc_index::{Idx, IndexSlice, IndexVec};
use rustc_macros::extension;
use rustc_middle::middle::resolve::{
    AstOwner, LifetimeRes, PartialRes, PerOwnerResolverData, ResolverAstLowering,
};
use rustc_middle::queries::Providers;
use rustc_middle::span_bug;
use rustc_middle::ty::TyCtxt;
use rustc_session::diagnostics::add_feature_diagnostics;
use rustc_span::symbol::{Ident, Symbol, kw, sym};
use rustc_span::{DUMMY_SP, DesugaringKind, Span};
use smallvec::{SmallVec, smallvec};
use thin_vec::ThinVec;
use tracing::{debug, instrument, trace};

use crate::diagnostics::{AssocTyParentheses, AssocTyParenthesesSub, MisplacedImplTrait};

macro_rules! arena_vec {
    ($this:expr; $($x:expr),*) => (
        $this.arena.alloc_from_iter([$($x),*])
    );
}

mod asm;
mod block;
mod body_cache;
mod contract;
mod delegation;
mod diagnostics;
mod expr;
mod format;
mod index;
mod item;
mod pat;
mod path;
pub mod stability;

pub fn provide(providers: &mut Providers) {
    providers.index_ast = index_ast;
    providers.lower_to_hir = lower_to_hir;
}

#[cfg(debug_assertions)]
pub(crate) mod re_lowering {
    use rustc_ast::NodeId;
    use rustc_ast::node_id::NodeMap;
    use rustc_hir as hir;

    use crate::LoweringContext;

    #[derive(Debug, Default)]
    pub(crate) struct ReloweringChecker {
        node_id_to_local_id: NodeMap<hir::ItemLocalId>,
        can_relower: bool,
    }

    impl ReloweringChecker {
        pub(crate) fn body_snapshot(&self) -> Option<NodeMap<hir::ItemLocalId>> {
            (!self.can_relower).then(|| self.node_id_to_local_id.clone())
        }

        pub(crate) fn assert_node_is_not_relowered(
            &mut self,
            ast_node_id: NodeId,
            local_id: hir::ItemLocalId,
        ) {
            if !self.can_relower {
                let old = self.node_id_to_local_id.insert(ast_node_id, local_id);
                assert_eq!(old, None);
            }
        }

        pub(crate) fn allow_relowering<'a, 'hir, TRes>(
            ctx: &mut LoweringContext<'a, 'hir>,
            op: impl FnOnce(&mut LoweringContext<'a, 'hir>) -> TRes,
        ) -> TRes {
            assert!(
                !ctx.curr_owner.relowering_checker.can_relower,
                "reentrant relowering is not supported"
            );

            ctx.curr_owner.relowering_checker.can_relower = true;

            let res = op(ctx);

            ctx.curr_owner.relowering_checker.can_relower = false;

            res
        }
    }
}

struct PerOwnerLoweringState<'a, 'hir> {
    // -- Identity --
    owner: &'a PerOwnerResolverData<'hir>,
    owner_id: hir::OwnerId,
    disambiguator: PerParentDisambiguatorState,

    // -- HirId allocation --
    item_local_id_counter: hir::ItemLocalId,
    /// NodeIds of pattern identifiers and labelled nodes that are lowered inside the current HIR
    /// owner.
    ident_and_label_to_local_id: NodeMap<hir::ItemLocalId>,
    /// NodeIds that are lowered inside the current HIR owner. Only used for duplicate lowering
    /// check.
    #[cfg(debug_assertions)]
    relowering_checker: re_lowering::ReloweringChecker,

    // -- Accumulated outputs --
    /// Attributes inside the owner being lowered.
    attrs: SortedMap<hir::ItemLocalId, &'hir [hir::Attribute]>,
    /// Bodies inside the owner being lowered.
    bodies: Vec<(hir::ItemLocalId, &'hir hir::Body<'hir>)>,
    /// `#[define_opaque]` attributes
    define_opaque: Option<&'hir [(Span, LocalDefId)]>,
    trait_map: ItemLocalMap<&'hir [TraitCandidate<'hir>]>,
    delayed_lints: Vec<DelayedLint>,
    /// Collect items that were created by lowering the current owner.
    children: LocalDefIdMap<hir::MaybeOwner<'hir>>,

    // -- Transient --
    impl_trait_defs: Vec<hir::GenericParam<'hir>>,
    impl_trait_bounds: Vec<hir::WherePredicate<'hir>>,
}

impl<'a, 'hir> PerOwnerLoweringState<'a, 'hir> {
    fn new(resolver: &'a ResolverAstLowering<'hir>, owner: NodeId) -> Self {
        let owner = &resolver.owners[&owner];

        let disambiguator = resolver
            .disambiguators
            .get(&owner.def_id)
            .map(|s| s.steal())
            .unwrap_or_else(|| PerParentDisambiguatorState::new(owner.def_id));

        PerOwnerLoweringState {
            owner,
            owner_id: hir::OwnerId { def_id: owner.def_id },
            disambiguator,
            // 0 corresponds to `owner` lowered as `owner_id`, and we never call
            // `lower_node_id(owner)`.
            item_local_id_counter: hir::ItemLocalId::new(1),
            ident_and_label_to_local_id: Default::default(),
            #[cfg(debug_assertions)]
            relowering_checker: Default::default(),
            attrs: SortedMap::default(),
            bodies: Vec::new(),
            define_opaque: None,
            trait_map: Default::default(),
            delayed_lints: Vec::new(),
            children: LocalDefIdMap::default(),
            impl_trait_defs: Vec::new(),
            impl_trait_bounds: Vec::new(),
        }
    }

    fn into_owner_info(
        self,
        tcx: TyCtxt<'hir>,
        node: hir::OwnerNode<'hir>,
    ) -> &'hir hir::OwnerInfo<'hir> {
        assert_eq!(self.owner_id, node.def_id());
        assert!(self.impl_trait_defs.is_empty());
        assert!(self.impl_trait_bounds.is_empty());

        let attrs = self.attrs;
        let mut bodies = self.bodies;
        let define_opaque = self.define_opaque;
        let trait_map = self.trait_map;
        let delayed_lints = Steal::new(self.delayed_lints.into_boxed_slice());
        let children = self.children;

        #[cfg(debug_assertions)]
        for (id, attrs) in attrs.iter() {
            // Verify that we do not store empty slices in the map.
            if attrs.is_empty() {
                panic!("Stored empty attributes for {:?}", id);
            }
        }

        bodies.sort_by_key(|(k, _)| *k);
        let bodies = SortedMap::from_presorted_elements(bodies);

        // Don't hash unless necessary, because it's expensive.
        let rustc_middle::hir::Hashes { bodies_hash, attrs_hash } =
            tcx.hash_owner_nodes(node, &bodies, &attrs, define_opaque);
        let num_nodes = self.item_local_id_counter.as_usize();
        let (nodes, parenting) = index::index_hir(tcx, node, &bodies, num_nodes);
        let nodes = hir::OwnerNodes { opt_hash: bodies_hash, nodes, bodies };
        let attrs = hir::AttributeMap { map: attrs, opt_hash: attrs_hash, define_opaque };

        let opt_hash = tcx.needs_hir_hash().then(|| {
            tcx.with_stable_hashing_context(|mut hcx| {
                let mut stable_hasher = StableHasher::new();
                bodies_hash.unwrap().stable_hash(&mut hcx, &mut stable_hasher);
                attrs_hash.unwrap().stable_hash(&mut hcx, &mut stable_hasher);
                // Do not hash delayed_lints.
                parenting.stable_hash(&mut hcx, &mut stable_hasher);
                trait_map.stable_hash(&mut hcx, &mut stable_hasher);
                children.stable_hash(&mut hcx, &mut stable_hasher);
                stable_hasher.finish()
            })
        });

        tcx.hir_arena.alloc(hir::OwnerInfo {
            opt_hash,
            nodes,
            parenting,
            attrs,
            trait_map,
            delayed_lints,
            children,
        })
    }
}

struct LoweringContext<'a, 'hir> {
    tcx: TyCtxt<'hir>,
    resolver: &'a ResolverAstLowering<'hir>,

    curr_owner: PerOwnerLoweringState<'a, 'hir>,

    /// Used to allocate HIR nodes.
    arena: &'hir hir::Arena<'hir>,

    contract_ensures: Option<(Span, Ident, HirId)>,

    coroutine_kind: Option<hir::CoroutineKind>,

    /// When inside an `async` context, this is the `HirId` of the
    /// `task_context` local bound to the resume argument of the coroutine.
    task_context: Option<HirId>,

    /// Used to get the current `fn`'s def span to point to when using `await`
    /// outside of an `async fn`.
    current_item: Option<Span>,

    try_block_scope: TryBlockScope,
    loop_scope: Option<HirId>,
    is_in_loop_condition: bool,
    is_in_dyn_type: bool,

    /// The `NodeId` space is split in two.
    /// `0..resolver.next_node_id` are created by the resolver on the AST.
    /// The higher part `resolver.next_node_id..next_node_id` are created during lowering.
    next_node_id: NodeId,
    /// Maps the `NodeId`s created during lowering to `LocalDefId`s.
    node_id_to_def_id: NodeMap<LocalDefId>,
    /// Overlay over resolver's `partial_res_map` used by delegation.
    /// This only contains `PartialRes::new(Res::Local(self_param_id))`,
    /// so we only store `self_param_id`.
    partial_res_overrides: NodeMap<NodeId>,

    allow_contracts: Arc<[Symbol]>,
    allow_try_trait: Arc<[Symbol]>,
    allow_gen_future: Arc<[Symbol]>,
    allow_pattern_type: Arc<[Symbol]>,
    allow_async_gen: Arc<[Symbol]>,
    allow_async_iterator: Arc<[Symbol]>,
    allow_for_await: Arc<[Symbol]>,
    allow_async_fn_traits: Arc<[Symbol]>,

    /// Stack of `move(...)` collection states. A plain closure body pushes
    /// `Some`, so `move(...)` expressions can record the generated locals they
    /// should lower to. Nested bodies that cannot use `move(...)` push `None`.
    move_expr_bindings: Vec<Option<expr::MoveExprState<'hir>>>,

    attribute_parser: AttributeParser<'hir>,
    body_candidate: Option<body_cache::Candidate>,
    body_trace: Option<body_cache::Trace>,
}

impl<'a, 'hir> LoweringContext<'a, 'hir> {
    fn new(tcx: TyCtxt<'hir>, resolver: &'a ResolverAstLowering<'hir>, owner: NodeId) -> Self {
        Self {
            tcx,
            resolver,
            curr_owner: PerOwnerLoweringState::new(resolver, owner),
            arena: tcx.hir_arena,

            contract_ensures: None,

            next_node_id: resolver.next_node_id,
            node_id_to_def_id: NodeMap::default(),
            partial_res_overrides: NodeMap::default(),

            // Lowering state.
            try_block_scope: TryBlockScope::Function,
            loop_scope: None,
            is_in_loop_condition: false,
            is_in_dyn_type: false,
            coroutine_kind: None,
            task_context: None,
            current_item: None,
            allow_contracts: [sym::contracts_internals].into(),
            allow_try_trait: [
                sym::try_trait_v2,
                sym::try_trait_v2_residual,
                sym::yeet_desugar_details,
            ]
            .into(),
            allow_pattern_type: [sym::pattern_types, sym::pattern_type_range_trait].into(),
            allow_gen_future: if tcx.features().async_fn_track_caller() {
                [sym::gen_future, sym::closure_track_caller].into()
            } else {
                [sym::gen_future].into()
            },
            allow_for_await: [sym::async_gen_internals, sym::async_iterator].into(),
            allow_async_fn_traits: [sym::async_fn_traits].into(),
            allow_async_gen: [sym::async_gen_internals].into(),
            // FIXME(gen_blocks): how does `closure_track_caller`/`async_fn_track_caller`
            // interact with `gen`/`async gen` blocks
            allow_async_iterator: [sym::gen_future, sym::async_iterator].into(),

            move_expr_bindings: Vec::new(),
            body_candidate: None,
            body_trace: None,
            attribute_parser: AttributeParser::new(
                tcx.sess,
                tcx.features(),
                tcx.registered_attr_tools(()),
                ShouldEmit::ErrorsAndLints { recovery: Recovery::Allowed },
            ),
        }
    }

    pub(crate) fn dcx(&self) -> DiagCtxtHandle<'hir> {
        self.tcx.dcx()
    }
}

struct SpanLowerer {
    is_incremental: bool,
    def_id: LocalDefId,
}

impl SpanLowerer {
    fn lower(&self, span: Span) -> Span {
        if self.is_incremental {
            span.with_parent(Some(self.def_id))
        } else {
            // Do not make spans relative when not using incremental compilation.
            span
        }
    }
}

#[extension(trait ResolverAstLoweringExt<'tcx>)]
impl<'tcx> ResolverAstLowering<'tcx> {
    fn legacy_const_generic_args(&self, expr: &Expr, tcx: TyCtxt<'tcx>) -> Option<Vec<usize>> {
        let ExprKind::Path(None, path) = &expr.kind else {
            return None;
        };

        // Don't perform legacy const generics rewriting if the path already
        // has generic arguments.
        if path.segments.last().unwrap().args.is_some() {
            return None;
        }

        // We do not need to look at `partial_res_overrides`. That map only contains overrides for
        // `self_param` locals. And here we are looking for the function definition that `expr`
        // resolves to.
        let def_id = self.partial_res_map.get(&expr.id)?.full_res()?.opt_def_id()?;

        // We only support cross-crate argument rewriting. Uses
        // within the same crate should be updated to use the new
        // const generics style.
        if def_id.is_local() {
            return None;
        }

        // we can use parsed attrs here since for other crates they're already available
        find_attr!(
            tcx, def_id,
            RustcLegacyConstGenerics{fn_indexes,..} => fn_indexes
        )
        .map(|fn_indexes| fn_indexes.iter().map(|(num, _)| *num).collect())
    }
}

/// How relaxed bounds `?Trait` should be treated.
///
/// Relaxed bounds should only be allowed in places where we later
/// (namely during HIR ty lowering) perform *sized elaboration*.
#[derive(Debug)]
enum RelaxedBoundPolicy<'a> {
    /// The `DefId` refers to the trait that is being relaxed.
    Allowed(&'a mut FxIndexMap<DefId, Span>),
    Forbidden(RelaxedBoundForbiddenReason),
}
impl RelaxedBoundPolicy<'_> {
    fn reborrow(&mut self) -> RelaxedBoundPolicy<'_> {
        match self {
            RelaxedBoundPolicy::Allowed(m) => RelaxedBoundPolicy::Allowed(m),
            RelaxedBoundPolicy::Forbidden(reason) => RelaxedBoundPolicy::Forbidden(*reason),
        }
    }
}

#[derive(Clone, Copy, Debug)]
enum RelaxedBoundForbiddenReason {
    TraitObjectTy,
    SuperTrait,
    TraitAlias,
    AssocTyBounds,
    /// We do not allow where bounds doing relaxed bounds,
    /// except if it's for generic parameters of the current item.
    WhereBound,
}

/// Context of `impl Trait` in code, which determines whether it is allowed in an HIR subtree,
/// and if so, what meaning it has.
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
enum ImplTraitContext {
    /// Treat `impl Trait` as shorthand for a new universal generic parameter.
    /// Example: `fn foo(x: impl Debug)`, where `impl Debug` is conceptually
    /// equivalent to a fresh universal parameter like `fn foo<T: Debug>(x: T)`.
    ///
    /// Newly generated parameters should be inserted into the given `Vec`.
    Universal,

    /// Treat `impl Trait` as shorthand for a new opaque type.
    /// Example: `fn foo() -> impl Debug`, where `impl Debug` is conceptually
    /// equivalent to a new opaque type like `type T = impl Debug; fn foo() -> T`.
    ///
    OpaqueTy { origin: hir::OpaqueTyOrigin<LocalDefId> },

    /// Treat `impl Trait` as a "trait ascription", which is like a type
    /// variable but that also enforces that a set of trait goals hold.
    ///
    /// This is useful to guide inference for unnameable types.
    InBinding,

    /// `impl Trait` is unstably accepted in this position.
    FeatureGated(ImplTraitPosition, Symbol),
    /// `impl Trait` is not accepted in this position.
    Disallowed(ImplTraitPosition),

    /// An error has already been emitted for this type.
    AlreadyErrored(ErrorGuaranteed),
}

/// Position in which `impl Trait` is disallowed.
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
enum ImplTraitPosition {
    Path,
    Variable,
    Trait,
    Bound,
    Generic,
    ExternFnParam,
    ClosureParam,
    PointerParam,
    FnTraitParam,
    ExternFnReturn,
    ClosureReturn,
    PointerReturn,
    FnTraitReturn,
    GenericDefault,
    ConstTy,
    StaticTy,
    AssocTy,
    FieldTy,
    Cast,
    ImplSelf,
    OffsetOf,
}

impl std::fmt::Display for ImplTraitPosition {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let name = match self {
            ImplTraitPosition::Path => "paths",
            ImplTraitPosition::Variable => "the type of variable bindings",
            ImplTraitPosition::Trait => "traits",
            ImplTraitPosition::Bound => "bounds",
            ImplTraitPosition::Generic => "generics",
            ImplTraitPosition::ExternFnParam => "`extern fn` parameters",
            ImplTraitPosition::ClosureParam => "closure parameters",
            ImplTraitPosition::PointerParam => "`fn` pointer parameters",
            ImplTraitPosition::FnTraitParam => "the parameters of `Fn` trait bounds",
            ImplTraitPosition::ExternFnReturn => "`extern fn` return types",
            ImplTraitPosition::ClosureReturn => "closure return types",
            ImplTraitPosition::PointerReturn => "`fn` pointer return types",
            ImplTraitPosition::FnTraitReturn => "the return type of `Fn` trait bounds",
            ImplTraitPosition::GenericDefault => "generic parameter defaults",
            ImplTraitPosition::ConstTy => "const types",
            ImplTraitPosition::StaticTy => "static types",
            ImplTraitPosition::AssocTy => "associated types",
            ImplTraitPosition::FieldTy => "field types",
            ImplTraitPosition::Cast => "cast expression types",
            ImplTraitPosition::ImplSelf => "impl headers",
            ImplTraitPosition::OffsetOf => "`offset_of!` parameters",
        };

        write!(f, "{name}")
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum FnDeclKind {
    Fn,
    Inherent,
    ExternFn,
    Closure,
    Pointer,
    Trait,
    Impl,
}

#[derive(Copy, Clone, Debug)]
enum TryBlockScope {
    /// There isn't a `try` block, so a `?` will use `return`.
    Function,
    /// We're inside a `try { … }` block, so a `?` will block-break
    /// from that block using a type depending only on the argument.
    Homogeneous(HirId),
    /// We're inside a `try as _ { … }` block, so a `?` will block-break
    /// from that block using the type specified.
    Heterogeneous(HirId),
}

fn index_ast<'tcx>(
    tcx: TyCtxt<'tcx>,
    (): (),
) -> &'tcx IndexSlice<LocalDefId, Steal<(Arc<ResolverAstLowering<'tcx>>, AstOwner)>> {
    // Queries that borrow `resolver_for_lowering`.
    tcx.ensure_done().output_filenames(());
    tcx.ensure_done().early_lint_checks(());
    tcx.ensure_done().get_lang_items(());
    tcx.ensure_done().debugger_visualizers(LOCAL_CRATE);

    let (resolver, krate) = tcx.resolver_for_lowering();
    let mut resolver = resolver.steal();
    let mut krate = krate.steal();

    let mut indexer = Indexer {
        owners: &resolver.owners,
        index: IndexVec::new(),
        next_node_id: resolver.next_node_id,
    };
    indexer.visit_crate(&mut krate);
    indexer.insert(CRATE_NODE_ID, AstOwner::Crate(Box::new(krate)));
    resolver.next_node_id = indexer.next_node_id;

    let index = indexer.index;
    let resolver = Arc::new(resolver);
    return tcx.arena.alloc_index_slice_from_iter::<LocalDefId, _, _>(
        index.into_iter().map(|owner| Steal::new((Arc::clone(&resolver), owner))),
    );

    struct Indexer<'s, 'hir> {
        owners: &'s NodeMap<PerOwnerResolverData<'hir>>,
        index: IndexVec<LocalDefId, AstOwner>,
        next_node_id: NodeId,
    }

    impl Indexer<'_, '_> {
        fn insert(&mut self, id: NodeId, node: AstOwner) {
            let def_id = self.owners[&id].def_id;
            self.index.ensure_contains_elem(def_id, || AstOwner::NonOwner);
            self.index[def_id] = node;
        }

        fn make_dummy<K>(
            &mut self,
            id: NodeId,
            span: Span,
            dummy: impl FnOnce(Box<MacCall>) -> K,
        ) -> Box<Item<K>> {
            use rustc_ast::token::Delimiter;
            use rustc_ast::tokenstream::{DelimSpan, TokenStream};
            use thin_vec::thin_vec;

            Box::new(Item {
                attrs: AttrVec::default(),
                id,
                span,
                vis: Visibility { kind: VisibilityKind::Public, span },
                // Lacking a better choice, we replace the contents with a macro call.
                // Unexpanded macros should never reach lowering, so this is not confusing.
                kind: dummy(Box::new(MacCall {
                    path: Path { span, segments: thin_vec![] },
                    args: Box::new(DelimArgs {
                        dspan: DelimSpan::from_single(span),
                        delim: Delimiter::Parenthesis,
                        tokens: TokenStream::new(Vec::new()),
                    }),
                })),
                tokens: None,
            })
        }

        fn replace_with_dummy<K>(
            &mut self,
            item: &mut ast::Item<K>,
            dummy: impl FnOnce(Box<MacCall>) -> K,
            node: impl FnOnce(Box<Item<K>>) -> AstOwner,
        ) {
            let dummy = self.make_dummy(item.id, item.span, dummy);
            let item = mem::replace(item, *dummy);
            self.insert(item.id, node(Box::new(item)));
        }

        #[tracing::instrument(level = "trace", skip(self))]
        fn visit_item_id_use_tree(
            &mut self,
            tree: &UseTree,
            parent: LocalDefId,
            items: &mut SmallVec<[Box<Item>; 1]>,
        ) {
            match tree.kind {
                UseTreeKind::Glob(_) | UseTreeKind::Simple(_) => {}
                UseTreeKind::Nested { items: ref nested_vec, span } => {
                    for &(ref nested, id) in nested_vec {
                        self.insert(id, AstOwner::NestedUseTree(parent));
                        items.push(self.make_dummy(id, span, ItemKind::MacCall));

                        let def_id = self.owners[&id].def_id;
                        self.visit_item_id_use_tree(nested, def_id, items);
                    }
                }
            }
        }
    }

    impl MutVisitor for Indexer<'_, '_> {
        fn visit_attribute(&mut self, _: &mut Attribute) {
            // We do not want to lower expressions that appear in attributes,
            // as they are not accessible to the rest of the HIR.
        }

        fn flat_map_item(&mut self, mut item: Box<Item>) -> SmallVec<[Box<Item>; 1]> {
            let def_id = self.owners[&item.id].def_id;
            mut_visit::walk_item(self, &mut *item);
            let dummy = self.make_dummy(item.id, item.span, ItemKind::MacCall);
            let mut items = smallvec![dummy];
            if let ItemKind::Use(ref use_tree) = item.kind {
                self.visit_item_id_use_tree(use_tree, def_id, &mut items);
            }
            self.insert(item.id, AstOwner::Item(item));
            items
        }

        fn flat_map_stmt(&mut self, stmt: Stmt) -> SmallVec<[Stmt; 1]> {
            let Stmt { id, span, kind } = stmt;
            let mut id = Some(id);
            mut_visit::walk_flat_map_stmt_kind(self, kind)
                .into_iter()
                .map(|kind| {
                    // Expanding the current statement is a nested `use` item,
                    // it is expanded into several flat `use` items.
                    // Create new NodeIds for the corresponding statements
                    // as two statements cannot have the same.
                    let id = id.take().unwrap_or_else(|| {
                        let next = self.next_node_id;
                        self.next_node_id.increment_by(1);
                        next
                    });
                    Stmt { id, kind, span }
                })
                .collect()
        }

        fn visit_assoc_item(&mut self, item: &mut AssocItem, ctxt: visit::AssocCtxt) {
            mut_visit::walk_assoc_item(self, item, ctxt);
            match ctxt {
                visit::AssocCtxt::Trait => {
                    self.replace_with_dummy(item, AssocItemKind::MacCall, AstOwner::TraitItem)
                }
                visit::AssocCtxt::Impl { .. } => {
                    self.replace_with_dummy(item, AssocItemKind::MacCall, AstOwner::ImplItem)
                }
            }
        }

        fn visit_foreign_item(&mut self, item: &mut ForeignItem) {
            mut_visit::walk_item(self, item);
            self.replace_with_dummy(item, ForeignItemKind::MacCall, AstOwner::ForeignItem);
        }
    }
}

#[instrument(level = "trace", skip(tcx))]
fn lower_to_hir(tcx: TyCtxt<'_>, def_id: LocalDefId) -> hir::MaybeOwner<'_> {
    let ast_index = tcx.index_ast(());
    let resolver_and_node = ast_index.get(def_id).map(Steal::steal);

    let fallback_to_ancestor = |parent_id| {
        // The item did not exist in the AST, it was created while lowering another item.
        // `parent_id` may be different from the direct parent of `def_id`,
        // for instance use-trees are lowered by the first sibling.
        let mut parent_info = tcx.lower_to_hir(parent_id);
        if let hir::MaybeOwner::NonOwner(hir_id) = parent_info {
            // `parent_id` could also not be a owner either.
            // For instance if `def_id` is an enum variant field,
            // the direct parent is the enum variant.
            // In that case `hir_id.owner` point to the actual HIR owner
            // and skips all non-owner parents, so fetch the HIR associated to it.
            parent_info = tcx.lower_to_hir(hir_id.owner);
        }

        let parent_info = parent_info.unwrap();
        *parent_info.children.get(&def_id).unwrap_or_else(|| {
            panic!(
                "{:?} does not appear in children of {:?}",
                def_id,
                parent_info.nodes.node().def_id()
            )
        })
    };

    let Some((resolver, node)) = resolver_and_node else {
        // `ast_index` does not contain all definitions, only up-to the highest
        // `LocalDefId` which has a non-trivial `AstOwner`. Gracefully handle
        // other definitions, in particular those nested inside this highest definition.
        return fallback_to_ancestor(tcx.local_parent(def_id));
    };

    let mut item_lowerer = item::ItemLowerer { tcx, resolver: &*resolver };

    let item = match &node {
        // The item existed in the AST.
        AstOwner::Crate(c) => item_lowerer.lower_crate(&c),
        AstOwner::Item(item) => item_lowerer.lower_item(&item),
        AstOwner::TraitItem(item) => item_lowerer.lower_trait_item(&item),
        AstOwner::ImplItem(item) => item_lowerer.lower_impl_item(&item),
        AstOwner::ForeignItem(item) => item_lowerer.lower_foreign_item(&item),
        AstOwner::NestedUseTree(owner_id) => fallback_to_ancestor(*owner_id),
        // The item existed in the AST, but is not a HIR owner.
        // Fetch the correct information from its parent.
        AstOwner::NonOwner => fallback_to_ancestor(tcx.local_parent(def_id)),
    };

    tcx.sess.time("drop_ast", || mem::drop(node));

    item
}

#[derive(Copy, Clone, PartialEq, Debug)]
enum ParamMode {
    /// Any path in a type context.
    Explicit,
    /// The `module::Type` in `module::Type::method` in an expression.
    Optional,
}

#[derive(Copy, Clone, Debug)]
enum AllowReturnTypeNotation {
    /// Only in types, since RTN is denied later during HIR lowering.
    Yes,
    /// All other positions (path expr, method, use tree).
    No,
}

enum GenericArgsMode {
    /// Allow paren sugar, don't allow RTN.
    ParenSugar,
    /// Allow RTN, don't allow paren sugar.
    ReturnTypeNotation,
    // Error if parenthesized generics or RTN are encountered.
    Err,
    /// Silence errors when lowering generics. Only used with `Res::Err`.
    Silence,
}

impl<'hir> LoweringContext<'_, 'hir> {
    fn create_def(
        &mut self,
        node_id: NodeId,
        name: Option<Symbol>,
        def_kind: DefKind,
        span: Span,
    ) -> LocalDefId {
        self.reject_body_capture("create-def");
        let parent = self.curr_owner.owner_id.def_id;
        assert_ne!(node_id, ast::DUMMY_NODE_ID);
        assert!(
            self.opt_local_def_id(node_id).is_none(),
            "adding a def'n for node-id {:?} and def kind {:?} but a previous def'n exists: {:?}",
            node_id,
            def_kind,
            self.tcx.hir_def_key(self.local_def_id(node_id)),
        );

        let def_id = self
            .tcx
            .at(span)
            .create_def(parent, name, def_kind, None, &mut self.curr_owner.disambiguator)
            .def_id();

        debug!("create_def: def_id_to_node_id[{:?}] <-> {:?}", def_id, node_id);
        self.node_id_to_def_id.insert(node_id, def_id);

        def_id
    }

    fn next_node_id(&mut self) -> NodeId {
        self.reject_body_capture("new-ast-node");
        let start = self.next_node_id;
        let next = start.as_u32().checked_add(1).expect("input too large; ran out of NodeIds");
        self.next_node_id = NodeId::from_u32(next);
        start
    }

    /// Given the id of some node in the AST, finds the `LocalDefId` associated with it by the name
    /// resolver (if any).
    #[instrument(level = "trace", skip(self), ret)]
    fn opt_local_def_id(&self, node: NodeId) -> Option<LocalDefId> {
        self.node_id_to_def_id
            .get(&node)
            .or_else(|| self.curr_owner.owner.node_id_to_def_id.get(&node))
            .copied()
    }

    fn local_def_id(&self, node: NodeId) -> LocalDefId {
        self.opt_local_def_id(node).unwrap_or_else(|| {
            self.resolver.owners.items().any(|(id, items)| {
                items.node_id_to_def_id.items().any(|(node_id, def_id)| {
                    if *node_id == node {
                        let actual_owner = items.node_id_to_def_id.get(id);
                        panic!("{def_id:?} ({node_id}) was found in {actual_owner:?} ({id})",)
                    }
                    false
                })
            });
            panic!("no entry for node id: `{node:?}`");
        })
    }

    fn get_partial_res(&self, id: NodeId) -> Option<PartialRes> {
        match self.partial_res_overrides.get(&id) {
            Some(self_param_id) => Some(PartialRes::new(Res::Local(*self_param_id))),
            None => self.resolver.partial_res_map.get(&id).copied(),
        }
    }

    /// Given the id of an owner node in the AST, returns the corresponding `OwnerId`.
    fn owner_id(&self, node: NodeId) -> hir::OwnerId {
        hir::OwnerId { def_id: self.resolver.owners[&node].def_id }
    }

    /// Freshen the `LoweringContext` and ready it to lower a nested item.
    /// The lowered item is registered into `self.curr_owner.children`.
    ///
    /// This function sets up `HirId` lowering infrastructure,
    /// and stashes the per-owner state to avoid pollution by the closure.
    #[instrument(level = "debug", skip(self, f))]
    fn with_hir_id_owner(
        &mut self,
        owner: NodeId,
        f: impl FnOnce(&mut Self) -> hir::OwnerNode<'hir>,
    ) {
        self.reject_body_capture("nested-owner");
        let child_owner = PerOwnerLoweringState::new(self.resolver, owner);
        let parent_owner = mem::replace(&mut self.curr_owner, child_owner);

        // Do not reset `next_node_id` and `node_id_to_def_id`:
        // we want `f` to be able to refer to the `LocalDefId`s that the caller created.
        // and the caller to refer to some of the subdefinitions' nodes' `LocalDefId`s.

        // Always allocate the first `HirId` for the owner itself.
        #[cfg(debug_assertions)]
        self.curr_owner
            .relowering_checker
            .assert_node_is_not_relowered(owner, hir::ItemLocalId::ZERO);

        let item = f(self);
        let completed_child_owner = mem::replace(&mut self.curr_owner, parent_owner);
        let owner_id = completed_child_owner.owner_id;
        let info = completed_child_owner.into_owner_info(self.tcx, item);

        self.curr_owner
            .children
            .extend_unord(info.children.items().map(|(&def_id, &info)| (def_id, info)));

        debug_assert!(!self.curr_owner.children.contains_key(&owner_id.def_id));
        self.curr_owner.children.insert(owner_id.def_id, hir::MaybeOwner::Owner(info));
    }

    /// This method allocates a new `HirId` for the given `NodeId`.
    /// Take care not to call this method if the resulting `HirId` is then not
    /// actually used in the HIR, as that would trigger an assertion in the
    /// `HirIdValidator` later on, which makes sure that all `NodeId`s got mapped
    /// properly. Calling the method twice with the same `NodeId` is also forbidden.
    #[instrument(level = "debug", skip(self), ret)]
    fn lower_node_id(&mut self, ast_node_id: NodeId) -> HirId {
        assert_ne!(ast_node_id, DUMMY_NODE_ID);

        let owner = self.curr_owner.owner_id;
        let local_id = self.curr_owner.item_local_id_counter;
        assert_ne!(local_id, hir::ItemLocalId::ZERO);
        self.curr_owner.item_local_id_counter.increment_by(1);
        let hir_id = HirId { owner, local_id };

        if let Some(def_id) = self.opt_local_def_id(ast_node_id) {
            self.curr_owner.children.insert(def_id, hir::MaybeOwner::NonOwner(hir_id));
        }

        if let Some(traits) = self.curr_owner.owner.trait_map.get(&ast_node_id) {
            self.curr_owner.trait_map.insert(hir_id.local_id, *traits);
        }

        // Check whether the same `NodeId` is lowered more than once.
        #[cfg(debug_assertions)]
        self.curr_owner.relowering_checker.assert_node_is_not_relowered(ast_node_id, local_id);

        if let Some(trace) = &mut self.body_trace { trace.ast(ast_node_id, local_id); }
        hir_id
    }

    /// Generate a new `HirId` without a backing `NodeId`.
    #[instrument(level = "debug", skip(self), ret)]
    fn next_id(&mut self) -> HirId {
        let owner = self.curr_owner.owner_id;
        let local_id = self.curr_owner.item_local_id_counter;
        assert_ne!(local_id, hir::ItemLocalId::ZERO);
        self.curr_owner.item_local_id_counter.increment_by(1);
        if let Some(trace) = &mut self.body_trace { trace.synthetic(local_id); }
        HirId { owner, local_id }
    }

    #[instrument(level = "trace", skip(self))]
    fn lower_res(&mut self, res: Res<NodeId>) -> Res {
        let res: Result<Res, ()> = res.apply_id(|id| {
            let owner = self.curr_owner.owner_id;
            let local_id =
                self.curr_owner.ident_and_label_to_local_id.get(&id).copied().ok_or(())?;
            Ok(HirId { owner, local_id })
        });
        trace!(?res);

        // We may fail to find a HirId when the Res points to a Local from an enclosing HIR owner.
        // This can happen when trying to lower the return type `x` in erroneous code like
        //   async fn foo(x: u8) -> x {}
        // In that case, `x` is lowered as a function parameter, and the return type is lowered as
        // an opaque type as a synthesized HIR owner.
        res.unwrap_or(Res::Err)
    }

    fn expect_full_res(&mut self, id: NodeId) -> Res<NodeId> {
        self.get_partial_res(id).map_or(Res::Err, |pr| pr.expect_full_res())
    }

    fn lower_import_res(&mut self, id: NodeId, span: Span) -> PerNS<Option<Res>> {
        debug_assert_eq!(id, self.curr_owner.owner.id);
        let per_ns = self.curr_owner.owner.import_res.map(|res| res.map(|res| self.lower_res(res)));
        if per_ns.is_empty() {
            // Propagate the error to all namespaces, just to be sure.
            self.dcx().span_delayed_bug(span, "no resolution for an import");
            let err = Some(Res::Err);
            return PerNS { type_ns: err, value_ns: err, macro_ns: err };
        }
        per_ns
    }

    fn make_lang_item_qpath(
        &mut self,
        lang_item: LangItem,
        span: Span,
        args: Option<&'hir hir::GenericArgs<'hir>>,
    ) -> hir::QPath<'hir> {
        hir::QPath::Resolved(None, self.make_lang_item_path(lang_item, span, args))
    }

    fn make_lang_item_path(
        &mut self,
        lang_item: LangItem,
        span: Span,
        args: Option<&'hir hir::GenericArgs<'hir>>,
    ) -> &'hir hir::Path<'hir> {
        let def_id = self.tcx.require_lang_item(lang_item, span);
        let def_kind = self.tcx.def_kind(def_id);
        let res = Res::Def(def_kind, def_id);
        self.arena.alloc(hir::Path {
            span,
            res,
            segments: self.arena.alloc_from_iter([hir::PathSegment {
                ident: Ident::new(lang_item.name(), span),
                hir_id: self.next_id(),
                res,
                args,
                infer_args: args.is_none(),
                delegation_child_segment: false,
            }]),
        })
    }

    /// Reuses the span but adds information like the kind of the desugaring and features that are
    /// allowed inside this span.
    fn mark_span_with_reason(
        &self,
        reason: DesugaringKind,
        span: Span,
        allow_internal_unstable: Option<Arc<[Symbol]>>,
    ) -> Span {
        self.tcx.with_stable_hashing_context(|hcx| {
            span.mark_with_reason(allow_internal_unstable, reason, span.edition(), hcx)
        })
    }

    fn span_lowerer(&self) -> SpanLowerer {
        SpanLowerer {
            is_incremental: self.tcx.sess.opts.incremental.is_some(),
            def_id: self.curr_owner.owner_id.def_id,
        }
    }

    /// Intercept all spans entering HIR.
    /// Mark a span as relative to the current owning item.
    fn lower_span(&self, span: Span) -> Span {
        self.span_lowerer().lower(span)
    }

    fn lower_ident(&self, ident: Ident) -> Ident {
        Ident::new(ident.name, self.lower_span(ident.span))
    }

    /// Converts a lifetime into a new generic parameter.
    #[instrument(level = "debug", skip(self))]
    fn lifetime_res_to_generic_param(
        &mut self,
        ident: Ident,
        node_id: NodeId,
        kind: MissingLifetimeKind,
        source: hir::GenericParamSource,
    ) -> hir::GenericParam<'hir> {
        // Late resolution delegates to us the creation of the `LocalDefId`.
        let _def_id = self.create_def(
            node_id,
            Some(kw::UnderscoreLifetime),
            DefKind::LifetimeParam,
            ident.span,
        );
        debug!(?_def_id);

        let hir_id = self.lower_node_id(node_id);
        let def_id = self.local_def_id(node_id);
        hir::GenericParam {
            hir_id,
            def_id,
            name: hir::ParamName::Fresh,
            span: self.lower_span(ident.span),
            pure_wrt_drop: false,
            kind: hir::GenericParamKind::Lifetime { kind: hir::LifetimeParamKind::Elided(kind) },
            colon_span: None,
            source,
        }
    }

    /// Lowers a lifetime binder that defines `generic_params`, returning the corresponding HIR
    /// nodes. The returned list includes any "extra" lifetime parameters that were added by the
    /// name resolver owing to lifetime elision; this also populates the resolver's node-id->def-id
    /// map, so that later calls to `opt_node_id_to_def_id` that refer to these extra lifetime
    /// parameters will be successful.
    #[instrument(level = "debug", skip(self), ret)]
    #[inline]
    fn lower_lifetime_binder(
        &mut self,
        binder: NodeId,
        generic_params: &[GenericParam],
    ) -> &'hir [hir::GenericParam<'hir>] {
        // Start by creating params for extra lifetimes params, as this creates the definitions
        // that may be referred to by the AST inside `generic_params`.
        let extra_lifetimes = self.curr_owner.owner.extra_lifetime_params(binder);
        debug!(?extra_lifetimes);
        let extra_lifetimes: Vec<_> = extra_lifetimes
            .iter()
            .map(|&(ident, node_id, res)| {
                self.lifetime_res_to_generic_param(
                    ident,
                    node_id,
                    res,
                    hir::GenericParamSource::Binder,
                )
            })
            .collect();
        let arena = self.arena;
        let explicit_generic_params =
            self.lower_generic_params_mut(generic_params, hir::GenericParamSource::Binder);
        arena.alloc_from_iter(explicit_generic_params.chain(extra_lifetimes.into_iter()))
    }

    fn with_dyn_type_scope<T>(&mut self, in_scope: bool, f: impl FnOnce(&mut Self) -> T) -> T {
        let was_in_dyn_type = self.is_in_dyn_type;
        self.is_in_dyn_type = in_scope;

        let result = f(self);

        self.is_in_dyn_type = was_in_dyn_type;

        result
    }

    fn with_new_scopes<T>(&mut self, scope_span: Span, f: impl FnOnce(&mut Self) -> T) -> T {
        let current_item = self.current_item;
        self.current_item = Some(scope_span);

        let was_in_loop_condition = self.is_in_loop_condition;
        self.is_in_loop_condition = false;

        let old_contract = self.contract_ensures.take();

        let try_block_scope = mem::replace(&mut self.try_block_scope, TryBlockScope::Function);
        let loop_scope = self.loop_scope.take();
        let ret = f(self);
        self.try_block_scope = try_block_scope;
        self.loop_scope = loop_scope;

        self.contract_ensures = old_contract;

        self.is_in_loop_condition = was_in_loop_condition;

        self.current_item = current_item;

        ret
    }

    fn lower_attrs(
        &mut self,
        id: HirId,
        attrs: &[Attribute],
        target_span: Span,
        target: Target,
    ) -> &'hir [hir::Attribute] {
        self.lower_attrs_with_extra(id, attrs, target_span, target, &[])
    }

    fn lower_attrs_with_extra(
        &mut self,
        id: HirId,
        attrs: &[Attribute],
        target_span: Span,
        target: Target,
        extra_hir_attributes: &[hir::Attribute],
    ) -> &'hir [hir::Attribute] {
        if attrs.is_empty() && extra_hir_attributes.is_empty() {
            &[]
        } else {
            let mut lowered_attrs =
                self.lower_attrs_vec(attrs, self.lower_span(target_span), id, target);
            lowered_attrs.extend(extra_hir_attributes.iter().cloned());

            assert_eq!(id.owner, self.curr_owner.owner_id);
            let ret = self.arena.alloc_from_iter(lowered_attrs);

            // this is possible if an item contained syntactical attribute,
            // but none of them parse successfully or all of them were ignored
            // for not being built-in attributes at all. They could be remaining
            // unexpanded attributes used as markers in proc-macro derives for example.
            // This will have emitted some diagnostics for the misparse, but will then
            // not emit the attribute making the list empty.
            if ret.is_empty() {
                &[]
            } else {
                self.curr_owner.attrs.insert(id.local_id, ret);
                ret
            }
        }
    }

    fn lower_attrs_vec(
        &mut self,
        attrs: &[Attribute],
        target_span: Span,
        target_hir_id: HirId,
        target: Target,
    ) -> Vec<hir::Attribute> {
        self.reject_body_capture("attribute-parser");
        let l = self.span_lowerer();
        self.attribute_parser.parse_attribute_list(
            attrs,
            target_span,
            target,
            |s| l.lower(s),
            |lint_id, span, kind| {
                self.curr_owner.delayed_lints.push(DelayedLint {
                    lint_id,
                    id: target_hir_id,
                    span,
                    callback: Box::new(move |dcx, level, sess: &dyn std::any::Any| {
                        let sess = sess
                            .downcast_ref::<rustc_session::Session>()
                            .expect("expected `Session`");
                        (kind.0)(dcx, level, sess)
                    }),
                });
            },
        )
    }

    fn alias_attrs(&mut self, id: HirId, target_id: HirId) {
        assert_eq!(id.owner, self.curr_owner.owner_id);
        assert_eq!(target_id.owner, self.curr_owner.owner_id);
        if let Some(&a) = self.curr_owner.attrs.get(&target_id.local_id) {
            assert!(!a.is_empty());
            self.curr_owner.attrs.insert(id.local_id, a);
        }
    }

    fn lower_delim_args(&self, args: &DelimArgs) -> DelimArgs {
        args.clone()
    }

    /// Lower an associated item constraint.
    #[instrument(level = "debug", skip_all)]
    fn lower_assoc_item_constraint(
        &mut self,
        constraint: &AssocItemConstraint,
        itctx: ImplTraitContext,
    ) -> hir::AssocItemConstraint<'hir> {
        debug!(?constraint, ?itctx);
        // Lower the generic arguments for the associated item.
        let gen_args = if let Some(gen_args) = &constraint.gen_args {
            let gen_args_ctor = match gen_args {
                GenericArgs::AngleBracketed(data) => {
                    self.lower_angle_bracketed_parameter_data(data, ParamMode::Explicit, itctx).0
                }
                GenericArgs::Parenthesized(data) => {
                    if let Some(first_char) = constraint.ident.as_str().chars().next()
                        && first_char.is_ascii_lowercase()
                    {
                        let err = match (&data.inputs[..], &data.output) {
                            ([_, ..], FnRetTy::Default(_)) => {
                                diagnostics::BadReturnTypeNotation::Inputs {
                                    span: data.inputs_span,
                                }
                            }
                            ([], FnRetTy::Default(_)) => {
                                diagnostics::BadReturnTypeNotation::NeedsDots {
                                    span: data.inputs_span,
                                }
                            }
                            // The case `T: Trait<method(..) -> Ret>` is handled in the parser.
                            (_, FnRetTy::Ty(ty)) => {
                                let span = data.inputs_span.shrink_to_hi().to(ty.span);
                                diagnostics::BadReturnTypeNotation::Output {
                                    span,
                                    suggestion: diagnostics::RTNSuggestion {
                                        output: span,
                                        input: data.inputs_span,
                                    },
                                }
                            }
                        };
                        let mut err = self.dcx().create_err(err);
                        if !self.tcx.features().return_type_notation()
                            && self.tcx.sess.is_nightly_build()
                        {
                            add_feature_diagnostics(
                                &mut err,
                                &self.tcx.sess,
                                sym::return_type_notation,
                            );
                        }
                        err.emit();
                        GenericArgsCtor {
                            args: Default::default(),
                            constraints: &[],
                            parenthesized: hir::GenericArgsParentheses::ReturnTypeNotation,
                            span: data.span,
                        }
                    } else {
                        let guar = self.emit_bad_parenthesized_trait_in_assoc_ty(data);
                        self.lower_angle_bracketed_parameter_data(
                            &data.as_angle_bracketed_args(),
                            ParamMode::Explicit,
                            ImplTraitContext::AlreadyErrored(guar),
                        )
                        .0
                    }
                }
                GenericArgs::ParenthesizedElided(span) => GenericArgsCtor {
                    args: Default::default(),
                    constraints: &[],
                    parenthesized: hir::GenericArgsParentheses::ReturnTypeNotation,
                    span: *span,
                },
            };
            gen_args_ctor.into_generic_args(self)
        } else {
            hir::GenericArgs::NONE
        };
        let kind = match &constraint.kind {
            AssocItemConstraintKind::Equality { term } => {
                let term = match term {
                    Term::Ty(ty) => self.lower_ty_alloc(ty, itctx).into(),
                    Term::Const(c) => self.lower_anon_const_to_const_arg_and_alloc(c).into(),
                };
                hir::AssocItemConstraintKind::Equality { term }
            }
            AssocItemConstraintKind::Bound { bounds } => {
                // Disallow ATB in dyn types
                if self.is_in_dyn_type {
                    let suggestion = match itctx {
                        ImplTraitContext::OpaqueTy { .. } | ImplTraitContext::Universal => {
                            let bound_end_span = constraint
                                .gen_args
                                .as_ref()
                                .map_or(constraint.ident.span, |args| args.span());
                            if bound_end_span.eq_ctxt(constraint.span) {
                                Some(self.tcx.sess.source_map().next_point(bound_end_span))
                            } else {
                                None
                            }
                        }
                        _ => None,
                    };

                    let guar = self.dcx().emit_err(diagnostics::MisplacedAssocTyBinding {
                        span: constraint.span,
                        suggestion,
                    });
                    let err_ty =
                        &*self.arena.alloc(self.ty(constraint.span, hir::TyKind::Err(guar)));
                    hir::AssocItemConstraintKind::Equality { term: err_ty.into() }
                } else {
                    let bounds = self.lower_param_bounds(
                        bounds,
                        RelaxedBoundPolicy::Forbidden(RelaxedBoundForbiddenReason::AssocTyBounds),
                        itctx,
                    );
                    hir::AssocItemConstraintKind::Bound { bounds }
                }
            }
        };

        hir::AssocItemConstraint {
            hir_id: self.lower_node_id(constraint.id),
            ident: self.lower_ident(constraint.ident),
            gen_args,
            kind,
            span: self.lower_span(constraint.span),
        }
    }

    fn emit_bad_parenthesized_trait_in_assoc_ty(
        &self,
        data: &ParenthesizedArgs,
    ) -> ErrorGuaranteed {
        // Suggest removing empty parentheses: "Trait()" -> "Trait"
        let sub = if data.inputs.is_empty() {
            let parentheses_span =
                data.inputs_span.shrink_to_lo().to(data.inputs_span.shrink_to_hi());
            AssocTyParenthesesSub::Empty { parentheses_span }
        }
        // Suggest replacing parentheses with angle brackets `Trait(params...)` to `Trait<params...>`
        else {
            // Start of parameters to the 1st argument
            let open_param = data.inputs_span.shrink_to_lo().to(data
                .inputs
                .first()
                .unwrap()
                .span
                .shrink_to_lo());
            // End of last argument to end of parameters
            let close_param =
                data.inputs.last().unwrap().span.shrink_to_hi().to(data.inputs_span.shrink_to_hi());
            AssocTyParenthesesSub::NotEmpty { open_param, close_param }
        };
        self.dcx().emit_err(AssocTyParentheses { span: data.span, sub })
    }

    #[instrument(level = "debug", skip(self))]
    fn lower_generic_arg(
        &mut self,
        arg: &ast::GenericArg,
        itctx: ImplTraitContext,
    ) -> hir::GenericArg<'hir> {
        match arg {
            ast::GenericArg::Lifetime(lt) => GenericArg::Lifetime(self.lower_lifetime(
                lt,
                LifetimeSource::Path { angle_brackets: hir::AngleBrackets::Full },
                lt.ident.into(),
            )),
            ast::GenericArg::Type(ty) => {
                // We cannot just match on `TyKind::Infer` as `(_)` is represented as
                // `TyKind::Paren(TyKind::Infer)` and should also be lowered to `GenericArg::Infer`
                if ty.is_maybe_parenthesised_infer() {
                    return GenericArg::Infer(self.arena.alloc(hir::InferArg {
                        hir_id: self.lower_node_id(ty.id),
                        span: self.lower_span(ty.span),
                        kind: hir::InferArgKind::TypeOrConst,
                    }));
                }

                match &ty.kind {
                    // We parse const arguments as path types as we cannot distinguish them during
                    // parsing. We try to resolve that ambiguity by attempting resolution in both the
                    // type and value namespaces. If we resolved the path in the value namespace, we
                    // transform it into a generic const argument.
                    //
                    // Note that even under `#![feature(min_generic_const_args)]`, only plain paths
                    // to constants are allowed - e.g. `A::<T::ASSOC_CONST>` and
                    // `A::<CONST_WITH_PARAM::<2>>` are disallowed (they must be wrapped in `{ }`).
                    //
                    // FIXME: Should we be handling `(PATH_TO_CONST)`?
                    TyKind::Path(None, path)
                        if path.is_single_argless_ident()
                            && let Some(res) = self
                                .get_partial_res(ty.id)
                                .and_then(|partial_res| partial_res.full_res())
                            && !res.matches_ns(Namespace::TypeNS) =>
                    {
                        let ct =
                            self.lower_const_path_to_const_arg(&None, path, res, ty.id, ty.span);
                        let ct = self.arena.alloc(ct);
                        return GenericArg::Const(ct.try_as_ambig_ct().unwrap());
                    }
                    TyKind::DirectConstArg(expr)
                        if self.tcx.features().min_generic_const_args() =>
                    {
                        let ct = match self.can_lower_expr_to_const_arg_direct(
                            expr,
                            DirectConstArgContext::MacrolessMinGenericConstArgs,
                        ) {
                            Ok(()) => self.lower_expr_to_const_arg_direct(expr, None),
                            Err(e) => e.emit(self),
                        };
                        let ct = self.arena.alloc(ct);
                        return match ct.try_as_ambig_ct() {
                            Some(ct) => GenericArg::Const(ct),
                            None => GenericArg::Infer(self.arena.alloc(hir::InferArg {
                                hir_id: ct.hir_id,
                                span: ct.span,
                                kind: hir::InferArgKind::Const,
                            })),
                        };
                    }
                    _ => {}
                }
                GenericArg::Type(self.lower_ty_alloc(ty, itctx).try_as_ambig_ty().unwrap())
            }
            ast::GenericArg::Const(ct) => {
                let ct = self.lower_anon_const_to_const_arg_and_alloc(ct);
                match ct.try_as_ambig_ct() {
                    Some(ct) => GenericArg::Const(ct),
                    None => GenericArg::Infer(self.arena.alloc(hir::InferArg {
                        hir_id: ct.hir_id,
                        span: ct.span,
                        kind: hir::InferArgKind::Const,
                    })),
                }
            }
        }
    }

    #[instrument(level = "debug", skip(self))]
    fn lower_ty_alloc(&mut self, t: &Ty, itctx: ImplTraitContext) -> &'hir hir::Ty<'hir> {
        self.arena.alloc(self.lower_ty(t, itctx))
    }

    fn lower_path_ty(
        &mut self,
        t: &Ty,
        qself: &Option<Box<QSelf>>,
        path: &Path,
        param_mode: ParamMode,
        itctx: ImplTraitContext,
    ) -> hir::Ty<'hir> {
        // Check whether we should interpret this as a bare trait object.
        // This check mirrors the one in late resolution. We only introduce this special case in
        // the rare occurrence we need to lower `Fresh` anonymous lifetimes.
        // The other cases when a qpath should be opportunistically made a trait object are handled
        // by `ty_path`.
        if qself.is_none()
            && let Some(partial_res) = self.get_partial_res(t.id)
            && let Some(Res::Def(DefKind::Trait | DefKind::TraitAlias, _)) = partial_res.full_res()
        {
            let (bounds, lifetime_bound) = self.with_dyn_type_scope(true, |this| {
                let bound = this.lower_poly_trait_ref(
                    &PolyTraitRef {
                        bound_generic_params: ThinVec::new(),
                        modifiers: TraitBoundModifiers::NONE,
                        trait_ref: TraitRef { path: path.clone(), ref_id: t.id },
                        span: t.span,
                        parens: ast::Parens::No,
                    },
                    RelaxedBoundPolicy::Forbidden(RelaxedBoundForbiddenReason::TraitObjectTy),
                    itctx,
                );
                let bounds = this.arena.alloc_from_iter([bound]);
                let lifetime_bound = this.elided_dyn_bound(t.span);
                (bounds, lifetime_bound)
            });
            let kind = hir::TyKind::TraitObject(
                bounds,
                TaggedRef::new(lifetime_bound, TraitObjectSyntax::None),
            );
            return hir::Ty { kind, span: self.lower_span(t.span), hir_id: self.next_id() };
        }

        let id = self.lower_node_id(t.id);
        let qpath = self.lower_qpath(
            t.id,
            qself,
            path,
            param_mode,
            AllowReturnTypeNotation::Yes,
            itctx,
            None,
        );
        self.ty_path(id, t.span, qpath)
    }

    fn ty(&mut self, span: Span, kind: hir::TyKind<'hir>) -> hir::Ty<'hir> {
        hir::Ty { hir_id: self.next_id(), kind, span: self.lower_span(span) }
    }

    fn ty_tup(&mut self, span: Span, tys: &'hir [hir::Ty<'hir>]) -> hir::Ty<'hir> {
        self.ty(span, hir::TyKind::Tup(tys))
    }

    fn lower_ty(&mut self, t: &Ty, itctx: ImplTraitContext) -> hir::Ty<'hir> {
        let kind = match &t.kind {
            TyKind::Infer => hir::TyKind::Infer(()),
            TyKind::Err(guar) => hir::TyKind::Err(*guar),
            TyKind::Slice(ty) => hir::TyKind::Slice(self.lower_ty_alloc(ty, itctx)),
            TyKind::Ptr(mt) => hir::TyKind::Ptr(self.lower_mt(mt, itctx)),
            TyKind::Ref(region, mt) => {
                let lifetime = self.lower_ty_direct_lifetime(t, *region);
                hir::TyKind::Ref(lifetime, self.lower_mt(mt, itctx))
            }
            TyKind::PinnedRef(region, mt) => {
                let lifetime = self.lower_ty_direct_lifetime(t, *region);
                let kind = hir::TyKind::Ref(lifetime, self.lower_mt(mt, itctx));
                let span = self.lower_span(t.span);
                let arg = hir::Ty { kind, span, hir_id: self.next_id() };
                let args = self.arena.alloc(hir::GenericArgs {
                    args: self.arena.alloc([hir::GenericArg::Type(self.arena.alloc(arg))]),
                    constraints: &[],
                    parenthesized: hir::GenericArgsParentheses::No,
                    span_ext: span,
                });
                let path = self.make_lang_item_qpath(LangItem::Pin, span, Some(args));
                hir::TyKind::Path(path)
            }
            TyKind::FnPtr(f) => {
                let generic_params = self.lower_lifetime_binder(t.id, &f.generic_params);
                hir::TyKind::FnPtr(self.arena.alloc(hir::FnPtrTy {
                    generic_params,
                    safety: self.lower_safety(f.safety, hir::Safety::Safe),
                    abi: self.lower_extern(f.ext),
                    decl: self.lower_fn_decl(&f.decl, t.id, t.span, FnDeclKind::Pointer, None),
                    param_idents: self.lower_fn_params_to_idents(&f.decl),
                }))
            }
            TyKind::UnsafeBinder(f) => {
                let generic_params = self.lower_lifetime_binder(t.id, &f.generic_params);
                hir::TyKind::UnsafeBinder(self.arena.alloc(hir::UnsafeBinderTy {
                    generic_params,
                    inner_ty: self.lower_ty_alloc(&f.inner_ty, itctx),
                }))
            }
            TyKind::Never => hir::TyKind::Never,
            TyKind::Tup(tys) => hir::TyKind::Tup(
                self.arena.alloc_from_iter(tys.iter().map(|ty| self.lower_ty(ty, itctx))),
            ),
            TyKind::Paren(ty) => {
                return self.lower_ty(ty, itctx);
            }
            TyKind::Path(qself, path) => {
                return self.lower_path_ty(t, qself, path, ParamMode::Explicit, itctx);
            }
            TyKind::ImplicitSelf => {
                let hir_id = self.next_id();
                let res = self.expect_full_res(t.id);
                let res = self.lower_res(res);
                hir::TyKind::Path(hir::QPath::Resolved(
                    None,
                    self.arena.alloc(hir::Path {
                        res,
                        segments: arena_vec![self; hir::PathSegment::new(
                            Ident::with_dummy_span(kw::SelfUpper),
                            hir_id,
                            res
                        )],
                        span: self.lower_span(t.span),
                    }),
                ))
            }
            TyKind::Array(ty, length) => hir::TyKind::Array(
                self.lower_ty_alloc(ty, itctx),
                self.lower_array_length_to_const_arg(length),
            ),
            TyKind::TraitObject(bounds, kind) => {
                let mut lifetime_bound = None;
                let (bounds, lifetime_bound) = self.with_dyn_type_scope(true, |this| {
                    let bounds =
                        this.arena.alloc_from_iter(bounds.iter().filter_map(|bound| match bound {
                            // We can safely ignore constness here since AST validation
                            // takes care of rejecting invalid modifier combinations and
                            // const trait bounds in trait object types.
                            GenericBound::Trait(ty) => {
                                let trait_ref = this.lower_poly_trait_ref(
                                    ty,
                                    RelaxedBoundPolicy::Forbidden(
                                        RelaxedBoundForbiddenReason::TraitObjectTy,
                                    ),
                                    itctx,
                                );
                                Some(trait_ref)
                            }
                            GenericBound::Outlives(lifetime) => {
                                if lifetime_bound.is_none() {
                                    lifetime_bound = Some(this.lower_lifetime(
                                        lifetime,
                                        LifetimeSource::Other,
                                        lifetime.ident.into(),
                                    ));
                                }
                                None
                            }
                            // Ignore `use` syntax since that is not valid in objects.
                            GenericBound::Use(_, span) => {
                                this.dcx()
                                    .span_delayed_bug(*span, "use<> not allowed in dyn types");
                                None
                            }
                        }));
                    let lifetime_bound =
                        lifetime_bound.unwrap_or_else(|| this.elided_dyn_bound(t.span));
                    (bounds, lifetime_bound)
                });
                hir::TyKind::TraitObject(bounds, TaggedRef::new(lifetime_bound, *kind))
            }
            TyKind::ImplTrait(def_node_id, bounds) => {
                let span = t.span;
                match itctx {
                    ImplTraitContext::OpaqueTy { origin } => {
                        self.lower_opaque_impl_trait(span, origin, *def_node_id, bounds, itctx)
                    }
                    ImplTraitContext::Universal => {
                        if let Some(span) = bounds.iter().find_map(|bound| match *bound {
                            ast::GenericBound::Use(_, span) => Some(span),
                            _ => None,
                        }) {
                            self.tcx.dcx().emit_err(diagnostics::NoPreciseCapturesOnApit { span });
                        }

                        let def_id = self.local_def_id(*def_node_id);
                        let name = self.tcx.item_name(def_id.to_def_id());
                        let ident = Ident::new(name, span);
                        let (param, bounds, path) = self.lower_universal_param_and_bounds(
                            *def_node_id,
                            span,
                            ident,
                            bounds,
                        );
                        self.curr_owner.impl_trait_defs.push(param);
                        if let Some(bounds) = bounds {
                            self.curr_owner.impl_trait_bounds.push(bounds);
                        }
                        path
                    }
                    ImplTraitContext::InBinding => {
                        hir::TyKind::TraitAscription(self.lower_param_bounds(
                            bounds,
                            RelaxedBoundPolicy::Allowed(&mut Default::default()),
                            itctx,
                        ))
                    }
                    ImplTraitContext::FeatureGated(position, feature) => {
                        let guar = self
                            .tcx
                            .sess
                            .create_feature_err(
                                MisplacedImplTrait {
                                    span: t.span,
                                    position: DiagArgFromDisplay(&position),
                                },
                                feature,
                            )
                            .emit();
                        hir::TyKind::Err(guar)
                    }
                    ImplTraitContext::Disallowed(position) => {
                        let guar = self.dcx().emit_err(MisplacedImplTrait {
                            span: t.span,
                            position: DiagArgFromDisplay(&position),
                        });
                        hir::TyKind::Err(guar)
                    }
                    ImplTraitContext::AlreadyErrored(guar) => {
                        // `GenericArgs::Parenthesized` stores its inputs as `Param`s, so the def
                        // collector visits `impl Trait` in a universal context and creates a
                        // `DefKind::TyParam`. During recovery we reinterpret these arguments as
                        // angle-bracketed, where lowering may otherwise expect an opaque type.
                        // The parenthesized syntax has already been rejected, so avoid lowering
                        // this `impl Trait` with the inconsistent `DefKind`.
                        hir::TyKind::Err(guar)
                    }
                }
            }
            TyKind::Pat(ty, pat) => {
                hir::TyKind::Pat(self.lower_ty_alloc(ty, itctx), self.lower_ty_pat(pat, ty.span))
            }
            TyKind::FieldOf(ty, variant, field) => hir::TyKind::FieldOf(
                self.lower_ty_alloc(ty, itctx),
                self.arena.alloc(hir::TyFieldPath {
                    variant: variant.map(|variant| self.lower_ident(variant)),
                    field: self.lower_ident(*field),
                }),
            ),
            TyKind::MacCall(_) => {
                span_bug!(t.span, "`TyKind::MacCall` should have been expanded by now")
            }
            TyKind::CVarArgs => {
                let guar = self.dcx().span_delayed_bug(
                    t.span,
                    "`TyKind::CVarArgs` should have been handled elsewhere",
                );
                hir::TyKind::Err(guar)
            }
            TyKind::View(ty, fields) => {
                let ty = self.lower_ty_alloc(ty, itctx);
                let fields = self.arena.alloc_slice(fields);
                hir::TyKind::View(ty, fields)
            }
            TyKind::DirectConstArg(expr) => {
                let e = self.emit_bad_direct_const_arg(t.span, expr, "type");
                hir::TyKind::Err(e)
            }
            TyKind::Dummy => panic!("`TyKind::Dummy` should never be lowered"),
        };

        hir::Ty { kind, span: self.lower_span(t.span), hir_id: self.lower_node_id(t.id) }
    }

    pub(crate) fn emit_bad_direct_const_arg(
        &mut self,
        span: Span,
        expr: &Expr,
        expected: &'static str,
    ) -> ErrorGuaranteed {
        let msg = format!("expected {expected}, found `direct_const_arg!()` constant");
        if expr::WillCreateDefIdsVisitor.visit_expr(expr).is_break() {
            // FIXME(mgca): make this non-fatal once we have a better way to handle
            // nested items in invalid `direct_const_arg!()` arguments.
            self.dcx().struct_span_fatal(span, msg).emit()
        } else {
            self.dcx().struct_span_err(span, msg).emit()
        }
    }

    fn lower_ty_direct_lifetime(
        &mut self,
        t: &Ty,
        region: Option<Lifetime>,
    ) -> &'hir hir::Lifetime {
        let (region, syntax) = match region {
            Some(region) => (region, region.ident.into()),

            None => {
                let id = if let Some(LifetimeRes::ElidedAnchor { start, end }) =
                    self.curr_owner.owner.get_lifetime_res(t.id)
                {
                    assert_eq!(start.plus(1), end);
                    start
                } else {
                    self.next_node_id()
                };
                let span = self.tcx.sess.source_map().start_point(t.span).shrink_to_hi();
                let region = Lifetime { ident: Ident::new(kw::UnderscoreLifetime, span), id };
                (region, LifetimeSyntax::Implicit)
            }
        };
        self.lower_lifetime(&region, LifetimeSource::Reference, syntax)
    }

    /// Lowers a `ReturnPositionOpaqueTy` (`-> impl Trait`) or a `TypeAliasesOpaqueTy` (`type F =
    /// impl Trait`): this creates the associated Opaque Type (TAIT) definition and then returns a
    /// HIR type that references the TAIT.
    ///
    /// Given a function definition like:
    ///
    /// ```rust
    /// use std::fmt::Debug;
    ///
    /// fn test<'a, T: Debug>(x: &'a T) -> impl Debug + 'a {
    ///     x
    /// }
    /// ```
    ///
    /// we will create a TAIT definition in the HIR like
    ///
    /// ```rust,ignore (pseudo-Rust)
    /// type TestReturn<'a, T, 'x> = impl Debug + 'x
    /// ```
    ///
    /// and return a type like `TestReturn<'static, T, 'a>`, so that the function looks like:
    ///
    /// ```rust,ignore (pseudo-Rust)
    /// fn test<'a, T: Debug>(x: &'a T) -> TestReturn<'static, T, 'a>
    /// ```
    ///
    /// Note the subtlety around type parameters! The new TAIT, `TestReturn`, inherits all the
    /// type parameters from the function `test` (this is implemented in the query layer, they aren't
    /// added explicitly in the HIR). But this includes all the lifetimes, and we only want to
    /// capture the lifetimes that are referenced in the bounds. Therefore, we add *extra* lifetime parameters
    /// for the lifetimes that get captured (`'x`, in our example above) and reference those.
    #[instrument(level = "debug", skip(self), ret)]
    fn lower_opaque_impl_trait(
        &mut self,
        span: Span,
        origin: hir::OpaqueTyOrigin<LocalDefId>,
        opaque_ty_node_id: NodeId,
        bounds: &GenericBounds,
        itctx: ImplTraitContext,
    ) -> hir::TyKind<'hir> {
        // Make sure we know that some funky desugaring has been going on here.
        // This is a first: there is code in other places like for loop
        // desugaring that explicitly states that we don't want to track that.
        // Not tracking it makes lints in rustc and clippy very fragile, as
        // frequently opened issues show.
        let opaque_ty_span = self.mark_span_with_reason(DesugaringKind::OpaqueTy, span, None);

        self.lower_opaque_inner(opaque_ty_node_id, origin, opaque_ty_span, |this| {
            this.lower_param_bounds(
                bounds,
                RelaxedBoundPolicy::Allowed(&mut Default::default()),
                itctx,
            )
        })
    }

    fn lower_opaque_inner(
        &mut self,
        opaque_ty_node_id: NodeId,
        origin: hir::OpaqueTyOrigin<LocalDefId>,
        opaque_ty_span: Span,
        lower_item_bounds: impl FnOnce(&mut Self) -> &'hir [hir::GenericBound<'hir>],
    ) -> hir::TyKind<'hir> {
        let opaque_ty_def_id = self.local_def_id(opaque_ty_node_id);
        let opaque_ty_hir_id = self.lower_node_id(opaque_ty_node_id);
        debug!(?opaque_ty_def_id, ?opaque_ty_hir_id);

        let bounds = lower_item_bounds(self);
        let opaque_ty_def = hir::OpaqueTy {
            hir_id: opaque_ty_hir_id,
            def_id: opaque_ty_def_id,
            bounds,
            origin,
            span: self.lower_span(opaque_ty_span),
        };
        let opaque_ty_def = self.arena.alloc(opaque_ty_def);

        hir::TyKind::OpaqueDef(opaque_ty_def)
    }

    fn lower_precise_capturing_args(
        &mut self,
        precise_capturing_args: &[PreciseCapturingArg],
    ) -> &'hir [hir::PreciseCapturingArg<'hir>] {
        self.arena.alloc_from_iter(precise_capturing_args.iter().map(|arg| match arg {
            PreciseCapturingArg::Lifetime(lt) => hir::PreciseCapturingArg::Lifetime(
                self.lower_lifetime(lt, LifetimeSource::PreciseCapturing, lt.ident.into()),
            ),
            PreciseCapturingArg::Arg(path, id) => {
                let [segment] = path.segments.as_slice() else {
                    panic!();
                };
                let res = self.get_partial_res(*id).map_or(Res::Err, |partial_res| {
                    partial_res.full_res().expect("no partial res expected for precise capture arg")
                });
                hir::PreciseCapturingArg::Param(hir::PreciseCapturingNonLifetimeArg {
                    hir_id: self.lower_node_id(*id),
                    ident: self.lower_ident(segment.ident),
                    res: self.lower_res(res),
                })
            }
        }))
    }

    fn lower_fn_params_to_idents(&mut self, decl: &FnDecl) -> &'hir [Option<Ident>] {
        self.arena.alloc_from_iter(decl.inputs.iter().map(|param| match param.pat.kind {
            PatKind::Missing => None,
            PatKind::Ident(_, ident, _) => Some(self.lower_ident(ident)),
            PatKind::Wild => Some(Ident::new(kw::Underscore, self.lower_span(param.pat.span))),
            _ => {
                self.dcx().span_delayed_bug(
                    param.pat.span,
                    "non-missing/ident/wild param pat must trigger an error",
                );
                None
            }
        }))
    }

    /// Lowers a function declaration.
    ///
    /// `decl`: the unlowered (AST) function declaration.
    ///
    /// `fn_node_id`: `impl Trait` arguments are lowered into generic parameters on the given
    /// `NodeId`.
    ///
    /// `transform_return_type`: if `Some`, applies some conversion to the return type, such as is
    /// needed for `async fn` and `gen fn`. See [`CoroutineKind`] for more details.
    #[instrument(level = "debug", skip(self))]
    fn lower_fn_decl(
        &mut self,
        decl: &FnDecl,
        fn_node_id: NodeId,
        fn_span: Span,
        kind: FnDeclKind,
        coro: Option<CoroutineMarker>,
    ) -> &'hir hir::FnDecl<'hir> {
        let c_variadic = decl.c_variadic();
        let mut splatted = decl.splatted();

        // Skip the `...` (`CVarArgs`) trailing arguments from the AST,
        // as they are not explicit in HIR/Ty function signatures.
        // (instead, the `c_variadic` flag is set to `true`)
        let mut inputs = &decl.inputs[..];
        if decl.c_variadic() {
            // Splat + variadic errors in AST validation, so just ignore one of them here.
            splatted = None;
            inputs = &inputs[..inputs.len() - 1];
        }
        let inputs = self.arena.alloc_from_iter(inputs.iter().map(|param| {
            let itctx = match kind {
                FnDeclKind::Fn | FnDeclKind::Inherent | FnDeclKind::Impl | FnDeclKind::Trait => {
                    ImplTraitContext::Universal
                }
                FnDeclKind::ExternFn => {
                    ImplTraitContext::Disallowed(ImplTraitPosition::ExternFnParam)
                }
                FnDeclKind::Closure => {
                    ImplTraitContext::Disallowed(ImplTraitPosition::ClosureParam)
                }
                FnDeclKind::Pointer => {
                    ImplTraitContext::Disallowed(ImplTraitPosition::PointerParam)
                }
            };
            self.lower_ty(&param.ty, itctx)
        }));

        let output = match coro {
            Some(coro) => {
                let fn_def_id = self.curr_owner.owner.def_id;
                self.lower_coroutine_fn_ret_ty(&decl.output, fn_def_id, coro, kind)
            }
            None => match &decl.output {
                FnRetTy::Ty(ty) => {
                    let itctx = match kind {
                        FnDeclKind::Fn | FnDeclKind::Inherent => ImplTraitContext::OpaqueTy {
                            origin: hir::OpaqueTyOrigin::FnReturn {
                                parent: self.curr_owner.owner.def_id,
                                in_trait_or_impl: None,
                            },
                        },
                        FnDeclKind::Trait => ImplTraitContext::OpaqueTy {
                            origin: hir::OpaqueTyOrigin::FnReturn {
                                parent: self.curr_owner.owner.def_id,
                                in_trait_or_impl: Some(hir::RpitContext::Trait),
                            },
                        },
                        FnDeclKind::Impl => ImplTraitContext::OpaqueTy {
                            origin: hir::OpaqueTyOrigin::FnReturn {
                                parent: self.curr_owner.owner.def_id,
                                in_trait_or_impl: Some(hir::RpitContext::TraitImpl),
                            },
                        },
                        FnDeclKind::ExternFn => {
                            ImplTraitContext::Disallowed(ImplTraitPosition::ExternFnReturn)
                        }
                        FnDeclKind::Closure => {
                            ImplTraitContext::Disallowed(ImplTraitPosition::ClosureReturn)
                        }
                        FnDeclKind::Pointer => {
                            ImplTraitContext::Disallowed(ImplTraitPosition::PointerReturn)
                        }
                    };
                    hir::FnRetTy::Return(self.lower_ty_alloc(ty, itctx))
                }
                FnRetTy::Default(span) => hir::FnRetTy::DefaultReturn(self.lower_span(*span)),
            },
        };

        let fn_decl_kind = hir::FnDeclFlags::default()
            .set_implicit_self(decl.inputs.get(0).map_or(hir::ImplicitSelfKind::None, |arg| {
                let is_mutable_pat = matches!(
                    arg.pat.kind,
                    PatKind::Ident(hir::BindingMode(_, Mutability::Mut), ..)
                );

                match &arg.ty.kind {
                    TyKind::ImplicitSelf if is_mutable_pat => hir::ImplicitSelfKind::Mut,
                    TyKind::ImplicitSelf => hir::ImplicitSelfKind::Imm,
                    // Given we are only considering `ImplicitSelf` types, we needn't consider
                    // the case where we have a mutable pattern to a reference as that would
                    // no longer be an `ImplicitSelf`.
                    TyKind::Ref(_, mt) | TyKind::PinnedRef(_, mt)
                        if mt.ty.kind.is_implicit_self() =>
                    {
                        match mt.mutbl {
                            hir::Mutability::Not => hir::ImplicitSelfKind::RefImm,
                            hir::Mutability::Mut => hir::ImplicitSelfKind::RefMut,
                        }
                    }
                    _ => hir::ImplicitSelfKind::None,
                }
            }))
            .set_lifetime_elision_allowed(
                self.curr_owner.owner.id == fn_node_id
                    && self.curr_owner.owner.lifetime_elision_allowed,
            )
            .set_c_variadic(c_variadic)
            .set_splatted(splatted, inputs.len())
            .unwrap();

        self.arena.alloc(hir::FnDecl { inputs, output, fn_decl_kind })
    }

    // Transforms `-> T` for `async fn` into `-> OpaqueTy { .. }`
    // combined with the following definition of `OpaqueTy`:
    //
    //     type OpaqueTy<generics_from_parent_fn> = impl Future<Output = T>;
    //
    // `output`: unlowered output type (`T` in `-> T`)
    // `fn_node_id`: `NodeId` of the parent function (used to create child impl trait definition)
    // `opaque_ty_node_id`: `NodeId` of the opaque `impl Trait` type that should be created
    #[instrument(level = "debug", skip(self))]
    fn lower_coroutine_fn_ret_ty(
        &mut self,
        output: &FnRetTy,
        fn_def_id: LocalDefId,
        coro: CoroutineMarker,
        fn_kind: FnDeclKind,
    ) -> hir::FnRetTy<'hir> {
        let span = self.lower_span(output.span());

        let (opaque_ty_node_id, allowed_features) = match coro.kind {
            CoroutineKind::Async | CoroutineKind::Gen => (coro.return_impl_trait_id, None),
            CoroutineKind::AsyncGen => {
                (coro.return_impl_trait_id, Some(Arc::clone(&self.allow_async_iterator)))
            }
        };

        let opaque_ty_span =
            self.mark_span_with_reason(DesugaringKind::Async, span, allowed_features);

        let in_trait_or_impl = match fn_kind {
            FnDeclKind::Trait => Some(hir::RpitContext::Trait),
            FnDeclKind::Impl => Some(hir::RpitContext::TraitImpl),
            FnDeclKind::Fn | FnDeclKind::Inherent => None,
            FnDeclKind::ExternFn | FnDeclKind::Closure | FnDeclKind::Pointer => unreachable!(),
        };

        let opaque_ty_ref = self.lower_opaque_inner(
            opaque_ty_node_id,
            hir::OpaqueTyOrigin::AsyncFn { parent: fn_def_id, in_trait_or_impl },
            opaque_ty_span,
            |this| {
                let bound = this.lower_coroutine_fn_output_type_to_bound(
                    output,
                    coro,
                    opaque_ty_span,
                    ImplTraitContext::OpaqueTy {
                        origin: hir::OpaqueTyOrigin::FnReturn {
                            parent: fn_def_id,
                            in_trait_or_impl,
                        },
                    },
                );
                arena_vec![this; bound]
            },
        );

        let opaque_ty = self.ty(opaque_ty_span, opaque_ty_ref);
        hir::FnRetTy::Return(self.arena.alloc(opaque_ty))
    }

    /// Transforms `-> T` into `Future<Output = T>`.
    fn lower_coroutine_fn_output_type_to_bound(
        &mut self,
        output: &FnRetTy,
        coro: CoroutineMarker,
        opaque_ty_span: Span,
        itctx: ImplTraitContext,
    ) -> hir::GenericBound<'hir> {
        // Compute the `T` in `Future<Output = T>` from the return type.
        let output_ty = match output {
            FnRetTy::Ty(ty) => {
                // Not `OpaqueTyOrigin::AsyncFn`: that's only used for the
                // `impl Future` opaque type that `async fn` implicitly
                // generates.
                self.lower_ty_alloc(ty, itctx)
            }
            FnRetTy::Default(ret_ty_span) => self.arena.alloc(self.ty_tup(*ret_ty_span, &[])),
        };

        // "<$assoc_ty_name = T>"
        let (assoc_ty_name, trait_lang_item) = match coro.kind {
            CoroutineKind::Async => (sym::Output, LangItem::Future),
            CoroutineKind::Gen => (sym::Item, LangItem::Iterator),
            CoroutineKind::AsyncGen => (sym::Item, LangItem::AsyncIterator),
        };

        let bound_args = self.arena.alloc(hir::GenericArgs {
            args: &[],
            constraints: arena_vec![self; self.assoc_ty_binding(assoc_ty_name, opaque_ty_span, output_ty)],
            parenthesized: hir::GenericArgsParentheses::No,
            span_ext: DUMMY_SP,
        });

        hir::GenericBound::Trait(hir::PolyTraitRef {
            bound_generic_params: &[],
            modifiers: hir::TraitBoundModifiers::NONE,
            trait_ref: hir::TraitRef {
                path: self.make_lang_item_path(trait_lang_item, opaque_ty_span, Some(bound_args)),
                hir_ref_id: self.next_id(),
            },
            span: opaque_ty_span,
        })
    }

    #[instrument(level = "trace", skip(self))]
    fn lower_param_bound(
        &mut self,
        tpb: &GenericBound,
        rbp: RelaxedBoundPolicy<'_>,
        itctx: ImplTraitContext,
    ) -> hir::GenericBound<'hir> {
        match tpb {
            GenericBound::Trait(p) => {
                hir::GenericBound::Trait(self.lower_poly_trait_ref(p, rbp, itctx))
            }
            GenericBound::Outlives(lifetime) => hir::GenericBound::Outlives(self.lower_lifetime(
                lifetime,
                LifetimeSource::OutlivesBound,
                lifetime.ident.into(),
            )),
            GenericBound::Use(args, span) => hir::GenericBound::Use(
                self.lower_precise_capturing_args(args),
                self.lower_span(*span),
            ),
        }
    }

    fn lower_lifetime(
        &mut self,
        l: &Lifetime,
        source: LifetimeSource,
        syntax: LifetimeSyntax,
    ) -> &'hir hir::Lifetime {
        self.new_named_lifetime(l.id, l.id, l.ident, source, syntax)
    }

    fn lower_lifetime_hidden_in_path(
        &mut self,
        id: NodeId,
        span: Span,
        angle_brackets: AngleBrackets,
    ) -> &'hir hir::Lifetime {
        self.new_named_lifetime(
            id,
            id,
            Ident::new(kw::UnderscoreLifetime, span),
            LifetimeSource::Path { angle_brackets },
            LifetimeSyntax::Implicit,
        )
    }

    #[instrument(level = "debug", skip(self))]
    fn new_named_lifetime(
        &mut self,
        id: NodeId,
        new_id: NodeId,
        ident: Ident,
        source: LifetimeSource,
        syntax: LifetimeSyntax,
    ) -> &'hir hir::Lifetime {
        let res = if let Some(res) = self.curr_owner.owner.get_lifetime_res(id) {
            match res {
                LifetimeRes::Param { param, .. } => hir::LifetimeKind::Param(param),
                LifetimeRes::Fresh { param, .. } => {
                    assert_eq!(ident.name, kw::UnderscoreLifetime);
                    let param = self.local_def_id(param);
                    hir::LifetimeKind::Param(param)
                }
                LifetimeRes::Infer => {
                    assert_eq!(ident.name, kw::UnderscoreLifetime);
                    hir::LifetimeKind::Infer
                }
                LifetimeRes::Static { .. } => {
                    assert!(matches!(ident.name, kw::StaticLifetime | kw::UnderscoreLifetime));
                    hir::LifetimeKind::Static
                }
                LifetimeRes::Error(guar) => hir::LifetimeKind::Error(guar),
                LifetimeRes::ElidedAnchor { .. } => {
                    panic!("Unexpected `ElidedAnchar` {:?} at {:?}", ident, ident.span);
                }
            }
        } else {
            hir::LifetimeKind::Error(self.dcx().span_delayed_bug(ident.span, "unresolved lifetime"))
        };

        debug!(?res);
        self.arena.alloc(hir::Lifetime::new(
            self.lower_node_id(new_id),
            self.lower_ident(ident),
            res,
            source,
            syntax,
        ))
    }

    fn lower_generic_params_mut(
        &mut self,
        params: &[GenericParam],
        source: hir::GenericParamSource,
    ) -> impl Iterator<Item = hir::GenericParam<'hir>> {
        params.iter().map(move |param| self.lower_generic_param(param, source))
    }

    fn lower_generic_params(
        &mut self,
        params: &[GenericParam],
        source: hir::GenericParamSource,
    ) -> &'hir [hir::GenericParam<'hir>] {
        self.arena.alloc_from_iter(self.lower_generic_params_mut(params, source))
    }

    #[instrument(level = "trace", skip(self))]
    fn lower_generic_param(
        &mut self,
        param: &GenericParam,
        source: hir::GenericParamSource,
    ) -> hir::GenericParam<'hir> {
        let (name, kind) = self.lower_generic_param_kind(param, source);

        let hir_id = self.lower_node_id(param.id);
        let param_attrs = &param.attrs;
        let param_span = param.span();
        let param = hir::GenericParam {
            hir_id,
            def_id: self.local_def_id(param.id),
            name,
            span: self.lower_span(param.span()),
            pure_wrt_drop: attr::contains_name(&param.attrs, sym::may_dangle),
            kind,
            colon_span: param.colon_span.map(|s| self.lower_span(s)),
            source,
        };
        self.lower_attrs(hir_id, param_attrs, param_span, Target::from(&param));
        param
    }

    fn lower_generic_param_kind(
        &mut self,
        param: &GenericParam,
        source: hir::GenericParamSource,
    ) -> (hir::ParamName, hir::GenericParamKind<'hir>) {
        match &param.kind {
            GenericParamKind::Lifetime => {
                // AST resolution emitted an error on those parameters, so we lower them using
                // `ParamName::Error`.
                let ident = self.lower_ident(param.ident);
                let param_name = if let Some(LifetimeRes::Error(..)) =
                    self.curr_owner.owner.get_lifetime_res(param.id)
                {
                    ParamName::Error(ident)
                } else {
                    ParamName::Plain(ident)
                };
                let kind =
                    hir::GenericParamKind::Lifetime { kind: hir::LifetimeParamKind::Explicit };

                (param_name, kind)
            }
            GenericParamKind::Type { default, .. } => {
                // Not only do we deny type param defaults in binders but we also map them to `None`
                // since later compiler stages cannot handle them (and shouldn't need to be able to).
                let default = default
                    .as_ref()
                    .filter(|_| match source {
                        hir::GenericParamSource::Generics => true,
                        hir::GenericParamSource::Binder => {
                            self.dcx().emit_err(diagnostics::GenericParamDefaultInBinder {
                                span: param.span(),
                            });

                            false
                        }
                    })
                    .map(|def| {
                        self.lower_ty_alloc(
                            def,
                            ImplTraitContext::Disallowed(ImplTraitPosition::GenericDefault),
                        )
                    });

                let kind = hir::GenericParamKind::Type { default, synthetic: false };

                (hir::ParamName::Plain(self.lower_ident(param.ident)), kind)
            }
            GenericParamKind::Const { ty, span: _, default } => {
                let ty = self.lower_ty_alloc(
                    ty,
                    ImplTraitContext::Disallowed(ImplTraitPosition::GenericDefault),
                );

                // Not only do we deny const param defaults in binders but we also map them to `None`
                // since later compiler stages cannot handle them (and shouldn't need to be able to).
                let default = default
                    .as_ref()
                    .filter(|anon_const| match source {
                        hir::GenericParamSource::Generics => true,
                        hir::GenericParamSource::Binder => {
                            let err =
                                diagnostics::GenericParamDefaultInBinder { span: param.span() };
                            if expr::WillCreateDefIdsVisitor
                                .visit_expr(&anon_const.value)
                                .is_break()
                            {
                                // FIXME(mgca): make this non-fatal once we have a better way
                                // to handle nested items in anno const from binder
                                // Issue: https://github.com/rust-lang/rust/issues/123629
                                self.dcx().emit_fatal(err)
                            } else {
                                self.dcx().emit_err(err);
                                false
                            }
                        }
                    })
                    .map(|def| self.lower_anon_const_to_const_arg_and_alloc(def));

                (
                    hir::ParamName::Plain(self.lower_ident(param.ident)),
                    hir::GenericParamKind::Const { ty, default },
                )
            }
        }
    }

    fn lower_trait_ref(
        &mut self,
        modifiers: ast::TraitBoundModifiers,
        p: &TraitRef,
        itctx: ImplTraitContext,
    ) -> hir::TraitRef<'hir> {
        let path = match self.lower_qpath(
            p.ref_id,
            &None,
            &p.path,
            ParamMode::Explicit,
            AllowReturnTypeNotation::No,
            itctx,
            Some(modifiers),
        ) {
            hir::QPath::Resolved(None, path) => path,
            qpath => panic!("lower_trait_ref: unexpected QPath `{qpath:?}`"),
        };
        hir::TraitRef { path, hir_ref_id: self.lower_node_id(p.ref_id) }
    }

    #[instrument(level = "debug", skip(self))]
    fn lower_poly_trait_ref(
        &mut self,
        PolyTraitRef { bound_generic_params, modifiers, trait_ref, span, parens: _ }: &PolyTraitRef,
        rbp: RelaxedBoundPolicy<'_>,
        itctx: ImplTraitContext,
    ) -> hir::PolyTraitRef<'hir> {
        let bound_generic_params =
            self.lower_lifetime_binder(trait_ref.ref_id, bound_generic_params);
        let trait_ref = self.lower_trait_ref(*modifiers, trait_ref, itctx);
        let modifiers = self.lower_trait_bound_modifiers(*modifiers);

        if let ast::BoundPolarity::Maybe(_) = modifiers.polarity {
            self.validate_relaxed_bound(trait_ref, *span, rbp);
        }

        hir::PolyTraitRef {
            bound_generic_params,
            modifiers,
            trait_ref,
            span: self.lower_span(*span),
        }
    }

    fn validate_relaxed_bound(
        &self,
        trait_ref: hir::TraitRef<'_>,
        span: Span,
        rbp: RelaxedBoundPolicy<'_>,
    ) {
        // Even though feature `more_maybe_bounds` enables the user to relax all default bounds
        // other than `Sized` in a lot more positions (thereby bypassing the given policy), we don't
        // want to advertise it to the user (via a feature gate error) since it's super internal.
        //
        // FIXME(more_maybe_bounds): Moreover, if we actually were to add proper default traits
        // (like a hypothetical `Move` or `Leak`) we would want to validate the location according
        // to default trait elaboration in HIR ty lowering (which depends on the specific trait in
        // question: E.g., `?Sized` & `?Move` most likely won't be allowed in all the same places).

        match rbp {
            RelaxedBoundPolicy::Allowed(dedup_map) => {
                // `trait_def_id` only returns `None` for errors during resolution.
                let Some(trait_def_id) = trait_ref.trait_def_id() else { return };
                let tcx = self.tcx;
                let err = |s| {
                    let name = tcx.item_name(trait_def_id);
                    tcx.dcx()
                        .struct_span_err(
                            vec![span, s],
                            format!("duplicate relaxed `{name}` bounds"),
                        )
                        .with_code(E0203)
                        .emit();
                };
                dedup_map.entry(trait_def_id).and_modify(|&mut s| err(s)).or_insert(span);
                return;
            }
            RelaxedBoundPolicy::Forbidden(reason) => {
                let gate = |context, subject| {
                    let extended = self.tcx.features().more_maybe_bounds();
                    let is_sized = trait_ref
                        .trait_def_id()
                        .is_some_and(|def_id| self.tcx.is_lang_item(def_id, LangItem::Sized));

                    if extended && !is_sized {
                        return;
                    }

                    let prefix = if extended { "`Sized` " } else { "" };
                    let mut diag = self.dcx().struct_span_err(
                        span,
                        format!("relaxed {prefix}bounds are not permitted in {context}"),
                    );
                    if is_sized {
                        diag.note(format!(
                            "{subject} are not implicitly bounded by `Sized`, \
                             so there is nothing to relax"
                        ));
                    }
                    diag.emit();
                };

                match reason {
                    RelaxedBoundForbiddenReason::TraitObjectTy => {
                        gate("trait object types", "trait object types");
                        return;
                    }
                    RelaxedBoundForbiddenReason::SuperTrait => {
                        gate("supertrait bounds", "traits");
                        return;
                    }
                    RelaxedBoundForbiddenReason::TraitAlias => {
                        gate("trait alias bounds", "trait aliases");
                        return;
                    }
                    RelaxedBoundForbiddenReason::AssocTyBounds
                    | RelaxedBoundForbiddenReason::WhereBound => {}
                };
            }
        }

        self.dcx()
            .struct_span_err(span, "this relaxed bound is not permitted here")
            .with_note(
                "in this context, relaxed bounds are only allowed on \
                 type parameters defined on the closest item",
            )
            .emit();
    }

    fn lower_mt(&mut self, mt: &MutTy, itctx: ImplTraitContext) -> hir::MutTy<'hir> {
        hir::MutTy { ty: self.lower_ty_alloc(&mt.ty, itctx), mutbl: mt.mutbl }
    }

    #[instrument(level = "debug", skip(self), ret)]
    fn lower_param_bounds(
        &mut self,
        bounds: &[GenericBound],
        rbp: RelaxedBoundPolicy<'_>,
        itctx: ImplTraitContext,
    ) -> hir::GenericBounds<'hir> {
        self.arena.alloc_from_iter(self.lower_param_bounds_mut(bounds, rbp, itctx))
    }

    fn lower_param_bounds_mut(
        &mut self,
        bounds: &[GenericBound],
        mut rbp: RelaxedBoundPolicy<'_>,
        itctx: ImplTraitContext,
    ) -> impl Iterator<Item = hir::GenericBound<'hir>> {
        bounds.iter().map(move |bound| self.lower_param_bound(bound, rbp.reborrow(), itctx))
    }

    #[instrument(level = "debug", skip(self), ret)]
    fn lower_universal_param_and_bounds(
        &mut self,
        node_id: NodeId,
        span: Span,
        ident: Ident,
        bounds: &[GenericBound],
    ) -> (hir::GenericParam<'hir>, Option<hir::WherePredicate<'hir>>, hir::TyKind<'hir>) {
        // Add a definition for the in-band `Param`.
        let def_id = self.local_def_id(node_id);
        let span = self.lower_span(span);

        // Set the name to `impl Bound1 + Bound2`.
        let param = hir::GenericParam {
            hir_id: self.lower_node_id(node_id),
            def_id,
            name: ParamName::Plain(self.lower_ident(ident)),
            pure_wrt_drop: false,
            span,
            kind: hir::GenericParamKind::Type { default: None, synthetic: true },
            colon_span: None,
            source: hir::GenericParamSource::Generics,
        };

        let preds = self.lower_generic_bound_predicate(
            ident,
            node_id,
            &GenericParamKind::Type { default: None },
            bounds,
            /* colon_span */ None,
            span,
            RelaxedBoundPolicy::Allowed(&mut Default::default()),
            ImplTraitContext::Universal,
            hir::PredicateOrigin::ImplTrait,
        );

        let hir_id = self.next_id();
        let res = Res::Def(DefKind::TyParam, def_id.to_def_id());
        let ty = hir::TyKind::Path(hir::QPath::Resolved(
            None,
            self.arena.alloc(hir::Path {
                span,
                res,
                segments:
                    arena_vec![self; hir::PathSegment::new(self.lower_ident(ident), hir_id, res)],
            }),
        ));

        (param, preds, ty)
    }

    /// Lowers a block directly to an expression, presuming that it
    /// has no attributes and is not targeted by a `break`.
    fn lower_block_expr(&mut self, b: &Block) -> hir::Expr<'hir> {
        let block = self.lower_block(b, false);
        self.expr_block(block)
    }

    fn lower_array_length_to_const_arg(&mut self, c: &AnonConst) -> &'hir hir::ConstArg<'hir> {
        // We cannot just match on `ExprKind::Underscore` as `(_)` is represented as
        // `ExprKind::Paren(ExprKind::Underscore)` and should also be lowered to `GenericArg::Infer`
        //
        // FIXME(macroless_generic_const_args): Handling of underscores should be moved into
        // lower_expr_to_const_arg_direct. It is left here as retaining compatibility of what is
        // currently allowed on stable gets hairy and annoying otherwise.
        match c.value.peel_parens().kind {
            ExprKind::Underscore => {
                let ct_kind = hir::ConstArgKind::Infer(());
                self.arena.alloc(hir::ConstArg {
                    hir_id: self.lower_node_id(c.id),
                    kind: ct_kind,
                    span: self.lower_span(c.value.span),
                })
            }
            _ => self.lower_anon_const_to_const_arg_and_alloc(c),
        }
    }

    /// Used when lowering a type argument that turned out to actually be a const argument.
    ///
    /// Only use for that purpose since otherwise it will create a duplicate def.
    #[instrument(level = "debug", skip(self))]
    fn lower_const_path_to_const_arg(
        &mut self,
        qself: &Option<Box<QSelf>>,
        path: &Path,
        res: Res<NodeId>,
        id: NodeId,
        span: Span,
    ) -> hir::ConstArg<'hir> {
        let context = self.ambient_direct_const_arg_context();
        if self.can_lower_path_to_const_arg_direct(qself, path, span, Some(res), context).is_ok() {
            let span = self.lower_span(span);
            self.lower_path_to_const_arg_direct(id, None, qself, path, span)
        } else {
            // Construct an AnonConst where the expr is the "ty"'s path.
            let node_id = self.next_node_id();
            let span = self.lower_span(span);

            // Add a definition for the in-band const def.
            // We're lowering a const argument that was originally thought to be a type argument,
            // so the def collector didn't create the def ahead of time. That's why we have to do
            // it here.
            let def_id = self.create_def(node_id, None, DefKind::AnonConst, span);
            let hir_id = self.lower_node_id(node_id);

            let path_expr = Expr {
                id,
                kind: ExprKind::Path(qself.clone(), path.clone()),
                span,
                attrs: AttrVec::new(),
                tokens: None,
            };

            let ct = self.with_new_scopes(span, |this| {
                self.arena.alloc(hir::AnonConst {
                    def_id,
                    hir_id,
                    body: this.lower_const_body(path_expr.span, Some(&path_expr)),
                    span,
                })
            });
            hir::ConstArg {
                hir_id: self.next_id(),
                kind: hir::ConstArgKind::Anon(ct),
                span: self.lower_span(span),
            }
        }
    }

    fn lower_const_item_rhs(
        &mut self,
        body: &Option<Box<Expr>>,
        kind: ConstItemKind,
        span: Span,
    ) -> hir::ConstItemRhs<'hir> {
        match (body, kind) {
            (body, ConstItemKind::Body) => {
                let is_direct = |body| {
                    if self.tcx.features().macroless_generic_const_args() {
                        self.can_lower_expr_to_const_arg_direct(
                            body,
                            DirectConstArgContext::MacrolessMinGenericConstArgs,
                        )
                        .is_ok()
                    } else {
                        // do not check can_lower_expr_to_const_arg_direct, but rather just
                        // ExprKind::DirectConstArg, because we don't want e.g.
                        // `impl<const N: u8> { const C: u8 = N; }` to be a direct-rhs const
                        matches!(body, Expr { kind: ExprKind::DirectConstArg(_), .. })
                    }
                };
                // N.B.: the feature gate for this is generic_const_args, not min_generic_const_args
                if self.tcx.features().generic_const_args()
                    && let Some(body) = body
                    && is_direct(body)
                {
                    hir::ConstItemRhs::Direct(
                        self.arena.alloc(self.lower_expr_to_const_arg_direct(&body, None)),
                    )
                } else {
                    hir::ConstItemRhs::Body(self.lower_const_body(span, body.as_deref()))
                }
            }
            (Some(body), ConstItemKind::TypeConst) => hir::ConstItemRhs::Direct(self.arena.alloc(
                match self.can_lower_expr_to_const_arg_direct(
                    &body,
                    DirectConstArgContext::MacrolessMinGenericConstArgs,
                ) {
                    Ok(()) => self.lower_expr_to_const_arg_direct(&body, None),
                    Err(err) => err.emit(self),
                },
            )),
            (None, ConstItemKind::TypeConst) => {
                let const_arg = ConstArg {
                    hir_id: self.next_id(),
                    kind: hir::ConstArgKind::Error(
                        self.dcx().span_delayed_bug(DUMMY_SP, "no block"),
                    ),
                    span: DUMMY_SP,
                };
                hir::ConstItemRhs::Direct(self.arena.alloc(const_arg))
            }
        }
    }

    fn ambient_direct_const_arg_context(&self) -> DirectConstArgContext {
        if self.tcx.features().macroless_generic_const_args() {
            DirectConstArgContext::MacrolessMinGenericConstArgs
        } else if self.tcx.features().min_generic_const_args() {
            DirectConstArgContext::MinGenericConstArgs
        } else {
            DirectConstArgContext::Stable
        }
    }

    fn can_lower_path_to_const_arg_direct(
        &self,
        qself: &Option<Box<QSelf>>,
        path: &Path,
        span: Span,
        res: Option<Res<NodeId>>,
        context: DirectConstArgContext,
    ) -> Result<(), UnrepresentableConstArgError> {
        if let DirectConstArgContext::MacrolessMinGenericConstArgs = context {
            Ok(())
        } else if qself.is_none()
            && path.is_single_argless_ident()
            && matches!(res, Some(Res::Def(DefKind::ConstParam, _)))
        {
            Ok(())
        } else {
            Err(UnrepresentableConstArgError { span, will_create_def_ids: false })
        }
    }

    #[instrument(level = "debug", skip(self), ret)]
    fn can_lower_expr_to_const_arg_direct(
        &self,
        expr: &Expr,
        context: DirectConstArgContext,
    ) -> Result<(), UnrepresentableConstArgError> {
        use DirectConstArgContext::*;
        // Note the only stable case is currently ExprKind::Path
        match (&expr.kind, context) {
            (
                ExprKind::Call(Expr { kind: ExprKind::Path(_, _), .. }, args),
                MacrolessMinGenericConstArgs,
            ) => {
                for arg in args {
                    self.can_lower_expr_to_const_arg_direct(arg, context)?;
                }
                Ok(())
            }
            (ExprKind::Tup(exprs), MacrolessMinGenericConstArgs) => {
                for expr in exprs {
                    self.can_lower_expr_to_const_arg_direct(expr, context)?;
                }
                Ok(())
            }
            (ExprKind::Path(qself, path), _) => {
                let res =
                    self.get_partial_res(expr.id).and_then(|partial_res| partial_res.full_res());
                self.can_lower_path_to_const_arg_direct(qself, path, expr.span, res, context)
            }
            (ExprKind::Struct(se), MacrolessMinGenericConstArgs) => {
                for f in &se.fields {
                    self.can_lower_expr_to_const_arg_direct(&f.expr, context)?;
                }
                Ok(())
            }
            (ExprKind::Array(elements), MacrolessMinGenericConstArgs) => {
                for element in elements {
                    self.can_lower_expr_to_const_arg_direct(element, context)?;
                }
                Ok(())
            }
            (ExprKind::Underscore, MacrolessMinGenericConstArgs) => Ok(()),
            (ExprKind::Paren(expr), MacrolessMinGenericConstArgs) => {
                self.can_lower_expr_to_const_arg_direct(expr, context)
            }
            (ExprKind::Block(block, _), MacrolessMinGenericConstArgs)
                if let [stmt] = block.stmts.as_slice()
                    && let StmtKind::Expr(expr) = &stmt.kind =>
            {
                self.can_lower_expr_to_const_arg_direct(expr, context)
            }
            (ExprKind::Lit(_), MacrolessMinGenericConstArgs) => Ok(()),
            (ExprKind::Unary(UnOp::Neg, inner_expr), MacrolessMinGenericConstArgs)
                if let ExprKind::Lit(_) = &inner_expr.kind =>
            {
                Ok(())
            }
            (ExprKind::ConstBlock(_), MacrolessMinGenericConstArgs) => Ok(()),
            (ExprKind::DirectConstArg(_), MacrolessMinGenericConstArgs | MinGenericConstArgs) => {
                // Always report this as able to be represented directly. If it turns out not to be,
                // `lower_expr_to_const_arg_direct` will report an error.
                Ok(())
            }
            _ => Err(UnrepresentableConstArgError::new(expr)),
        }
    }

    /// It is not allowed to call this function without checking can_lower_path_to_const_arg_direct
    /// first, as we assume all feature gates/etc. have been checked already.
    fn lower_path_to_const_arg_direct(
        &mut self,
        id: NodeId,
        id_override: Option<NodeId>,
        qself: &Option<Box<QSelf>>,
        path: &Path,
        span: Span,
    ) -> hir::ConstArg<'hir> {
        let qpath = self.lower_qpath(
            id,
            qself,
            path,
            ParamMode::Explicit,
            AllowReturnTypeNotation::No,
            // FIXME(mgca): update for `fn foo() -> Bar<FOO<impl Trait>>` support
            ImplTraitContext::Disallowed(ImplTraitPosition::Path),
            None,
        );

        let node_id = id_override.unwrap_or(id);
        ConstArg { hir_id: self.lower_node_id(node_id), kind: hir::ConstArgKind::Path(qpath), span }
    }

    /// It is not allowed to call this function without checking can_lower_expr_to_const_arg_direct
    /// first, as we assume all feature gates/etc. have been checked already.
    #[instrument(level = "debug", skip(self), ret)]
    fn lower_expr_to_const_arg_direct(
        &mut self,
        expr: &Expr,
        id_override: Option<NodeId>,
    ) -> hir::ConstArg<'hir> {
        let span = self.lower_span(expr.span);
        let node_id = id_override.unwrap_or(expr.id);
        match &expr.kind {
            ExprKind::Call(func, args) if let ExprKind::Path(qself, path) = &func.kind => {
                let qpath = self.lower_qpath(
                    func.id,
                    qself,
                    path,
                    ParamMode::Explicit,
                    AllowReturnTypeNotation::No,
                    ImplTraitContext::Disallowed(ImplTraitPosition::Path),
                    None,
                );

                let lowered_args = self.arena.alloc_from_iter(args.iter().map(|arg| {
                    let const_arg = self.lower_expr_to_const_arg_direct(arg, None);
                    &*self.arena.alloc(const_arg)
                }));

                ConstArg {
                    hir_id: self.lower_node_id(node_id),
                    kind: hir::ConstArgKind::TupleCall(qpath, lowered_args),
                    span,
                }
            }
            ExprKind::Tup(exprs) => {
                let exprs = self.arena.alloc_from_iter(exprs.iter().map(|expr| {
                    let expr = self.lower_expr_to_const_arg_direct(expr, None);
                    &*self.arena.alloc(expr)
                }));

                ConstArg {
                    hir_id: self.lower_node_id(node_id),
                    kind: hir::ConstArgKind::Tup(exprs),
                    span,
                }
            }
            ExprKind::Path(qself, path) => {
                self.lower_path_to_const_arg_direct(expr.id, id_override, qself, path, span)
            }
            ExprKind::Struct(se) => {
                let path = self.lower_qpath(
                    expr.id,
                    &se.qself,
                    &se.path,
                    // FIXME(mgca): we may want this to be `Optional` instead, but
                    // we would also need to make sure that HIR ty lowering errors
                    // when these paths wind up in signatures.
                    ParamMode::Explicit,
                    AllowReturnTypeNotation::No,
                    ImplTraitContext::Disallowed(ImplTraitPosition::Path),
                    None,
                );

                let fields = self.arena.alloc_from_iter(se.fields.iter().map(|f| {
                    let hir_id = self.lower_node_id(f.id);
                    // FIXME(mgca): This might result in lowering attributes that
                    // then go unused as the `Target::ExprField` is not actually
                    // corresponding to `Node::ExprField`.
                    self.lower_attrs(hir_id, &f.attrs, f.span, Target::ExprField);
                    let expr = self.lower_expr_to_const_arg_direct(&f.expr, None);

                    &*self.arena.alloc(hir::ConstArgExprField {
                        hir_id,
                        field: self.lower_ident(f.ident),
                        expr: self.arena.alloc(expr),
                        span: self.lower_span(f.span),
                    })
                }));

                ConstArg {
                    hir_id: self.lower_node_id(node_id),
                    kind: hir::ConstArgKind::Struct(path, fields),
                    span,
                }
            }
            ExprKind::Array(elements) => {
                let lowered_elems = self.arena.alloc_from_iter(elements.iter().map(|element| {
                    let const_arg = self.lower_expr_to_const_arg_direct(element, None);
                    &*self.arena.alloc(const_arg)
                }));
                let array_expr = self.arena.alloc(hir::ConstArgArrayExpr {
                    span: self.lower_span(expr.span),
                    elems: lowered_elems,
                });

                ConstArg {
                    hir_id: self.lower_node_id(node_id),
                    kind: hir::ConstArgKind::Array(array_expr),
                    span,
                }
            }
            ExprKind::Underscore => ConstArg {
                hir_id: self.lower_node_id(node_id),
                kind: hir::ConstArgKind::Infer(()),
                span,
            },
            ExprKind::Paren(expr) => self.lower_expr_to_const_arg_direct(expr, id_override),
            ExprKind::Block(block, _)
                if let [stmt] = block.stmts.as_slice()
                    && let StmtKind::Expr(expr) = &stmt.kind =>
            {
                self.lower_expr_to_const_arg_direct(expr, id_override)
            }
            ExprKind::Lit(literal) => {
                let span = self.lower_span(expr.span);
                let literal = self.lower_lit(literal, span);

                ConstArg {
                    hir_id: self.lower_node_id(node_id),
                    kind: hir::ConstArgKind::Literal { lit: literal.node, negated: false },
                    span,
                }
            }
            ExprKind::Unary(UnOp::Neg, inner_expr)
                if let ExprKind::Lit(literal) = &inner_expr.kind =>
            {
                let span = self.lower_span(expr.span);
                let literal = self.lower_lit(literal, span);

                let kind = if !matches!(literal.node, LitKind::Int(..)) {
                    let err =
                        self.dcx().struct_span_err(expr.span, "negated literal must be an integer");
                    hir::ConstArgKind::Error(err.emit())
                } else {
                    hir::ConstArgKind::Literal { lit: literal.node, negated: true }
                };
                ConstArg { hir_id: self.lower_node_id(node_id), kind, span }
            }
            ExprKind::ConstBlock(anon_const) => {
                // Do not use lower_anon_const_to_const_arg, as that attempts to represent the body
                // directly. Instead, force an anon const.
                let def_id = self.local_def_id(anon_const.id);
                assert_eq!(DefKind::AnonConst, self.tcx.def_kind(def_id));
                let lowered_anon = self.lower_anon_const_to_anon_const(anon_const, span);
                ConstArg {
                    hir_id: self.lower_node_id(node_id),
                    kind: hir::ConstArgKind::Anon(lowered_anon),
                    span,
                }
            }
            ExprKind::DirectConstArg(expr) => {
                // `can_lower_expr_to_const_arg_direct` always returns success upon encountering a
                // ExprKind::DirectConstArg, which effectively forces the expression to be lowered
                // as a direct arg. If it actually turns out to not be possible, emit an error
                // instead.
                // Always use MacrolessMinGenericConstArgs, even if we're under regular GCA, because
                // that's what the macro means: to enter a context that is like macroless GCA.
                match self.can_lower_expr_to_const_arg_direct(
                    expr,
                    DirectConstArgContext::MacrolessMinGenericConstArgs,
                ) {
                    Ok(()) => self.lower_expr_to_const_arg_direct(expr, id_override),
                    Err(err) => err.emit(self),
                }
            }
            _ => {
                span_bug!(
                    expr.span,
                    "lower_expr_to_const_arg_direct encountered an unlowerable expression, either \
                    can_lower_expr_to_const_arg_direct returned Ok() on something it shouldn't \
                    have, or you forgot to check can_lower_expr_to_const_arg_direct first"
                );
            }
        }
    }

    /// See [`hir::ConstArg`] for when to use this function vs
    /// [`Self::lower_anon_const_to_anon_const`].
    fn lower_anon_const_to_const_arg_and_alloc(
        &mut self,
        anon: &AnonConst,
    ) -> &'hir hir::ConstArg<'hir> {
        self.arena.alloc(self.lower_anon_const_to_const_arg(anon))
    }

    #[instrument(level = "debug", skip(self))]
    fn lower_anon_const_to_const_arg(&mut self, anon: &AnonConst) -> hir::ConstArg<'hir> {
        // Stable only allows one nesting of blocks for directly represented paths. mGCA allows
        // arbitrarily many, and are handled inside lower_expr_to_const_arg_direct for consistency.
        let expr = if self.tcx.features().macroless_generic_const_args() {
            &anon.value
        } else {
            anon.value.maybe_unwrap_block()
        };

        let context = self.ambient_direct_const_arg_context();
        if self.can_lower_expr_to_const_arg_direct(expr, context).is_ok() {
            return self.lower_expr_to_const_arg_direct(expr, Some(anon.id));
        }

        let lowered_anon = self.lower_anon_const_to_anon_const(anon, anon.value.span);
        ConstArg {
            hir_id: self.next_id(),
            kind: hir::ConstArgKind::Anon(lowered_anon),
            span: self.lower_span(anon.value.span),
        }
    }

    /// See [`hir::ConstArg`] for when to use this function vs
    /// [`Self::lower_anon_const_to_const_arg`].
    fn lower_anon_const_to_anon_const(
        &mut self,
        c: &AnonConst,
        span: Span,
    ) -> &'hir hir::AnonConst {
        self.arena.alloc(self.with_new_scopes(c.value.span, |this| {
            let def_id = this.local_def_id(c.id);
            let hir_id = this.lower_node_id(c.id);
            hir::AnonConst {
                def_id,
                hir_id,
                body: this.lower_const_body(c.value.span, Some(&c.value)),
                span: this.lower_span(span),
            }
        }))
    }

    fn lower_unsafe_source(&mut self, u: UnsafeSource) -> hir::UnsafeSource {
        match u {
            CompilerGenerated => hir::UnsafeSource::CompilerGenerated,
            UserProvided => hir::UnsafeSource::UserProvided,
        }
    }

    fn lower_trait_bound_modifiers(
        &mut self,
        modifiers: TraitBoundModifiers,
    ) -> hir::TraitBoundModifiers {
        let constness = match modifiers.constness {
            BoundConstness::Never => BoundConstness::Never,
            BoundConstness::Always(span) => BoundConstness::Always(self.lower_span(span)),
            BoundConstness::Maybe(span) => BoundConstness::Maybe(self.lower_span(span)),
        };
        let polarity = match modifiers.polarity {
            BoundPolarity::Positive => BoundPolarity::Positive,
            BoundPolarity::Negative(span) => BoundPolarity::Negative(self.lower_span(span)),
            BoundPolarity::Maybe(span) => BoundPolarity::Maybe(self.lower_span(span)),
        };
        hir::TraitBoundModifiers { constness, polarity }
    }

    // Helper methods for building HIR.

    fn stmt(&mut self, span: Span, kind: hir::StmtKind<'hir>) -> hir::Stmt<'hir> {
        hir::Stmt { span: self.lower_span(span), kind, hir_id: self.next_id() }
    }

    fn stmt_expr(&mut self, span: Span, expr: hir::Expr<'hir>) -> hir::Stmt<'hir> {
        self.stmt(span, hir::StmtKind::Expr(self.arena.alloc(expr)))
    }

    fn stmt_let_pat(
        &mut self,
        attrs: Option<&'hir [hir::Attribute]>,
        span: Span,
        init: Option<&'hir hir::Expr<'hir>>,
        pat: &'hir hir::Pat<'hir>,
        source: hir::LocalSource,
    ) -> hir::Stmt<'hir> {
        let hir_id = self.next_id();
        if let Some(a) = attrs {
            assert!(!a.is_empty());
            self.curr_owner.attrs.insert(hir_id.local_id, a);
        }
        let local = hir::LetStmt {
            super_: None,
            hir_id,
            init,
            pat,
            els: None,
            source,
            span: self.lower_span(span),
            ty: None,
        };
        self.stmt(span, hir::StmtKind::Let(self.arena.alloc(local)))
    }

    fn stmt_super_let_pat(
        &mut self,
        span: Span,
        pat: &'hir hir::Pat<'hir>,
        init: Option<&'hir hir::Expr<'hir>>,
    ) -> hir::Stmt<'hir> {
        let hir_id = self.next_id();
        let span = self.lower_span(span);
        let local = hir::LetStmt {
            super_: Some(span),
            hir_id,
            init,
            pat,
            els: None,
            source: hir::LocalSource::Normal,
            span,
            ty: None,
        };
        self.stmt(span, hir::StmtKind::Let(self.arena.alloc(local)))
    }

    fn block_expr(&mut self, expr: &'hir hir::Expr<'hir>) -> &'hir hir::Block<'hir> {
        self.block_all(expr.span, &[], Some(expr))
    }

    fn block_all(
        &mut self,
        span: Span,
        stmts: &'hir [hir::Stmt<'hir>],
        expr: Option<&'hir hir::Expr<'hir>>,
    ) -> &'hir hir::Block<'hir> {
        let blk = hir::Block {
            stmts,
            expr,
            hir_id: self.next_id(),
            rules: hir::BlockCheckMode::DefaultBlock,
            span: self.lower_span(span),
            targeted_by_break: false,
        };
        self.arena.alloc(blk)
    }

    fn pat_cf_continue(&mut self, span: Span, pat: &'hir hir::Pat<'hir>) -> &'hir hir::Pat<'hir> {
        let field = self.single_pat_field(span, pat);
        self.pat_lang_item_variant(span, LangItem::ControlFlowContinue, field)
    }

    fn pat_cf_break(&mut self, span: Span, pat: &'hir hir::Pat<'hir>) -> &'hir hir::Pat<'hir> {
        let field = self.single_pat_field(span, pat);
        self.pat_lang_item_variant(span, LangItem::ControlFlowBreak, field)
    }

    fn pat_some(&mut self, span: Span, pat: &'hir hir::Pat<'hir>) -> &'hir hir::Pat<'hir> {
        let field = self.single_pat_field(span, pat);
        self.pat_lang_item_variant(span, LangItem::OptionSome, field)
    }

    fn pat_none(&mut self, span: Span) -> &'hir hir::Pat<'hir> {
        self.pat_lang_item_variant(span, LangItem::OptionNone, &[])
    }

    fn single_pat_field(
        &mut self,
        span: Span,
        pat: &'hir hir::Pat<'hir>,
    ) -> &'hir [hir::PatField<'hir>] {
        let field = hir::PatField {
            hir_id: self.next_id(),
            ident: Ident::new(sym::integer(0), self.lower_span(span)),
            is_shorthand: false,
            pat,
            span: self.lower_span(span),
        };
        arena_vec![self; field]
    }

    fn pat_lang_item_variant(
        &mut self,
        span: Span,
        lang_item: LangItem,
        fields: &'hir [hir::PatField<'hir>],
    ) -> &'hir hir::Pat<'hir> {
        let path = self.make_lang_item_qpath(lang_item, self.lower_span(span), None);
        self.pat(span, hir::PatKind::Struct(path, fields, None))
    }

    fn pat_ident(&mut self, span: Span, ident: Ident) -> (&'hir hir::Pat<'hir>, HirId) {
        self.pat_ident_binding_mode(span, ident, hir::BindingMode::NONE)
    }

    fn pat_ident_mut(&mut self, span: Span, ident: Ident) -> (hir::Pat<'hir>, HirId) {
        self.pat_ident_binding_mode_mut(span, ident, hir::BindingMode::NONE)
    }

    fn pat_ident_binding_mode(
        &mut self,
        span: Span,
        ident: Ident,
        bm: hir::BindingMode,
    ) -> (&'hir hir::Pat<'hir>, HirId) {
        let (pat, hir_id) = self.pat_ident_binding_mode_mut(span, ident, bm);
        (self.arena.alloc(pat), hir_id)
    }

    fn pat_ident_binding_mode_mut(
        &mut self,
        span: Span,
        ident: Ident,
        bm: hir::BindingMode,
    ) -> (hir::Pat<'hir>, HirId) {
        let hir_id = self.next_id();

        (
            hir::Pat {
                hir_id,
                kind: hir::PatKind::Binding(bm, hir_id, self.lower_ident(ident), None),
                span: self.lower_span(span),
                default_binding_modes: true,
            },
            hir_id,
        )
    }

    fn pat(&mut self, span: Span, kind: hir::PatKind<'hir>) -> &'hir hir::Pat<'hir> {
        self.arena.alloc(hir::Pat {
            hir_id: self.next_id(),
            kind,
            span: self.lower_span(span),
            default_binding_modes: true,
        })
    }

    fn pat_without_dbm(&mut self, span: Span, kind: hir::PatKind<'hir>) -> hir::Pat<'hir> {
        hir::Pat {
            hir_id: self.next_id(),
            kind,
            span: self.lower_span(span),
            default_binding_modes: false,
        }
    }

    fn ty_path(&mut self, mut hir_id: HirId, span: Span, qpath: hir::QPath<'hir>) -> hir::Ty<'hir> {
        let kind = match qpath {
            hir::QPath::Resolved(None, path) => {
                // Turn trait object paths into `TyKind::TraitObject` instead.
                match path.res {
                    Res::Def(DefKind::Trait | DefKind::TraitAlias, _) => {
                        let principal = hir::PolyTraitRef {
                            bound_generic_params: &[],
                            modifiers: hir::TraitBoundModifiers::NONE,
                            trait_ref: hir::TraitRef { path, hir_ref_id: hir_id },
                            span: self.lower_span(span),
                        };

                        // The original ID is taken by the `PolyTraitRef`,
                        // so the `Ty` itself needs a different one.
                        hir_id = self.next_id();
                        hir::TyKind::TraitObject(
                            arena_vec![self; principal],
                            TaggedRef::new(self.elided_dyn_bound(span), TraitObjectSyntax::None),
                        )
                    }
                    _ => hir::TyKind::Path(hir::QPath::Resolved(None, path)),
                }
            }
            _ => hir::TyKind::Path(qpath),
        };

        hir::Ty { hir_id, kind, span: self.lower_span(span) }
    }

    /// Invoked to create the lifetime argument(s) for an elided trait object
    /// bound, like the bound in `Box<dyn Debug>`. This method is not invoked
    /// when the bound is written, even if it is written with `'_` like in
    /// `Box<dyn Debug + '_>`. In those cases, `lower_lifetime` is invoked.
    fn elided_dyn_bound(&mut self, span: Span) -> &'hir hir::Lifetime {
        let r = hir::Lifetime::new(
            self.next_id(),
            Ident::new(kw::UnderscoreLifetime, self.lower_span(span)),
            hir::LifetimeKind::ImplicitObjectLifetimeDefault,
            LifetimeSource::Other,
            LifetimeSyntax::Implicit,
        );
        debug!("elided_dyn_bound: r={:?}", r);
        self.arena.alloc(r)
    }
}

/// Helper struct for the delayed construction of [`hir::GenericArgs`].
struct GenericArgsCtor<'hir> {
    args: SmallVec<[hir::GenericArg<'hir>; 4]>,
    constraints: &'hir [hir::AssocItemConstraint<'hir>],
    parenthesized: hir::GenericArgsParentheses,
    span: Span,
}

impl<'hir> GenericArgsCtor<'hir> {
    fn is_empty(&self) -> bool {
        self.args.is_empty()
            && self.constraints.is_empty()
            && self.parenthesized == hir::GenericArgsParentheses::No
    }

    fn into_generic_args(self, this: &LoweringContext<'_, 'hir>) -> &'hir hir::GenericArgs<'hir> {
        let ga = hir::GenericArgs {
            args: this.arena.alloc_from_iter(self.args),
            constraints: self.constraints,
            parenthesized: self.parenthesized,
            span_ext: this.lower_span(self.span),
        };
        this.arena.alloc(ga)
    }
}

#[derive(Copy, Clone, Debug)]
enum DirectConstArgContext {
    /// The only allowed direct const arg representation is simple paths that nameres to generic
    /// const parameters.
    Stable,
    /// The allowed representations are what is allowed on stable, plus the `direct_const_arg!` macro.
    MinGenericConstArgs,
    /// Expressions attempt to be lowered directly, and if that fails, the expression falls back to
    /// being represented as an anon const.
    ///
    /// This context is also used under MinGenericConstArgs inside a `direct_const_arg!` macro, for
    /// simplicity, as they allow the same code.
    MacrolessMinGenericConstArgs,
}

#[derive(Debug)]
struct UnrepresentableConstArgError {
    span: Span,
    will_create_def_ids: bool,
}

impl UnrepresentableConstArgError {
    fn new(expr: &Expr) -> Self {
        Self {
            span: expr.span,
            will_create_def_ids: expr::WillCreateDefIdsVisitor.visit_expr(expr).is_break(),
        }
    }

    fn emit<'hir>(self, lowering_context: &mut LoweringContext<'_, 'hir>) -> ConstArg<'hir> {
        let msg = "complex const arguments must be placed inside of a `const` block";
        let e = if self.will_create_def_ids {
            // FIXME(mgca): make this non-fatal once we have a better way to handle
            // nested items in const args
            // Issue: https://github.com/rust-lang/rust/issues/154539
            lowering_context.dcx().struct_span_fatal(self.span, msg).emit()
        } else {
            lowering_context.dcx().struct_span_err(self.span, msg).emit()
        };

        ConstArg {
            hir_id: lowering_context.next_id(),
            kind: hir::ConstArgKind::Error(e),
            span: self.span,
        }
    }
}
