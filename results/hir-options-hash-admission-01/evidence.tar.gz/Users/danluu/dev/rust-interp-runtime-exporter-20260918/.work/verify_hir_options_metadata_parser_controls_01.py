import hashlib,json,re,time
from pathlib import Path
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
H=X/'experiments/hir-options-hash/compiler-metadata-continuation-01'
W=X/'.work/hir-options-hash-metadata-parser-controls-01'
O=X/'.work/experiments/hir-options-hash-metadata-parser-controls-supervisor-01'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=read(W/'receipt.json');c=read(W/'command/receipt.json');o=read(O/'status.json');f=read(H/'control-inputs.json');launch=read(H/'control-launch.json')
assert r['status']=='passed' and r['controls_passed']==9 and len(r['commands'])==1
assert r['commands'][0]==dict(path=str(W/'command/receipt.json'),sha256=sha(W/'command/receipt.json'),pid=c['pid'])
assert o['status']=='finished' and o['returncode']==0 and o['child_pid']==r['pid'] and o['supervisor_pid']==r['parent_pid']
assert sha(O/'plan.json')==o['plan_sha256'] and sha(O/'command.log')==o['log_sha256']
assert o['started_at']<=r['started_at']<=r['admitted_at']<=c['started_at']<=c['finished_at']<=r['finished_at']<=o['finished_at']
assert c['status']=='finished' and c['returncode']==0 and c['supervisor_pid']==r['pid'] and c['parent_pid']==r['parent_pid']
assert c['command']==f['command'] and c['cwd']==str(H)
assert c['environment']==dict(f['environment'],TMPDIR=str(W/'tmp'))
for stream in ['stdout','stderr']:assert sha(W/'command'/stream)==c[stream+'_sha256']
assert not (W/'command/stdout').read_bytes()
stderr=(W/'command/stderr').read_text()
assert sorted(re.findall(r'^(test_[A-Za-z0-9_]+) .* \.\.\. ok$',stderr,re.M))==f['expected_names']
assert re.search(r'^Ran 9 tests in [0-9.]+s\n\nOK\n$',stderr,re.M)
assert sha(H/'control-inputs.json')==launch['inputs_sha256'] and sha(H/'run_controls.py')==launch['helper_sha256']
for name,row in f['files'].items():
 p=Path(name);assert p.resolve(strict=True)==p and sha(p)==row['sha256']
p=X/'.work/hir-options-hash-metadata-parser-controls-verification-01.json'
with p.open('x') as stream:
 json.dump(dict(status='verified',time=time.time(),script_sha256=sha(Path(__file__)),receipt_sha256=sha(W/'receipt.json'),child_sha256=sha(W/'command/receipt.json'),freeze_sha256=sha(H/'control-inputs.json'),controls=9,files=len(f['files'])),stream,indent=2);stream.write('\n')
print(p,sha(p))
