import ast,hashlib,json,sys
from pathlib import Path
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918');H=X/'experiments/hir-options-hash';W=X/'.work'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,d):
 with p.open('x') as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n')
files={};directories={}
def add(p):
 assert p.resolve(strict=True)==p and p.is_file() and not p.is_symlink()
 s=p.lstat();files[str(p)]=dict(sha256=sha(p),bytes=s.st_size,stamp=[s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink])
def tree(p):
 members=sorted(x for x in p.rglob('*') if x.is_file() or x.is_symlink());directories[str(p)]=list(map(str,members))
 for x in members:add(x)
tree(H)
stages=[]
for kind,name,source,tests in [('acquisition','hir-options-hash-acquisition-01','build-01',None),('controls','hir-options-hash-acquisition-controls-01','build-01',4),('controls','hir-options-hash-build-budget-controls-01','compiler-build-01',5),('controls','hir-options-hash-build-budget-controls-02','compiler-build-01',15)]:
 work=W/name;tree(work)
 outer=W/'experiments'/name.replace('-01','-supervisor-01').replace('-02','-supervisor-02');tree(outer)
 audit=W/name.replace('-01','-verification-01').replace('-02','-verification-02');audit=Path(str(audit)+'.json');add(audit)
 item=dict(kind=kind,work=str(work),terminal=str(work/'receipt.json'),outer=str(outer),audit=str(audit),children=17 if kind=='acquisition' else 1)
 if kind=='acquisition':item.update(inputs=str(H/source/'acquisition-inputs.json'),plan=str(H/source/'acquisition-plan.json'),acquired=str(work/'acquired.json'))
 else:item.update(inputs=str(H/source/('control-inputs-v2.json' if tests==15 else 'control-inputs.json')),cwd=str(H/source),tests=tests)
 stages.append(item)
for p in W.iterdir():
 if p.is_file() and (p.name.startswith('hir-options-hash-') or p.name.startswith('verify_hir_options_')):add(p)
for p in [W/'archive_hir_options_preparation_03.py',Path(__file__).resolve(),X/'experiments/stable-cgu/owned_stage.py',X/'scripts/supervise_experiment.py']:add(p)
for name in ['archive_hir_options_preparation_01.py','prepare_hir_options_retention_01.py','hir-options-preparation-retention-inputs-01.json','hir-options-preparation-retention-launch-01.json']:add(W/name)
for name in ['archive_hir_options_preparation_02.py','prepare_hir_options_retention_02.py','hir-options-preparation-retention-inputs-02.json','hir-options-preparation-retention-launch-02.json']:add(W/name)
python=Path(sys.executable).resolve(strict=True)
for p in [W/'archive_hir_options_preparation_03.py',Path(__file__).resolve()]:ast.parse(p.read_text())
unrun=[str(W/('hir-options-hash-compiler-metadata-'+i)) for i in ['01','02','03']]+[str(W/'hir-options-hash-compiler-build-01')]
assert all(not Path(p).exists() for p in unrun)
f=dict(owner=str(X),files=files,directories=directories,stages=stages,unrun_work_paths=unrun,python_sha256=sha(python),capacity=dict(entry_gib=9,extra_reservation_mib=128,output_mib=64),logical_bytes=sum(v['bytes'] for v in files.values()))
assert len(files)<=4096 and f['logical_bytes']<=512*2**20 and max(v['bytes'] for v in files.values())<=96*2**20
freeze=W/'hir-options-preparation-retention-inputs-03.json';write(freeze,f)
env=dict(HOME='/Users/danluu',PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',LANG='C',LC_ALL='C',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
launch=dict(status='prepared-unrun-awaiting-review',environment=env,command=[str(python),'-B',str(X/'scripts/supervise_experiment.py'),'--run-id','hir-options-preparation-retention-supervisor-03','--',str(python),'-B',str(W/'archive_hir_options_preparation_03.py'),'--inputs-sha256',sha(freeze)],inputs_sha256=sha(freeze),compiler_builds=0)
p=W/'hir-options-preparation-retention-launch-03.json';write(p,launch)
print(json.dumps(dict(files=len(files),logical_bytes=f['logical_bytes'],max_file=max(v['bytes'] for v in files.values()),launch_sha256=sha(p),inputs_sha256=sha(freeze)),indent=2))
