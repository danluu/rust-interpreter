"""Retain completed source acquisition, controls and explicitly unrun proposals."""
import argparse,gzip,hashlib,importlib.util,io,json,os,stat,sys,tarfile,time
from pathlib import Path
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
F=X/'.work/hir-options-preparation-retention-inputs-03.json'
W=X/'.work/hir-options-preparation-retention-03'
OUT=X/'results/hir-options-hash-preparation-01'
MIB=2**20

def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stamp(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink]
def capture(p,row):
 assert p.resolve(strict=True)==p and stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size<=96*MIB
 before=stamp(p);data=p.read_bytes();assert stamp(p)==before==row['stamp'] and len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 return data

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--inputs-sha256',required=True);args=ap.parse_args()
 assert Path.cwd()==X and sys.dont_write_bytecode and not sys.flags.optimize and sha(F)==args.inputs_sha256
 f=read(F);assert sha(Path(sys.executable).resolve())==f['python_sha256']
 helper=X/'experiments/stable-cgu/owned_stage.py';capture(helper,f['files'][str(helper)])
 spec=importlib.util.spec_from_file_location('retention_owned',helper);owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
 W.mkdir(exist_ok=False);receipt=dict(status='waiting',pid=os.getpid(),parent_pid=os.getppid(),started_at=time.time(),compiler_builds=0,metadata_launches=0)
 owned.write(W/'receipt.json',receipt)
 try:
  with owned.workload_lock(owned.CANONICAL_LOCK,600):
   free=owned.disk(X,9);assert free>=9*2**30+128*MIB
   receipt.update(status='running',admitted_at=time.time(),free_bytes_before=free);owned.write(W/'receipt.json',receipt)
   payloads={};unique={}
   for name,row in f['files'].items():
    owned.disk(X,9);data=capture(Path(name),row);payloads[name]=unique.setdefault((row['sha256'],len(data)),data)
   assert len(payloads)<=4096 and sum(len(v) for v in payloads.values())<=512*MIB and sum(len(v) for v in unique.values())<=512*MIB
   for name,members in f['directories'].items():assert sorted(str(p) for p in Path(name).rglob('*') if p.is_file() or p.is_symlink())==sorted(members)
   def datajson(p):return json.loads(payloads[str(p)])
   actual=[]
   for item in f['stages']:
    terminal=datajson(item['terminal']);assert terminal['status']=='passed' and len(terminal['commands'])==item['children']
    frozen=datajson(item['inputs']);outer=datajson(item['outer']+'/status.json')
    assert outer['status']=='finished' and outer['returncode']==0 and outer['child_pid']==terminal['pid'] and outer['supervisor_pid']==terminal['parent_pid']
    assert outer['plan_sha256']==hashlib.sha256(payloads[item['outer']+'/plan.json']).hexdigest()
    assert outer['log_sha256']==hashlib.sha256(payloads[item['outer']+'/command.log']).hexdigest()
    assert outer['started_at']<=terminal['started_at']<=terminal['admitted_at']<=terminal['finished_at']<=outer['finished_at']
    if item['kind']=='acquisition':
     plan=datajson(item['plan']);rows=plan['children_before_copy']+plan['children_after_copy']
     acquired=datajson(item['acquired']);assert acquired['builds']==terminal['compiler_builds']==terminal['cargo_commands']==0
     assert hashlib.sha256(payloads[item['acquired']]).hexdigest()==terminal['acquired_sha256']
    else:
     rows=[dict(argv=frozen['command'],cwd=item['cwd'],environment=frozen['environment']|{'TMPDIR':item['work']+'/tmp'})]
     assert terminal['controls_passed']==item['tests']
    previous=terminal['admitted_at']
    for ref,row in zip(terminal['commands'],rows,strict=True):
     child=datajson(ref['path']);assert hashlib.sha256(payloads[ref['path']]).hexdigest()==ref['sha256']
     assert child['pid']==ref['pid'] and child['status']=='finished' and child['returncode']==0
     assert child['command']==row['argv'] and child['cwd']==row['cwd'] and child['environment']==row['environment']
     assert child['supervisor_pid']==terminal['pid'] and child['parent_pid']==terminal['parent_pid']
     assert previous<=child['started_at']<=child['finished_at']<=terminal['finished_at'];previous=child['finished_at']
     for stream in ['stdout','stderr']:assert hashlib.sha256(payloads[str(Path(ref['path']).parent/stream)]).hexdigest()==child[stream+'_sha256']
    audit=datajson(item['audit']);assert audit['status']=='verified' and audit['receipt_sha256']==hashlib.sha256(payloads[item['terminal']]).hexdigest()
    actual.append(dict(kind=item['kind'],children=item['children'],tests=item.get('tests'),receipt_sha256=hashlib.sha256(payloads[item['terminal']]).hexdigest()))
   for directory in f['unrun_work_paths']:assert not Path(directory).exists()
   payloads[str(F)]=F.read_bytes();OUT.mkdir(parents=True,exist_ok=False)
   archive=OUT/'evidence.tar.gz';manifest={};seen_content={}
   with archive.open('xb') as file:
    with gzip.GzipFile(fileobj=file,mode='wb',filename='',mtime=0) as gz:
     with tarfile.open(fileobj=gz,mode='w') as tar:
      for path,data in sorted(payloads.items()):
       owned.disk(X,9);digest=hashlib.sha256(data).hexdigest();name=path.lstrip('/');key=(digest,len(data));member=tarfile.TarInfo(name);member.mode=0o644
       if key in seen_content:member.type=tarfile.LNKTYPE;member.linkname=seen_content[key];tar.addfile(member)
       else:member.size=len(data);tar.addfile(member,io.BytesIO(data));seen_content[key]=name
       manifest[name]=dict(source=path,sha256=digest,bytes=len(data))
   assert archive.stat().st_size<=64*MIB
   seen=set()
   with tarfile.open(archive,'r:gz') as tar:
    for member in tar:
     assert member.name in manifest and member.name not in seen and (member.isfile() or member.islnk())
     if member.islnk():assert member.linkname in seen
     data=tar.extractfile(member).read();row=manifest[member.name]
     assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];seen.add(member.name)
   assert seen==set(manifest)
   expanded=0
   with gzip.open(archive,'rb') as gz:
    while block:=gz.read(MIB):expanded+=len(block);assert expanded<=544*MIB;owned.disk(X,9)
   for name,row in f['files'].items():assert capture(Path(name),row)==payloads[name]
   for name,members in f['directories'].items():assert sorted(str(p) for p in Path(name).rglob('*') if p.is_file() or p.is_symlink())==sorted(members)
   owned.write(OUT/'manifest.json',dict(schema_version=1,files=manifest,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,logical_bytes=sum(v['bytes'] for v in manifest.values()),physical_payloads=len(seen_content),stages=actual,
    scope='All selected experiment source, actual receipts/raw streams, independent audits and frozen input catalogs. Live compiler/SDK/registry/provider payload bytes are not copied; their complete acquisition readback and content catalogs are retained. Metadata/build/application qualification remains unrun.',full_member_readback=True,gzip_eof_crc=True))
   receipt.update(status='passed',manifest_sha256=sha(OUT/'manifest.json'),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,logical_members=len(manifest),free_bytes_after=owned.disk(X,9))
 except BaseException as error:receipt.update(status='failed',error=repr(error));raise
 finally:receipt['finished_at']=time.time();owned.write(W/'receipt.json',receipt)
if __name__=='__main__':main()
