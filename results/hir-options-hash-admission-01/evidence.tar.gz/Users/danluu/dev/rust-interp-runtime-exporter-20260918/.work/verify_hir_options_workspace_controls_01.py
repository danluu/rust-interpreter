import hashlib,json,time
from pathlib import Path
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
H=X/'experiments/hir-options-hash/workspace-controls-01'
W=X/'.work/hir-options-hash-workspace-controls-01'
O=X/'.work/experiments/hir-options-hash-workspace-controls-supervisor-01'
FIXTURE=Path('/Users/danluu/dev/rust-interp-cargo-workspace-controls-20260918')
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def stamp(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink]
r=read(W/'receipt.json');o=read(O/'status.json');p=read(H/'plan.json');f=read(H/'inputs.json');result=read(W/'controls.json')
assert r['status']=='passed' and r['compiler_builds']==0 and r['controls_passed']==6 and len(r['commands'])==6
assert o['status']=='finished' and o['returncode']==0 and o['child_pid']==r['pid'] and o['supervisor_pid']==r['parent_pid']
assert sha(O/'plan.json')==o['plan_sha256'] and sha(O/'command.log')==o['log_sha256']
assert o['started_at']<=r['started_at']<=r['admitted_at']<=r['finished_at']<=o['finished_at']
assert sha(W/'controls.json')==r['controls_sha256'] and result['status']=='passed' and result['metadata_commands']==6 and result['compiler_builds']==0
assert result['candidate_workspace']==dict(exclude=['.work'],members=['member'],resolver='2')
outer=FIXTURE/'outer';inner=outer/'.work/generated/source';bootstrap=inner/'src/bootstrap'
expected_roots=[outer,None,outer,bootstrap,inner,None]
expected_members=[{'outer_member':outer/'member'},None,{'outer_member':outer/'member'},{'bootstrap':bootstrap},{'inner_compiler':inner/'compiler','build_helper':inner/'src/build_helper'},None]
previous=r['admitted_at']
for index,(ref,row,observed) in enumerate(zip(r['commands'],p['children'],result['rows'],strict=True)):
 d=W/'commands'/f'{index:03}';c=read(d/'receipt.json')
 assert ref==dict(path=str(d/'receipt.json'),sha256=sha(d/'receipt.json'),pid=c['pid'],label=row['label'])
 assert c['command']==row['argv'] and c['cwd']==row['cwd'] and c['environment']==row['environment']
 assert c['status']=='finished' and c['returncode']==row['expected_returncode']==observed['expected_returncode']
 assert c['supervisor_pid']==r['pid'] and c['parent_pid']==r['parent_pid']
 assert previous<=c['started_at']<=c['finished_at']<=r['finished_at'];previous=c['finished_at']
 for stream in ['stdout','stderr']:assert sha(d/stream)==c[stream+'_sha256']==observed[stream+'_sha256']
 assert all(s['free_bytes']>=9*2**30 and s['namespace_allocated_bytes']<=4*2**20 and s['evidence_allocated_bytes']<=256*2**20 and not s['allocation_errors'] for s in c['samples'])
 if expected_roots[index] is None:
  assert not (d/'stdout').read_bytes()
  text=(d/'stderr').read_text();assert "current package believes it's in a workspace when it's not" in text and 'workspace: '+str(outer/'Cargo.toml') in text and 'current:   '+str(Path(row['cwd'])/'Cargo.toml') in text
 else:
  assert not (d/'stderr').read_bytes();data=read(d/'stdout')
  assert data['workspace_root']==str(expected_roots[index])
  assert {pkg['name']:pkg['manifest_path'] for pkg in data['packages'] if pkg['id'] in data['workspace_members']}=={name:str(path/'Cargo.toml') for name,path in expected_members[index].items()}
for name,row in f['files'].items():
 path=Path(name);assert path.resolve(strict=True)==path and stamp(path)==row['stamp'] and sha(path)==row['sha256'],name
assert not (FIXTURE/'target').exists()
assert (outer/'Cargo.toml').read_bytes()==(FIXTURE/'after-Cargo.toml').read_bytes()
assert sha(X/'Cargo.toml')==f['files'][str(X/'Cargo.toml')]['sha256']
target=X/'.work/hir-options-hash-workspace-controls-verification-01.json'
with target.open('x') as stream:
 json.dump(dict(status='verified',time=time.time(),script_sha256=sha(Path(__file__)),receipt_sha256=sha(W/'receipt.json'),controls_sha256=sha(W/'controls.json'),freeze_sha256=sha(H/'inputs.json'),children=6,compiler_builds=0,files=len(f['files']),parent_manifest_still_original=True,fixture_target_absent=True),stream,indent=2,sort_keys=True);stream.write('\n')
print(target,sha(target))
