"""Reconcile both histories and independently reread every immutable input."""
import hashlib,json,os,stat,time
from pathlib import Path
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
H=X/'experiments/hir-options-hash/compiler-metadata-continuation-01'
M=X/'experiments/hir-options-hash/compiler-metadata-03'
W=X/'.work/hir-options-hash-compiler-metadata-continuation-01'
P=X/'.work/hir-options-hash-compiler-metadata-03'
O=X/'.work/experiments/hir-options-hash-compiler-metadata-continuation-supervisor-01'
PO=X/'.work/experiments/hir-options-hash-compiler-metadata-supervisor-03'
def read(p):return json.loads(p.read_bytes())
def sha(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def stamp(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_nlink]
plan=read(H/'plan.json');f=read(H/'inputs.json');mf=read(M/'inputs.json');r=read(W/'receipt.json');old=read(P/'receipt.json');meta=read(W/'metadata.json');launch=read(H/'launch.json')
assert sha(H/'launch.json')=='6d8165cc351153e1591a6a6f92554f822bbf5786696bd0195e900f2b3f2a7dd0'
assert sha(H/'inputs.json')==launch['inputs_sha256'] and sha(H/'plan.json')==f['plan_sha256']==launch['plan_sha256']
assert sha(M/'inputs.json')==plan['original_inputs_sha256'] and sha(M/'plan.json')==mf['plan_sha256']
mp=read(M/'plan.json');assert mp==plan['original_plan']
assert old['status']=='failed' and old['error']=="RuntimeError('unknown linker architecture grammar')" and len(old['commands'])==48
assert old['compiler_builds']==0 and sha(P/'receipt.json')==plan['prior_receipt_sha256']
assert r['status']=='passed' and r['compiler_builds']==0 and r['saved_children']==48 and len(r['commands'])==2
previous=0
for root,outer_root,terminal,expected_rows,returncode in [(P,PO,old,mp['children'][:48],1),(W,O,r,mp['children'][48:],0)]:
 outer=read(outer_root/'status.json')
 assert outer['status']=='finished' and outer['returncode']==returncode
 assert outer['child_pid']==terminal['pid'] and outer['supervisor_pid']==terminal['parent_pid']
 assert sha(outer_root/'plan.json')==outer['plan_sha256'] and sha(outer_root/'command.log')==outer['log_sha256']
 assert previous<=outer['started_at']<=terminal['started_at']<=terminal['admitted_at']<=terminal['finished_at']<=outer['finished_at']
 previous=terminal['admitted_at']
 for index,(ref,row) in enumerate(zip(terminal['commands'],expected_rows,strict=True)):
  directory=root/'commands'/f'{index:03}';child=read(directory/'receipt.json')
  assert ref==dict(path=str(directory/'receipt.json'),sha256=sha(directory/'receipt.json'),pid=child['pid'],command=row['argv'])
  assert child['command']==row['argv'] and child['environment']==row['environment'] and child['cwd']==row['cwd']
  assert child['status']=='finished' and child['returncode'] in row['expected']
  assert child['supervisor_pid']==terminal['pid'] and child['parent_pid']==terminal['parent_pid']
  assert previous<=child['started_at']<=child['finished_at']<=terminal['finished_at'];previous=child['finished_at']
  for stream in ['stdout','stderr']:
   assert sha(directory/stream)==child[stream+'_sha256']
   if stream in row:assert (directory/stream).read_bytes()==row[stream].encode()
 previous=outer['finished_at']
assert sha(W/'metadata.json')==r['metadata_sha256']
assert meta['status']=='metadata-qualified-not-built' and meta['candidate_revision']==mp['candidate_revision']==r['candidate_revision']
assert meta['closures']==mp['closures'] and meta['seeds']==mp['seeds']
assert meta['llvm_version']==mp['llvm']['numeric_version']=='23.1.1'
assert meta['llvm_provider_version']==mp['llvm']['provider_version']=='23.1.1-rust-1.100.0-nightly'
assert meta['build_environment']==mp['build_environment'] and meta['platform']==mp['platform'] and meta['network_block']==mp['network_block']
assert meta['prior_receipt_sha256']==r['prior_receipt_sha256']==sha(P/'receipt.json') and meta['prior_children']==48 and meta['continuation_children']==2
assert meta['linker_probe_sha256']==sha(W/'linker-probe.json')
linker=read(W/'linker-probe.json');raw=(P/'commands/047/stderr').read_bytes()
assert linker['raw_sha256']==hashlib.sha256(raw).hexdigest() and linker['raw_bytes']==len(raw)
assert linker['private_paths']==sorted(mp['linker_expected_loaded']) and len(linker['version_lines'])==6
cursor=0
for number,row in enumerate(linker['lines'],1):
 data=bytes.fromhex(row['raw_hex']);assert row['line']==number and row['start']==cursor
 cursor+=len(data);assert row['end']==cursor and raw[row['start']:cursor]==data==row['raw'].encode()
assert cursor==len(raw) and len(linker['lines'])==713
files={**mf['files'],**f['files']};byte_count=0
for name,row in files.items():
 p=Path(name);assert p.resolve(strict=True)==p and stat.S_ISREG(p.lstat().st_mode)
 assert stamp(p)==row['stamp'] and sha(p)==row['sha256'],name
 byte_count+=p.stat().st_size
for name,row in mf['links'].items():
 p=Path(name);assert p.is_symlink() and stamp(p)==row['stamp'] and os.readlink(p)==row['target'] and str(p.resolve(strict=True))==row['resolved']
for name,expected in mp['configuration'].items():
 p=Path(name);assert not p.is_symlink() and (sha(p) if p.is_file() else None)==expected
for name,target in mp['routes'].items():assert str(Path(name).resolve(strict=True))==target
for root_name,members in plan['prior_membership'].items():
 root=Path(root_name);assert sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file())==members
sdk=Path('/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk');members={''}
for parent,dirs,names in os.walk(sdk,followlinks=False):members.update(str((Path(parent)/name).relative_to(sdk)) for name in dirs+names)
assert members==set(mp['sdk_inventory'])
for name,row in mp['sdk_inventory'].items():
 p=sdk/name;assert stamp(p)==row['stamp']
 if row['kind']=='directory':assert stat.S_ISDIR(p.lstat().st_mode)
 elif row['kind']=='link':assert p.is_symlink() and os.readlink(p)==row['target'] and str(p.resolve(strict=True))==row['resolved']
 else:assert row['kind']=='file' and files[str(p)]['sha256']==row['sha256']
assert meta['sdk_inventory_sha256']==hashlib.sha256(json.dumps(mp['sdk_inventory'],sort_keys=True).encode()).hexdigest()
acquired=read(X/'.work/hir-options-hash-acquisition-01/acquired.json');assert meta['source_identity']==acquired['source_identity']
for root,records in [(Path(acquired['source']),acquired['source_files']),(Path(acquired['source'])/'library/backtrace',acquired['backtrace_files'])]:
 for name,row in records.items():
  p=root/name
  if row['mode']=='120000':assert p.is_symlink() and os.readlink(p)==row['target']
  else:assert p.resolve(strict=True)==p and sha(p)==row['sha256']
assert not (X/'.work/hir-options-hash-compiler-build-01').exists()
target=X/'.work/hir-options-hash-compiler-metadata-continuation-verification-01.json'
with target.open('x') as stream:
 json.dump(dict(status='verified',time=time.time(),script_sha256=sha(Path(__file__)),receipt_sha256=sha(W/'receipt.json'),metadata_sha256=sha(W/'metadata.json'),prior_receipt_sha256=sha(P/'receipt.json'),saved_children=48,new_children=2,compiler_builds=0,frozen_files=len(files),frozen_bytes=byte_count,frozen_links=len(mf['links']),sdk_entries=len(members)),stream,indent=2,sort_keys=True);stream.write('\n')
print(target,sha(target))
