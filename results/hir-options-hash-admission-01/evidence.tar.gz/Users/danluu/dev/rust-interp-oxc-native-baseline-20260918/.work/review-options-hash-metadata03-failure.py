"""Read-only independent audit of already completed metadata children."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import time

O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
H=X/'experiments/hir-options-hash/compiler-metadata-03'
W=X/'.work/hir-options-hash-compiler-metadata-03'
OUTER=X/'.work/experiments/hir-options-hash-compiler-metadata-supervisor-03'


def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    plan=read(H/'plan.json');freeze=read(H/'inputs.json');launch=read(H/'launch.json')
    assert sha(H/'launch.json')=='b3ec64075b7615209785b6c7914a0545e8ef0739d4246d36483eac77ac2b99e3'
    assert sha(H/'inputs.json')==launch['inputs_sha256']=='04af101aceaa3ee52ccacf93d7f5ca85b8bcd82c418f020e3bcd473340d74e88'
    assert sha(H/'plan.json')==freeze['plan_sha256']==launch['plan_sha256']
    terminal=read(W/'receipt.json');outer=read(OUTER/'status.json')
    assert terminal['status']=='failed' and terminal['compiler_builds']==0 and terminal['error']=="RuntimeError('unknown linker architecture grammar')"
    assert outer['status']=='finished' and outer['returncode']==1
    assert terminal['pid']==outer['child_pid']==8767 and terminal['parent_pid']==outer['supervisor_pid']==8764
    assert outer['started_at']<=terminal['started_at']<=terminal['admitted_at']<=terminal['finished_at']<=outer['finished_at']
    assert outer['command']==launch['command'][launch['command'].index('--')+1:] and outer['cwd']==str(X)
    assert len(terminal['commands'])==48 and len(plan['children'])==50
    observations=[]; pids=set(); prior=terminal['admitted_at'];outs=[];errs=[];missing_ps=[];missing_cwd=[]
    for index,(actual,expected) in enumerate(zip(terminal['commands'],plan['children'])):
        directory=W/'commands'/f'{index:03}';path=directory/'receipt.json';child=read(path)
        assert actual['path']==str(path) and actual['sha256']==sha(path) and actual['pid']==child['pid']
        assert actual['command']==child['command']==expected['argv']
        assert child['cwd']==expected['cwd'] and child['environment']==expected['environment']
        assert child['status']=='finished' and child['returncode'] in expected['expected']
        assert child['supervisor_pid']==terminal['pid'] and child['parent_pid']==terminal['parent_pid']
        assert prior<=child['started_at']<=child['finished_at']<=terminal['finished_at'];prior=child['finished_at']
        assert child['pid'] not in pids;pids.add(child['pid'])
        stdout=(directory/'stdout').read_bytes();stderr=(directory/'stderr').read_bytes()
        assert hashlib.sha256(stdout).hexdigest()==child['stdout_sha256'] and hashlib.sha256(stderr).hexdigest()==child['stderr_sha256']
        if 'stdout' in expected:assert stdout==expected['stdout'].encode()
        if 'stderr' in expected:assert stderr==expected['stderr'].encode()
        if 16<=index<=45:assert not stderr
        identity=child['identity'];ps=identity['ps']
        if ps:
            fields=ps.split();assert [int(x) for x in fields[:3]]==[child['pid'],terminal['pid'],child['pid']]
            start=datetime.datetime.strptime(' '.join(fields[3:8]),'%a %b %d %H:%M:%S %Y').replace(tzinfo=datetime.timezone.utc).timestamp()
            assert child['started_at']-1<=start<=child['finished_at']
            assert identity['ps_returncode']==0
        else:missing_ps.append(index)
        if identity['cwd']:
            assert identity['cwd_returncode']==0 and 'n'+child['cwd']+'\n' in identity['cwd']
        else:missing_cwd.append(index)
        observations.append(dict(index=index,pid=child['pid'],receipt_sha256=sha(path),stdout_sha256=child['stdout_sha256'],stderr_sha256=child['stderr_sha256'],started_at=child['started_at'],finished_at=child['finished_at'],ps_recorded=bool(ps),cwd_observed=bool(identity['cwd'])))
        outs.append(stdout);errs.append(stderr)
    assert sha(W/'receipt.json')=='0aa470640dcbe112aadca653753bf90c3ea0178e1a5afa647844af7491cddc9f'
    assert not (W/'metadata.json').exists() and not (W/'linker-probe.json').exists()
    assert not (W/'commands/048').exists() and not (W/'commands/049').exists()
    assert outs[0]==(plan['candidate_revision']+'\n').encode() and outs[1]==outs[4]==b''
    assert outs[2]==outs[3]==(plan['llvm']['commit']+'\n').encode() and outs[5]==b'nightly\n' and outs[6]==b'1.100.0\n'
    assert outs[46]==b'23.1.1-rust-1.100.0-nightly\n' and not errs[46]
    assert plan['llvm']['provider_version']=='23.1.1-rust-1.100.0-nightly' and plan['llvm']['numeric_version']=='23.1.1'
    header=Path(plan['llvm']['version_header']['path']);assert sha(header)==plan['llvm']['version_header']['sha256']
    text=header.read_text();assert re.search(r'^#define LLVM_VERSION_STRING "23\.1\.1-rust-1\.100\.0-nightly"$',text,re.M)
    assert [re.search(r'^#define LLVM_VERSION_'+name+r' (\d+)$',text,re.M).group(1) for name in ['MAJOR','MINOR','PATCH']]==['23','1','1']
    seed_headers=[v['members']['include/llvm/Config/llvm-config.h'] for v in plan['seeds'].values() if 'include/llvm/Config/llvm-config.h' in v['members']]
    assert len(seed_headers)==1 and seed_headers[0]['sha256']==sha(header) and seed_headers[0]['existing']==str(header)
    raw=errs[47];assert not outs[47] and raw.endswith(b'\n')
    ld_pid=terminal['commands'][47]['pid'];private=set();images={};version=[];partition=[];cursor=0
    for number,line in enumerate(raw.decode().splitlines(keepends=True),1):
        encoded=line.encode();assert encoded.endswith(b'\n') and b'\r' not in encoded and b'\0' not in encoded
        row=dict(line=number,start=cursor,end=cursor+len(encoded),raw_hex=encoded.hex());cursor=row['end'];line=line[:-1]
        match=re.fullmatch(r'dyld\['+str(ld_pid)+r'\]: (?:<[0-9A-Fa-f-]{36}>\s+)?(/.+)',line)
        move=re.fullmatch(r'dyld\['+str(ld_pid)+r'\]: move loaded to delayed: ([^/\r\n]+)',line)
        if match:
            path=match.group(1);assert str(Path(path))==path and '..' not in Path(path).parts
            images.setdefault(Path(path).name,set()).add(path);row.update(kind='image',path=path)
            if not path.startswith(('/usr/lib/','/System/Library/')):private.add(path)
        elif move:
            paths=images[move.group(1)];assert len(paths)==1 and all(p.startswith(('/usr/lib/','/System/Library/')) for p in paths)
            row.update(kind='delayed-system-image',path=next(iter(paths)))
        else:
            assert not line.startswith('dyld[');version.append(line);row.update(kind='version',text=line)
        partition.append(row)
    assert cursor==len(raw) and b''.join(bytes.fromhex(x['raw_hex']) for x in partition)==raw
    assert sorted(private)==sorted(plan['linker_expected_loaded']) and len(private)==5
    assert version==['@(#)PROGRAM:ld PROJECT:ld-1266.8','BUILD 01:30:17 Apr  9 2026',
      'configured to support archs: armv6 armv7 armv7s arm64 arm64e arm64_32 i386 x86_64 x86_64h armv6m armv7k armv7m armv7em armv8m.main armv8.1m.main',
      'will use ld-classic for: armv6 armv7 armv7s i386 armv6m armv7k armv7m armv7em',
      'LTO support using: LLVM version 21.0.0 (static support for 30, runtime is 30)',
      'TAPI support using: Apple TAPI version 21.0.0 (tapi-2100.0.2.6)']
    for path in private:
        resolved=str(Path(path).resolve(strict=True));assert resolved in freeze['files'] and sha(Path(path))==freeze['files'][resolved]['sha256']
    assert len(outs[16:46])==30 and all(outs[i].startswith(plan['children'][i]['argv'][-1].encode()+b':') for i in range(16,46))
    result=dict(status='retained-failure-audit-passed',checked_at=time.time(),reviewer_owner=str(O),producer_owner=str(X),commands=48,planned_commands=50,
        exact_actual_argv_environment_cwd_raw_parent_time=True,initial_source_git_and_ci_selection=True,final_git_bookends_executed=False,
        actual_linker_lossless_partition=True,actual_private_linker_images=sorted(private),actual_linker_pid=ld_pid,actual_linker_returncode=0,
        linker_stderr_sha256=hashlib.sha256(raw).hexdigest(),linker_version_lines=version,linker_lines=partition,
        llvm_provider_version=plan['llvm']['provider_version'],llvm_numeric_version=plan['llvm']['numeric_version'],llvm_header_bound_to_seed=True,
        terminal_sha256=sha(W/'receipt.json'),outer_sha256=sha(OUTER/'status.json'),metadata_produced=False,
        error=terminal['error'],plan_sha256=sha(H/'plan.json'),freeze_sha256=sha(H/'inputs.json'),observations=observations,
        missing_fast_child_ps_indices=missing_ps,missing_fast_child_cwd_indices=missing_cwd,
        limitation='Fast children can exit before lsof/ps identity capture; declared cwd is from exact Popen receipt, not invented live observation. Final two Git probes and final full guard/metadata did not execute. No compiler was built or probe rerun. Independent raw line partition does not relabel the producer failure as metadata-qualified.')
    path=O/'.work/options-hash-metadata03-failure-independent-actual-verification.json'
    with path.open('x') as output:json.dump(result,output,indent=2,sort_keys=True);output.write('\n')
    print(json.dumps(dict(path=str(path),sha256=sha(path),commands=48,terminal_sha256=result['terminal_sha256'],missing_fast_child_ps_indices=missing_ps,missing_fast_child_cwd_count=len(missing_cwd),linker_lines=len(partition),linker_stderr_sha256=result['linker_stderr_sha256']),indent=2))


if __name__=='__main__':main()
