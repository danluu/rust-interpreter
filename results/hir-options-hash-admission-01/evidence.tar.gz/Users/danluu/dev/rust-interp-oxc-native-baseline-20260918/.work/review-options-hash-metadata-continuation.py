"""Read-only audit of the completed two-probe continuation and preserved prior."""
import hashlib
import json
from pathlib import Path
import time

O=Path('/Users/danluu/dev/rust-interp-oxc-native-baseline-20260918')
X=Path('/Users/danluu/dev/rust-interp-runtime-exporter-20260918')
H=X/'experiments/hir-options-hash/compiler-metadata-continuation-01'
W=X/'.work/hir-options-hash-compiler-metadata-continuation-01'
PRIOR=X/'.work/hir-options-hash-compiler-metadata-03'
OUTER=X/'.work/experiments/hir-options-hash-compiler-metadata-continuation-supervisor-01'


def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    launch=read(H/'launch.json');freeze=read(H/'inputs.json');plan=read(H/'plan.json')
    assert sha(H/'launch.json').startswith('6d8165cc') and sha(H/'inputs.json')==launch['inputs_sha256']
    assert sha(H/'plan.json')==freeze['plan_sha256']==launch['plan_sha256']
    prior_report=read(O/'.work/options-hash-metadata03-failure-independent-actual-verification.json')
    assert sha(O/'.work/options-hash-metadata03-failure-independent-actual-verification.json')=='fc464b0659163a701b3b74edfc8d5d9b414f0abaf9ca9c2cf67ef71d951ced3a'
    prior=read(PRIOR/'receipt.json');terminal=read(W/'receipt.json');outer=read(OUTER/'status.json')
    assert sha(PRIOR/'receipt.json')==terminal['prior_receipt_sha256']==plan['prior_receipt_sha256']==prior_report['terminal_sha256']
    assert prior['status']=='failed' and terminal['status']=='passed' and terminal['compiler_builds']==0
    assert len(terminal['commands'])==len(plan['children'])==2 and terminal['saved_children']==48
    assert plan['children']==plan['original_plan']['children'][48:]
    assert outer['status']=='finished' and outer['returncode']==0 and outer['child_pid']==terminal['pid'] and outer['supervisor_pid']==terminal['parent_pid']
    assert outer['command']==launch['command'][launch['command'].index('--')+1:] and outer['cwd']==str(X)
    assert outer['started_at']<=terminal['started_at']<=terminal['admitted_at']<=terminal['finished_at']<=outer['finished_at']
    previous=terminal['admitted_at'];observations=[]
    for index,(ref,expected) in enumerate(zip(terminal['commands'],plan['children'],strict=True)):
        d=W/'commands'/f'{index:03}';c=read(d/'receipt.json')
        assert ref==dict(path=str(d/'receipt.json'),sha256=sha(d/'receipt.json'),pid=c['pid'],command=expected['argv'])
        assert c['command']==expected['argv'] and c['cwd']==expected['cwd'] and c['environment']==expected['environment']
        assert c['status']=='finished' and c['returncode']==0 and c['returncode'] in expected['expected']
        assert c['supervisor_pid']==terminal['pid'] and c['parent_pid']==terminal['parent_pid']
        assert previous<=c['started_at']<=c['finished_at']<=terminal['finished_at'];previous=c['finished_at']
        for stream in ['stdout','stderr']:
            assert sha(d/stream)==c[stream+'_sha256'] and (d/stream).read_bytes()==expected[stream].encode()
        fields=c['identity']['ps'].split()
        if fields:assert [int(v) for v in fields[:3]]==[c['pid'],terminal['pid'],c['pid']]
        observations.append(dict(index=index,receipt_sha256=sha(d/'receipt.json'),pid=c['pid'],stdout_sha256=c['stdout_sha256'],stderr_sha256=c['stderr_sha256'],started_at=c['started_at'],finished_at=c['finished_at'],ps_recorded=bool(fields),cwd_observed=bool(c['identity']['cwd'])))
    # Each previous command and raw stream retains the already independently audited bytes.
    assert len(prior['commands'])==len(prior_report['observations'])==48
    for index,(ref,proof) in enumerate(zip(prior['commands'],prior_report['observations'],strict=True)):
        d=PRIOR/'commands'/f'{index:03}'
        assert sha(d/'receipt.json')==proof['receipt_sha256']==ref['sha256']
        assert sha(d/'stdout')==proof['stdout_sha256'] and sha(d/'stderr')==proof['stderr_sha256']
    assert not (PRIOR/'metadata.json').exists() and not (PRIOR/'linker-probe.json').exists()
    for root_name,members in plan['prior_membership'].items():
        root=Path(root_name);assert sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file())==members
    metadata=read(W/'metadata.json');original=plan['original_plan']
    assert sha(W/'metadata.json')==terminal['metadata_sha256']
    assert metadata['status']=='metadata-qualified-not-built' and metadata['prior_children']==48 and metadata['continuation_children']==2
    assert metadata['candidate_revision']==terminal['candidate_revision']==original['candidate_revision']=='4de35bdacef0e3cd18a66bc30b5459c19e09b118'
    assert metadata['prior_receipt_sha256']==sha(PRIOR/'receipt.json') and metadata['closures']==original['closures'] and metadata['seeds']==original['seeds']
    assert metadata['source_identity']==read(X/'.work/hir-options-hash-acquisition-01/acquired.json')['source_identity']
    for field in ['platform','build_environment','network_block']:assert metadata[field]==original[field]
    assert metadata['sdk_inventory_sha256']==hashlib.sha256(json.dumps(original['sdk_inventory'],sort_keys=True).encode()).hexdigest()
    assert metadata['llvm_provider_version']==prior_report['llvm_provider_version']=='23.1.1-rust-1.100.0-nightly' and metadata['llvm_version']==prior_report['llvm_numeric_version']=='23.1.1'
    linker=read(W/'linker-probe.json');raw=(PRIOR/'commands/047/stderr').read_bytes()
    assert sha(W/'linker-probe.json')==metadata['linker_probe_sha256']
    assert linker['raw_bytes']==len(raw) and linker['raw_sha256']==prior_report['linker_stderr_sha256']==hashlib.sha256(raw).hexdigest()
    assert linker['private_paths']==prior_report['actual_private_linker_images']==sorted(original['linker_expected_loaded'])
    assert linker['version_text']=='\n'.join(prior_report['linker_version_lines'])+'\n'
    assert len(linker['lines'])==len(prior_report['linker_lines'])==713 and len(linker['version_lines'])==6
    for current,old in zip(linker['lines'],prior_report['linker_lines'],strict=True):
        for key in ['line','start','end','raw_hex','kind']:assert current[key]==old[key]
        assert current['raw'].encode()==bytes.fromhex(current['raw_hex'])
    assert b''.join(bytes.fromhex(row['raw_hex']) for row in linker['lines'])==raw
    assert len(freeze['files'])==166
    for name,row in freeze['files'].items():assert sha(Path(name))==row['sha256']
    controls=read(O/'.work/options-hash-metadata-parser-controls-independent-verification.json');assert controls['status']=='passed' and controls['controls']==9
    result=dict(status='passed',checked_at=time.time(),actual_new_children=2,preserved_children=48,parser_controls=9,
        no_completed_probe_rerun=True,prior_failure_preserved=True,all_166_new_frozen_input_hashes_match=True,
        exact_actual_argv_environment_cwd_raw_parent_time=True,lossless713line_saved_linker_replay=True,
        terminal_sha256=sha(W/'receipt.json'),outer_sha256=sha(OUTER/'status.json'),metadata_sha256=sha(W/'metadata.json'),linker_probe_sha256=sha(W/'linker-probe.json'),
        plan_sha256=sha(H/'plan.json'),freeze_sha256=sha(H/'inputs.json'),prior_audit_sha256=sha(O/'.work/options-hash-metadata03-failure-independent-actual-verification.json'),
        control_audit_sha256=sha(O/'.work/options-hash-metadata-parser-controls-independent-verification.json'),observations=observations,
        limitation='This admits metadata only. Full inherited100344-file/current provider audit belongs to producer/root; no compiler build or application timing is established. Fast child cwd observations are distinguished from declared Popen cwd.')
    p=O/'.work/options-hash-metadata-continuation-independent-actual-verification.json'
    with p.open('x') as output:json.dump(result,output,indent=2,sort_keys=True);output.write('\n')
    print(json.dumps(dict(path=str(p),sha256=sha(p),terminal_sha256=result['terminal_sha256'],metadata_sha256=result['metadata_sha256']),indent=2))


if __name__=='__main__':main()
